"""Independent stream restoration of every new/referenced archive mapping."""
from pathlib import Path
import gzip
import hashlib
import json

def digest(path,restore=False):
    p=Path(path)
    with p.open('rb') as s:compressed=s.read(2)==b'\x1f\x8b'
    h=hashlib.sha256();size=0
    with (gzip.open(p,'rb') if restore and compressed else p.open('rb')) as s:
        while block:=s.read(32768):h.update(block);size+=len(block)
    return size,h.hexdigest()

receipt=json.loads(Path('.tmp/single-owner-learning-archive-seal-receipt.json').read_text());p=Path(receipt['manifest'])
assert digest(p)[1]==receipt['manifestSha256'];m=json.loads(p.read_text());objects=set();mappings=0
for category in ('files','referencedFiles'):
    for item in m[category]:
        stored=p.parent/item['archive'] if category=='files' else Path(item['archive']);expected=(item['bytes'],item['sha256'])
        assert digest(stored,True)==expected and digest(item['source'])==expected
        objects.add(str(stored));mappings+=1
for item in m['prerequisiteManifests']:assert digest(item['path'])[1]==item['sha256']
assert digest(m['candidateSource'])[1]==m['candidateSha256']
assert m['recordsVerification']['status']==m['trainingVerification']['status']=='pass'
assert m['trainingVerification']['selectedWeightsMatchReplayExactly']
assert m['productAudit']['actualProductFileLoadVerified'] and m['productAudit']['roundTripViewSwitchVerified']
assert (m['overviewVisual'],m['individualVisual'])==(288,1963) and not m['targetMet']
result={'status':'pass','manifestSha256':receipt['manifestSha256'],'archiveMappingsRestoredAndLiveSourcesMatched':mappings,
 'distinctStoredObjects':len(objects),'prerequisiteManifestsMatched':len(m['prerequisiteManifests']),
 'candidateSha256':m['candidateSha256'],'overviewVisual':288,'individualVisual':1963,'targetMet':False}
out=Path('.tmp/single-owner-learning-archive-independent-verification.json');assert not out.exists();out.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
