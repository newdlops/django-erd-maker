"""Re-export the verified neural geometry without choosing new coordinates."""
from pathlib import Path
import hashlib
import json
import shutil
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
root=Path('.tmp/visualcross-ml-150-750-20261004/single-owner-learning1')
old=Path('.tmp/visualcross-ml-150-750-20261003/individual-slot-cached1')
winner=Path('.tmp/visualcross-ml-150-750-20261004/single-owner1/individual-frozen1')
candidate=Path('data/erd-poc/candidates/captain-ml-independent-views.layout.json')
assert sha(candidate)=='7aa76f957e12361b8e72add0e12e08d97494d78cc087309d9d15448f237cfcda'
report=json.loads((winner/'report.json').read_text());assert report['accepted']==1 and report['final']['individualVisual']==1963
output=root/'individual-source1963';output.mkdir(exist_ok=False)
files=['nodes.tsv','edges.tsv','positions.tsv','routes.tsv','individual.nodes.tsv','individual.edges.tsv',
       'individual.positions.tsv','individual.routes.tsv','components.tsv','groups.tsv']
for name in files:assert sha(old/name)==report['sourceInputs'][name];shutil.copyfile(old/name,output/name)
for name in ('positions.tsv','individual.positions.tsv'):shutil.copyfile(winner/'learned.tsv.individual',output/name)
for name in ('routes.tsv','individual.routes.tsv'):shutil.copyfile(winner/'learned.tsv.individual.routes.tsv',output/name)
positions={key:(float(x),float(y)) for key,x,y in [line.split('\t') for line in (output/'positions.tsv').read_text().splitlines()]}
layout=json.loads(candidate.read_text());assert len(positions)==1244
for n in layout['individualView']['nodes']:
    p=positions[n['modelId']];assert abs(p[0]-n['position']['x']-n['size']['width']/2)<1e-8 and abs(p[1]-n['position']['y']-n['size']['height']/2)<1e-8
overview=Path('.tmp/visualcross-ml-150-750-20261003/overview-slot-cached1')
binding={'viewSources':{'individual':{'directory':str(output),'inputs':{n:sha(output/n) for n in files}},
    'overview':{'directory':str(overview),'inputs':{n:sha(overview/n) for n in files}}},
    'promotedCandidateSha256':sha(candidate),'geometryChosenByNewCode':False,'winningNeuralReportSha256':sha(winner/'report.json'),
    'individualVisual':1963,'overviewVisual':289}
(root/'source-binding.json').write_text(json.dumps(binding,indent=2)+'\n');print(json.dumps({'sourcePrepared':str(output),'newGeometryProposals':0}))
