"""Bind the verified neural winner to product conversion, without geometry edits."""
from pathlib import Path
import hashlib
import json
import shutil

root=Path('.tmp/visualcross-ml-150-750-20261004/single-owner-learning1')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
for name in ('records','training'):
    assert json.loads((root/f'verification/{name}.audit.json').read_text())['status']=='pass'
stage=root/'overview-trained-current1';r=json.loads((stage/'report.json').read_text())
assert (r['initialVisual'],r['final']['visual'])==(289,288)
assert r['trainedOnSingleOwnerMoves'] and r['nativeSearchCalls']==r['coordinateRepairs']==0
out=root/'overview-product1';out.mkdir(exist_ok=False)
source=Path(r['sourceDirectory'])
for name in r['sourceInputs']:
    assert sha(source/name)==r['sourceInputs'][name]
    shutil.copyfile(source/name,out/name)
shutil.copyfile(source/'export.json',out/'export.json')
for name in ('learned.tsv','learned.tsv.individual','learned.tsv.routes.tsv','learned.tsv.individual.routes.tsv','learned.tsv.stats.json'):
    shutil.copyfile(stage/name,out/name)
policy={'modelKind':r['checkpointTraining']['kind'],'featureSchema':r['featureSchema'],'actionSchema':r['actionSchema'],
        'checkpoint':r['checkpoint'],'checkpointSha256':r['checkpointSha256'],'untrainedControl':False,
        'criticTrainingUpdatesExecuted':r['checkpointTraining']['newTrainingUpdatesExecuted'],
        'selectedCheckpointUpdates':r['checkpointTraining']['selectedCheckpointUpdates'],
        'newTrainingUpdatesDuringInference':0,'overviewOnly':True,'final':r['final'],
        'experimentReport':str(stage/'report.json'),'experimentReportSha256':sha(stage/'report.json'),
        'modelSelectedAllGeometry':True,'coordinateRepairs':0,'nativeSearchCalls':0,'browserVerified':False}
(out/'learned.tsv.policy.json').write_text(json.dumps(policy,indent=2)+'\n')
helper=Path('scripts/erd-poc/apply_learned_single_owner_components.cjs')
original=Path('scripts/erd-poc/apply_learned_components.cjs');text=original.read_text()
old="actualAlgorithm:policy.modelKind==='neural-anchor-pair-walk'?"
new="actualAlgorithm:policy.modelKind==='single-owner-partial-cycle-critic-v1'?'NeuralSingleOwnerCycleCritic(model-ranked one-card translations, direct boundary ports)':policy.modelKind==='neural-anchor-pair-walk'?"
assert text.count(old)==1 and not helper.exists()
helper.write_text('// Versioned adapter: describe the verified single-owner critic accurately.\n'+text.replace(old,new))
binding={'nativeStage':str(stage),'nativeStageReportSha256':sha(stage/'report.json'),'outputDirectory':str(out),
         'sourceLayout':json.loads((out/'export.json').read_text())['sourceFile'],
         'originalApplyHelperSha256':sha(original),'versionedApplyHelper':str(helper),'versionedApplyHelperSha256':sha(helper),
         'helperChanges':'only the descriptive algorithm string for the new critic kind',
         'geometryCopiedExactlyFromVerifiedNeuralStage':True,'positionsSelectedOrRepaired':False}
(out/'preparation.json').write_text(json.dumps(binding,indent=2)+'\n');print(json.dumps(binding),flush=True)
