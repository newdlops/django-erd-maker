"""Stream-seal verified single-owner learning and retain its bounded failures."""
import ast
import gzip
import hashlib
import json
import re
import shutil
from pathlib import Path

ROOT=Path('.tmp/visualcross-ml-150-750-20261004/single-owner-learning1')
ARCHIVE=Path('data/erd-poc/experiments/independent-views-single-owner-learning-20261004')
STABLE=Path('data/erd-poc/candidates/captain-ml-independent-views.layout.json')
OLD='7aa76f957e12361b8e72add0e12e08d97494d78cc087309d9d15448f237cfcda'

def stream_hash(s):
    h=hashlib.sha256();size=0
    while block:=s.read(65536):h.update(block);size+=len(block)
    return size,h.hexdigest()
def digest(p):
    with Path(p).open('rb') as s:return stream_hash(s)[1]
def restore(p):
    with Path(p).open('rb') as s:compressed=s.read(2)==b'\x1f\x8b'
    with (gzip.open(p,'rb') if compressed else Path(p).open('rb')) as s:return stream_hash(s)

assert not ARCHIVE.exists() and digest(STABLE)==OLD
audit=json.loads((ROOT/'combined-best1/audit.json').read_text())
assert (audit['overviewVisual'],audit['individualVisual'])==(288,1963)
assert (audit['models'],audit['canonicalRelationships'])==(1244,1727)
assert (audit['overviewTarget'],audit['individualTarget'])==(150,750) and not audit['thresholdsMet']
for k in ('actualProductFileLoadVerified','completeIndividualGeometryPreserved','browserRouteFunctionParity','roundTripViewSwitchVerified'):assert audit[k]
candidate=ROOT/'combined-best1/candidate.layout.json';new=digest(candidate);assert new==audit['candidateSha256']
records=json.loads((ROOT/'verification/records.audit.json').read_text());training=json.loads((ROOT/'verification/training.audit.json').read_text())
assert records['status']==training['status']=='pass' and records['readOnlyFullNativeMeasurements']==4162
assert records['syntheticActionsAllFullScored']==records['captainActionsAllReconstructed']==4096
assert training['optimizerUpdatesReplayedExactly']==20512 and training['selectedCheckpointUpdatesReplayed']==13461
trained=json.loads((ROOT/'training2/training.json').read_text())
assert digest(ROOT/'training2/model.npz')==trained['checkpointSha256']==training['checkpointSha256']
stages=[json.loads(p.read_text()) for p in sorted((ROOT/'synthetic2').glob('graph-*/*/report.json'))]
assert len(stages)==64 and sum(r['attempts'] for r in stages)==4096 and sum(r['improvingLegalActions'] for r in stages)==509
tests=[json.loads(p.read_text()) for p in ROOT.glob('*-current1/report.json')];assert len(tests)==4 and sum(r['attempts'] for r in tests)==4096
improving=set()
for p in ROOT.glob('*-current1/actions.jsonl'):
    report=json.loads((p.parent/'report.json').read_text())
    for row in map(json.loads,p.read_text().splitlines()):
        if row['result']['legal'] and row['result']['visual']<report['initialVisual']:improving.add((report['view'],row['wireSha256']))
snapshot=ROOT/'promotion-before';snapshot.mkdir(exist_ok=False)
for suffix in ('layout.json','audit.json','provenance.json'):
    p=STABLE.with_name('captain-ml-independent-views.'+suffix);shutil.copyfile(p,snapshot/p.name)
resources={'guardLimitMiB':128,'limitRaised':False,'numericalJobsSerialized':True,'mathThreads':1,'niceAdjustment':10,'sampledProcessGroupRss':True,'hardCpuPercentageQuota':False,'logs':[]}
for p in sorted(ROOT.glob('*.guard.log')):
    txt=p.read_text();peaks=re.findall(r'memory guard: peak=([0-9.]+) MiB limit=([0-9.]+) MiB',txt);stops=re.findall(r'memory limit exceeded: rss=([0-9.]+) MiB limit=([0-9.]+) MiB',txt)
    assert all(float(limit)==128 for _,limit in peaks+stops)
    resources['logs'].append({'path':str(p),'peakMiB':float(peaks[-1][0]) if peaks else None,'guardStoppedAtMiB':float(stops[-1][0]) if stops else None})
(ROOT/'resources.json').write_text(json.dumps(resources,indent=2)+'\n')
diagnosis={'overviewVisual':288,'individualVisual':1963,'targetOverview':150,'targetIndividual':750,'targetMet':False,
 'completedSyntheticNeuralProposals':4096,'completedCaptainNeuralProposals':4096,'completedNeuralProposals':8192,
 'failedCollectorUnloggedNativeTryBeforeFailure':1,'failedFirstProposalReplayedByCorrectedCollector':True,
 'allHistoryWireUniquenessClaimed':False,'syntheticImprovingLegalActions':509,'syntheticGraphsWithImprovingActions':32,
 'distinctCaptainImprovingWireHashes':len(improving),'captainWinningGeometryIdenticalAcrossCritics':True,
 'learningCausedCaptainGainEstablished':False,'captainIndividualImprovedByThisContinuation':False,
 'trainedSingleOwnerCheckpointSha256':trained['checkpointSha256'],'newTrainingUpdatesExecuted':20512,'selectedCheckpointUpdates':13461,
 'trainingRows':18416,'singleOwnerTrainingRows':4687,'improvingTrainingExamplesByKind':training['improvingTrainingExamplesByKind'],
 'newSingleOwnerImprovingTrainingExamples':365,'trainingValidationMeanImproved':True,'originalCaptainAndNegativeValidationRegressed':True,
 'trainingInterruptedAt128MiBGuard':True,'completedInterruptedDatasetReused':True,'failedTrainingOptimizerUpdatesNotEstablished':True,
 'optimizerTraceIndependentlyReplayed':20512,'independentReadOnlyFullNativeMeasurements':4162,
 'allSyntheticNativeScoresIndependentlyRecomputed':True,'allCaptainNativeScoresIndependentlyRecomputed':False,
 'modelSelectedAllGeometry':True,'nativeCoordinateSearchOrRepairAdded':False,'browserVerified':False,
 'globalGeometryFloorEstablished':False,
 'nextDirection':'Keep the verified 288/1963 geometry and train from new actual Captain outcomes with preserved holdouts; consider fresh cumulative model trajectories without repeating closed unchanged schedules'}
(ROOT/'diagnosis.json').write_text(json.dumps(diagnosis,indent=2)+'\n')
entries={str(p):Path('run')/p.relative_to(ROOT) for p in ROOT.rglob('*') if p.is_file()}
scripts=Path('scripts/erd-poc');pending=['synthetic_single_owner_curriculum.py','synthetic_single_owner_curriculum_v2.py','train_single_owner_cycle_model.py','train_single_owner_cycle_model_v2.py','run_single_owner_cycle_policy_v2.py','run_memory_bounded.py']
for name in ('verify_single_owner_learning.py','prepare_single_owner_learning_sources.py','run_single_owner_learning_evaluations.py','prepare_single_owner_overview_product.py','seal_single_owner_learning.py','verify_single_owner_learning_archive.py','promote_single_owner_learning.py'):
    p=Path('.tmp')/name;assert p.is_file();entries[str(p)]=Path('tools')/name
    for node in ast.walk(ast.parse(p.read_text())):
        if isinstance(node,ast.ImportFrom) and node.module and (scripts/(node.module+'.py')).is_file():pending.append(node.module+'.py')
seen=set()
while pending:
    name=pending.pop()
    if name in seen:continue
    seen.add(name);p=scripts/name;entries[str(p)]=Path('code')/name
    for node in ast.walk(ast.parse(p.read_text())):
        modules=[node.module] if isinstance(node,ast.ImportFrom) else [i.name for i in node.names] if isinstance(node,ast.Import) else []
        for module in modules:
            if module and (scripts/(module+'.py')).is_file():pending.append(module+'.py')
for name in ('apply_learned_components.cjs','apply_learned_single_owner_components.cjs','audit_leaf_card_connections.cjs','compose_independent_views_memory_bounded.cjs'):
    p=scripts/name;entries[str(p)]=Path('code')/name
deps={trained['parent'],trained['parentDatasetPath'],'data/erd-poc/recovered/captain-2026-09-15-payload.json',audit['individualSource'],audit['overviewSource']}
individual=Path(audit['individualSource']).parent
deps.update(str(individual/n) for n in ('individual.audit.json','workflow.audit.json'))
for stage in stages+tests:
    deps.update((stage['checkpoint'],stage['environment']));deps.update(str(Path(stage['sourceDirectory'])/n) for n in stage['sourceInputs'])
for ref in trained['sourceStages']:deps.update((ref['path'],str(Path(ref['path']).parent/'labels.npz')))
original=Path('.tmp/visualcross-ml-150-750-20261003/overview-bounded-trained2')
deps.update(str(original/n) for n in ('candidate.layout.json','product.audit.json'))
native=Path('.tmp/visualcross-ml-150-750-20261003/pair-neutral-walk1')
deps.add(str(native/'build-inputs.json'));deps.update(str(p) for p in (native/'build-inputs').iterdir() if p.is_file())
bindings=json.loads((ROOT/'combined-best1/product-code-bindings.json').read_text())
for item in bindings['loadedCommonJsModules']:
    p=Path(item['path']);assert digest(p)==item['sha256'];deps.add(str(p))
    if p.parts[0]=='out':
        ts=Path('src').joinpath(*p.parts[1:]).with_suffix('.ts')
        if ts.is_file():deps.add(str(ts))
for source in deps:
    if source not in entries:entries[source]=Path('dependencies')/digest(source)/Path(source).name
parents={
 'data/erd-poc/experiments/independent-views-single-owner-20261004/manifest.json':'8c24abd16db00344e05fcce1441a00b2c1b002db723185c3f36e93c4b3d52f15',
 'data/erd-poc/experiments/independent-views-owner-amplitudes-20261004-v2/manifest.json':'6b31d46cd53ab370048e36ba43ed04bdc423e3507adddd42423dca0426a565a7'}
prior={};expected=dict(parents)
for name,value in parents.items():
    p=Path(name);assert digest(p)==value;old=json.loads(p.read_text())
    for item in old.get('prerequisiteManifests',[]):expected[item['path']]=item['sha256']
    for item in old['files']:prior.setdefault(item['sha256'],(p.parent/item['archive'],item['bytes'],name))
    for item in old['referencedFiles']:prior.setdefault(item['sha256'],(Path(item['archive']),item['bytes'],item['prerequisiteManifest']))
ARCHIVE.mkdir(parents=True);files=[];references=[];reused={};checked=set();required=set(parents)
for source,relative in sorted(entries.items()):
    p=Path(source);size=p.stat().st_size;value=digest(p)
    if value in prior:
        stored,n,prerequisite=prior[value];assert n==size
        if value not in checked:assert restore(stored)==(size,value);checked.add(value)
        required.add(prerequisite);references.append({'source':source,'archive':str(stored),'bytes':size,'sha256':value,'prerequisiteManifest':prerequisite,'restoreHashVerified':True});continue
    if value in reused:stored,packed=reused[value]
    else:
        stored=Path(str(relative)+'.gz');target=ARCHIVE/stored;target.parent.mkdir(parents=True,exist_ok=True)
        with target.open('xb') as dest,gzip.GzipFile(filename='',mode='wb',compresslevel=1,mtime=0,fileobj=dest) as zipped,p.open('rb') as original:
            while block:=original.read(65536):zipped.write(block)
        assert restore(target)==(size,value);packed=target.stat().st_size;reused[value]=(stored,packed)
    files.append({'source':source,'archive':str(stored),'bytes':size,'sha256':value,'compressedBytes':packed})
assert digest(STABLE)==OLD
prerequisites=[]
for name in sorted(required):
    value=digest(name);assert value==expected[name];prerequisites.append({'path':name,'sha256':value})
manifest={'scope':'Single-owner outcome learning, matched Captain controls, exact optimizer replay, product promotion and bounded failures',
 'previousCandidateSha256':OLD,'candidateSha256':new,'candidateSource':str(candidate),'previousBestSnapshot':str(snapshot),
 'overviewVisual':288,'individualVisual':1963,'targetOverview':150,'targetIndividual':750,'targetMet':False,
 'fullModelsPerView':1244,'fullRelationshipsPerView':1727,'sourceSizesAndCanonicalRelationshipsUnchanged':True,
 'modelSelectedAllGeometry':True,'nativeSearchOrCoordinateRepairs':0,'browserVerified':False,
 'completedNeuralProposals':8192,'newTrainingUpdatesExecuted':20512,'selectedCheckpointUpdates':13461,
 'trainedCheckpointSha256':trained['checkpointSha256'],'learningCausedCaptainGainEstablished':False,
 'productAudit':audit,'recordsVerification':records,'trainingVerification':training,'diagnosis':diagnosis,'resources':resources,
 'prerequisiteManifests':prerequisites,'files':files,'referencedFiles':references,'newPhysicalCompressedFiles':len(reused),
 'newPhysicalCompressedBytes':sum(v[1] for v in reused.values()),'logicalFiles':len(files),'referencedLogicalFiles':len(references),
 'allCompressedAndReferencedBytesRestoreHashVerified':True,'sourcesUnchangedAtSeal':True}
p=ARCHIVE/'manifest.json';p.write_text(json.dumps(manifest,indent=2)+'\n')
result={'manifest':str(p),'manifestSha256':digest(p),'candidateSha256':new,'newPhysicalCompressedFiles':len(reused),'newPhysicalCompressedBytes':manifest['newPhysicalCompressedBytes'],'newMappings':len(files),'referencedMappings':len(references)}
receipt=Path('.tmp/single-owner-learning-archive-seal-receipt.json');assert not receipt.exists();receipt.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
