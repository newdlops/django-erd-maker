"""Serialize matched frozen/learned NN evaluations on the current best inputs."""
from pathlib import Path
import json
import subprocess
import sys

root=Path('.tmp/visualcross-ml-150-750-20261004/single-owner-learning1')
binding=root/'source-binding.json';sources=json.loads(binding.read_text())['viewSources']
jobs=[]
for view in ('individual','overview'):
    for name,checkpoint in [('frozen-current1',Path('.tmp/visualcross-ml-150-750-20261004/owner-amplitude-cycles1/training2/model.npz')),
                            ('trained-current1',root/'training2/model.npz')]:
        out=root/(view+'-'+name)
        command=[sys.executable,'scripts/erd-poc/run_single_owner_cycle_policy_v2.py',
            '--directory',sources[view]['directory'],'--source-binding',str(binding),'--checkpoint',str(checkpoint),
            '--environment','.tmp/visualcross-ml-150-750-20261003/pair-neutral-walk1/environment',
            '--out',str(out),'--view',view,'--seed','96301','--triples','1024','--budget','1024']
        subprocess.run(command,check=True)
        report=json.loads((out/'report.json').read_text());assert report['attempts']==1024
        jobs.append({'stage':str(out),'view':view,'checkpoint':str(checkpoint),'initial':report['initialVisual'],
            'final':report['final']['visual'],'accepted':report['accepted'],'reasons':report['reasons']})
(root/'captain-evaluations.json').write_text(json.dumps({'jobs':jobs,'seed':96301,'matchedSourceNodesVocabularyAndNoise':True},indent=2)+'\n')
