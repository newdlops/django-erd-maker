"""Promote the independently restored 288/1963 pair with scoped lineage."""
from pathlib import Path
import hashlib
import json
import os

sha=lambda data:hashlib.sha256(data).hexdigest()
root=Path('.tmp/visualcross-ml-150-750-20261004/single-owner-learning1')
receipt=json.loads(Path('.tmp/single-owner-learning-archive-seal-receipt.json').read_text())
verified=json.loads(Path('.tmp/single-owner-learning-archive-independent-verification.json').read_text())
p=Path(receipt['manifest']);assert sha(p.read_bytes())==receipt['manifestSha256']==verified['manifestSha256']
m=json.loads(p.read_text());assert verified['status']=='pass'
base=Path('data/erd-poc/candidates/captain-ml-independent-views')
paths={k:Path(str(base)+'.'+k+'.json') for k in ('layout','audit','provenance')}
for path in paths.values():assert path.read_bytes()==(root/'promotion-before'/path.name).read_bytes()
assert sha(paths['layout'].read_bytes())==m['previousCandidateSha256']
candidate=Path(m['candidateSource']).read_bytes();assert sha(candidate)==m['candidateSha256']
audit=json.loads((root/'combined-best1/audit.json').read_text());assert audit==m['productAudit']
assert (audit['overviewVisual'],audit['individualVisual'])==(288,1963)
assert not audit['thresholdsMet'] and audit['models']==1244 and audit['canonicalRelationships']==1727
for k in ('actualProductFileLoadVerified','completeIndividualGeometryPreserved','browserRouteFunctionParity','roundTripViewSwitchVerified'):assert audit[k]
before=json.loads(paths['layout'].read_bytes());after=json.loads(candidate)
assert before['individualView']==after['individualView']
old_nodes={n['modelId']:n for n in before['nodes']};new_nodes={n['modelId']:n for n in after['nodes']}
assert old_nodes.keys()==new_nodes.keys() and len(new_nodes)==1244
changed=[key for key,n in new_nodes.items() if n['position']!=old_nodes[key]['position']]
assert len(changed)==1 and all(n['size']==old_nodes[key]['size'] for key,n in new_nodes.items())
assert len(after['routedEdges'])==1727 and {e['edgeId'] for e in after['routedEdges']}=={e['edgeId'] for e in before['routedEdges']}
assert before['engineMetadata']['leafBundles']==after['engineMetadata']['leafBundles']
del before,after,old_nodes,new_nodes
previous=json.loads(paths['provenance'].read_text());assert previous['candidateSha256']==m['previousCandidateSha256']
training=json.loads((root/'training2/training.json').read_text());overview=json.loads((root/'overview-product1/product.audit.json').read_text())
peak=next(x['peakMiB'] for x in m['resources']['logs'] if x['path'].endswith('/combined-product.guard.log'))
audit.update(candidate=str(paths['layout']),promoted=True,viewSpecificGeometry=True,browserVerified=False,
             overviewSpacingViolations=overview['spacingViolations'],overviewBboxArea=overview['bboxB']*1e9,
             dimensionsPreserved=True,canonicalRelationshipsPreserved=True,nativeHardConditions=0)
history=list(previous.get('subsequentResearchArchives',[]));history.append({
 'archiveManifest':str(p),'archiveManifestSha256':receipt['manifestSha256'],'promotedCandidateChanged':True,
 'previousCandidateSha256':m['previousCandidateSha256'],'candidateSha256':m['candidateSha256'],
 'overviewVisual':288,'individualVisual':1963,'newNetworkTrainingUpdates':20512,'selectedCheckpointUpdates':13461,
 'nativeModelActions':8192,'syntheticActions':4096,'matchedCaptainActions':4096,'failedUnloggedCollectorTry':1,
 'readOnlyFullScoringComparisons':4162,'optimizerUpdatesIndependentlyReplayed':20512,
 'learningCausedCaptainGainEstablished':False,'targetMet':False,'browserVerified':False})
provenance={**previous,
 'candidateSha256':m['candidateSha256'],'previousCandidateSha256':m['previousCandidateSha256'],
 'overviewVisual':288,'individualVisual':1963,'archiveManifest':str(p),'archiveManifestSha256':receipt['manifestSha256'],
 'priorArchives':list(dict.fromkeys(previous['priorArchives']+[Path(previous['archiveManifest']).parent.name])),
 'subsequentResearchArchives':history,'stagesInLatestArchive':68,'sourceStagesUsedForLatestTraining':66,
 'additionalActionsArchived':8192,'modelsTrainedInLatestArchive':1,'coordinatedNetworkBatchesArchived':0,
 'trainingRewardMeasurementsArchived':6144,'syntheticRewardMeasurementsArchived':4096,
 'actualCaptainRewardMeasurementsUsedForTraining':1615,'newCaptainInferenceMeasurementsNotUsedForTraining':4096,
 'trainingMeasurementCountsScope':'latest fine-tuning: 2048 previously collected Captain single-owner rows (1615 training, 433 validation) and 4096 new synthetic rows (3072 training, 1024 validation); the 4096 matched Captain inference outcomes are excluded from this training',
 'latestSingleOwnerDataset':{'captainOutcomeRows':2048,'captainTrainingRows':1615,'captainValidationRows':433,
   'syntheticOutcomeRows':4096,'syntheticTrainingRows':3072,'syntheticValidationRows':1024,
   'parentReplayRows':17408,'totalRows':23552,'trainingRows':18416,'singleOwnerTrainingRows':4687},
 'newNetworkTrainingUpdatesInLatestContinuation':20512,'selectedCheckpointUpdatesInLatestContinuation':13461,
 'latestFrozenCriticCheckpointSha256':m['trainedCheckpointSha256'],'latestCriticTrainedOnSingleOwnerMoves':True,
 'matchedFrozenParentCheckpointSha256':training['parentSha256'],
 'overviewSource':audit['overviewSource'],'individualSource':audit['individualSource'],
 'neuralTranslationDecoder':'view-specific: trained single-owner critic selects the overview translation; the previously verified frozen-parent individual geometry is preserved; Native only decodes direct perimeter routes and accepts/rejects',
 'neuralTranslationSchema':training['schema'],'overviewNeuralTranslationSchema':training['schema'],
 'overviewCriticTraining':{'checkpointSha256':m['trainedCheckpointSha256'],'kind':training['kind'],
   'newTrainingUpdatesExecuted':20512,'selectedCheckpointUpdates':13461,'initialValidationParts':training['initialValidationParts'],
   'selectedValidationParts':training['selectedValidationParts'],'learningCausedCaptainGainEstablished':False},
 'validationEvidence':str(root/'verification/records.audit.json'),'trainingValidationEvidence':str(root/'verification/training.audit.json'),
 'productAuditPeakMiB':peak,'resourceLimitMiB':128,'resourceLimitRaised':False,'nativeCoordinateSearchOrRepairAdded':False,
 'outwardBoundaryContractVerified':True,'causalAblationVerified':False,'learningCausedCaptainGainEstablished':False,
 'overviewTarget':150,'individualTarget':750,'targetMet':False,'browserVerified':False,
 'latestResearchArchiveIndependentVerification':'.tmp/single-owner-learning-archive-independent-verification.json'}
for k in ('metadataReconciliationRecord','metadataReconciliationRecordSha256'):
    if k in provenance:provenance['previousPromotion'+k[0].upper()+k[1:]]=provenance.pop(k)
pending=[]
for key,value in (('layout',candidate),('audit',(json.dumps(audit,indent=2)+'\n').encode()),('provenance',(json.dumps(provenance,indent=2)+'\n').encode())):
    path=paths[key];tmp=path.with_name(path.name+'.promoting')
    with tmp.open('xb') as s:s.write(value)
    pending.append((tmp,path))
for tmp,path in pending:os.replace(tmp,path)
assert sha(paths['layout'].read_bytes())==m['candidateSha256']
for key in ('audit','provenance'):assert json.loads(paths[key].read_text())['candidateSha256']==m['candidateSha256']
result={'promoted':True,'overviewVisual':288,'individualVisual':1963,'candidateSha256':m['candidateSha256'],
 'previousCandidatePreserved':True,'individualViewExactlyPreserved':True,'overviewMovedModels':changed,
 'sizesAnd1727RelationshipsPreserved':True,'archiveManifestSha256':receipt['manifestSha256'],'targetMet':False,'browserVerified':False}
out=Path('.tmp/single-owner-learning-promotion-receipt.json');assert not out.exists();out.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
