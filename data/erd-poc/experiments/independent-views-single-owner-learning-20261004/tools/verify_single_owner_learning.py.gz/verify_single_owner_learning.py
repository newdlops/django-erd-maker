"""Read-only replay of closed single-owner collection, learning and controls."""
import argparse
import gc
import hashlib
import json
import sys
import zipfile
from collections import Counter
from pathlib import Path
import numpy as np

sys.path.insert(0, str(Path('scripts/erd-poc').resolve()))
from directed_cycle_model import KEYS
from learned_global_replay import INPUT_FILES
from mixed_size_synthetic_fixture import fixture
from owner_amplitude_cycle_model import action_features
from run_anchor_pair_policy import Native, wire
from run_anchor_pair_walk import WalkDecoder, verify_saved
from run_fraction_conditioned_policy import sample_order
from run_single_owner_cycle_policy_v2 import hashes as captain_hashes, prepare
from single_owner_cycle_model import AMPLITUDES, action, allowed_indices, load, rank, schedule, vocabulary
from synthetic_cycle_curriculum import flatten_fixture
from synthetic_single_owner_curriculum_v2 import code_hashes as synthetic_hashes
from train_anchor_pair_outcomes import outcome_target
from train_single_owner_cycle_model_v2 import hashes as training_hashes

ROOT=Path('.tmp/visualcross-ml-150-750-20261004/single-owner-learning1')
OUT=ROOT/'verification'
METRICS=('legal','reason','visual','individualVisual','spacing','hard','individualHard')

def digest(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        while block:=f.read(65536): h.update(block)
    return h.hexdigest()

def equal(a,b):
    return np.array_equal(a,b,equal_nan=True) if np.issubdtype(a.dtype,np.inexact) else np.array_equal(a,b)

def records():
    checks=[];synthetic_total=full_samples=0;winning=[]
    # Regenerate fixture inputs without calling a scorer or choosing coordinates.
    for graph in range(128,160):
        source=OUT/f'fixture-control-{graph}'/'input';fixture(source,93101+graph)
        flat=source.parent/'input-individual';flatten_fixture(source,flat)
        for a,b in ((source,ROOT/f'synthetic2/graph-{graph}/input'),(flat,ROOT/f'synthetic2/graph-{graph}/input-individual')):
            for name in INPUT_FILES: assert digest(a/name)==digest(b/name)
    stages=[(ROOT/f'synthetic2/graph-{g}/{v}',True) for g in range(128,160) for v in ('overview','individual')]
    stages += [(ROOT/(v+'-'+m+'-current1'),False) for v in ('individual','overview') for m in ('frozen','trained')]
    controls={}
    for stage,synthetic in stages:
        r=json.loads((stage/'report.json').read_text());source=Path(r['sourceDirectory']);view=r['view']
        for n,s in r['sourceInputs'].items():assert digest(source/n)==s
        for k in ('checkpoint','environment'):assert digest(r[k])==r[k+'Sha256']
        for n in ('observations','labels'):assert digest(stage/(n+'.npz'))==r[n+'Sha256']
        assert digest(stage/'actions.jsonl')==r['actionsSha256']
        assert r['codeSha256']==(synthetic_hashes() if synthetic else captain_hashes())
        if not synthetic:
            assert digest(r['sourceBinding'])==r['sourceBindingSha256']
            binding=json.loads(Path(r['sourceBinding']).read_text())['viewSources'][view]
            assert (str(source),r['sourceInputs'])==(binding['directory'],binding['inputs'])
        decoder=WalkDecoder(source);model,_=load(Path(r['checkpoint']))
        with np.load(stage/'observations.npz',allow_pickle=False) as z:
            nodes=z['node_features'].copy()
            if synthetic:
                cycles,support=vocabulary(decoder,nodes,r['vocabularySeed'],128)
                scores,fh,error=rank(model,decoder,nodes,cycles,view=='overview')
                allowed=allowed_indices(nodes,cycles)
                order,noise,policy=sample_order(scores.ravel()[allowed,None],r['samplingSeed'],4.)
                chosen,dedup=schedule(decoder,cycles,allowed[order],64)
            else:
                cycles,support,scores,fh,error,allowed,noise,policy,chosen,dedup=prepare(model,decoder,nodes,view,r['seed'],r['triples'],r['budget'])
                common={n:digest(stage/'observations.npz') for n in ()}
                # Both checkpoints must receive identical features, vocabulary,
                # source gates and Gumbel samples; only their scores/order differ.
                for name,value in [('nodes',nodes),('cycles',cycles),('allowed',allowed),('noise',noise)]:
                    h=hashlib.sha256(value.tobytes()).hexdigest()
                    key=(view,name)
                    if key in controls:assert controls[key]==h
                    else:controls[key]=h
            for name,value in [('cycles',cycles),('amplitudes',AMPLITUDES),('scores',scores),('allowed_indices',allowed),('gumbel',noise),('proposal_schedule',chosen)]:assert np.array_equal(z[name],value),name
        assert (support,fh,error,policy,dedup)==tuple(r[k] for k in ('support','featureChunkHashes','scaleFeatureMaxError','policy','deduplication'))
        features,_=action_features(nodes,decoder,cycles[chosen[:,0]],AMPLITUDES[chosen[:,1]],view=='overview')
        rows=[json.loads(line) for line in (stage/'actions.jsonl').read_text().splitlines()]
        lookup={int(v):i for i,v in enumerate(allowed)};best=None;best_visual=r['initialVisual'];best_ind=r['initialIndividualVisual']
        wires=set();reasons=Counter();measured=0
        control=OUT/(str(stage.parent.name)+'-'+stage.name+'-full.tsv')
        native=Native(Path(r['environment']),source,control,view=='overview',False)
        try:
            assert np.array_equal(nodes,np.array([n['features'] for n in native.initial['nodes']]))
            assert (native.initial['visual'],native.initial['individualVisual'])==(best_visual,best_ind)
            with np.load(stage/'labels.npz',allow_pickle=False) as labels:
                for i,row in enumerate(rows):
                    ci,ai=map(int,chosen[i]);cycle=cycles[ci];amps=AMPLITUDES[ai]
                    assert row['rank']==i and (row['cycleIndex'],row['amplitudeIndex'])==(ci,ai)
                    assert row['cycle']==cycle.tolist() and row['amplitudes']==amps.tolist()
                    ni=lookup[int(np.ravel_multi_index((ci,ai),scores.shape))]
                    assert row['score']==float(scores[ci,ai]) and row['gumbel']==float(noise[ni,0])
                    proposed=action(decoder,cycle,amps);command=wire(proposed)
                    h=hashlib.sha256(command.encode()).hexdigest();assert h==row['wireSha256'] and h not in wires;wires.add(h)
                    assert np.count_nonzero(np.any(proposed[:len(decoder.positions)]!=0,axis=1))==1
                    result=row['result'];gain=float(r['initialVisual']-result['visual']) if result['legal'] else np.nan
                    assert np.array_equal(labels['x'][i],features[i].astype(np.float32))
                    assert labels['y'][i]==outcome_target(result,r['initialVisual'])
                    assert (np.isnan(gain) and np.isnan(labels['actual_gain'][i])) or gain==labels['actual_gain'][i]
                    assert np.array_equal(labels['cycles'][i],cycle) and np.array_equal(labels['amplitudes'][i],amps)
                    accepted=result['legal'] and result['visual']<best_visual and (view=='overview' or result['individualVisual']<=best_ind)
                    assert accepted==result['accepted'] and not result['measureOnly']
                    reasons[result['reason']]+=1
                    if synthetic or i<16 or accepted:
                        actual=native.request(wire(proposed,'MEASURE'))
                        assert all(actual[k]==result[k] for k in METRICS),(str(stage),i,actual,result)
                        measured+=1
                    if accepted:
                        best=proposed;best_visual=result['visual'];best_ind=result['individualVisual']
                        if not synthetic:winning.append({'stage':str(stage),'rank':i,'cycle':cycle.tolist(),'amplitudes':amps.tolist(),'wireSha256':h,'visual':best_visual})
            assert native.request('SAVE')['saved']
            stats=json.loads(Path(str(control)+'.stats.json').read_text())
            assert stats['policyActionsEvaluated']==stats['acceptedActions']==0
            assert (stats['visual'],stats['individualVisual'])==(r['initialVisual'],r['initialIndividualVisual'])
        finally:native.close()
        assert len(rows)==r['attempts'] and dict(reasons)==r['reasons'] and best_visual==r['final']['visual']
        assert sum(x['result']['accepted'] for x in rows)==r['accepted']
        assert sum(x['result']['legal'] and x['result']['visual']<r['initialVisual'] for x in rows)==r['improvingLegalActions']
        if best is not None and not synthetic:assert np.array_equal(best,np.load(stage/'best-action.npy',allow_pickle=False))
        verify_saved(source,stage,decoder,best)
        check={'stage':str(stage),'actionsAndLabelsReconstructed':len(rows),'allNeuralScoresAndSchedulesReplayed':True,'independentFullMeasurements':measured,'allNativeActionScoresIndependentlyRecomputed':synthetic,'finalVisual':best_visual}
        checks.append(check);full_samples+=measured
        if synthetic:synthetic_total+=len(rows)
        print(json.dumps(check),flush=True)
        del model,decoder,features,nodes,scores,rows;gc.collect()
    assert synthetic_total==4096 and len(winning)==2 and len({x['wireSha256'] for x in winning})==1
    result={'status':'pass','syntheticActionsAllFullScored':4096,'captainActionsAllReconstructed':4096,'readOnlyFullNativeMeasurements':full_samples,'captainNativeScoresFullyRecomputed':False,'all32FixtureInputsRegeneratedWithoutScoring':True,'matchedCaptainInputsAndGumbelVerified':True,'winningActions':winning,'winningGeometryIdenticalAcrossCritics':True,'learningCausedCaptainGainEstablished':False,'newNativeProposalsDuringVerification':0,'checks':checks,'verifierSha256':digest(__file__)}
    (OUT/'records.audit.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='checks'}),flush=True)

def training():
    r=json.loads((ROOT/'training2/training.json').read_text());model,metadata=load(ROOT/'training2/model.npz')
    assert digest(ROOT/'training2/model.npz')==r['checkpointSha256'] and metadata=={k:v for k,v in r.items() if k not in ('checkpointSha256','history')}
    assert r['codeSha256']==training_hashes()
    data_dir=Path(r['trainingDatasetDirectory']);index_path=data_dir/'dataset-index.json';assert digest(index_path)==r['trainingDatasetIndexSha256']
    ledger=json.loads(index_path.read_text());data={}
    for name,item in ledger.items():
        p=data_dir/name;assert p.stat().st_size==item['bytes'] and digest(p)==item['sha256']
        data[p.stem]=np.load(p,allow_pickle=False,mmap_mode='r' if p.stem=='x' else None)
    assert data['x'].shape==(23552,3,141) and data['x'].dtype==np.float32
    parent,parent_meta=load(Path(r['parent']));assert digest(r['parent'])==r['parentSha256']
    old_path=Path(r['parentDatasetPath']);assert digest(old_path)==r['parentDatasetSha256']
    with zipfile.ZipFile(old_path) as a,a.open('x.npy') as s:
        ver=np.lib.format.read_magic(s);shape,fort,dtype=(np.lib.format.read_array_header_1_0 if ver==(1,0) else np.lib.format.read_array_header_2_0)(s)
        assert shape==(17408,3,141) and not fort and dtype==np.float32
        for start in range(0,17408,64):
            n=min(64,17408-start);block=s.read(n*3*141*4);assert len(block)==n*3*141*4
            assert np.array_equal(data['x'][start:start+n],np.frombuffer(block,dtype=np.float32).reshape(n,3,141))
        assert not s.read(1)
    with np.load(old_path,allow_pickle=False) as old:
        for key in ('y','actual_gain','cycles','amplitudes','view','kind','graph'):assert equal(data[key][:17408],old[key])
        old_train=old['training'];parts={k:old[k+'_validation'] for k in ('captain','positive','negative','mixed')}
        graph_fold=old['uniform_validation_graphs']+128
    def word(i):return (str(data['view'][i]),*sorted(map(int,data['cycles'][i])))
    val_words={word(i) for i in parts['captain']};seen_words={word(i) for i in old_train if data['kind'][i]=='captain'}
    assert not val_words&seen_words
    new_train=[];captain_val=[];offset=17408
    for ref in r['sourceStages']:
        p=Path(ref['path']);assert digest(p)==ref['sha256'];stage=json.loads(p.read_text());n=stage['attempts']
        assert digest(p.parent/'labels.npz')==ref['labelsSha256']==stage['labelsSha256']
        with np.load(p.parent/'labels.npz',allow_pickle=False) as z:
            for key in ('x','y','actual_gain','cycles','amplitudes'):assert equal(data[key][offset:offset+n],z[key])
        assert np.all(data['view'][offset:offset+n]==ref['view']) and np.all(data['kind'][offset:offset+n]==ref['kind']) and np.all(data['graph'][offset:offset+n]==ref['graph'])
        for i in range(offset,offset+n):
            if ref['graph']<0:
                key=word(i);hold=key in val_words or (int(hashlib.sha256(repr(key).encode()).hexdigest(),16)%5==0 and key not in seen_words)
                (captain_val if hold else new_train).append(i)
            elif ref['graph'] not in graph_fold:new_train.append(i)
        offset+=n
    assert offset==23552
    parts['captain_single']=np.array(captain_val,dtype=np.int64)
    parts['single_synthetic']=np.flatnonzero((data['kind']=='single_synthetic')&np.isin(data['graph'],graph_fold))
    train=np.r_[old_train,np.array(new_train,dtype=np.int64)]
    for name,ids in parts.items():assert np.array_equal(ids,data[name+'_validation'])
    assert np.array_equal(train,data['training']) and np.array_equal(graph_fold,data['single_validation_graphs'])
    hold={word(i) for i in np.r_[parts['captain'],parts['captain_single']]}
    assert all(word(i) not in hold for i in train if data['kind'][i] in ('captain','captain_single'))
    assert not np.intersect1d(train,np.r_[*parts.values()]).size and not np.isin(data['graph'][train],graph_fold).any()
    single=train[np.isin(data['kind'][train],['captain_single','single_synthetic'])];positive=train[data['actual_gain'][train]>0]
    assert (len(train),len(single),len(positive))==(18416,4687,1884)
    assert np.array_equal(np.r_[train,np.tile(single,2),np.tile(positive,7)],data['sampling'])
    counts={str(k):int(((data['kind'][train]==k)&(data['actual_gain'][train]>0)).sum()) for k in np.unique(data['kind'])}
    assert counts==r['improvingTrainingExamplesByKind']
    with np.load(ROOT/'training2/model.npz',allow_pickle=False) as z:
        for k in KEYS:assert np.array_equal(z['initial__'+k],parent.p[k])
        assert np.array_equal(z['mean'],parent.mean) and np.array_equal(z['scale'],parent.scale)
    def loss(m):
        values={}
        for name,ids in parts.items():
            values[name]=sum(float(m.loss(data['x'][chunk],data['y'][chunk]))*len(chunk) for start in range(0,len(ids),256) for chunk in [ids[start:start+256]])/len(ids)
        return float(sum(values.values())/len(values)),values
    assert loss(parent)==(r['initialValidationLoss'],r['initialValidationParts'])
    assert loss(model)==(r['bestValidationLoss'],r['selectedValidationParts'])
    changes={k:float(np.linalg.norm(model.p[k]-parent.p[k])) for k in KEYS};assert changes==r['parameterGroupChangesL2'] and all(v>0 for v in changes.values())
    first={k:np.zeros_like(v) for k,v in parent.p.items()};second={k:v.copy() for k,v in first.items()};rng=np.random.default_rng(r['seed']);updates=0;selected_verified=False
    # Replay the fixed completed optimizer trace into memory, without publishing
    # or selecting a new model and without collecting any additional outcomes.
    for record in r['history']:
        order=rng.permutation(data['sampling'])
        for start in range(0,len(order),64):
            if updates>=record['updates']:break
            ids=order[start:start+64];_,grads=parent.loss(data['x'][ids],data['y'][ids],True)
            norm=np.sqrt(sum(np.sum(g*g) for g in grads.values()));updates+=1
            for key in KEYS:
                g=grads[key]*min(1.,5/max(norm,1e-12));first[key]=.9*first[key]+.1*g;second[key]=.999*second[key]+.001*g*g
                parent.p[key]-=.0005*(first[key]/(1-.9**updates))/(np.sqrt(second[key]/(1-.999**updates))+1e-8)
        assert updates==record['updates'] and loss(parent)==(record['loss'],record['parts'])
        if updates==r['selectedCheckpointUpdates']:
            assert all(np.array_equal(model.p[k],parent.p[k]) for k in KEYS);selected_verified=True
        if record['epoch']%8==0:print(json.dumps({'optimizerEpochReplayed':record['epoch'],'updates':updates}),flush=True)
    assert updates==r['newTrainingUpdatesExecuted']==20512 and selected_verified
    result={'status':'pass','all23552RowsReconstructed':True,'allDatasetFilesStreamHashVerified':True,'rows':23552,'trainingRows':len(train),'singleOwnerTrainingRows':len(single),'improvingTrainingExamplesByKind':counts,'captainWordFoldsAndSyntheticGraphFoldsPreserved':True,'validationRowsByPart':{k:len(v) for k,v in parts.items()},'validationValuesRecomputedExactly':True,'optimizerUpdatesReplayedExactly':updates,'selectedCheckpointUpdatesReplayed':r['selectedCheckpointUpdates'],'selectedWeightsMatchReplayExactly':True,'normalizationUnchanged':True,'newTrainingUpdatesDuringVerification':0,'checkpointSha256':digest(ROOT/'training2/model.npz'),'verifierSha256':digest(__file__)}
    (OUT/'training.audit.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--part',choices=['records','training'],required=True);a=p.parse_args()
    OUT.mkdir(exist_ok=True);(records if a.part=='records' else training)()
