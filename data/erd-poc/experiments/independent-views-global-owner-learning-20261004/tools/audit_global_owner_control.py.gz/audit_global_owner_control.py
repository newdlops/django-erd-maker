"""Confirm the matched counterfactual and scope legacy dtype-report metadata."""
from pathlib import Path
import hashlib
import json
import sys
import numpy as np
sys.path.insert(0, str(Path('scripts/erd-poc').resolve()))
from single_owner_cycle_model import load
from float32_input_owner_model import Float32InputCritic


def digest(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


root = Path('.tmp/visualcross-ml-150-750-20261004/single-owner-global-walk1')
assert json.loads((root / 'verification/static.audit.json').read_text())['status'] == 'pass'
cases = []
dtype_records = []
for view in ('individual', 'overview'):
    old_stage = root / (view + '-frozen1')
    new_stage = root / (view + '-trained1')
    old = json.loads((old_stage / 'report.json').read_text())
    new = json.loads((new_stage / 'report.json').read_text())
    for key in ('sourceInputs', 'sourceBindingSha256', 'seed', 'triples', 'budget',
                'samplingTemperature', 'support', 'featureChunkHashes', 'initialVisual', 'initialIndividualVisual'):
        assert old[key] == new[key]
    with np.load(old_stage / 'observations.npz', allow_pickle=False) as a, np.load(new_stage / 'observations.npz', allow_pickle=False) as b:
        for key in ('node_features', 'cycles', 'amplitudes', 'allowed_indices', 'gumbel'):
            assert np.array_equal(a[key], b[key])
        assert not np.array_equal(a['scores'], b['scores'])
    old_model, _ = load(Path(old['checkpoint']))
    new_model, metadata = load(Path(new['checkpoint']))
    assert isinstance(old_model, Float32InputCritic) and isinstance(new_model, Float32InputCritic)
    assert np.array_equal(old_model.mean, new_model.mean) and np.array_equal(old_model.scale, new_model.scale)
    assert new['inferenceFeatureInputDtype'] == 'float64' and 'inferenceFeatureInputDtype' not in metadata
    dtype_records.append({'report': str(new_stage / 'report.json'), 'reportSha256': digest(new_stage / 'report.json'),
                          'rawReportInferenceFeatureInputDtype': 'float64', 'effectiveInferenceFeatureInputDtype': 'float32',
                          'reason': 'legacy runner default when checkpoint metadata omits the field; actual trained-kind loader always constructs Float32InputCritic',
                          'rawReportUnchanged': True, 'selectionAndCoordinatesAffected': False})
    old_winners = [row for row in (json.loads(line) for line in (old_stage / 'actions.jsonl').read_text().splitlines()) if row['result']['accepted']]
    new_winners = [row for row in (json.loads(line) for line in (new_stage / 'actions.jsonl').read_text().splitlines()) if row['result']['accepted']]
    assert [row['wireSha256'] for row in old_winners] == [row['wireSha256'] for row in new_winners]
    cases.append({'view': view, 'vocabularyFeaturesGumbelAndBudgetExactlyMatched': True,
                  'scoresChanged': True, 'normalizationUnchanged': True,
                  'frozenFinalVisual': old['final']['visual'], 'trainedFinalVisual': new['final']['visual'],
                  'sameWinningGeometry': True, 'winners': [
                     {'wireSha256': a['wireSha256'], 'frozenRank': a['rank'], 'trainedRank': b['rank'],
                      'frozenScore': a['score'], 'trainedScore': b['score']} for a, b in zip(old_winners, new_winners)]})
result = {'status': 'pass', 'checks': cases, 'learningCausedCaptainGainEstablished': False,
          'effectiveInferenceFeatureInputDtype': 'float32', 'innerArithmeticAndGeometryDtype': 'float64',
          'dtypeMetadataReconciliation': dtype_records,
          'float32CriticSourceSha256': digest('scripts/erd-poc/float32_input_owner_model.py'),
          'auditorSha256': digest(__file__)}
(root / 'verification/matched-control.audit.json').write_text(json.dumps(result, indent=2) + '\n')

# Preserve the executed v3 runner and fix only the descriptive dtype fallback
# for subsequent experiments. No inference is rerun with this version.
original = Path('scripts/erd-poc/run_single_owner_cycle_policy_v3.py')
future = original.with_name('run_single_owner_cycle_policy_v4.py')
assert not future.exists()
text = original.read_text()
changes = {
    "'inferenceFeatureInputDtype': metadata.get('inferenceFeatureInputDtype', 'float64')":
    "'inferenceFeatureInputDtype': 'float32' if metadata['kind'] == MODEL_KIND else metadata.get('inferenceFeatureInputDtype', 'float64')",
    "'run_single_owner_cycle_policy_v3.py', 'global_single_owner_support.py'":
    "'run_single_owner_cycle_policy_v3.py', 'run_single_owner_cycle_policy_v4.py', 'global_single_owner_support.py'",
    "'kind': 'single-owner-global-Captain-policy-v3'": "'kind': 'single-owner-global-Captain-policy-v4'"
}
for old, new in changes.items():
    assert text.count(old) == 1, old
    text = text.replace(old, new)
future.write_text(text)
(root / 'future-policy-metadata-fix.json').write_text(json.dumps({
    'originalRunnerSha256': digest(original), 'futureRunnerSha256': digest(future),
    'inferenceExecutedWithFutureRunner': False,
    'changeScope': 'metadata dtype reporting only; no neural scores, action support or geometry changes',
    'originalExecutedRunnerUnchanged': True
}, indent=2) + '\n')
print(json.dumps({'status': 'pass', 'matchedViews': 2, 'sameWinningGeometry': True,
                  'learningCausedCaptainGainEstablished': False, 'effectiveInferenceFeatureInputDtype': 'float32'}), flush=True)
