"""Closed neural replay and read-only Native controls for new walk policies."""
import argparse
from collections import Counter
import hashlib
import json
import sys
from pathlib import Path
from types import SimpleNamespace
import numpy as np
sys.path.insert(0,str(Path('scripts/erd-poc').resolve()))
from run_anchor_pair_policy import Native,digest,wire
from run_anchor_pair_walk import WalkDecoder,array_hash,verify_saved
from run_single_owner_cycle_policy_v2 import prepare as local_prepare
from run_single_owner_neural_walk_v2 import cumulative_action,hashes as ordinary_hashes
from run_single_owner_neural_walk_v3 import prepare as cached_prepare,hashes as cached_hashes
from run_single_owner_cycle_policy_v3 import prepare as global_prepare,hashes as global_hashes
from run_neural_owner_batches import propose,decode,hashes as batch_hashes
from single_owner_cached_observer_v2 import CachedObserver
from single_owner_cycle_model import AMPLITUDES,load,motion_key,action,vocabulary,rank,allowed_indices
from owner_amplitude_cycle_model import action_features
from train_anchor_pair_outcomes import outcome_target

ROOT=Path('.tmp/visualcross-ml-150-750-20261004/single-owner-global-walk1');OUT=ROOT/'verification'
METRICS=('legal','reason','visual','individualVisual','hard','individualHard','spacing')
def bind(stage,expected_hashes):
    r=json.loads((stage/'report.json').read_text());source=Path(r['sourceDirectory'])
    assert r['codeSha256']==expected_hashes()
    for name,s in r['sourceInputs'].items():assert digest(source/name)==s
    for name in ('checkpoint','environment','sourceBinding'):assert digest(r[name])==r[name+'Sha256']
    binding=json.loads(Path(r['sourceBinding']).read_text())['viewSources'][r['view']]
    assert (str(source),r['sourceInputs'],r['initialVisual'])==(binding['directory'],binding['inputs'],binding['expectedVisual'])
    assert digest(stage/'actions.jsonl')==r['actionsSha256']
    return r,source
def immutable(native,path,source,decoder):
    assert native.request('SAVE')['saved'];s=json.loads(Path(str(path)+'.stats.json').read_text())
    assert s['policyActionsEvaluated']==s['acceptedActions']==0
    assert (s['visual'],s['individualVisual'])==(native.initial['visual'],native.initial['individualVisual'])
    # verify_saved expects a fixed stem under its stage directory.
    return s
def compare(actual,expected):assert all(actual[k]==expected[k] for k in METRICS),(actual,expected)

def static():
    checks=[];samples=0
    for view in ('individual','overview'):
      for kind in ('frozen','trained'):
        stage=ROOT/(view+'-'+kind+'1');batch=False;r,source=bind(stage,batch_hashes if batch else global_hashes)
        decoder=WalkDecoder(source);model,_=load(Path(r['checkpoint']));assert digest(stage/'observations.npz')==r['observationsSha256']
        with np.load(stage/'observations.npz',allow_pickle=False) as z:
            nodes=z['node_features'].copy()
            if batch:
                cycles,support=vocabulary(decoder,nodes,r['seed'],r['triples']);scores,fh,error=rank(model,decoder,nodes,cycles,view=='overview');allowed=allowed_indices(nodes,cycles)
                for name,value in [('cycles',cycles),('amplitudes',AMPLITUDES),('scores',scores),('allowed_indices',allowed)]:assert np.array_equal(z[name],value)
                assert (support,fh,error)==(r['sourceSupport'],r['featureChunkHashes'],r['scaleFeatureMaxError'])
                assert digest(stage/'proposal-schedule.json')==r['scheduleSha256'];schedule=json.loads((stage/'proposal-schedule.json').read_text())
                for entry in schedule:
                    components,policy,dedup=propose(decoder,cycles,scores,allowed,entry['seed'],entry['arity'],r['temperature'])
                    assert (components,policy,dedup)==(entry['components'],entry['policy'],entry['deduplication'])
            else:
                cycles,support,scores,fh,error,allowed,noise,policy,chosen,dedup=global_prepare(model,decoder,nodes,view,r['seed'],r['triples'],r['budget'])
                for name,value in [('cycles',cycles),('amplitudes',AMPLITUDES),('scores',scores),('allowed_indices',allowed),('gumbel',noise),('proposal_schedule',chosen)]:assert np.array_equal(z[name],value)
                assert (support,fh,error,policy,dedup)==tuple(r[k] for k in ('support','featureChunkHashes','scaleFeatureMaxError','policy','deduplication'))
        rows=[json.loads(s) for s in (stage/'actions.jsonl').read_text().splitlines()];best=None;best_visual=r['initialVisual'];best_ind=r['initialIndividualVisual'];reasons=Counter();wires=set();measured=0
        control=OUT/(stage.name+'-control.tsv');native=Native(Path(r['environment']),source,control,view=='overview',False)
        try:
          assert np.array_equal(nodes,np.array([n['features'] for n in native.initial['nodes']]))
          if not batch:
              labels=np.load(stage/'labels.npz',allow_pickle=False);lookup={int(v):i for i,v in enumerate(allowed)}
              features,_=action_features(nodes,decoder,cycles[chosen[:,0]],AMPLITUDES[chosen[:,1]],view=='overview')
          for i,row in enumerate(rows):
            assert row['rank']==i
            if batch:entry=schedule[i];assert row['arity']==entry['arity'];proposed=decode(decoder,entry['components'])
            else:
                ci,ai=map(int,chosen[i]);assert (ci,ai)==(row['cycleIndex'],row['amplitudeIndex'])
                assert row['cycle']==cycles[ci].tolist() and row['amplitudes']==AMPLITUDES[ai].tolist()
                ni=lookup[int(np.ravel_multi_index((ci,ai),scores.shape))];assert row['score']==float(scores[ci,ai]) and row['gumbel']==float(noise[ni,0])
                proposed=action(decoder,cycles[ci],AMPLITUDES[ai])
                assert np.array_equal(labels['x'][i],features[i].astype(np.float32)) and labels['y'][i]==outcome_target(row['result'],r['initialVisual'])
            key=hashlib.sha256(wire(proposed).encode()).hexdigest();assert key==row['wireSha256'] and key not in wires;wires.add(key)
            result=row['result'];accepted=result['legal'] and result['visual']<best_visual and (view=='overview' or result['individualVisual']<=best_ind)
            assert accepted==result['accepted'];reasons[result['reason']]+=1
            if i<16 or accepted:compare(native.request(wire(proposed,'MEASURE')),result);measured+=1
            if accepted:best=proposed.copy();best_visual=result['visual'];best_ind=result['individualVisual']
          if not batch:labels.close()
          immutable(native,control,source,decoder)
        finally:native.close()
        assert len(rows)==r['attempts'] and dict(reasons)==r['reasons'] and best_visual==r['final']['visual'];verify_saved(source,stage,decoder,best)
        check={'stage':str(stage),'allModelScoresSchedulesAndActionsReplayed':len(rows),'fullNativeMeasurementSamples':measured,'finalVisual':best_visual,'allNativeScoresIndependentlyRecomputed':False}
        checks.append(check);samples+=measured;print(json.dumps(check),flush=True)
    result={'status':'pass','checks':checks,'readOnlyFullNativeMeasurements':samples,'newNeuralProposalsDuringVerification':0,'verifierSha256':digest(__file__)}
    (OUT/'static.audit.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)

if __name__=='__main__':
    assert OUT.is_dir();static()
