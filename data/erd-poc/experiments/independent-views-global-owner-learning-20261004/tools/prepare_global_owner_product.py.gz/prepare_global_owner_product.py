"""Apply the verified new NN's identical matched-control winner to the product."""
from pathlib import Path
import hashlib
import json
import shutil


def digest(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


root = Path('.tmp/visualcross-ml-150-750-20261004/single-owner-global-walk1')
assert json.loads((root / 'verification/static.audit.json').read_text())['status'] == 'pass'
assert json.loads((root / 'verification/training.audit.json').read_text())['status'] == 'pass'
assert json.loads((root / 'verification/matched-control.audit.json').read_text())['status'] == 'pass'
stage = root / 'overview-trained1'
report = json.loads((stage / 'report.json').read_text())
assert (report['initialVisual'], report['final']['visual']) == (286, 285)
assert report['trainedOnSingleOwnerMoves'] and report['accepted'] == 1
assert report['nativeSearchCalls'] == report['coordinateRepairs'] == 0
assert report['checkpointSha256'] == '7831d4b8679769a22e4eab8a344f846e892e5ebd52b89b68afafb8ef92c777f9'
out = root / 'overview-product1'
out.mkdir(exist_ok=False)
source = Path(report['sourceDirectory'])
for name, value in report['sourceInputs'].items():
    assert digest(source / name) == value
    shutil.copyfile(source / name, out / name)
shutil.copyfile(source / 'export.json', out / 'export.json')
for name in ('learned.tsv', 'learned.tsv.individual', 'learned.tsv.routes.tsv',
             'learned.tsv.individual.routes.tsv', 'learned.tsv.stats.json'):
    shutil.copyfile(stage / name, out / name)
model = report['checkpointTraining']
policy = {
    'modelKind': model['kind'], 'featureSchema': report['featureSchema'], 'actionSchema': report['actionSchema'],
    'checkpoint': report['checkpoint'], 'checkpointSha256': report['checkpointSha256'],
    'untrainedControl': False, 'overviewOnly': True, 'final': report['final'],
    'criticAdaptationUpdatesExecuted': model['newTrainingUpdatesExecuted'],
    'selectedCriticAdaptationUpdates': model['selectedAdaptationUpdates'],
    'parentCriticSha256': model['parentSha256'],
    'parentSelectedCheckpointUpdates': model['parentSelectedCheckpointUpdates'],
    'inferenceFeatureInputDtype': 'float32', 'innerNetworkArithmeticDtype': 'float64',
    'newTrainingUpdatesDuringInference': 0,
    'globalAllSizeDirectionSupport': True, 'conflictingIsolatedCardsEligible': True,
    'matchedFrozenParentSameWinner': True, 'learningCausedCaptainGainEstablished': False,
    'experimentReport': str(stage / 'report.json'), 'experimentReportSha256': digest(stage / 'report.json'),
    'modelSelectedAllGeometry': True, 'coordinateRepairs': 0, 'nativeSearchCalls': 0, 'browserVerified': False
}
(out / 'learned.tsv.policy.json').write_text(json.dumps(policy, indent=2) + '\n')
(out / 'preparation.json').write_text(json.dumps({
    'stage': str(stage), 'stageReportSha256': digest(stage / 'report.json'),
    'sourceLayout': json.loads((out / 'export.json').read_text())['sourceFile'],
    'productApplyHelper': 'scripts/erd-poc/apply_learned_single_owner_components.cjs',
    'productApplyHelperSha256': digest('scripts/erd-poc/apply_learned_single_owner_components.cjs'),
    'geometryCopiedExactlyFromVerifiedNeuralWinner': True, 'newCoordinateProposals': 0
}, indent=2) + '\n')
print(json.dumps({'preparedProduct': str(out), 'overviewVisual': 285, 'newCoordinateProposals': 0}), flush=True)
