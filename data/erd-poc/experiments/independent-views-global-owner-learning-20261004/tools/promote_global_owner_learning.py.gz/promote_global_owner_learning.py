"""Promote the archived, independently restored 285/1963 NN product candidate."""
import hashlib
import json
import os
from pathlib import Path


def digest(path):
    with Path(path).open('rb') as source:
        return hashlib.file_digest(source, 'sha256').hexdigest()


root = Path('.tmp/visualcross-ml-150-750-20261004/single-owner-global-walk1')
seal = json.loads(Path('.tmp/global-owner-learning-archive-seal-receipt.json').read_text())
restored = json.loads(Path('.tmp/global-owner-learning-archive-independent-verification.json').read_text())
manifest_path = Path(seal['manifest'])
assert digest(manifest_path) == seal['manifestSha256'] == restored['manifestSha256']
assert restored['status'] == 'pass'
manifest = json.loads(manifest_path.read_text())
base = Path('data/erd-poc/candidates/captain-ml-independent-views')
paths = {key: Path(str(base) + '.' + key + '.json') for key in ('layout', 'audit', 'provenance')}
for path in paths.values():
    assert path.read_bytes() == (root / 'promotion-before' / path.name).read_bytes()
assert digest(paths['layout']) == manifest['previousCandidateSha256']
candidate = Path(manifest['candidateSource'])
assert digest(candidate) == manifest['candidateSha256']
before = json.loads(paths['layout'].read_text())
after = json.loads(candidate.read_text())
assert before['individualView'] == after['individualView']
old = {node['modelId']: node for node in before['nodes']}
new = {node['modelId']: node for node in after['nodes']}
assert old.keys() == new.keys() and len(new) == 1244
assert all(node['size'] == old[key]['size'] for key, node in new.items())
changed = [key for key, node in new.items() if node['position'] != old[key]['position']]
assert len(changed) == 1
assert before['engineMetadata']['leafBundles'] == after['engineMetadata']['leafBundles']
assert len(after['routedEdges']) == 1727
assert {edge['edgeId'] for edge in before['routedEdges']} == {edge['edgeId'] for edge in after['routedEdges']}
audit = json.loads((root / 'combined-best1/audit.json').read_text())
assert audit == manifest['productAudit'] and (audit['overviewVisual'], audit['individualVisual']) == (285, 1963)
assert not audit['thresholdsMet']
for key in ('actualProductFileLoadVerified', 'completeIndividualGeometryPreserved',
            'browserRouteFunctionParity', 'roundTripViewSwitchVerified'):
    assert audit[key]
previous = json.loads(paths['provenance'].read_text())
training = json.loads((root / 'training1/training.json').read_text())
training_proof = manifest['verification']['training']
assert training_proof['optimizerUpdatesExactlyReplayed'] == 23488
assert training_proof['selectedAdaptationUpdatesExactlyReplayed'] == 734
overview = json.loads((root / 'overview-product1/product.audit.json').read_text())
peak = next(row['peakMiB'] for row in manifest['resources']['logs'] if row['path'].endswith('/combined-product.guard.log'))
audit.update(candidate=str(paths['layout']), promoted=True, viewSpecificGeometry=True, browserVerified=False,
             overviewSpacingViolations=0, overviewBboxArea=overview['bboxB'] * 1e9,
             dimensionsPreserved=True, canonicalRelationshipsPreserved=True, nativeHardConditions=0)
history = list(previous['subsequentResearchArchives'])
history.append({'archiveManifest': str(manifest_path), 'archiveManifestSha256': seal['manifestSha256'],
                'promotedCandidateChanged': True, 'previousCandidateSha256': manifest['previousCandidateSha256'],
                'candidateSha256': manifest['candidateSha256'], 'overviewVisual': 285, 'individualVisual': 1963,
                'nativeModelActions': 4349, 'trajectoryActions': 253, 'matchedPolicyActions': 4096,
                'newNetworkTrainingUpdates': 23488, 'selectedAdaptationUpdates': 734,
                'sourceTrainingOutcomeRows': 2512, 'newCaptainTrainingRows': 1991,
                'readOnlyFullScoringComparisons': 2580, 'fullNativeFeatureControls': 85,
                'matchedFrozenParentHasIdenticalWinner': True, 'learningCausedCaptainGainEstablished': False,
                'targetMet': False, 'browserVerified': False})
provenance = {
    **previous, 'candidateSha256': manifest['candidateSha256'],
    'previousCandidateSha256': manifest['previousCandidateSha256'], 'overviewVisual': 285, 'individualVisual': 1963,
    'archiveManifest': str(manifest_path), 'archiveManifestSha256': seal['manifestSha256'],
    'priorArchives': list(dict.fromkeys(previous['priorArchives'] + [Path(previous['archiveManifest']).parent.name])),
    'subsequentResearchArchives': history, 'stagesInLatestArchive': 6, 'sourceStagesUsedForLatestTraining': 8,
    'additionalActionsArchived': 4349, 'modelsTrainedInLatestArchive': 1,
    'coordinatedNetworkBatchesArchived': 23488,
    'coordinatedNetworkBatchesArchivedScope': 'current optimizer batches; excludes 4349 inference proposals',
    'trainingRewardMeasurementsArchived': 2512, 'syntheticRewardMeasurementsArchived': 0,
    'actualCaptainRewardMeasurementsUsedForTraining': 1991, 'newCaptainInferenceMeasurementsNotUsedForTraining': 4096,
    'newCaptainInferenceMeasurementsNotUsedForTrainingScope': 'current matched policy TRY attempts, including rejected proposals; not 4096 independently full-measured legal rewards',
    'trainingMeasurementCountsScope': '2512 fully verified actual Captain outcomes added to the 23552 inherited rows; 1991 new rows used for training and 521 kept for validation',
    'newNetworkTrainingUpdatesInLatestContinuation': 23488, 'selectedCheckpointUpdatesInLatestContinuation': 734,
    'rawCheckpointSelectedUpdateMarker': 14195,
    'rawCheckpointSelectedUpdateMarkerScope': 'immediate parent selection 13461 plus current adaptation 734; not all-ancestor lifetime updates',
    'latestFrozenCriticCheckpointSha256': training['checkpointSha256'], 'latestCriticTrainedOnSingleOwnerMoves': True,
    'overviewSource': audit['overviewSource'], 'individualSource': audit['individualSource'],
    'matchedFrozenParentCheckpointSha256': training['parentSha256'],
    'matchedFrozenParentControlScope': 'current 286-to-285 global policy; same source features, vocabulary, Gumbel and 1024 proposal budget per view',
    'currentMatchedFrozenParentAblationExecuted': True, 'matchedFrozenParentHasIdenticalWinner': True,
    'latestSingleOwnerDataset': {
        'rows': 26064, 'trainingRows': 20407, 'newCaptainOutcomeRows': 2512, 'newCaptainTrainingRows': 1991,
        'singleOwnerTrainingRows': 6678, 'validationRowsByPart': training['validationRowsByPart'],
        'datasetIndexSha256': training['trainingDatasetIndexSha256'],
        'wholeWordAndGraphFoldsPreserved': True, 'validationScope': training['validationScope']},
    'overviewCriticTraining': {
        'checkpointSha256': training['checkpointSha256'], 'kind': training['kind'],
        'parentCheckpointSha256': training['parentSha256'], 'newTrainingUpdatesExecuted': 23488,
        'selectedAdaptationUpdates': 734, 'selectedEpoch': 1,
        'initialValidationParts': training['initialValidationParts'], 'selectedValidationParts': training['selectedValidationParts'],
        'trainingReport': str(root / 'training1/training.json'), 'trainingReportSha256': digest(root / 'training1/training.json'),
        'learningCausedCaptainGainEstablished': False},
    'neuralTranslationDecoder': 'newly adapted single-owner global critic selects overview translations; original individual geometry preserved; Native only decodes, observes, measures and accepts/rejects',
    'validationEvidence': str(root / 'verification/static.audit.json'),
    'trajectoryValidationEvidence': str(root / 'verification/walks.audit.json'),
    'trainingValidationEvidence': str(root / 'verification/training.audit.json'),
    'trainingValidationEvidenceScope': 'current 26064 rows/folds and all 23488 optimizer updates exactly replayed',
    'matchedControlValidationEvidence': str(root / 'verification/matched-control.audit.json'),
    'effectiveInferenceFeatureInputDtype': 'float32',
    'rawTrainedInferenceReportDtypeFallbackReconciliation': str(root / 'verification/matched-control.audit.json'),
    'cachedModelInputStateNativeControls': 85, 'allCachedModelInputsNativeVerifiedExactly': True,
    'neuralOwnerBatchInferenceProposalsArchived': 0, 'jointInteractionCriticTrainedInLatestArchive': False,
    'productAuditPeakMiB': peak, 'resourceLimitMiB': 128, 'resourceLimitRaised': False,
    'nativeCoordinateSearchOrRepairAdded': False, 'outwardBoundaryContractVerified': True,
    'causalAblationVerified': False, 'learningCausedCaptainGainEstablished': False,
    'winningNeuralScore': manifest['diagnosis']['winningNeuralScore'], 'winnerSampledViaNeuralWeightedExploration': True,
    'overviewTarget': 150, 'individualTarget': 750, 'targetMet': False, 'browserVerified': False,
    'latestResearchArchiveIndependentVerification': '.tmp/global-owner-learning-archive-independent-verification.json'
}
for key in ('latestPromotionMetadataReconciliationRecord', 'latestPromotionMetadataReconciliationRecordSha256'):
    if key in provenance:
        provenance['previousGlobalPolicyPromotion' + key[0].upper() + key[1:]] = provenance.pop(key)
pending = []
for key, value in (('layout', candidate.read_bytes()),
                   ('audit', (json.dumps(audit, indent=2) + '\n').encode()),
                   ('provenance', (json.dumps(provenance, indent=2) + '\n').encode())):
    path = paths[key]
    temporary = path.with_name(path.name + '.promoting')
    with temporary.open('xb') as stream:
        stream.write(value)
    pending.append((temporary, path))
for temporary, path in pending:
    os.replace(temporary, path)
assert digest(paths['layout']) == manifest['candidateSha256']
result = {'promoted': True, 'overviewVisual': 285, 'individualVisual': 1963,
          'candidateSha256': manifest['candidateSha256'], 'previousCandidatePreserved': True,
          'individualViewExactlyPreserved': True, 'overviewMovedModels': changed,
          'sizesAnd1727RelationshipsPreserved': True, 'archiveManifestSha256': seal['manifestSha256'],
          'newTrainingUpdates': 23488, 'selectedAdaptationUpdates': 734, 'targetMet': False, 'browserVerified': False}
output = Path('.tmp/global-owner-learning-promotion-receipt.json')
assert not output.exists()
output.write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result), flush=True)
