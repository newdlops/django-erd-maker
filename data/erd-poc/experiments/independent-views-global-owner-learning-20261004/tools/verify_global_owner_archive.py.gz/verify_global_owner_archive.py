"""Restore every archived mapping and match source bytes independently."""
import gzip
import hashlib
import json
from pathlib import Path


def digest(path, restore=False):
    with Path(path).open('rb') as source:
        compressed = source.read(2) == b'\x1f\x8b'
    h = hashlib.sha256()
    size = 0
    with (gzip.open(path, 'rb') if restore and compressed else Path(path).open('rb')) as source:
        while block := source.read(32768):
            h.update(block)
            size += len(block)
    return size, h.hexdigest()


receipt = json.loads(Path('.tmp/global-owner-learning-archive-seal-receipt.json').read_text())
path = Path(receipt['manifest'])
assert digest(path)[1] == receipt['manifestSha256']
manifest = json.loads(path.read_text())
objects = set()
mappings = 0
for category in ('files', 'referencedFiles'):
    for item in manifest[category]:
        stored = path.parent / item['archive'] if category == 'files' else Path(item['archive'])
        expected = item['bytes'], item['sha256']
        assert digest(stored, True) == expected and digest(item['source']) == expected
        objects.add(str(stored))
        mappings += 1
for item in manifest['prerequisiteManifests']:
    assert digest(item['path'])[1] == item['sha256']
assert digest(manifest['candidateSource'])[1] == manifest['candidateSha256']
assert all(record['status'] == 'pass' for record in manifest['verification'].values())
assert manifest['productAudit']['roundTripViewSwitchVerified']
assert (manifest['overviewVisual'], manifest['individualVisual']) == (285, 1963) and not manifest['targetMet']
result = {'status': 'pass', 'manifestSha256': receipt['manifestSha256'],
          'mappingsRestoredAndLiveSourcesMatched': mappings, 'distinctStoredObjects': len(objects),
          'prerequisiteManifestsMatched': len(manifest['prerequisiteManifests']),
          'candidateSha256': manifest['candidateSha256'], 'overviewVisual': 285, 'individualVisual': 1963,
          'targetMet': False}
out = Path('.tmp/global-owner-learning-archive-independent-verification.json')
assert not out.exists()
out.write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result), flush=True)
