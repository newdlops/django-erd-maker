"""Run predeclared frozen/trained global policies serially on the same sources."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys


def digest(path):
    with Path(path).open('rb') as source:
        return hashlib.file_digest(source, 'sha256').hexdigest()


root = Path('.tmp/visualcross-ml-150-750-20261004/single-owner-global-walk1')
training = json.loads((root / 'verification/training.audit.json').read_text())
assert training['status'] == 'pass' and training['optimizerUpdatesExactlyReplayed'] == 23488
parent = Path('.tmp/visualcross-ml-150-750-20261004/single-owner-learning1/training2/model.npz')
learned = root / 'training1/model.npz'
assert digest(parent) == 'ef92608e90a15f9d8b467f3a7ee964b900ea57d740da4503f83199d57e107df1'
assert digest(learned) == training['checkpointSha256'] == '7831d4b8679769a22e4eab8a344f846e892e5ebd52b89b68afafb8ef92c777f9'
binding_path = root / 'source-binding.json'
binding = json.loads(binding_path.read_text())
assert digest('data/erd-poc/candidates/captain-ml-independent-views.layout.json') == binding['promotedCandidateSha256']
environment = Path('.tmp/visualcross-ml-150-750-20261003/pair-neutral-walk1/environment')
runner = Path('scripts/erd-poc/run_single_owner_cycle_policy_v3.py')
plan = {
    'sourceBinding': str(binding_path), 'sourceBindingSha256': digest(binding_path),
    'environment': str(environment), 'environmentSha256': digest(environment),
    'runner': str(runner), 'runnerSha256': digest(runner),
    'seed': 102503, 'triples': 1024, 'budget': 1024, 'secondsLimit': 30,
    'samplingTemperature': 4,
    'vocabularyFeaturesGumbelAndBudgetsMatchedWithinEachView': True,
    'scheduleChosenByNeuralScoresBeforeNativeMeasurement': True,
    'numericalJobsSerialized': True, 'coordinateRepairsOrNativeSearch': 0,
    'cases': [{'view': view, 'variant': variant, 'checkpoint': str(model),
               'checkpointSha256': digest(model), 'out': str(root / (view + '-' + variant + '1'))}
              for view in ('individual', 'overview') for variant, model in (('frozen', parent), ('trained', learned))]
}
plan_path = root / 'matched-plan.json'
assert not plan_path.exists()
plan_path.write_text(json.dumps(plan, indent=2) + '\n')
plan_sha = digest(plan_path)
for case in plan['cases']:
    assert digest(plan_path) == plan_sha
    assert digest(case['checkpoint']) == case['checkpointSha256']
    command = [sys.executable, str(runner), '--directory', binding['viewSources'][case['view']]['directory'],
               '--checkpoint', case['checkpoint'], '--environment', str(environment),
               '--source-binding', str(binding_path), '--view', case['view'], '--seed', str(plan['seed']),
               '--triples', str(plan['triples']), '--budget', str(plan['budget']), '--seconds', str(plan['secondsLimit']),
               '--out', case['out']]
    subprocess.run(command, check=True)
    report_path = Path(case['out']) / 'report.json'
    report = json.loads(report_path.read_text())
    assert report['attempts'] == plan['budget']
    assert report['checkpointSha256'] == case['checkpointSha256']
    assert report['newTrainingUpdatesDuringInference'] == report['nativeSearchCalls'] == report['coordinateRepairs'] == 0
    print(json.dumps({'completedMatchedCase': case['view'] + '-' + case['variant'],
                      'reportSha256': digest(report_path), 'initialVisual': report['initialVisual'],
                      'finalVisual': report['final']['visual']}), flush=True)
result = {'status': 'pass', 'planSha256': plan_sha, 'completedCases': 4, 'newNeuralProposals': 4096,
          'newOptimizerUpdatesDuringInference': 0, 'orchestratorSha256': digest(__file__)}
(root / 'matched-completion.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result), flush=True)
