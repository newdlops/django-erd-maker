"""Bind the current NN-generated 286/1963 geometry for fresh global trajectories."""
from pathlib import Path
import hashlib
import json
import shutil


def digest(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


root = Path('.tmp/visualcross-ml-150-750-20261004/single-owner-global-walk1')
prior = Path('.tmp/visualcross-ml-150-750-20261004/single-owner-trained-walk1')
candidate = Path('data/erd-poc/candidates/captain-ml-independent-views.layout.json')
assert digest(candidate) == '4c88250bd2dce3ffb85d640c35d11d952664b0358658a0f0b35b94cbccd28688'
layout = json.loads(candidate.read_text())
audit_path = candidate.with_name('captain-ml-independent-views.audit.json')
audit = json.loads(audit_path.read_text())
assert (audit['overviewVisual'], audit['individualVisual']) == (286, 1963)
binding = json.loads((prior / 'source-binding.json').read_text())
winner = prior / 'overview-global1'
report = json.loads((winner / 'report.json').read_text())
assert report['final']['visual'] == 286 and report['savedGeometryMatchesModelOutput']
root.mkdir(exist_ok=False)
views = {}
for view in ('overview', 'individual'):
    source = Path(binding['viewSources'][view]['directory'])
    out = root / (view + '-source' + str(audit[view + 'Visual']))
    out.mkdir()
    for name, value in binding['viewSources'][view]['inputs'].items():
        assert digest(source / name) == value
        shutil.copyfile(source / name, out / name)
    if view == 'overview':
        for target, saved in [('positions.tsv', 'learned.tsv'), ('routes.tsv', 'learned.tsv.routes.tsv'),
                              ('individual.positions.tsv', 'learned.tsv.individual'),
                              ('individual.routes.tsv', 'learned.tsv.individual.routes.tsv')]:
            shutil.copyfile(winner / saved, out / target)
        exported = json.loads((source / 'export.json').read_text())
        applied = json.loads((prior / 'overview-product1/proposal.audit.json').read_text())
        exported.update(sourceFile=audit['overviewSource'], sourceSha256=audit['overviewSourceSha256'],
                        baseline=applied['metrics'], individualBaseline=applied['candidateIndividual'],
                        bboxB=applied['bboxArea'] / 1e9)
        (out / 'export.json').write_text(json.dumps(exported, indent=2) + '\n')
        geometry_nodes = layout['nodes']
        physical = json.loads((prior / 'overview-product1/product.scene.json').read_text())['tables']
        positions = {key: (float(x), float(y)) for key, x, y in
                     (line.split('\t') for line in (out / 'positions.tsv').read_text().splitlines())}
        assert len(positions) == len(physical) == 1035
        for node in physical:
            p = positions[node['modelId']]
            assert abs(p[0] - node['position']['x'] - node['size']['width'] / 2) < 1e-8
            assert abs(p[1] - node['position']['y'] - node['size']['height'] / 2) < 1e-8
    else:
        geometry_nodes = layout['individualView']['nodes']
    positions = {key: (float(x), float(y)) for key, x, y in
                 (line.split('\t') for line in (out / 'individual.positions.tsv').read_text().splitlines())}
    assert len(positions) == len(geometry_nodes) == 1244
    for node in geometry_nodes:
        p = positions[node['modelId']]
        assert abs(p[0] - node['position']['x'] - node['size']['width'] / 2) < 1e-8
        assert abs(p[1] - node['position']['y'] - node['size']['height'] / 2) < 1e-8
    views[view] = {'directory': str(out),
                   'inputs': {name: digest(out / name) for name in binding['viewSources'][view]['inputs']},
                   'expectedVisual': audit[view + 'Visual']}
record = {'viewSources': views, 'promotedCandidateSha256': digest(candidate),
          'promotedAuditSha256': digest(audit_path), 'geometryChosenByNewCode': False,
          'modelSavedOverviewReport': str(winner / 'report.json'),
          'modelSavedOverviewReportSha256': digest(winner / 'report.json'),
          'individualCopiedFromVerified1963Source': True}
(root / 'source-binding.json').write_text(json.dumps(record, indent=2) + '\n')

original = Path('scripts/erd-poc/run_single_owner_neural_walk_v3.py')
new = original.with_name('run_single_owner_neural_walk_v4.py')
assert not new.exists()
text = original.read_text()
changes = {
    'from single_owner_cycle_model import ACTION_SCHEMA, MODEL_KIND, AMPLITUDES, action, load, motion_key, vocabulary, rank, allowed_indices, schedule':
    'from single_owner_cycle_model import ACTION_SCHEMA, MODEL_KIND, AMPLITUDES, action, load, motion_key, rank, allowed_indices, schedule\nfrom global_single_owner_support import vocabulary',
    "'single_owner_cached_observer_v2.py']}":
    "'single_owner_cached_observer_v2.py','run_single_owner_neural_walk_v4.py','global_single_owner_support.py']}",
    "'kind': 'single-owner-neural-neutral-walk-v3'":
    "'kind': 'single-owner-global-neutral-walk-v4'",
    "'baselineNativeFullMeasurement': baseline":
    "'baselineNativeSparseMeasurement': baseline"
}
for old, updated in changes.items():
    assert text.count(old) == 1, old
    text = text.replace(old, updated)
new.write_text(text)
(root / 'runner-binding.json').write_text(json.dumps({
    'originalRunnerSha256': digest(original), 'newRunnerSha256': digest(new),
    'globalSupportSha256': digest('scripts/erd-poc/global_single_owner_support.py'),
    'changes': ['global all-size source words at every current pose',
                'truthful sparse baseline measurement metadata'],
    'originalRunnerUnchanged': True, 'coordinateSearchOrRepairAdded': False,
    'featureSchemaAndNeuralWeightsChanged': False
}, indent=2) + '\n')
print(json.dumps({'promotedCandidateSha256': digest(candidate), 'expectedVisual': {'overview': 286, 'individual': 1963},
                  'preparedViews': list(views), 'newCoordinateProposals': 0, 'runnerSha256': digest(new)}), flush=True)
