"""Audit streamed rows, protected folds, and exact replay of the new optimizer."""
from pathlib import Path
import hashlib
import json
import sys
import numpy as np
sys.path.insert(0, str(Path('scripts/erd-poc').resolve()))
from directed_cycle_model import KEYS
from single_owner_cycle_model import load
from train_single_owner_cycle_model_v2 import validation_loss, word, fold
from train_single_owner_cycle_model_v3 import hashes


def digest(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as source:
        while block := source.read(65536):
            h.update(block)
    return h.hexdigest()


root = Path('.tmp/visualcross-ml-150-750-20261004/single-owner-global-walk1')
stage = root / 'training1'
report = json.loads((stage / 'training.json').read_text())
assert digest(stage / 'model.npz') == report['checkpointSha256']
assert report['codeSha256'] == hashes()
assert digest(report['parent']) == report['parentSha256']
model, parent = load(Path(report['parent']))
original = Path(report['parentDatasetDirectory'])
assert digest(original / 'dataset-index.json') == report['parentDatasetIndexSha256']
dataset = stage / 'dataset'
assert digest(dataset / 'dataset-index.json') == report['trainingDatasetIndexSha256']
for name, item in json.loads((dataset / 'dataset-index.json').read_text()).items():
    path = dataset / name
    assert path.stat().st_size == item['bytes'] and digest(path) == item['sha256']
data = {path.stem: np.load(path, allow_pickle=False, mmap_mode='r' if path.stem == 'x' else None)
        for path in dataset.glob('*.npy')}
assert data['x'].shape == (26064, 3, 141) and data['x'].dtype == np.float32
for name in ('y', 'actual_gain', 'cycles', 'amplitudes', 'view', 'kind', 'graph'):
    original_values = np.load(original / (name + '.npy'), allow_pickle=False)
    assert np.array_equal(data[name][:23552], original_values, equal_nan=True) if original_values.dtype.kind not in 'US' else np.array_equal(data[name][:23552], original_values)
with (original / 'x.npy').open('rb') as source:
    version = np.lib.format.read_magic(source)
    shape, fortran, dtype = (np.lib.format.read_array_header_1_0 if version == (1, 0)
                            else np.lib.format.read_array_header_2_0)(source)
    assert shape == (23552, 3, 141) and dtype == np.float32 and not fortran
    for first_row in range(0, 23552, 64):
        size = min(64, 23552 - first_row)
        values = np.frombuffer(source.read(size * 3 * 141 * 4), dtype=np.float32).reshape(size, 3, 141)
        assert np.array_equal(data['x'][first_row:first_row + size], values)
    assert not source.read(1)
old_parts = ('captain', 'positive', 'negative', 'mixed', 'captain_single', 'single_synthetic')
parts = {name: data[name + '_validation'] for name in (*old_parts, 'captain_global', 'captain_walk')}
for name in old_parts:
    assert np.array_equal(parts[name], np.load(original / (name + '_validation.npy'), allow_pickle=False))
old_train = np.load(original / 'training.npy', allow_pickle=False)
val_words = {word(data['view'][i], data['cycles'][i]) for i in np.r_[parts['captain'], parts['captain_single']]}
seen_words = {word(data['view'][i], data['cycles'][i]) for i in old_train
              if data['kind'][i] in ('captain', 'captain_single')}
assert not val_words & seen_words
new_train = []
new_val = {name: [] for name in ('captain_global', 'captain_walk')}
offset = 23552
for source in report['sourceStages']:
    assert digest(source['path']) == source['sha256'] and digest(source['labels']) == source['labelsSha256']
    count = source['rows']
    with np.load(source['labels'], allow_pickle=False) as labels:
        for name in ('x', 'y', 'actual_gain', 'cycles', 'amplitudes'):
            assert np.array_equal(data[name][offset:offset + count], labels[name], equal_nan=True)
    assert np.all(data['kind'][offset:offset + count] == source['kind'])
    assert np.all(data['view'][offset:offset + count] == source['view'])
    assert np.all(data['graph'][offset:offset + count] == -1)
    for i in range(offset, offset + count):
        key = word(source['view'], data['cycles'][i])
        if key in val_words or (fold(key) and key not in seen_words):
            new_val[source['kind']].append(i)
        else:
            new_train.append(i)
    offset += count
assert offset == len(data['x'])
for name, ids in new_val.items():
    assert np.array_equal(parts[name], np.array(ids))
assert np.array_equal(data['training'], np.r_[old_train, np.array(new_train)])
holds = {word(data['view'][i], data['cycles'][i]) for name in
         ('captain', 'captain_single', 'captain_global', 'captain_walk') for i in parts[name]}
assert all(word(data['view'][i], data['cycles'][i]) not in holds for i in data['training']
           if str(data['kind'][i]).startswith('captain'))
single = data['training'][np.isin(data['kind'][data['training']],
         ['captain_single', 'single_synthetic', 'captain_global', 'captain_walk'])]
positive = data['training'][data['actual_gain'][data['training']] > 0]
assert np.array_equal(data['sampling'], np.r_[data['training'], np.tile(single, 2), np.tile(positive, 7)])
assert not np.isin(data['graph'][data['training']], data['single_validation_graphs']).any()
initial = {key: value.copy() for key, value in model.p.items()}
initial_loss, values = validation_loss(model, data, parts)
assert (initial_loss, values) == (report['initialValidationLoss'], report['initialValidationParts'])
first = {key: np.zeros_like(value) for key, value in model.p.items()}
second = {key: value.copy() for key, value in first.items()}
rng = np.random.default_rng(report['seed'])
updates = selected_updates = selected_epoch = 0
best_loss = initial_loss
best = initial
for record in report['history']:
    order = rng.permutation(data['sampling'])
    for offset in range(0, len(order), 64):
        ids = order[offset:offset + 64]
        _, gradients = model.loss(data['x'][ids], data['y'][ids], True)
        norm = np.sqrt(sum(np.sum(g * g) for g in gradients.values()))
        updates += 1
        for key in KEYS:
            gradient = gradients[key] * min(1., 5 / max(norm, 1e-12))
            first[key] = .9 * first[key] + .1 * gradient
            second[key] = .999 * second[key] + .001 * gradient * gradient
            model.p[key] -= .0005 * (first[key] / (1 - .9 ** updates)) / (np.sqrt(second[key] / (1 - .999 ** updates)) + 1e-8)
        if updates == record['updates']:
            break
    assert updates == record['updates']
    loss, values = validation_loss(model, data, parts)
    assert (loss, values) == (record['loss'], record['parts'])
    if loss < best_loss:
        best_loss = loss
        best = {key: value.copy() for key, value in model.p.items()}
        selected_updates = updates
        selected_epoch = record['epoch']
assert updates == report['newTrainingUpdatesExecuted']
assert selected_updates == report['selectedAdaptationUpdates'] and selected_epoch == report['selectedEpoch']
assert best_loss == report['bestValidationLoss']
saved, metadata = load(stage / 'model.npz')
assert metadata['selectedCheckpointUpdates'] == parent['selectedCheckpointUpdates'] + selected_updates
assert np.array_equal(saved.mean, model.mean) and np.array_equal(saved.scale, model.scale)
with np.load(stage / 'model.npz', allow_pickle=False) as checkpoint:
    for key in KEYS:
        assert np.array_equal(checkpoint['initial__' + key], initial[key])
        assert np.array_equal(saved.p[key], best[key])
result = {'status': 'pass', 'datasetRowsExactlyReconstructed': len(data['x']),
          'newCaptainOutcomeRows': 2512, 'wholeCaptainWordsAndAllPriorValidationFoldsPreserved': True,
          'optimizerUpdatesExactlyReplayed': updates, 'selectedAdaptationUpdatesExactlyReplayed': selected_updates,
          'selectedWeightsExactlyMatch': True, 'normalizationUnchanged': True,
          'checkpointSha256': digest(stage / 'model.npz'), 'verifierSha256': digest(__file__)}
(root / 'verification/training.audit.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result), flush=True)
