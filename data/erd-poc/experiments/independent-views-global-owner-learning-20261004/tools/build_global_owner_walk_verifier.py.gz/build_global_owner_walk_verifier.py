"""Version the closed replay for global support and measure every new action."""
from pathlib import Path
import hashlib
import json


def digest(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


source = Path('.tmp/verify_trained_single_owner_policies.py')
out = Path('.tmp/verify_global_owner_walk.py')
assert not out.exists()
text = source.read_text().split('\ndef static():')[0]
changes = {
    'from run_single_owner_neural_walk_v3 import prepare as cached_prepare,hashes as cached_hashes':
    'from run_single_owner_neural_walk_v4 import prepare as cached_prepare,hashes as cached_hashes',
    "ROOT=Path('.tmp/visualcross-ml-150-750-20261004/single-owner-trained-walk1')":
    "ROOT=Path('.tmp/visualcross-ml-150-750-20261004/single-owner-global-walk1')",
    "for kind in ('walk','cached'):": "for kind in ('global-walk',):",
    "cached=kind=='cached'": 'cached=True',
    'if attempts<=16 or accepted:compare': 'if True:compare',
    "'allModelInputStatesNativeVerified':cached":
    "'allModelInputStatesNativeVerified':cached,'allNewNativeActionScoresIndependentlyRecomputed':True"
}
for old, new in changes.items():
    assert text.count(old) == 1, old
    text = text.replace(old, new)
text += "\nif __name__=='__main__':\n    OUT.mkdir(exist_ok=False);walks()\n"
out.write_text(text)
root = Path('.tmp/visualcross-ml-150-750-20261004/single-owner-global-walk1')
(root / 'verifier-binding.json').write_text(json.dumps({
    'originalVerifierSha256': digest(source), 'globalVerifierSha256': digest(out),
    'originalVerifierUnchanged': True,
    'changes': ['replay the global-support v4 runner and new immutable source binding',
                'check every cached input against full Native features',
                'full-MEASURE every new action plus final exploratory state'],
    'nativeCoordinateProposalsAdded': False
}, indent=2) + '\n')
print(json.dumps({'verifier': str(out), 'sha256': digest(out)}), flush=True)
