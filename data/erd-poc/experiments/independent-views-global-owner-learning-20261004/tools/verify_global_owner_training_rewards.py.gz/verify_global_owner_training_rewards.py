"""Fully remeasure prior global/trajectory labels before using them for learning."""
import hashlib
import json
from pathlib import Path
import sys
import numpy as np
sys.path.insert(0, str(Path('scripts/erd-poc').resolve()))
from run_anchor_pair_policy import Native, digest, wire
from run_anchor_pair_walk import WalkDecoder
from run_single_owner_neural_walk_v2 import cumulative_action
from single_owner_cycle_model import action
from train_anchor_pair_outcomes import outcome_target

root = Path('.tmp/visualcross-ml-150-750-20261004/single-owner-global-walk1')
prior = Path('.tmp/visualcross-ml-150-750-20261004/single-owner-trained-walk1')
out = root / 'training-reward-controls'
out.mkdir(exist_ok=False)
metrics = ('legal', 'reason', 'visual', 'individualVisual', 'hard', 'individualHard', 'spacing')
checks = []
for view in ('individual', 'overview'):
    for kind in ('global', 'walk', 'cached'):
        stage = prior / (view + '-' + kind + '1')
        report = json.loads((stage / 'report.json').read_text())
        source = Path(report['sourceDirectory'])
        assert all(digest(source / name) == sha for name, sha in report['sourceInputs'].items())
        assert digest(report['environment']) == report['environmentSha256']
        assert digest(stage / 'actions.jsonl') == report['actionsSha256']
        static = kind == 'global'
        labels_path = stage / 'labels.npz' if static else prior / 'verification' / (stage.name + '-labels.npz')
        if static:
            assert digest(labels_path) == report['labelsSha256']
        else:
            proof = json.loads((prior / 'verification/walks.audit.json').read_text())
            assert proof['status'] == 'pass'
            proof_row = next(row for row in proof['checks'] if row['stage'] == str(stage))
            assert proof_row['modelScoresSchedulesAndAllActionsReplayed'] == report['newNeuralProposals']
        decoder = WalkDecoder(source)
        control_path = out / (stage.name + '.tsv')
        native = Native(Path(report['environment']), source, control_path, view == 'overview', False)
        current = np.zeros_like(decoder.positions)
        visual = report['initialVisual']
        count = 0
        with np.load(labels_path, allow_pickle=False) as labels:
            assert len(labels['y']) == report.get('attempts', report.get('newNeuralProposals'))
            try:
                for line in (stage / 'actions.jsonl').read_text().splitlines():
                    row = json.loads(line)
                    if 'skipped' in row:
                        continue
                    if static:
                        proposed = action(decoder, np.array(row['cycle']), np.array(row['amplitudes']))
                    else:
                        key = row['ownerDeltaCents']
                        cents = np.rint(current * 100).astype(np.int64)
                        cents[key[0]] += np.array(key[1:])
                        delta = cents.astype(np.float64) / 100
                        proposed = cumulative_action(decoder, delta)
                    assert hashlib.sha256(wire(proposed).encode()).hexdigest() == row['wireSha256']
                    actual = native.request(wire(proposed, 'MEASURE'))
                    assert all(actual[key] == row['result'][key] for key in metrics), (stage.name, count)
                    assert labels['y'][count] == outcome_target(actual, visual)
                    gain = float(visual - actual['visual']) if actual['legal'] else np.nan
                    assert (np.isnan(gain) and np.isnan(labels['actual_gain'][count])) or gain == labels['actual_gain'][count]
                    count += 1
                    if not static and row['walkAdmitted']:
                        current = delta
                        visual = actual['visual']
                assert native.request('SAVE')['saved']
                stats = json.loads(Path(str(control_path) + '.stats.json').read_text())
                assert stats['policyActionsEvaluated'] == stats['acceptedActions'] == 0
                assert (stats['visual'], stats['individualVisual']) == (native.initial['visual'], native.initial['individualVisual'])
            finally:
                native.close()
        check = {'stage': str(stage), 'labels': str(labels_path), 'labelsSha256': digest(labels_path),
                 'reportSha256': digest(stage / 'report.json'), 'readOnlyFullNativeMeasurements': count,
                 'allRewardsRecomputedExactly': True, 'labelsBaselineIsCurrentWalkVisual': not static}
        checks.append(check)
        print(json.dumps(check), flush=True)
result = {'status': 'pass', 'checks': checks,
          'readOnlyFullNativeMeasurements': sum(row['readOnlyFullNativeMeasurements'] for row in checks),
          'newNativeTRYCommands': 0, 'optimizerUpdates': 0, 'verifierSha256': digest(__file__)}
(out / 'audit.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result), flush=True)
