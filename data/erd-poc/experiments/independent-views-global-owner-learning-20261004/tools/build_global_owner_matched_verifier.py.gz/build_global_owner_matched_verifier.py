"""Version the static replay for frozen/trained matched global policies."""
from pathlib import Path
import hashlib
import json


def digest(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


source = Path('.tmp/verify_trained_single_owner_policies.py')
out = Path('.tmp/verify_global_owner_matched.py')
assert not out.exists()
original = source.read_text()
text = original.split('\ndef walks():')[0] + '\ndef static():' + original.split('\ndef static():')[1].split("\nif __name__=='__main__':")[0]
changes = {
    "ROOT=Path('.tmp/visualcross-ml-150-750-20261004/single-owner-trained-walk1')":
    "ROOT=Path('.tmp/visualcross-ml-150-750-20261004/single-owner-global-walk1')",
    "for kind in ('batches','global'):": "for kind in ('frozen','trained'):",
    "batch=kind=='batches'": 'batch=False'
}
for old, new in changes.items():
    assert text.count(old) == 1, old
    text = text.replace(old, new)
text += "\nif __name__=='__main__':\n    assert OUT.is_dir();static()\n"
out.write_text(text)
root = Path('.tmp/visualcross-ml-150-750-20261004/single-owner-global-walk1')
(root / 'matched-verifier-binding.json').write_text(json.dumps({
    'originalVerifierSha256': digest(source), 'matchedVerifierSha256': digest(out),
    'changes': ['new 286/1963 geometry binding',
                'identical frozen/trained vocabulary, source features, Gumbel and proposal budget',
                'replay all NN scores/schedules/geometry and full-MEASURE samples and all strict winners'],
    'allNewNativeScoresIndependentlyRecomputed': False,
    'nativeSearchOrCoordinateProposalsAdded': False
}, indent=2) + '\n')
print(json.dumps({'verifier': str(out), 'sha256': digest(out)}), flush=True)
