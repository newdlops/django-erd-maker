"""Stream-seal new global trajectories, reward learning and matched product gain."""
import ast
import gzip
import hashlib
import json
import re
import shutil
from pathlib import Path

ROOT = Path('.tmp/visualcross-ml-150-750-20261004/single-owner-global-walk1')
ARCHIVE = Path('data/erd-poc/experiments/independent-views-global-owner-learning-20261004')
STABLE = Path('data/erd-poc/candidates/captain-ml-independent-views.layout.json')
OLD = '4c88250bd2dce3ffb85d640c35d11d952664b0358658a0f0b35b94cbccd28688'


def streamed(stream):
    h = hashlib.sha256()
    size = 0
    while block := stream.read(65536):
        h.update(block)
        size += len(block)
    return size, h.hexdigest()


def digest(path):
    with Path(path).open('rb') as stream:
        return streamed(stream)[1]


def restored(path):
    with Path(path).open('rb') as stream:
        compressed = stream.read(2) == b'\x1f\x8b'
    with (gzip.open(path, 'rb') if compressed else Path(path).open('rb')) as stream:
        return streamed(stream)


assert not ARCHIVE.exists() and digest(STABLE) == OLD
audit = json.loads((ROOT / 'combined-best1/audit.json').read_text())
assert (audit['overviewVisual'], audit['individualVisual']) == (285, 1963)
assert audit['models'] == 1244 and audit['canonicalRelationships'] == 1727 and not audit['thresholdsMet']
for key in ('actualProductFileLoadVerified', 'completeIndividualGeometryPreserved',
            'browserRouteFunctionParity', 'roundTripViewSwitchVerified'):
    assert audit[key]
candidate = ROOT / 'combined-best1/candidate.layout.json'
assert digest(candidate) == audit['candidateSha256']
proofs = {name: json.loads((ROOT / 'verification' / (name + '.audit.json')).read_text())
          for name in ('walks', 'training', 'static', 'matched-control')}
assert all(proof['status'] == 'pass' for proof in proofs.values())
assert (proofs['walks']['readOnlyFullNativeMeasurements'], proofs['walks']['fullNativeFeatureControls']) == (255, 85)
assert proofs['static']['readOnlyFullNativeMeasurements'] == 66
training = json.loads((ROOT / 'training1/training.json').read_text())
assert (training['newTrainingUpdatesExecuted'], training['selectedAdaptationUpdates']) == (23488, 734)
names = [view + '-' + kind + '1' for view in ('individual', 'overview') for kind in ('global-walk', 'frozen', 'trained')]
reports = [json.loads((ROOT / name / 'report.json').read_text()) for name in names]
proposals = sum(report.get('newNeuralProposals', report.get('attempts', 0)) for report in reports)
assert proposals == 4349
resources = {'guardLimitMiB': 128, 'limitRaised': False, 'mathThreads': 1, 'niceAdjustment': 10,
             'numericalJobsSerialized': True, 'hardCpuPercentageQuota': False,
             'sampledProcessGroupRss': True, 'logs': []}
for path in sorted(ROOT.glob('*.guard.log')):
    peaks = re.findall(r'memory guard: peak=([0-9.]+) MiB limit=([0-9.]+) MiB', path.read_text())
    assert peaks and all(float(limit) == 128 and float(peak) <= 128 for peak, limit in peaks)
    resources['logs'].append({'path': str(path), 'peakMiB': float(peaks[-1][0])})
(ROOT / 'resources.json').write_text(json.dumps(resources, indent=2) + '\n')
winner = next(row for row in (json.loads(line) for line in (ROOT / 'overview-trained1/actions.jsonl').read_text().splitlines())
              if row['result']['accepted'])
diagnosis = {
    'overviewVisual': 285, 'individualVisual': 1963, 'targetOverview': 150, 'targetIndividual': 750, 'targetMet': False,
    'newNeuralProposals': 4349, 'trajectoryProposals': 253, 'matchedProposals': 4096, 'completedStages': 6,
    'trajectoryAdmittedNeutralStates': 83, 'trajectoryStrictImprovements': 0,
    'newTrainingUpdates': 23488, 'selectedAdaptationUpdates': 734, 'parentSelectedCheckpointUpdates': 13461,
    'selectedCountScope': '734 updates in this adaptation; raw checkpoint marker 14195 adds the immediate parent 13461 and is not an all-ancestor lifetime count',
    'trainedCriticSha256': training['checkpointSha256'], 'parentCriticSha256': training['parentSha256'],
    'trainingDatasetRows': 26064, 'addedCaptainOutcomes': 2512, 'addedCaptainTrainingRows': 1991,
    'newValidationGlobalRows': 438, 'newValidationWalkRows': 83, 'protectedWholeWordsAndGraphsPreserved': True,
    'newTrainingImprovingGlobalRows': 1, 'newTrainingImprovingWalkRows': 0,
    'initialValidationParts': training['initialValidationParts'], 'selectedValidationParts': training['selectedValidationParts'],
    'trainingValidationScope': training['validationScope'], 'winningNeuralScore': winner['score'],
    'winningRank': winner['rank'], 'winningCycle': winner['cycle'], 'winningAmplitudes': winner['amplitudes'],
    'winningWireSha256': winner['wireSha256'], 'frozenParentHasIdenticalWinner': True,
    'learningCausedCaptainGainEstablished': False,
    'allNewTrajectoryScoresIndependentlyFullMeasured': True, 'fullNativeModelInputStateControls': 85,
    'priorTrainingOutcomeFullMeasurements': 2259, 'newTrajectoryFullMeasurementsIncludingFinalStates': 255,
    'matchedStaticFullMeasurementSamples': 66, 'totalReadOnlyFullNativeMeasurements': 2580,
    'allMatchedNativeActionScoresIndependentlyRecomputed': False,
    'effectiveInferenceFeatureInputDtype': 'float32', 'rawTrainedReportDtypeFallbackReconciled': True,
    'futurePolicyV4MetadataFixExecutedForInference': False,
    'nativeBuilds': 0, 'nativeCoordinateSearchOrRepairAdded': False, 'allHistoryWireUniquenessClaimed': False,
    'browserVerified': False, 'globalGeometryFloorEstablished': False,
    'nextDirection': 'bind verified 285/1963; reuse the trained checkpoint without rerunning closed schedules; consider lower-temperature global cumulative policies and further protected outcome learning'
}
(ROOT / 'diagnosis.json').write_text(json.dumps(diagnosis, indent=2) + '\n')
snapshot = ROOT / 'promotion-before'
snapshot.mkdir(exist_ok=False)
for suffix in ('layout.json', 'audit.json', 'provenance.json'):
    path = STABLE.with_name('captain-ml-independent-views.' + suffix)
    shutil.copyfile(path, snapshot / path.name)
entries = {str(path): Path('run') / path.relative_to(ROOT) for path in ROOT.rglob('*') if path.is_file()}
scripts = Path('scripts/erd-poc')
pending = ['run_single_owner_neural_walk_v4.py', 'train_single_owner_cycle_model_v3.py',
           'run_single_owner_cycle_policy_v3.py', 'run_single_owner_cycle_policy_v4.py', 'run_memory_bounded.py']
for name in ('prepare_global_owner_walk.py', 'build_global_owner_walk_verifier.py', 'verify_global_owner_walk.py',
             'verify_global_owner_training_rewards.py', 'verify_global_owner_learning.py',
             'build_global_owner_matched_verifier.py', 'verify_global_owner_matched.py', 'run_global_owner_matched.py',
             'audit_global_owner_control.py', 'prepare_global_owner_product.py', 'seal_global_owner_learning.py',
             'verify_global_owner_archive.py', 'promote_global_owner_learning.py'):
    path = Path('.tmp') / name
    assert path.is_file()
    entries[str(path)] = Path('tools') / name
    for node in ast.walk(ast.parse(path.read_text())):
        if isinstance(node, ast.ImportFrom) and node.module and (scripts / (node.module + '.py')).is_file():
            pending.append(node.module + '.py')
seen = set()
while pending:
    name = pending.pop()
    if name in seen:
        continue
    seen.add(name)
    path = scripts / name
    entries[str(path)] = Path('code') / name
    for node in ast.walk(ast.parse(path.read_text())):
        modules = [node.module] if isinstance(node, ast.ImportFrom) else [item.name for item in node.names] if isinstance(node, ast.Import) else []
        for module in modules:
            if module and (scripts / (module + '.py')).is_file():
                pending.append(module + '.py')
for name in ('apply_learned_single_owner_components.cjs', 'audit_leaf_card_connections.cjs', 'compose_independent_views_memory_bounded.cjs'):
    entries[str(scripts / name)] = Path('code') / name
deps = {'data/erd-poc/recovered/captain-2026-09-15-payload.json', audit['individualSource']}
for report in reports:
    deps.update((report['checkpoint'], report['environment']))
    deps.update(str(Path(report['sourceDirectory']) / name) for name in report['sourceInputs'])
deps.update(str(Path(audit['individualSource']).parent / name) for name in ('individual.audit.json', 'workflow.audit.json'))
deps.update(str(Path(training['parentDatasetDirectory']) / name) for name in
            json.loads((Path(training['parentDatasetDirectory']) / 'dataset-index.json').read_text()))
deps.add(str(Path(training['parentDatasetDirectory']) / 'dataset-index.json'))
for source in training['sourceStages']:
    deps.update((source['path'], source['labels']))
prior = Path('.tmp/visualcross-ml-150-750-20261004/single-owner-trained-walk1')
deps.update(str(prior / relative) for relative in
            ('source-binding.json', 'overview-product1/candidate.layout.json', 'overview-product1/product.audit.json',
             'observer-probe2/probe.audit.json', 'verification/walks.audit.json', 'verification/static.audit.json'))
native = Path('.tmp/visualcross-ml-150-750-20261003/pair-neutral-walk1')
deps.add(str(native / 'build-inputs.json'))
deps.update(str(path) for path in (native / 'build-inputs').iterdir() if path.is_file())
for item in json.loads((ROOT / 'combined-best1/product-code-bindings.json').read_text())['loadedCommonJsModules']:
    path = Path(item['path'])
    assert digest(path) == item['sha256']
    deps.add(str(path))
    if path.parts[0] == 'out':
        typed = Path('src').joinpath(*path.parts[1:]).with_suffix('.ts')
        if typed.is_file():
            deps.add(str(typed))
for source in deps:
    entries.setdefault(source, Path('dependencies') / digest(source) / Path(source).name)
parents = {
    'data/erd-poc/experiments/independent-views-trained-owner-policies-20261004/manifest.json': '5a24ded20b6c2feec46b7d11f2911d9673052dece55c59762e8162e487e32f16',
    'data/erd-poc/experiments/independent-views-single-owner-learning-20261004/manifest.json': '6b9b97a2aafd690eed135ce561091e0b98b29758ee70ba73fbeb397a1a956298'
}
known = {}
expected = dict(parents)
for filename, sha in parents.items():
    parent_path = Path(filename)
    assert digest(parent_path) == sha
    parent = json.loads(parent_path.read_text())
    for item in parent['prerequisiteManifests']:
        expected[item['path']] = item['sha256']
    for item in parent['files']:
        known.setdefault(item['sha256'], (parent_path.parent / item['archive'], item['bytes'], filename))
    for item in parent['referencedFiles']:
        known.setdefault(item['sha256'], (Path(item['archive']), item['bytes'], item['prerequisiteManifest']))
ARCHIVE.mkdir(parents=True)
files = []
references = []
reused = {}
checked = set()
required = set(parents)
for source, relative in sorted(entries.items()):
    path = Path(source)
    size = path.stat().st_size
    sha = digest(path)
    if sha in known:
        stored, original_size, prerequisite = known[sha]
        assert size == original_size
        if sha not in checked:
            assert restored(stored) == (size, sha)
            checked.add(sha)
        required.add(prerequisite)
        references.append({'source': source, 'archive': str(stored), 'bytes': size, 'sha256': sha,
                           'prerequisiteManifest': prerequisite, 'restoreHashVerified': True})
        continue
    if sha in reused:
        stored, packed = reused[sha]
    else:
        stored = Path(str(relative) + '.gz')
        destination = ARCHIVE / stored
        destination.parent.mkdir(parents=True, exist_ok=True)
        with destination.open('xb') as output, gzip.GzipFile(filename='', mode='wb', compresslevel=1, mtime=0, fileobj=output) as compressed, path.open('rb') as original:
            while block := original.read(65536):
                compressed.write(block)
        assert restored(destination) == (size, sha)
        packed = destination.stat().st_size
        reused[sha] = stored, packed
    files.append({'source': source, 'archive': str(stored), 'bytes': size, 'sha256': sha, 'compressedBytes': packed})
assert digest(STABLE) == OLD
prerequisites = []
for filename in sorted(required):
    assert digest(filename) == expected[filename]
    prerequisites.append({'path': filename, 'sha256': expected[filename]})
manifest = {
    'scope': 'global NN trajectories, fully checked Captain reward adaptation, matched control and verified 285/1963 product',
    'previousCandidateSha256': OLD, 'candidateSha256': digest(candidate), 'candidateSource': str(candidate),
    'previousBestSnapshot': str(snapshot), 'overviewVisual': 285, 'individualVisual': 1963,
    'targetOverview': 150, 'targetIndividual': 750, 'targetMet': False,
    'fullModelsPerView': 1244, 'fullRelationshipsPerView': 1727,
    'modelSelectedAllGeometry': True, 'nativeSearchOrCoordinateRepairs': 0,
    'newNeuralProposals': 4349, 'newTrainingUpdates': 23488, 'selectedAdaptationUpdates': 734,
    'trainedCriticSha256': training['checkpointSha256'],
    'productAudit': audit, 'verification': proofs, 'diagnosis': diagnosis, 'resources': resources,
    'browserVerified': False, 'prerequisiteManifests': prerequisites, 'files': files, 'referencedFiles': references,
    'newPhysicalCompressedFiles': len(reused), 'newPhysicalCompressedBytes': sum(item[1] for item in reused.values()),
    'allCompressedAndReferencedBytesRestoreHashVerified': True, 'sourcesUnchangedAtSeal': True
}
path = ARCHIVE / 'manifest.json'
path.write_text(json.dumps(manifest, indent=2) + '\n')
result = {'manifest': str(path), 'manifestSha256': digest(path), 'candidateSha256': digest(candidate),
          'newPhysicalCompressedFiles': len(reused), 'newPhysicalCompressedBytes': manifest['newPhysicalCompressedBytes'],
          'newMappings': len(files), 'referencedMappings': len(references)}
receipt = Path('.tmp/global-owner-learning-archive-seal-receipt.json')
assert not receipt.exists()
receipt.write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result), flush=True)
