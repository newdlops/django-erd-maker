"""Seal owner-amplitude learning, actual failures, and terminal diagnostics."""
from pathlib import Path
import ast
import gzip
import hashlib
import json
import re

root = Path('.tmp/visualcross-ml-150-750-20261004/owner-amplitude-cycles1')
archive = Path('data/erd-poc/experiments/independent-views-owner-amplitudes-20261004-v2')
assert not archive.exists()
sha = lambda data: hashlib.sha256(data).hexdigest()
def payload_hash(stream):
    h = hashlib.sha256(); size = 0
    while block := stream.read(65536): h.update(block); size += len(block)
    return size, h.hexdigest()

def digest(path):
    with Path(path).open('rb') as stream: return payload_hash(stream)[1]

def restored_hash(path):
    with Path(path).open('rb') as stream: compressed = stream.read(2) == b'\x1f\x8b'
    with (gzip.open(path, 'rb') if compressed else Path(path).open('rb')) as stream: return payload_hash(stream)
training = json.loads((root/'training2/training.json').read_text())
training_check = json.loads((root/'training-verification.json').read_text())
actions_check = json.loads((root/'actions-verification.json').read_text())
assert training_check['status'] == actions_check['status'] == 'pass'
assert actions_check['readOnlyFullScoringActions'] == 4224
assert actions_check['CaptainActionsReplayed'] == 8192 and actions_check['CaptainStrictImprovements'] == 0
assert digest(root/'training2/model.npz') == training['checkpointSha256']
actual = []
for view in ['individual', 'overview']:
    for suffix in ['transfer1', 'mixed-transfer2', 'mixed-trained1', 'mixed-global1']:
        stage = root/(view+'-'+suffix); record = json.loads((stage/'report.json').read_text())
        assert record['attempts'] == 1024 and record['accepted'] == 0
        assert record['final']['hardConditions'] == record['final']['individualHardConditions'] == 0
        assert record['final']['overlap'] == record['final']['spacing'] == 0
        actual.append({'stage': str(stage), 'view': view, 'actionFamily': suffix,
            'attempts': record['attempts'], 'accepted': record['accepted'], 'legal': record['reasons']['legal'],
            'legalTies': record['legalTies'], 'reasons': record['reasons'],
            'finalVisual': record['final']['visual'], 'centroidChangingActions': record['proposalsChangingRawTripletCentroid'],
            'checkpointSha256': record['checkpointSha256'], 'wallSeconds': record['wallSeconds']})
        source = Path(record['sourceDirectory'])
        assert len((source/'individual.nodes.tsv').read_text().splitlines()) == 1244
        assert len((source/'individual.edges.tsv').read_text().splitlines()) == 1727
resources = {'memoryGuardLimitMiB': 128, 'numericalJobsSerialized': True, 'mathThreads': 1,
    'niceAdjustment': 10, 'hardCpuPercentageQuota': False, 'guardUsesSampledProcessGroupRss': True,
    'limitRaised': False, 'guardLogs': []}
for log in sorted(root.rglob('*.log')):
    matches = re.findall(r'memory guard: peak=([0-9.]+) MiB limit=([0-9.]+) MiB', log.read_text())
    if matches: resources['guardLogs'].append({'path': str(log), 'peakMiB': float(matches[-1][0]), 'limitMiB': float(matches[-1][1])})
resources['interruptedFloat64Training'] = json.loads((root/'training1-failure.json').read_text())
resources['earlyCompatibilityFailure'] = json.loads((root/'mixed-transfer1-failure.json').read_text())
resources['interruptedSeal'] = json.loads((root/'sealing1-failure.json').read_text())
(root/'resources2.json').write_text(json.dumps(resources, indent=2)+'\n')
diagnosis = {'actualCaptainStages': actual, 'retainedOverviewVisual': 289, 'retainedIndividualVisual': 1964,
    'newNeuralNativeProposals': 12288, 'actualCaptainProposals': 8192, 'newMixedSyntheticProposals': 4096,
    'newMixedSyntheticImprovingActions': 612, 'CaptainStrictImprovements': 0,
    'failedCompatibilityProposals': 0, 'failedTrainingProducedCheckpoint': False,
    'nonuniformAmplitudeSpace': '18 sign-or-zero patterns at each of five common magnitudes; 90 vectors; not independent continuous magnitudes',
    'centroidPreservationRestrictionRemoved': True, 'mixedSizeSupportRestrictionRemoved': True,
    'globalDistanceSupportTested': True, 'nativeSearchOrCoordinateRepairs': 0,
    'frozenTrainedLocalNodesVocabularyAndNoiseMatched': True,
    'frozenTrainedLocalRepeatedWires': actions_check['frozenTrainedLocalRepeatedWireCounts'],
    'inputPrecisionOnlyControls': actions_check['inputPrecisionOnlyControls'],
    'CaptainAndNegativeValidationRegressed': True, 'positiveValidationRecoveredPartially': True,
    'positiveValidationStillWorseThanOriginalPositiveCritic': True,
    'newFixtureDistributionRepresentsCaptain': False, 'individualCaptainPhysicalOwnersAlreadySingletons': True,
    'globalGeometryFloorEstablished': False, 'targetMet': False, 'browserVerified': False,
    'nextDirection': 'Learn a richer action space or Captain-relevant fixture distribution; retain the original positive critic and graph fold; do not repeat these unchanged trials'}
assert json.loads((root/'diagnosis.json').read_text()) == diagnosis
stable = Path('data/erd-poc/candidates/captain-ml-independent-views.layout.json'); stable_sha = digest(stable)
assert stable_sha == 'da2317d3d9fe72181587f543843bfdde3cc7030ca328e93c4f627ae21ec356e7'
provenance = Path('data/erd-poc/candidates/captain-ml-independent-views.provenance.json')
before = provenance.read_text(); doc = json.loads(before); assert doc['candidateSha256'] == stable_sha
assert (root/'promotion-provenance-before.json').read_text() == before
entries = {str(p): Path('run')/p.relative_to(root) for p in sorted(root.rglob('*')) if p.is_file()}
scripts = Path('scripts/erd-poc')
pending = ['owner_amplitude_cycle_model.py', 'run_owner_amplitude_cycles.py', 'synthetic_owner_amplitude_curriculum.py',
    'mixed_size_owner_cycles.py', 'run_mixed_size_owner_cycles.py', 'mixed_size_synthetic_fixture.py',
    'synthetic_mixed_size_owner_curriculum.py', 'train_balanced_owner_amplitude_model.py',
    'float32_input_owner_model.py', 'train_balanced_owner_amplitude_model_v2.py',
    'run_float32_mixed_owner_cycles.py', 'global_mixed_owner_support.py', 'run_global_mixed_owner_cycles.py',
    'run_memory_bounded.py']
for name in ['verify_owner_amplitude_records.py', 'seal_owner_amplitude_research.py', 'seal_owner_amplitude_research_v2.py', 'verify_owner_amplitude_archive.py']:
    path = Path('.tmp')/name; tree = ast.parse(path.read_text()); entries[str(path)] = Path('tools')/name
    for node in ast.walk(tree):
        if isinstance(node, ast.ImportFrom) and node.module and (scripts/(node.module+'.py')).is_file(): pending.append(node.module+'.py')
seen = set()
while pending:
    name = pending.pop()
    if name in seen: continue
    seen.add(name); path = scripts/name; entries[str(path)] = Path('code')/name
    for node in ast.walk(ast.parse(path.read_text())):
        modules = [node.module] if isinstance(node, ast.ImportFrom) else [item.name for item in node.names] if isinstance(node, ast.Import) else []
        for module in modules:
            if module and (scripts/(module+'.py')).is_file(): pending.append(module+'.py')
dependencies = {training['parent'], training['datasetPath'], str(stable),
    'data/erd-poc/candidates/captain-ml-independent-views.audit.json'}
for item in training['sourceStages']:
    path = Path(item['path']); report = json.loads(path.read_text()); stage = path.parent
    dependencies.update(str(p) for p in stage.iterdir() if p.is_file())
    source = Path(report['sourceDirectory']); dependencies.update(str(source/n) for n in report['sourceInputs'])
    dependencies.update([report['checkpoint'], report['environment']])
    if (source/'fixture.json').is_file(): dependencies.add(str(source/'fixture.json'))
for stage in sorted((root/'mixed-curriculum1').glob('graph-*/*/report.json')):
    report = json.loads(stage.read_text()); dependencies.add(report['environment'])
for item in actual:
    report = json.loads((Path(item['stage'])/'report.json').read_text())
    dependencies.add(report['environment']); dependencies.update(str(Path(report['sourceDirectory'])/n) for n in report['sourceInputs'])
for source in dependencies:
    if source not in entries: entries[source] = Path('dependencies')/digest(source)/Path(source).name
prior = {}; manifest_hashes = {}
for path in [archive.parent/'independent-views-signed-cycles-20261003/manifest.json',
             archive.parent/'independent-views-positive-cycles-20261003/manifest.json']:
    manifest_hashes[str(path)] = digest(path); old = json.loads(path.read_text())
    for item in old.get('files', []):
        stored = item.get('archive', item.get('stored'))
        if stored is not None: prior[item['sha256']] = (path.parent/stored, item['bytes'], str(path))
    for item in old.get('referencedFiles', []):
        prior.setdefault(item['sha256'], (Path(item['archive']), item['bytes'], str(path)))
# Retain the interrupted archive and recover only complete, matching byte objects.
partial = archive.parent/'independent-views-owner-amplitudes-20261004'
index_path = Path('.tmp/owner-amplitude-seal-partial-index.json'); assert not index_path.exists()
partial_files = []; incomplete = []; partial_seen = set()
for source, relative in sorted(entries.items()):
    stored = partial/Path(str(relative)+'.gz')
    if not stored.is_file() or str(stored) in partial_seen: continue
    partial_seen.add(str(stored))
    expected = (Path(source).stat().st_size, digest(source))
    try: observed = restored_hash(stored)
    except (OSError, EOFError): incomplete.append(str(stored)); continue
    if observed != expected: incomplete.append(str(stored)); continue
    item = {'source': source, 'archive': str(stored), 'sha256': expected[1], 'bytes': expected[0]}
    partial_files.append(item); prior.setdefault(expected[1], (stored, expected[0], str(index_path)))
index_path.write_text(json.dumps({'status': 'byte objects verified; enclosing seal was interrupted',
    'archiveManifestProduced': False, 'partialFiles': partial_files, 'incompleteOrMismatchedFilesRetained': incomplete}, indent=2)+'\n')
manifest_hashes[str(index_path)] = digest(index_path)
entries[str(index_path)] = Path('diagnostics')/index_path.name
archive.mkdir(parents=True); files = []; references = []; reused = {}; restored_hashes = set(); required = set()
for source, relative in sorted(entries.items()):
    size = Path(source).stat().st_size; source_sha = digest(source)
    if source_sha in prior:
        stored, expected_size, prerequisite = prior[source_sha]; assert expected_size == size
        if source_sha not in restored_hashes:
            assert restored_hash(stored) == (size, source_sha); restored_hashes.add(source_sha)
        required.add(prerequisite)
        references.append({'source': source, 'archive': str(stored), 'sha256': source_sha, 'bytes': size,
            'prerequisiteManifest': prerequisite, 'restoreHashVerified': True}); continue
    if source_sha in reused: stored, packed_bytes = reused[source_sha]
    else:
        stored = Path(str(relative)+'.gz'); destination = archive/stored; destination.parent.mkdir(parents=True, exist_ok=True)
        with destination.open('xb') as output:
            with gzip.GzipFile(filename='', mode='wb', compresslevel=1, mtime=0, fileobj=output) as compressed:
                with Path(source).open('rb') as original:
                    while block := original.read(65536): compressed.write(block)
        assert restored_hash(destination) == (size, source_sha)
        packed_bytes = destination.stat().st_size; reused[source_sha] = (stored, packed_bytes)
    files.append({'source': source, 'archive': str(stored), 'sha256': source_sha, 'bytes': size, 'compressedBytes': packed_bytes})
assert digest(stable) == stable_sha and provenance.read_text() == before
manifest = {'completedObjectsRecoveredFromInterruptedSeal': len(partial_files),
    'incompleteOrMismatchedPartialFilesRetained': incomplete,
    'scope': 'Per-owner sign-or-zero partial moves, mixed sizes, fresh mixed fixtures, balanced positive replay, float32 input pipeline, local/global Captain evaluations and bounded CLI evidence',
    'retainedCandidate': str(stable), 'retainedCandidateSha256': stable_sha, 'promotedCandidateChanged': False,
    'overviewVisual': 289, 'individualVisual': 1964, 'targetOverview': 150, 'targetIndividual': 750, 'targetMet': False,
    'fullModelsPerView': 1244, 'fullRelationshipsPerView': 1727, 'sourceSizesAndCanonicalRelationshipsUnchanged': True,
    'trainedCheckpoint': str(root/'training2/model.npz'), 'trainedCheckpointSha256': training['checkpointSha256'],
    'newTrainingUpdates': training['newTrainingUpdatesExecuted'], 'selectedCheckpointUpdates': training['selectedCheckpointUpdates'],
    'trainingRows': training['trainingRows'], 'mixedDatasetRows': training['rows'], 'rowsByKind': training['rowsByKind'],
    'trainingImprovingExamplesByKind': training['improvingTrainingExamplesByKind'],
    'uniformValidationGraphs': training['uniformValidationGraphs'], 'mixedValidationGraphs': training['mixedValidationGraphs'],
    'initialValidationParts': training['initialValidationParts'], 'selectedValidationParts': training['selectedValidationParts'],
    'newNativeModelActions': 12288, 'syntheticModelActions': 4096, 'CaptainModelActions': 8192,
    'CaptainStrictImprovements': 0, 'syntheticImprovingActions': 612, 'readOnlyFullScoringActions': 4224,
    'allNewSyntheticLabelsIndependentlyFullScored': True, 'CaptainFullScoringSampleActions': 128,
    'allCaptainNativeScoresRecomputed': False, 'optimizerHistoryIndependentlyReplayed': False,
    'unexecutedScaffolds': ['scripts/erd-poc/synthetic_owner_amplitude_curriculum.py'],
    'nativeSearchOrCoordinateRepairs': 0, 'newProductCandidates': 0, 'browserVerified': False,
    'trainingVerification': training_check, 'actionsVerification': actions_check, 'diagnosis': diagnosis, 'resources': resources,
    'cliReportedDecodeErrorRootCauseConfirmed': False, 'cliRecoveryExecuted': False,
    'prerequisiteManifests': [{'path': p, 'sha256': manifest_hashes[p]} for p in sorted(required)],
    'referencedFiles': references, 'referencedLogicalBytes': sum(i['bytes'] for i in references),
    'allReferencedBytesRestoreHashVerified': True, 'newPhysicalCompressedFiles': len(reused),
    'newPhysicalCompressedBytes': sum(v[1] for v in reused.values()), 'logicalFiles': len(files),
    'logicalBytes': sum(i['bytes'] for i in files), 'identicalCurrentFilesShareStoredBytes': True,
    'allCompressedFilesRoundTripHashVerified': True, 'files': files}
path = archive/'manifest.json'; path.write_text(json.dumps(manifest, indent=2)+'\n'); manifest_sha = digest(path)
assert all(i['archiveManifest'] != str(path) for i in doc['subsequentResearchArchives'])
doc['subsequentResearchArchives'].append({'archiveManifest': str(path), 'archiveManifestSha256': manifest_sha,
    'promotedCandidateChanged': False, 'retainedCandidateSha256': stable_sha, 'overviewVisual': 289, 'individualVisual': 1964,
    'newNetworkTrainingUpdates': training['newTrainingUpdatesExecuted'], 'selectedCheckpointUpdates': training['selectedCheckpointUpdates'],
    'actualImprovingTrainingExamples': sum(training['improvingTrainingExamplesByKind'].values()),
    'nativeModelActions': 12288, 'readOnlyFullScoringComparisons': 4224, 'CaptainStrictImprovements': 0,
    'targetMet': False, 'browserVerified': False})
assert provenance.read_text() == before; provenance.write_text(json.dumps(doc, indent=2)+'\n')
result = {'manifest': str(path), 'manifestSha256': manifest_sha, 'logicalFiles': len(files),
    'logicalBytes': manifest['logicalBytes'], 'newPhysicalCompressedFiles': len(reused),
    'newPhysicalCompressedBytes': manifest['newPhysicalCompressedBytes'], 'referencedFiles': len(references),
    'referencedLogicalBytes': manifest['referencedLogicalBytes'], 'promotedCandidateUnchanged': True}
receipt = Path('.tmp/owner-amplitude-archive-seal-receipt.json'); assert not receipt.exists()
receipt.write_text(json.dumps(result, indent=2)+'\n'); print(json.dumps(result), flush=True)
