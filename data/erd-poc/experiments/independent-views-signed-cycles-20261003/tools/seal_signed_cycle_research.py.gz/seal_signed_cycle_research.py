"""Seal signed action learning, its limitations, and bounded terminal evidence."""
from pathlib import Path
import ast
import gzip
import hashlib
import json

root = Path('.tmp/visualcross-ml-150-750-20261003/signed-cycle-transfer1')
archive = Path('data/erd-poc/experiments/independent-views-signed-cycles-20261003'); assert not archive.exists()
sha = lambda data: hashlib.sha256(data).hexdigest()
digest = lambda path: sha(Path(path).read_bytes())
training = json.loads((root/'training2/training.json').read_text())
verification = json.loads((root/'records-verification.json').read_text())
diagnosis = json.loads((root/'diagnosis.json').read_text()); resources = json.loads((root/'resources.json').read_text())
assert verification['status'] == 'pass' and verification['readOnlyNativeFullScoringActions'] == 4160
assert verification['CaptainActionsReplayed'] == 4096 and verification['CaptainStrictImprovements'] == 0
assert training['checkpointSha256'] == digest(root/'training2/model.npz')
stable = Path('data/erd-poc/candidates/captain-ml-independent-views.layout.json'); stable_sha = digest(stable)
assert stable_sha == 'da2317d3d9fe72181587f543843bfdde3cc7030ca328e93c4f627ae21ec356e7'
provenance = Path('data/erd-poc/candidates/captain-ml-independent-views.provenance.json')
before = provenance.read_text(); doc = json.loads(before); assert doc['candidateSha256'] == stable_sha
assert not (root/'promotion-provenance-before.json').exists()
(root/'promotion-provenance-before.json').write_text(before)
entries = {str(p): Path('run')/p.relative_to(root) for p in sorted(root.rglob('*')) if p.is_file()}
scripts = Path('scripts/erd-poc'); pending = ['signed_cycle_model.py', 'run_signed_cycle_policy.py',
    'run_trained_signed_cycle_policy.py', 'synthetic_signed_cycle_curriculum.py', 'signed_trained_critic.py',
    'train_signed_cycle_model.py', 'train_signed_cycle_model_v2.py', 'synthetic_cycle_curriculum.py', 'run_memory_bounded.py']; seen = set()
while pending:
    name = pending.pop()
    if name in seen: continue
    seen.add(name); path = scripts/name; entries[str(path)] = Path('code')/name
    for node in ast.walk(ast.parse(path.read_text())):
        modules = [node.module] if isinstance(node, ast.ImportFrom) else [item.name for item in node.names] if isinstance(node, ast.Import) else []
        for module in modules:
            if module and (scripts/(module+'.py')).is_file(): pending.append(module+'.py')
for name in ['verify_signed_cycle_records.py', 'seal_signed_cycle_research.py']:
    path = Path('.tmp')/name; ast.parse(path.read_text()); entries[str(path)] = Path('tools')/name
cli = Path('.tmp/cli-transport-terminal-reply-20261003.json'); entries[str(cli)] = Path('diagnostics')/cli.name
dependencies = {training['parent'], training['datasetPath'], training['positiveValidationDataset'], str(stable),
    'data/erd-poc/candidates/captain-ml-independent-views.audit.json',
    str(Path(training['parent']).parent/'metadata-normalization.json')}
for report_path in sorted((root/'curriculum1').glob('graph-*/*/report.json')):
    report = json.loads(report_path.read_text()); source = Path(report['sourceDirectory'])
    dependencies.add(report['environment']); dependencies.update(str(source/n) for n in report['sourceInputs'])
    dependencies.add(str(source/'fixture.json'))
for view in ['individual', 'overview']:
    for suffix in ['local1', 'trained1']:
        report = json.loads((root/(view+'-'+suffix)/'report.json').read_text())
        dependencies.add(report['environment']); dependencies.update(str(Path(report['sourceDirectory'])/n) for n in report['sourceInputs'])
for source in dependencies:
    if source not in entries: entries[source] = Path('dependencies')/digest(source)/Path(source).name

prior = {}; manifest_hashes = {}
for path in sorted(archive.parent.glob('independent-views-*-20261003/manifest.json')):
    manifest_hashes[str(path)] = digest(path); old = json.loads(path.read_text())
    for item in old.get('files', []):
        stored = item.get('archive', item.get('stored'))
        if stored is not None: prior[item['sha256']] = (path.parent/stored, item['bytes'], str(path))
    for item in old.get('referencedFiles', []):
        prior.setdefault(item['sha256'], (Path(item['archive']), item['bytes'], str(path)))
archive.mkdir(parents=True); files = []; referenced = []; reused = {}; restored_hashes = set(); required = set()
for source, relative in sorted(entries.items()):
    data = Path(source).read_bytes(); source_sha = sha(data)
    if source_sha in prior:
        stored, size, manifest = prior[source_sha]; assert size == len(data)
        if source_sha not in restored_hashes:
            packed = stored.read_bytes(); restored = gzip.decompress(packed) if packed[:2] == b'\x1f\x8b' else packed
            assert sha(restored) == source_sha and len(restored) == len(data); restored_hashes.add(source_sha)
        required.add(manifest)
        referenced.append({'source': source, 'archive': str(stored), 'sha256': source_sha, 'bytes': len(data),
                           'prerequisiteManifest': manifest, 'restoreHashVerified': True}); continue
    if source_sha in reused:
        stored, packed_bytes = reused[source_sha]
    else:
        stored = Path(str(relative)+'.gz'); destination = archive/stored; destination.parent.mkdir(parents=True, exist_ok=True)
        packed = gzip.compress(data, compresslevel=1, mtime=0); destination.write_bytes(packed)
        assert gzip.decompress(destination.read_bytes()) == data
        packed_bytes = len(packed); reused[source_sha] = (stored, packed_bytes)
    files.append({'source': source, 'archive': str(stored), 'sha256': source_sha, 'bytes': len(data), 'compressedBytes': packed_bytes})
assert digest(stable) == stable_sha and provenance.read_text() == before
manifest = {'scope': 'signed action compatibility, negative synthetic learning, inherited whole-graph holdout, matched frozen/trained Captain policies and bounded CLI transport evidence',
    'retainedCandidate': str(stable), 'retainedCandidateSha256': stable_sha, 'promotedCandidateChanged': False,
    'overviewVisual': 289, 'individualVisual': 1964, 'targetOverview': 150, 'targetIndividual': 750, 'targetMet': False,
    'fullModelsPerView': 1244, 'fullRelationshipsPerView': 1727, 'sourceSizesAndCanonicalRelationshipsUnchanged': True,
    'trainedSignedCheckpoint': str(root/'training2/model.npz'), 'trainedSignedCheckpointSha256': training['checkpointSha256'],
    'newTrainingUpdates': training['newTrainingUpdatesExecuted'], 'selectedCheckpointUpdates': training['selectedCheckpointUpdates'],
    'trainingRows': training['trainingRows'], 'mixedDatasetRows': training['rows'], 'signedSyntheticRows': 4096,
    'actualImprovingTrainingExamples': 255, 'signedWholeGraphValidationPositiveExamples': 70,
    'wholeSyntheticValidationGraphs': training['validationGraphs'], 'newNativeModelActions': 8192,
    'signedSyntheticActions': 4096, 'CaptainFrozenActions': 2048, 'CaptainTrainedActions': 2048,
    'CaptainStrictImprovements': 0, 'readOnlyNativeFullScoringActions': 4160,
    'allSignedSyntheticSparseLabelParityVerified': True, 'allCaptainNativeScoresRecomputed': False,
    'CaptainFullScoringSampleActions': 64, 'signedSyntheticImprovingActions': 325,
    'frozenTrainedVocabularyAndNoiseMatched': True, 'frozenTrainedRepeatedWires': verification['frozenTrainedRepeatedWireCounts'],
    'initialValidationParts': training['initialValidationParts'], 'selectedValidationParts': training['selectedValidationParts'],
    'positiveValidationRegressionObserved': True, 'optimizerHistoryIndependentlyReplayed': False,
    'nativeSearchOrCoordinateRepairCalls': 0, 'newProductCandidates': 0, 'browserVerified': False,
    'recordsVerification': verification, 'diagnosis': diagnosis, 'resources': resources,
    'cliRootCauseConfirmed': False, 'cliSettingsOrAuthenticationChanged': False,
    'prerequisiteManifests': [{'path': name, 'sha256': manifest_hashes[name]} for name in sorted(required)],
    'referencedFiles': referenced, 'referencedLogicalBytes': sum(i['bytes'] for i in referenced),
    'allReferencedBytesRestoreHashVerified': True, 'newPhysicalCompressedFiles': len(reused),
    'newPhysicalCompressedBytes': sum(v[1] for v in reused.values()), 'logicalFiles': len(files),
    'logicalBytes': sum(i['bytes'] for i in files), 'identicalCurrentFilesShareStoredBytes': True,
    'allCompressedFilesRoundTripHashVerified': True, 'files': files}
path = archive/'manifest.json'; path.write_text(json.dumps(manifest, indent=2)+'\n'); manifest_sha = digest(path)
assert all(i['archiveManifest'] != str(path) for i in doc['subsequentResearchArchives'])
doc['subsequentResearchArchives'].append({'archiveManifest': str(path), 'archiveManifestSha256': manifest_sha,
    'promotedCandidateChanged': False, 'retainedCandidateSha256': stable_sha, 'overviewVisual': 289, 'individualVisual': 1964,
    'newNetworkTrainingUpdates': training['newTrainingUpdatesExecuted'], 'selectedCheckpointUpdates': training['selectedCheckpointUpdates'],
    'actualImprovingTrainingExamples': 255, 'nativeModelActions': 8192, 'readOnlyFullScoringComparisons': 4160,
    'CaptainStrictImprovements': 0, 'targetMet': False, 'browserVerified': False})
assert provenance.read_text() == before; provenance.write_text(json.dumps(doc, indent=2)+'\n')
print(json.dumps({'manifest': str(path), 'manifestSha256': manifest_sha, 'logicalFiles': len(files),
    'logicalBytes': manifest['logicalBytes'], 'newPhysicalCompressedFiles': len(reused),
    'newPhysicalCompressedBytes': manifest['newPhysicalCompressedBytes'], 'referencedFiles': len(referenced),
    'referencedLogicalBytes': manifest['referencedLogicalBytes'], 'allStoredAndReferencedBytesVerified': True,
    'promotedCandidateUnchanged': True}), flush=True)
