"""Reconstruct signed learning and independently measure saved neural actions."""
import sys
from pathlib import Path
sys.path.insert(0, str(Path('scripts/erd-poc').resolve()))
import gc
import hashlib
import json
import zipfile
from contextlib import redirect_stdout
from io import StringIO
from types import SimpleNamespace
import numpy as np
from directed_cycle_model import KEYS
from fractional_cycle_model import load as parent_load
from learned_global_replay import INPUT_FILES
from run_anchor_pair_policy import Native, wire, digest
from run_anchor_pair_walk import WalkDecoder, verify_saved
from run_directed_cycle_policy import coordinated_cycles
from run_fraction_conditioned_policy import sample_order
from run_signed_cycle_policy import replay as replay_frozen, motion_check
from run_trained_signed_cycle_policy import replay as replay_trained
from signed_cycle_model import FRACTIONS, rank
from signed_trained_critic import load
from synthetic_signed_cycle_curriculum import code_hashes, features
from train_anchor_pair_outcomes import outcome_target
from train_signed_cycle_model_v2 import collect, validation_loss, hashes

root = Path('.tmp/visualcross-ml-150-750-20261003/signed-cycle-transfer1')
report_path = root/'records-verification.json'; assert not report_path.exists()
training = json.loads((root/'training2/training.json').read_text())
assert hashes() == training['codeSha256'] and digest(root/'training2/model.npz') == training['checkpointSha256']
parent, metadata = parent_load(Path(training['parent']))
args = SimpleNamespace(parent=Path(training['parent']), captain=Path(training['datasetPath']),
    source=root/'curriculum1', positive_validation=Path(training['positiveValidationDataset']))
data, stages = collect(args, metadata); assert stages == training['sourceStages']
with zipfile.ZipFile(root/'training2/dataset.npz') as archive:
    for name, expected in data.items():
        with archive.open(name+'.npy') as stream:
            version = np.lib.format.read_magic(stream)
            shape, fortran, dtype = (np.lib.format.read_array_header_1_0 if version == (1, 0)
                else np.lib.format.read_array_header_2_0)(stream)
            assert shape == expected.shape and dtype == expected.dtype and not fortran
            h = hashlib.sha256(); size = 0
            while block := stream.read(65536):
                h.update(block); size += len(block)
            assert size == expected.nbytes and h.hexdigest() == hashlib.sha256(memoryview(expected).cast('B')).hexdigest()
# Independently reconstruct the streamed inherited validation tensor from its
# sixteen original stage labels rather than reuse the same stream-row reader.
positive = Path(training['positiveValidationDataset']).parent.parent; chunks = []; targets = []
for graph in training['validationGraphs']:
    for view in ['individual-flat', 'overview']:
        with np.load(positive/f'graph-{graph:02}'/view/'labels.npz', allow_pickle=False) as saved:
            chunks.append(saved['x']); targets.append(saved['y'])
assert np.array_equal(np.concatenate(chunks), data['positive_validation_x'])
assert np.array_equal(np.concatenate(targets), data['positive_validation_y'])
del chunks, targets
model, restored_metadata = load(root/'training2/model.npz')
assert restored_metadata == {k: v for k, v in training.items() if k not in ['checkpointSha256', 'history']}
assert np.array_equal(model.mean, parent.mean) and np.array_equal(model.scale, parent.scale)
with np.load(root/'training2/model.npz', allow_pickle=False) as saved:
    assert all(np.array_equal(parent.p[key], saved['initial__'+key]) for key in KEYS)
selected = training['history'][training['selectedEpoch']-1]
loss, parts = validation_loss(model, data)
assert loss == selected['validationLoss'] == training['bestValidationLoss'] and parts == selected['parts'] == training['selectedValidationParts']
initial_loss, initial_parts = validation_loss(parent, data)
assert initial_loss == training['initialValidationLoss'] and initial_parts == training['initialValidationParts']
changes = {key: float(np.linalg.norm(model.p[key]-parent.p[key])) for key in KEYS}
assert changes == training['parameterGroupChangesL2'] and all(v > 0 for v in changes.values())
assert int((data['actual_gain'][data['training']] > 0).sum()) == training['actualImprovementExamples'] == 255
assert int((data['fractions'][data['training']] < 0).sum()) == training['negativeTrainingRows'] == 3072
assert not np.isin(data['graph'][data['training']], data['validation_graphs']).any()
assert not np.intersect1d(data['training'], data['captain_validation']).size
signed_validation_positives = int((data['actual_gain'][data['signed_validation']] > 0).sum())
parameters = int(sum(v.size for v in model.p.values()))
del data, model, parent; gc.collect()

checks = root/'verification1'; checks.mkdir(exist_ok=False)
full_actions = improved = accepted_total = 0; checked_stages = []
for index, (graph, view) in enumerate((g, v) for g in range(32) for v in ['overview', 'individual']):
    stage = root/'curriculum1'/f'graph-{graph:02}'/view; report = json.loads((stage/'report.json').read_text())
    assert report['codeSha256'] == code_hashes()
    directory = Path(report['sourceDirectory'])
    assert {name: digest(directory/name) for name in INPUT_FILES} == report['sourceInputs']
    decoder = WalkDecoder(directory); model, _ = parent_load(Path(report['checkpoint']))
    with np.load(stage/'observations.npz', allow_pickle=False) as saved:
        nodes = saved['node_features'].copy()
        vocabulary, support = coordinated_cycles(decoder, nodes, np.empty((0, 3), dtype=np.int32), report['vocabularySeed'], 128)
        support.pop('previouslyMeasuredCyclesSubmitted'); support['priorPositiveWordsMayBeReused'] = True
        assert support == report['support'] and np.array_equal(vocabulary, saved['cycles'])
        assert np.array_equal(FRACTIONS, saved['fractions'])
        scores, feature_hashes, error = rank(model, decoder, nodes, vocabulary, view == 'overview')
        assert np.array_equal(scores, saved['scores']) and feature_hashes == report['featureChunkHashes']
        assert error == report['scaleFeatureMaxError']
        order, noise, policy = sample_order(scores, report['samplingSeed'], 4.)
        assert np.array_equal(noise, saved['gumbel']) and policy == report['policy']
    native = Native(Path(report['environment']), directory, checks/f'synthetic-full-{index:03}.tsv', view == 'overview', False)
    assert native.initial['visual'] == report['initialVisual'] and native.initial['individualVisual'] == report['initialIndividualVisual']
    best = None; best_visual = report['initialVisual']; best_individual = report['initialIndividualVisual']
    checked = positives = accepted = 0; xs = []; ys = []; gains = []; words = []; fractions = []
    try:
        for line in (stage/'actions.jsonl').read_text().splitlines():
            row = json.loads(line); ci, fi = map(int, np.unravel_index(order[checked], scores.shape))
            assert row['rank'] == checked and (row['cycleIndex'], row['fractionIndex']) == (ci, fi)
            assert row['cycle'] == vocabulary[ci].tolist() and row['fraction'] == FRACTIONS[fi]
            assert row['score'] == scores[ci, fi] and row['gumbel'] == noise[ci, fi]
            from signed_cycle_model import signed_action
            action = signed_action(decoder, vocabulary[ci], float(FRACTIONS[fi])); motion_check(decoder, vocabulary[ci], float(FRACTIONS[fi]), action)
            command = wire(action); assert hashlib.sha256(command.encode()).hexdigest() == row['wireSha256']
            x, _ = features(nodes, decoder, vocabulary[ci:ci+1], np.array([FRACTIONS[fi]]), view == 'overview')
            scale = 512*np.expm1(nodes[vocabulary[ci], 62])
            assert np.array_equal(x[0, :, 137:139], np.clip(action[:len(decoder.positions)][vocabulary[ci]]/scale[:, None], -8, 8))
            full = native.request(wire(action, 'MEASURE')); original = row['result']
            assert all(full[name] == original[name] for name in ['legal', 'reason', 'visual', 'individualVisual', 'spacing', 'hard', 'individualHard'])
            admitted = full['legal'] and full['visual'] < best_visual and (view == 'overview' or full['individualVisual'] <= best_individual)
            assert admitted == original['accepted']
            if admitted:
                best = action; best_visual = full['visual']; best_individual = full['individualVisual']; accepted += 1
            gain = float(report['initialVisual']-full['visual']) if full['legal'] else np.nan
            xs.append(x[0]); ys.append(outcome_target(full, report['initialVisual'])); gains.append(gain)
            words.append(vocabulary[ci]); fractions.append(FRACTIONS[fi]); positives += int(gain > 0); checked += 1
        zero = native.request(wire(decoder.decode(np.arange(len(decoder.positions), dtype=np.int32)), 'MEASURE'))
        assert zero['visual'] == report['initialVisual'] and zero['individualVisual'] == report['initialIndividualVisual']
    finally:
        native.close()
    with np.load(stage/'labels.npz', allow_pickle=False) as saved:
        for name, values in [('x', xs), ('y', ys), ('cycles', words), ('fractions', fractions)]:
            assert np.array_equal(saved[name], np.array(values))
        assert np.array_equal(saved['actual_gain'], np.array(gains), equal_nan=True)
    assert (checked, positives, accepted) == (report['attempts'], report['improvingLegalActions'], report['accepted'])
    assert best_visual == report['final']['visual'] and best_individual == report['final']['individualVisual']
    verify_saved(directory, stage, decoder, best)
    checked_stages.append({'stage': str(stage), 'actions': checked, 'positives': positives, 'fullSparseScoresEqual': True})
    full_actions += checked; improved += positives; accepted_total += accepted
    if index % 16 == 0:
        print(json.dumps({'syntheticStagesVerified': index+1, 'fullScoringActionsCompared': full_actions}), flush=True)
    del decoder, model, nodes, vocabulary, scores, noise, xs; gc.collect()

actual = []; matched = {}; captain_full_actions = 0; repeats = {}
for view in ['individual', 'overview']:
    sets = []
    for suffix, replay in [('local1', replay_frozen), ('trained1', replay_trained)]:
        stage = root/(view+'-'+suffix); stream = StringIO()
        with redirect_stdout(stream): replay(SimpleNamespace(out=stage))
        reconstructed = json.loads(stream.getvalue()); report = json.loads((stage/'report.json').read_text())
        with np.load(stage/'observations.npz', allow_pickle=False) as saved:
            arrays = [saved[k].copy() for k in ['node_features', 'cycles', 'gumbel']]
        if view in matched:
            assert all(np.array_equal(a, b) for a, b in zip(matched[view], arrays))
        else:
            matched[view] = arrays
        rows = [json.loads(line) for line in (stage/'actions.jsonl').read_text().splitlines()]
        sets.append({row['wireSha256'] for row in rows}); directory = Path(report['sourceDirectory']); decoder = WalkDecoder(directory)
        native = Native(Path(report['environment']), directory, checks/(view+'-'+suffix+'-full.tsv'), view == 'overview', False)
        measured = 0
        try:
            for row in rows[:16]:
                proposed = signed_action(decoder, np.array(row['cycle']), row['fraction'])
                full = native.request(wire(proposed, 'MEASURE')); original = row['result']
                assert all(full[name] == original[name] for name in ['legal', 'reason', 'visual', 'individualVisual', 'spacing', 'hard', 'individualHard'])
                measured += 1
            zero = native.request(wire(decoder.decode(np.arange(len(decoder.positions), dtype=np.int32)), 'MEASURE'))
            assert zero['visual'] == report['initialVisual'] and zero['individualVisual'] == report['initialIndividualVisual']
        finally:
            native.close()
        legal = [row['result']['visual'] for row in rows if row['result']['legal']]
        actual.append({'stage': str(stage), 'view': view, 'trainedOnNegativeFractions': suffix == 'trained1',
            'replay': reconstructed, 'bestLegalVisual': min(legal), 'equalVisualActions': legal.count(report['initialVisual']),
            'hardRejectedBetterVisual': sum(row['result']['reason'] == 'hard' and row['result']['visual'] < report['initialVisual'] for row in rows),
            'fullSparseNativeScoresIndependentlyCompared': measured, 'allCaptainNativeScoresRecomputed': False})
        captain_full_actions += measured
    repeats[view] = len(sets[0] & sets[1])

result = {'status': 'pass', 'mixedSignedDatasetReconstructed': True, 'streamedPositiveValidationRowsIndependentlyReconstructed': True,
    'wholeGraphFoldExcludedFromParentAndSignedTraining': True, 'originalCaptainValidationExcludedFromTraining': True,
    'selectedCheckpointValidationRecomputed': True, 'selectedParameterGroupsMatchRecordedChanges': True,
    'normalizationUnchanged': True, 'networkParameters': parameters, 'fullOptimizerHistoryReplayed': False,
    'syntheticPolicyStagesVerified': len(checked_stages), 'syntheticModelActionsAndSavedGeometryReplayed': full_actions,
    'allSyntheticSparseLabelsEqualFullNativeScoring': True, 'signedSyntheticPositiveActions': improved,
    'trainingPositiveExamples': 255, 'signedWholeGraphValidationPositiveExamples': signed_validation_positives,
    'signedSyntheticAcceptedActions': accepted_total, 'nativeMeasureDoesNotChangeSource': True,
    'actualFeatureMotionMatchesDecodedWire': True, 'CaptainStages': actual,
    'CaptainActionsReplayed': sum(r['replay']['actionsReplayed'] for r in actual),
    'CaptainFullScoringSampleActions': captain_full_actions,
    'readOnlyNativeFullScoringActions': full_actions+captain_full_actions,
    'frozenTrainedNodesVocabularyAndGumbelMatched': True, 'frozenTrainedRepeatedWireCounts': repeats,
    'CaptainStrictImprovements': sum(r['replay']['accepted'] for r in actual),
    'allCaptainNativeScoresRecomputed': False, 'positiveValidationRegressionObserved': True,
    'targetMet': False, 'browserVerified': False}
assert full_actions == 4096 and improved == 325 and result['CaptainActionsReplayed'] == 4096
assert captain_full_actions == 64 and signed_validation_positives == 70
report_path.write_text(json.dumps(result, indent=2)+'\n')
print(json.dumps({k: result[k] for k in ['status', 'syntheticPolicyStagesVerified', 'readOnlyNativeFullScoringActions',
    'CaptainActionsReplayed', 'CaptainStrictImprovements', 'frozenTrainedRepeatedWireCounts']}), flush=True)
