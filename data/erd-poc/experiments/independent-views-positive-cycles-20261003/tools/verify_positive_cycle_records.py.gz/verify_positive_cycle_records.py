"""Rebuild learning data and compare every synthetic sparse label to full scoring."""
import sys
from pathlib import Path
sys.path.insert(0, str(Path('scripts/erd-poc').resolve()))
import gc
import hashlib
import json
import zipfile
from contextlib import redirect_stdout
from io import StringIO
from types import SimpleNamespace
import numpy as np
from directed_cycle_model import KEYS
from fractional_cycle_model import load
from train_positive_cycle_model import collect, split, validation_loss, hashes
from synthetic_cycle_curriculum import fixture, flatten_fixture
from run_anchor_pair_policy import Native, wire, digest
from run_anchor_pair_walk import WalkDecoder, verify_saved
from run_directed_cycle_policy import coordinated_cycles
from run_fraction_conditioned_policy import rank, sample_order, FRACTIONS
from run_fractional_cycle_transfer import fractional_action
from run_positive_cycle_transfer import replay as replay_global
from run_local_positive_cycles import replay as replay_local

root = Path('.tmp/visualcross-ml-150-750-20261003/cycle-positive-curriculum1')
report_path = root/'records-verification.json'; assert not report_path.exists()
training = json.loads((root/'training1/training.json').read_text())
assert hashes() == training['codeSha256'] and digest(root/'training1/model.npz') == training['checkpointSha256']
data, stages = collect(Path(training['parent']).parent, root); assert stages == training['sourceStages']
with zipfile.ZipFile(root/'training1/dataset.npz') as archive:
    for name, expected in data.items():
        with archive.open(name+'.npy') as stream:
            version = np.lib.format.read_magic(stream)
            shape, fortran, dtype = (np.lib.format.read_array_header_1_0 if version==(1, 0)
                else np.lib.format.read_array_header_2_0)(stream)
            assert shape == expected.shape and dtype == expected.dtype and not fortran
            h = hashlib.sha256(); size = 0
            while block := stream.read(65536):
                h.update(block); size += len(block)
            assert size == expected.nbytes and h.hexdigest() == hashlib.sha256(memoryview(expected).cast('B')).hexdigest()
ids, validation, graphs, sampling, _ = split(data, training['seed'])
with np.load(root/'training1/dataset.npz', allow_pickle=False) as saved:
    assert np.array_equal(ids, saved['training']) and np.array_equal(validation, saved['synthetic_validation'])
    assert np.array_equal(graphs, saved['validation_graphs']) and np.array_equal(sampling, saved['sampling'])
assert graphs.tolist() == training['syntheticValidationGraphs'] and int((data['actual_gain'][ids]>0).sum()) == 804
model, _ = load(root/'training1/model.npz'); parent, _ = load(Path(training['parent']))
assert np.array_equal(model.mean, parent.mean) and np.array_equal(model.scale, parent.scale)
with np.load(root/'training1/model.npz', allow_pickle=False) as saved:
    assert all(np.array_equal(parent.p[key], saved['initial__'+key]) for key in KEYS)
selected = training['history'][training['selectedEpoch']-1]
loss, captain_loss, synthetic_loss = validation_loss(model, data, validation)
assert loss == selected['validationLoss'] == training['bestValidationLoss']
assert captain_loss == selected['captainValidationHuber'] and synthetic_loss == selected['syntheticGraphValidationHuber']
norms = {key: float(np.linalg.norm(model.p[key]-parent.p[key])) for key in KEYS}
assert norms == training['parameterGroupChangesL2'] and all(value>0 for value in norms.values())
initial_loss, _, _ = validation_loss(parent, data, validation); assert initial_loss == training['initialValidationLoss']
del data, model, parent; gc.collect()

checks = root/'verification1'; checks.mkdir(exist_ok=False)
grouped = checks/'fixture'; fixture(grouped, 86243)
flat = checks/'fixture-flat'; flatten_fixture(grouped, flat)
for fresh, original in [(grouped, root/'graph-00/input'), (flat, root/'graph-00/input-individual')]:
    from learned_global_replay import INPUT_FILES
    assert all(digest(fresh/name)==digest(original/name) for name in INPUT_FILES)

stage_paths = [root/f'graph-{graph:02}'/view for graph in range(32) for view in ['overview', 'individual-flat']]
stage_paths += [root/f'graph-{graph:02}'/'individual' for graph in range(4)]
controls = json.loads((root/'fresh-graph-controls1/report.json').read_text())
stage_paths += [Path(path) for path in controls['stages']]
full_actions = improved = 0; checked_stages = []; matched = {}
for index, stage in enumerate(stage_paths):
    report = json.loads((stage/'report.json').read_text())
    for name, expected in report['codeSha256'].items():
        path = Path('scripts/erd-poc')/name
        if name=='synthetic_cycle_curriculum.py' and digest(path)!=expected:
            path = root/'probe-code'/name
        assert digest(path) == expected
    decoder = WalkDecoder(Path(report['sourceDirectory'])); model, _ = load(Path(report['checkpoint']))
    with np.load(stage/'observations.npz', allow_pickle=False) as saved:
        nodes = saved['node_features'].copy()
        vocabulary, support = coordinated_cycles(decoder, nodes, np.empty((0, 3), dtype=np.int32), report['vocabularySeed'], 128)
        assert support == report['support'] and np.array_equal(vocabulary, saved['cycles'])
        scores, feature_hashes, _ = rank(model, decoder, nodes, vocabulary, report['view']=='overview')
        assert np.array_equal(scores, saved['scores']) and feature_hashes == report['featureChunkHashes']
        order, noise, policy = sample_order(scores, report['samplingSeed'], 4.)
        assert np.array_equal(noise, saved['gumbel']) and policy == report['policy']
    if stage.is_relative_to(root/'fresh-graph-controls1'):
        key = (report['graph'], report['view'])
        if key in matched:
            assert all(np.array_equal(a, b) for a, b in zip(matched[key], (nodes, vocabulary, noise)))
        else:
            matched[key] = (nodes.copy(), vocabulary.copy(), noise.copy())
    native = Native(Path(report['environment']), Path(report['sourceDirectory']), checks/f'full-{index:03}.tsv', report['view']=='overview', False)
    best = None; best_visual = native.initial['visual']; best_individual = native.initial['individualVisual']
    assert best_visual == report['initialVisual'] and best_individual == report['initialIndividualVisual']
    checked = positives = accepted = 0
    try:
        for line in (stage/'actions.jsonl').read_text().splitlines():
            row = json.loads(line); ci, fi = map(int, np.unravel_index(order[checked], scores.shape))
            assert row['rank'] == checked and row['cycle'] == vocabulary[ci].tolist() and row['fraction'] == FRACTIONS[fi]
            assert row['score'] == scores[ci, fi] and row['gumbel'] == noise[ci, fi]
            action = fractional_action(decoder, vocabulary[ci], float(FRACTIONS[fi]))
            command = wire(action); assert hashlib.sha256(command.encode()).hexdigest() == row['wireSha256']
            full = native.request(wire(action, 'MEASURE')); original = row['result']
            assert all(full[name] == original[name] for name in ['legal', 'reason', 'visual', 'individualVisual', 'spacing', 'hard', 'individualHard'])
            admitted = full['legal'] and full['visual']<best_visual and (report['view']=='overview' or full['individualVisual']<=best_individual)
            assert admitted == original['accepted']
            if admitted:
                best = action; best_visual = full['visual']; best_individual = full['individualVisual']; accepted += 1
            positives += int(full['legal'] and full['visual']<report['initialVisual']); checked += 1
        zero = native.request(wire(decoder.decode(np.arange(len(decoder.positions), dtype=np.int32)), 'MEASURE'))
        assert zero['visual'] == report['initialVisual'] and zero['individualVisual'] == report['initialIndividualVisual']
    finally:
        native.close()
    assert checked == report['attempts'] and positives == report['improvingLegalActions'] and accepted == report['accepted']
    assert best_visual == report['final']['visual'] and best_individual == report['final']['individualVisual']
    verify_saved(Path(report['sourceDirectory']), stage, decoder, best)
    checked_stages.append({'stage': str(stage), 'actions': checked, 'positives': positives, 'fullSparseScoresEqual': True})
    full_actions += checked; improved += positives
    if index%20 == 0:
        print(json.dumps({'syntheticStagesVerified': index+1, 'fullScoringActionsCompared': full_actions}), flush=True)
    del decoder, model, nodes, vocabulary, scores, noise; gc.collect()
actual = []; repeats = {}
for view in ['individual', 'overview']:
    wires = []
    for suffix, function in [('1', replay_global), ('-local1', replay_local)]:
        stage = root/('captain-'+view+suffix); stream = StringIO()
        with redirect_stdout(stream):
            function(SimpleNamespace(out=stage))
        replay = json.loads(stream.getvalue()); report = json.loads((stage/'report.json').read_text())
        rows = [json.loads(line) for line in (stage/'actions.jsonl').read_text().splitlines()]
        legal = [row['result']['visual'] for row in rows if row['result']['legal']]
        hashes_set = {row['wireSha256'] for row in rows}; wires.append(hashes_set)
        actual.append({'stage': str(stage), 'view': view, 'local': suffix!='1', 'replay': replay,
            'bestLegalVisual': min(legal), 'equalVisualActions': legal.count(report['initialVisual']),
            'hardRejectedBetterVisual': sum(row['result']['reason']=='hard' and row['result']['visual']<report['initialVisual'] for row in rows),
            'nativeScoresRecomputed': False})
    repeats[view] = len(wires[0]&wires[1])
result = {'status': 'pass', 'mixedDatasetReconstructed': True, 'wholeSyntheticGraphHoldoutVerified': True,
    'originalCaptainValidationExcludedFromTraining': True, 'selectedCheckpointValidationRecomputed': True,
    'selectedParameterGroupsMatchRecordedChanges': True, 'originalNormalizationUnchanged': True,
    'fullOptimizerHistoryReplayed': False, 'syntheticPolicyStagesVerified': len(stage_paths),
    'syntheticModelActionsAndSavedGeometryReplayed': full_actions, 'allSyntheticSparseLabelsEqualFullNativeScoring': True,
    'readOnlyNativeFullScoringActions': full_actions, 'nativeMeasureDoesNotChangeSource': True,
    'freshControlsMatchedNodesVocabularyAndNoiseVerified': True, 'freshGraphControls': controls,
    'trainingPositiveExamples': 804, 'wholeGraphValidationPositiveExamples': 272,
    'originalGroupedIndividualProbeExcludedFromTraining': True,
    'CaptainStages': actual, 'CaptainActionsReplayed': sum(row['replay']['actionsReplayed'] for row in actual),
    'globalLocalRepeatedWireCounts': repeats, 'globalLocalComparisonIsNotAControlledSameVocabularyComparison': True,
    'CaptainStrictImprovements': 0, 'targetMet': False, 'browserVerified': False}
assert full_actions == 6400 and result['CaptainActionsReplayed'] == 4096
report_path.write_text(json.dumps(result, indent=2)+'\n')
print(json.dumps({key: result[key] for key in ['status', 'syntheticPolicyStagesVerified',
    'readOnlyNativeFullScoringActions', 'CaptainActionsReplayed', 'globalLocalRepeatedWireCounts']}), flush=True)
