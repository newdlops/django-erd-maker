"""Publish accurate metadata with byte-identical learned parameters."""
import sys
from pathlib import Path
sys.path.insert(0, str(Path('scripts/erd-poc').resolve()))
import json
import numpy as np
from fractional_cycle_model import load
from run_anchor_pair_policy import digest

root = Path('.tmp/visualcross-ml-150-750-20261003/cycle-positive-curriculum1/training1')
source = root/'model.npz'; output = root/'model-clean-metadata.npz'; assert not output.exists()
model, original = load(source)
legacy = ['novelMeasuredRows', 'fractionalRows', 'multiConflictRows', 'validationRows', 'validationFractionalRows',
    'fractionalSamplingMultiplicity', 'validationScope', 'normalizationOfExistingFeaturesUnchanged',
    'newFeatures', 'fractionalOutcomesUsedForTraining', 'warmPredictionMaxDifference',
    'datasetSha256', 'datasetPath']
metadata = {key: value for key, value in original.items() if key not in legacy}
metadata |= {'datasetPath': original['datasetPath'], 'datasetSha256': original['datasetSha256'],
    'datasetRole': 'inherited Captain measured-word exclusion only; actual mixed learning data is trainingDatasetPath',
    'metadataNormalizedFromCheckpoint': str(source), 'metadataNormalizedFromCheckpointSha256': digest(source),
    'metadataOnlyChange': True, 'learnedParametersUnchanged': True,
    'trainingReport': str(root/'training.json'), 'trainingReportSha256': digest(root/'training.json')}
with np.load(source, allow_pickle=False) as saved:
    arrays = {name: saved[name].copy() for name in saved.files if name!='metadata'}
np.savez_compressed(output, **arrays, metadata=json.dumps(metadata))
restored, actual = load(output)
assert all(np.array_equal(model.p[key], restored.p[key]) for key in model.p)
assert np.array_equal(model.mean, restored.mean) and np.array_equal(model.scale, restored.scale)
report = {'sourceCheckpoint': str(source), 'sourceCheckpointSha256': digest(source),
    'normalizedCheckpoint': str(output), 'normalizedCheckpointSha256': digest(output),
    'allLearnedAndInitialParametersBitwiseUnchanged': True, 'normalizationUnchanged': True,
    'removedLegacyParentStatistics': {key: original[key] for key in legacy if key in original and key not in ['datasetPath','datasetSha256']},
    'allCompletedStageCheckpointReferencesPreserved': True, 'futureParentUsesNormalizedMetadata': True}
(root/'metadata-normalization.json').write_text(json.dumps(report, indent=2)+'\n')
print(json.dumps({key: report[key] for key in ['normalizedCheckpointSha256', 'allLearnedAndInitialParametersBitwiseUnchanged']}))
