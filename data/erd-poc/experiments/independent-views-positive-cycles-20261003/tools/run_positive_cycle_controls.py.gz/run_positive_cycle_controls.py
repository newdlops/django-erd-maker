"""Matched frozen parent/trained policies on completely new synthetic graphs."""
import sys
from pathlib import Path
sys.path.insert(0, str(Path('scripts/erd-poc').resolve()))
import gc
import json
from synthetic_cycle_curriculum import fixture, flatten_fixture, collect_stage

root = Path('.tmp/visualcross-ml-150-750-20261003/cycle-positive-curriculum1')
output = root/'fresh-graph-controls1'; output.mkdir(exist_ok=False)
environment = root.parent/'pair-neutral-walk1/environment'
models = [('parent', root.parent/'fraction-conditioned-model1/training1/model.npz'),
    ('trained', root/'training1/model.npz')]
stages = []; comparisons = []
for graph in range(40, 48):
    grouped = output/f'graph-{graph:02}'/'input'; fixture(grouped, 86243+graph)
    individual = grouped.parent/'input-individual'; flatten_fixture(grouped, individual)
    for view, source in [('individual', individual), ('overview', grouped)]:
        pair = []
        for name, checkpoint in models:
            report = collect_stage(output, graph, source, view, checkpoint, environment, stage_name=view+'-'+name)
            stages.append(str(output/f'graph-{graph:02}'/(view+'-'+name)))
            pair.append(report)
            gc.collect()
        parent, trained = pair
        assert parent['sourceInputs'] == trained['sourceInputs']
        assert parent['support'] == trained['support']
        assert parent['vocabularySeed'] == trained['vocabularySeed'] and parent['samplingSeed'] == trained['samplingSeed']
        assert parent['initialVisual'] == trained['initialVisual']
        comparisons.append({'graph': graph, 'view': view, 'initial': parent['initialVisual'],
            'parentBestVisual': parent['final']['visual'], 'trainedBestVisual': trained['final']['visual'],
            'parentImprovingLegalActions': parent['improvingLegalActions'],
            'trainedImprovingLegalActions': trained['improvingLegalActions'],
            'trainedBetter': trained['final']['visual'] < parent['final']['visual'],
            'equal': trained['final']['visual'] == parent['final']['visual']})
report = {'scope': 'eight fresh graphs absent from all training/validation; matched vocabulary, source and Gumbel fields',
    'stages': stages, 'comparisons': comparisons, 'nativeActions': len(stages)*64,
    'trainedBetterStages': sum(row['trainedBetter'] for row in comparisons),
    'equalStages': sum(row['equal'] for row in comparisons),
    'parentBetterStages': sum(not row['trainedBetter'] and not row['equal'] for row in comparisons),
    'parentBestVisualSum': sum(row['parentBestVisual'] for row in comparisons),
    'trainedBestVisualSum': sum(row['trainedBestVisual'] for row in comparisons),
    'CaptainImprovementProved': False}
(output/'report.json').write_text(json.dumps(report, indent=2)+'\n')
print(json.dumps({k: report[k] for k in ['nativeActions', 'trainedBetterStages', 'equalStages',
    'parentBetterStages', 'parentBestVisualSum', 'trainedBestVisualSum']}), flush=True)
