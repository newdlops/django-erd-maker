"""Seal positive learning and its independently bounded generalization evidence."""
from pathlib import Path
import ast
import gzip
import hashlib
import json

root = Path('.tmp/visualcross-ml-150-750-20261003/cycle-positive-curriculum1')
archive = Path('data/erd-poc/experiments/independent-views-positive-cycles-20261003'); assert not archive.exists()
sha = lambda data: hashlib.sha256(data).hexdigest()
digest = lambda path: sha(Path(path).read_bytes())
training = json.loads((root/'training1/training.json').read_text())
verification = json.loads((root/'records-verification.json').read_text())
diagnosis = json.loads((root/'diagnosis.json').read_text())
normalized = json.loads((root/'training1/metadata-normalization.json').read_text())
assert verification['status']=='pass' and verification['readOnlyNativeFullScoringActions']==6400
assert verification['CaptainActionsReplayed']==4096 and verification['CaptainStrictImprovements']==0
assert training['checkpointSha256']==digest(root/'training1/model.npz')
assert normalized['normalizedCheckpointSha256']==digest(root/'training1/model-clean-metadata.npz')
stable = Path('data/erd-poc/candidates/captain-ml-independent-views.layout.json'); stable_sha = digest(stable)
assert stable_sha=='da2317d3d9fe72181587f543843bfdde3cc7030ca328e93c4f627ae21ec356e7'
provenance = Path('data/erd-poc/candidates/captain-ml-independent-views.provenance.json')
before = provenance.read_text(); doc = json.loads(before); assert doc['candidateSha256']==stable_sha
(root/'promotion-provenance-before.json').write_text(before)
resources = {'policy':'serialized numerical jobs; one math thread; nice +10; 128 MiB process-group sampled RSS guard',
    'hardCpuPercentQuotaEnforced':False, 'memoryLimitMiB':128,
    'initialProbeObservedPeakMiB':53.6, 'correctedCollectionObservedPeakMiB':51.2,
    'trainingObservedPeakMiB':110.7, 'trainingLoopSeconds':training['seconds'],
    'freshMatchedControlsObservedPeakMiB':49.2,
    'CaptainObservedPeaksMiB':{'individual-global':60.2,'overview-global':59.5,'individual-local':62.9,'overview-local':59.6},
    'recordsVerificationObservedPeakMiB':112.5, 'familyAnalysisObservedPeakMiB':42.9,
    'metadataNormalizationObservedPeakMiB':34.1, 'noGuardTermination':True,
    'allCurrentStagesTerminal':True, 'noFreshCliDiagnosticsOrDoctorRun':True}
(root/'resources.json').write_text(json.dumps(resources, indent=2)+'\n')

entries = {str(p):Path('run')/p.relative_to(root) for p in sorted(root.rglob('*')) if p.is_file()}
scripts = Path('scripts/erd-poc'); pending = ['synthetic_cycle_curriculum.py','train_positive_cycle_model.py',
    'run_positive_cycle_transfer.py','run_local_positive_cycles.py','local_positive_cycle_support.py','run_memory_bounded.py']; seen=set()
while pending:
    name=pending.pop()
    if name in seen:
        continue
    seen.add(name); path=scripts/name; entries[str(path)]=Path('code')/name
    for node in ast.walk(ast.parse(path.read_text())):
        modules=[node.module] if isinstance(node,ast.ImportFrom) else [item.name for item in node.names] if isinstance(node,ast.Import) else []
        for module in modules:
            if module and (scripts/(module+'.py')).is_file(): pending.append(module+'.py')
for name in ['run_positive_cycle_controls.py','verify_positive_cycle_records.py','analyze_positive_cycle_family.py',
    'normalize_positive_cycle_metadata.py','seal_positive_cycle_research.py']:
    path=Path('.tmp')/name; ast.parse(path.read_text()); entries[str(path)]=Path('tools')/name
dependencies={training['parent'],training['parentDataset'],training['parentTrainingReport'],training['datasetPath'],str(stable),
    'data/erd-poc/candidates/captain-ml-independent-views.audit.json'}
for view in ['individual','overview']:
    for suffix in ['1','-local1']:
        stage=root/('captain-'+view+suffix); report=json.loads((stage/'report.json').read_text())
        dependencies.add(report['environment'])
        dependencies.update(str(Path(report['sourceDirectory'])/name) for name in report['sourceInputs'])
        for previous in report['exclusionReports']:
            dependencies.update([previous['path'],str(Path(previous['path']).parent/'actions.jsonl')])
        reference=root.parent/'pair-anchor-sparse1/actual-validation'/(view+'-sparse.tsv')
        dependencies.update(str(reference)+ending for ending in ['', '.routes.tsv','.individual','.individual.routes.tsv'])
for source in dependencies:
    if source not in entries: entries[source]=Path('dependencies')/digest(source)/Path(source).name

prior={}; manifest_hashes={}
for path in sorted(archive.parent.glob('independent-views-*-20261003/manifest.json')):
    manifest_hashes[str(path)]=digest(path); previous=json.loads(path.read_text())
    for item in previous.get('files',[]):
        stored=item.get('archive',item.get('stored'))
        if stored is not None: prior[item['sha256']]=(path.parent/stored,item['bytes'],str(path))
    for item in previous.get('referencedFiles',[]):
        prior.setdefault(item['sha256'],(Path(item['archive']),item['bytes'],str(path)))
archive.mkdir(parents=True); files=[]; referenced=[]; reused={}; restored_hashes=set(); required=set()
for source,relative in sorted(entries.items()):
    data=Path(source).read_bytes(); source_sha=sha(data)
    if source_sha in prior:
        stored,size,manifest=prior[source_sha]; assert size==len(data)
        if source_sha not in restored_hashes:
            packed=stored.read_bytes(); restored=gzip.decompress(packed) if packed[:2]==b'\x1f\x8b' else packed
            assert sha(restored)==source_sha and len(restored)==len(data); restored_hashes.add(source_sha)
        required.add(manifest)
        referenced.append({'source':source,'archive':str(stored),'sha256':source_sha,'bytes':len(data),
            'prerequisiteManifest':manifest,'restoreHashVerified':True}); continue
    if source_sha in reused:
        stored,packed_bytes=reused[source_sha]
    else:
        stored=Path(str(relative)+'.gz'); destination=archive/stored; destination.parent.mkdir(parents=True,exist_ok=True)
        packed=gzip.compress(data,compresslevel=1,mtime=0); destination.write_bytes(packed)
        assert gzip.decompress(destination.read_bytes())==data
        packed_bytes=len(packed); reused[source_sha]=(stored,packed_bytes)
    files.append({'source':source,'archive':str(stored),'sha256':source_sha,'bytes':len(data),'compressedBytes':packed_bytes})
assert digest(stable)==stable_sha and provenance.read_text()==before
manifest={'scope':'positive neural cycle outcomes; whole-graph holdout; matched fresh synthetic controls; global and local Captain transfer; movement-family algebra',
    'retainedCandidate':str(stable),'retainedCandidateSha256':stable_sha,'promotedCandidateChanged':False,
    'overviewVisual':289,'individualVisual':1964,'targetOverview':150,'targetIndividual':750,'targetMet':False,
    'newTrainingUpdates':13248,'selectedCheckpointUpdates':12627,'trainingRows':7585,'mixedDatasetRows':9216,
    'syntheticRows':4096,'actualImprovingTrainingExamples':804,'syntheticValidationRows':1024,
    'syntheticValidationPositiveExamples':272,'wholeSyntheticValidationGraphs':[1,4,8,10,20,24,26,27],
    'newNativeModelActions':10496,'initialProbeActions':512,'additionalCorrectedCollectionActions':3840,
    'freshMatchedSyntheticActions':2048,'CaptainActions':4096,'CaptainStrictImprovements':0,
    'readOnlyNativeFullScoringActions':6400,'syntheticFullSparseLabelParityVerified':True,
    'freshMatchedTrainedBetterEqualParentBetter':[8,7,1], 'freshParentBestVisualSum':6718,'freshTrainedBestVisualSum':6381,
    'globalLocalRepeatedWiresByView':{'individual':16,'overview':15},
    'globalLocalComparisonSameVocabulary':False,'syntheticImprovementProvesCaptainImprovement':False,
    'originalGroupedIndividualProbeExcludedFromTraining':True,'completedOverviewProbeReusedWithoutRerun':4,
    'normalizedMetadataCheckpoint':normalized['normalizedCheckpoint'],
    'normalizedMetadataCheckpointSha256':normalized['normalizedCheckpointSha256'],
    'metadataNormalizationParametersUnchanged':True,'optimizerHistoryIndependentlyReplayed':False,
    'nativeSearchOrCoordinateRepairCalls':0,'newProductCandidates':0,'browserVerified':False,
    'recordsVerification':verification,'diagnosis':diagnosis,'resources':resources,
    'prerequisiteManifests':[{'path':name,'sha256':manifest_hashes[name]} for name in sorted(required)],
    'referencedFiles':referenced,'referencedLogicalBytes':sum(item['bytes'] for item in referenced),
    'allReferencedBytesRestoreHashVerified':True,'newPhysicalCompressedFiles':len(reused),
    'newPhysicalCompressedBytes':sum(value[1] for value in reused.values()),
    'logicalFiles':len(files),'logicalBytes':sum(item['bytes'] for item in files),
    'identicalCurrentFilesShareStoredBytes':True,'allCompressedFilesRoundTripHashVerified':True,'files':files}
path=archive/'manifest.json'; path.write_text(json.dumps(manifest,indent=2)+'\n'); manifest_sha=digest(path)
assert all(item['archiveManifest']!=str(path) for item in doc['subsequentResearchArchives'])
doc['subsequentResearchArchives'].append({'archiveManifest':str(path),'archiveManifestSha256':manifest_sha,
    'promotedCandidateChanged':False,'retainedCandidateSha256':stable_sha,'overviewVisual':289,'individualVisual':1964,
    'newNetworkTrainingUpdates':13248,'selectedCheckpointUpdates':12627,'actualImprovingTrainingExamples':804,
    'nativeModelActions':10496,'readOnlyFullScoringComparisons':6400,'CaptainStrictImprovements':0,
    'targetMet':False,'browserVerified':False})
assert provenance.read_text()==before; provenance.write_text(json.dumps(doc,indent=2)+'\n')
print(json.dumps({'manifest':str(path),'manifestSha256':manifest_sha,'logicalFiles':len(files),
    'logicalBytes':manifest['logicalBytes'],'newPhysicalCompressedFiles':len(reused),
    'newPhysicalCompressedBytes':manifest['newPhysicalCompressedBytes'],'referencedFiles':len(referenced),
    'referencedLogicalBytes':manifest['referencedLogicalBytes'],'allStoredAndReferencedBytesVerified':True,
    'promotedCandidateUnchanged':True}),flush=True)
