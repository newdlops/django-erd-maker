"""Measure reported outcomes and derive the present movement family's limits."""
import sys
from pathlib import Path
sys.path.insert(0, str(Path('scripts/erd-poc').resolve()))
import json
import numpy as np
from run_anchor_pair_walk import WalkDecoder

root = Path('.tmp/visualcross-ml-150-750-20261003/cycle-positive-curriculum1')
verification = json.loads((root/'records-verification.json').read_text()); assert verification['status']=='pass'
summaries = []; comparisons = 0; maximum_relative_error = 0.; maximum_centroid_drift = 0.
for view in ['individual', 'overview']:
    for suffix in ['1', '-local1']:
        stage = root/('captain-'+view+suffix); report = json.loads((stage/'report.json').read_text())
        decoder = WalkDecoder(Path(report['sourceDirectory']))
        rows = [json.loads(line) for line in (stage/'actions.jsonl').read_text().splitlines()]
        legal = [row['result']['visual'] for row in rows if row['result']['legal']]
        for row in rows[:64]:
            p = decoder.positions[row['cycle']]; rho = row['fraction']
            centered = p-p.mean(0); original = float(np.sum(centered**2))
            delta = rho*(np.roll(p, -1, axis=0)-p); q = p+delta
            target = (1-3*rho+3*rho*rho)*original
            actual = float(np.sum((q-q.mean(0))**2))
            relative = abs(actual-target)/max(1., target); assert relative<1e-12
            rounded_delta = np.copysign(np.floor(abs(delta)*100+.5), delta)/100
            shifted = p+rounded_delta; rounded_variance = float(np.sum((shifted-shifted.mean(0))**2))
            error_bound = 2*np.sqrt(target)*np.sqrt(6)*.005+6*.005**2
            assert abs(rounded_variance-target)<=error_bound+1e-5
            drift = float(np.max(abs(shifted.mean(0)-p.mean(0)))); assert drift<=.005+1e-8
            maximum_centroid_drift = max(maximum_centroid_drift, drift)
            maximum_relative_error = max(maximum_relative_error, relative); comparisons += 1
        summaries.append({'view': view, 'local': suffix!='1', 'attempts': report['attempts'],
            'accepted': report['accepted'], 'reasons': report['reasons'], 'bestLegalVisual': min(legal),
            'equalVisualActions': legal.count(report['initialVisual']),
            'support': report['support'], 'samplingFractionMass': report['policy']['fractionProbabilityMass']})
result = {'retainedOverview':289, 'retainedIndividual':1964, 'targetMet':False,
    'syntheticFreshControlsShowLimitedImprovement':True, 'CaptainStrictImprovements':0,
    'CaptainStages':summaries, 'globalLocalRepeatedWireCounts':verification['globalLocalRepeatedWireCounts'],
    'movementFamily':{'unroundedCentroidPreserved':True, 'unroundedVarianceMultiplier':'1 - 3*rho + 3*rho^2',
        'allCurrentFractionsWithinZeroAndOne':True, 'unroundedPositiveFractionalCyclesCannotIncreaseCenterVariance':True,
        'unitFractionPermutesSlotsWithUnchangedVariance':True, 'currentModelHasNoNegativeAmplitudeTraining':True,
        'realSourceActionComparisons':comparisons, 'maximumRelativeFormulaError':maximum_relative_error,
        'centQuantizationVarianceErrorBoundVerified':True, 'maximumObservedCentroidDriftPerAxis':maximum_centroid_drift,
        'thisDoesNotProveContractionCausesPlateauOrTargetImpossible':True},
    'nextResearch':'test signed cycle amplitudes with explicit transfer/training provenance so the neural policy can also spread three-owner configurations; retain native gates and immutable source frames; do not repeat these positive-amplitude controls unchanged',
    'newProductCandidates':0, 'browserVerified':False}
path = root/'diagnosis.json'; assert not path.exists(); path.write_text(json.dumps(result, indent=2)+'\n')
print(json.dumps({'formulaComparisons':comparisons,'maximumRelativeError':maximum_relative_error,
    'maximumCentroidDriftPerAxis':maximum_centroid_drift,'CaptainStrictImprovements':0}), flush=True)
