"""Independently restore and hash-check all new archive mappings and sources."""
import gzip
import hashlib
import json
from pathlib import Path

sha = lambda data: hashlib.sha256(data).hexdigest()
digest = lambda p: sha(Path(p).read_bytes())
receipt = json.loads(Path('.tmp/owner-amplitude-archive-seal-receipt.json').read_text())
path = Path(receipt['manifest']); expected = receipt['manifestSha256']
assert digest(path) == expected; manifest = json.loads(path.read_text()); objects = set(); mappings = 0
for category in ['files', 'referencedFiles']:
    for item in manifest[category]:
        stored = path.parent/item['archive'] if category == 'files' else Path(item['archive'])
        packed = stored.read_bytes(); restored = gzip.decompress(packed) if packed[:2] == b'\x1f\x8b' else packed
        assert len(restored) == item['bytes'] and sha(restored) == item['sha256']
        assert digest(item['source']) == item['sha256']; objects.add(str(stored)); mappings += 1
for item in manifest['prerequisiteManifests']: assert digest(item['path']) == item['sha256']
assert digest(manifest['retainedCandidate']) == manifest['retainedCandidateSha256']
doc = json.loads(Path('data/erd-poc/candidates/captain-ml-independent-views.provenance.json').read_text())
assert doc['subsequentResearchArchives'][-1]['archiveManifestSha256'] == expected
audit = json.loads(Path('data/erd-poc/candidates/captain-ml-independent-views.audit.json').read_text())
assert audit['models'] == 1244 and audit['canonicalRelationships'] == 1727
assert audit['overviewVisual'] == 289 and audit['individualVisual'] == 1964 and not audit['thresholdsMet']
result = {'status': 'pass', 'manifestSha256': expected, 'archiveMappingsRestoredAndLiveSourcesMatched': mappings,
    'distinctStoredObjects': len(objects), 'prerequisiteManifestsMatched': len(manifest['prerequisiteManifests']),
    'retainedProductCountsAndMetricsVerified': True, 'promotedCandidateUnchanged': True, 'targetMet': False}
out = Path('.tmp/owner-amplitude-archive-independent-verification.json'); assert not out.exists()
out.write_text(json.dumps(result, indent=2)+'\n'); print(json.dumps(result), flush=True)
