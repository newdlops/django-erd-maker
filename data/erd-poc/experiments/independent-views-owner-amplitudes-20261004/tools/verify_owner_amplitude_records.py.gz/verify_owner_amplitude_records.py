"""Bounded reconstruction and independent full scoring of neural owner moves."""
import argparse
import gc
import hashlib
import json
import sys
import zipfile
from contextlib import redirect_stdout
from io import StringIO
from itertools import combinations
from pathlib import Path
from types import SimpleNamespace

sys.path.insert(0, str(Path('scripts/erd-poc').resolve()))
import numpy as np
from directed_cycle_model import KEYS
from float32_input_owner_model import load, with_float32_inputs
from global_mixed_owner_support import support as global_support
from learned_global_replay import INPUT_FILES
from mixed_size_owner_cycles import mixed, mixed_action, support
from mixed_size_synthetic_fixture import fixture
from owner_amplitude_cycle_model import AMPLITUDES, action_features, rank
from run_anchor_pair_policy import Native, wire, digest
from run_anchor_pair_walk import WalkDecoder, verify_saved
from run_fraction_conditioned_policy import sample_order
from run_owner_amplitude_cycles import motion_check, replay as replay_equal
from run_mixed_size_owner_cycles import replay as replay_mixed
from run_float32_mixed_owner_cycles import replay as replay_trained
from run_global_mixed_owner_cycles import replay as replay_global
from synthetic_cycle_curriculum import flatten_fixture
from synthetic_mixed_size_owner_curriculum import code_hashes
from train_anchor_pair_outcomes import outcome_target
from train_balanced_owner_amplitude_model_v2 import collect, hashes, validation_loss

ROOT = Path('.tmp/visualcross-ml-150-750-20261004/owner-amplitude-cycles1')
OLD = Path('.tmp/visualcross-ml-150-750-20261003')
FIELDS = ['legal', 'reason', 'visual', 'individualVisual', 'spacing', 'hard', 'individualHard']


def header(stream):
    version = np.lib.format.read_magic(stream)
    return (np.lib.format.read_array_header_1_0 if version == (1, 0)
            else np.lib.format.read_array_header_2_0)(stream)


def stream_hash(stream):
    h = hashlib.sha256(); size = 0
    while block := stream.read(65536): h.update(block); size += len(block)
    return size, h.hexdigest()


def training():
    destination = ROOT/'training-verification.json'; assert not destination.exists()
    record = json.loads((ROOT/'training2/training.json').read_text())
    assert record['codeSha256'] == hashes()
    assert digest(ROOT/'training2/model.npz') == record['checkpointSha256']
    assert digest(ROOT/'training2/dataset.npz') == record['trainingDatasetSha256']
    parent, metadata = load(Path(record['parent'])); parent = with_float32_inputs(parent)
    assert digest(record['parent']) == record['parentSha256']
    args = SimpleNamespace(parent=Path(record['parent']), captain=Path(record['datasetPath']),
        positive_source=OLD/'cycle-positive-curriculum1',
        negative_source=OLD/'signed-cycle-transfer1/curriculum1', mixed_source=ROOT/'mixed-curriculum1')
    data, stages = collect(args, metadata); assert stages == record['sourceStages']
    with zipfile.ZipFile(ROOT/'training2/dataset.npz') as saved:
        assert set(saved.namelist()) == {name+'.npy' for name in data}
        for name, value in data.items():
            with saved.open(name+'.npy') as stream:
                shape, fortran, dtype = header(stream)
                assert shape == value.shape and dtype == value.dtype and not fortran
                assert stream_hash(stream) == (value.nbytes, hashlib.sha256(memoryview(value).cast('B')).hexdigest())
    # The interrupted float64 attempt completed its dataset. Verify that the
    # successful version changes only feature input precision and its error field.
    with zipfile.ZipFile(ROOT/'training1/dataset.npz') as saved:
        assert set(saved.namelist()) == {name+'.npy' for name in data if name != 'feature_quantization_error'}
        for name, value in data.items():
            if name == 'feature_quantization_error': continue
            with saved.open(name+'.npy') as stream:
                shape, fortran, dtype = header(stream); assert shape == value.shape and not fortran
                if name == 'x':
                    assert dtype == np.dtype('float64') and value.dtype == np.dtype('float32')
                    row_bytes = int(np.prod(shape[1:]))*dtype.itemsize
                    for first in range(0, len(value), 64):
                        end = min(first+64, len(value)); block = stream.read((end-first)*row_bytes)
                        original = np.frombuffer(block, dtype=dtype).reshape(end-first, *shape[1:])
                        assert np.array_equal(original.astype(np.float32), value[first:end])
                    assert not stream.read(1)
                else:
                    assert dtype == value.dtype
                    assert stream_hash(stream) == (value.nbytes, hashlib.sha256(memoryview(value).cast('B')).hexdigest())
    model, restored = load(ROOT/'training2/model.npz')
    assert restored == {k: v for k, v in record.items() if k not in ['checkpointSha256', 'history']}
    assert np.array_equal(parent.mean, model.mean) and np.array_equal(parent.scale, model.scale)
    with np.load(ROOT/'training2/model.npz', allow_pickle=False) as saved:
        assert all(np.array_equal(parent.p[k], saved['initial__'+k]) for k in KEYS)
    initial, initial_parts = validation_loss(parent, data); selected, selected_parts = validation_loss(model, data)
    assert initial == record['initialValidationLoss'] and initial_parts == record['initialValidationParts']
    assert selected == record['bestValidationLoss'] and selected_parts == record['selectedValidationParts']
    chosen = record['history'][record['selectedEpoch']-1]
    assert chosen['updates'] == record['selectedCheckpointUpdates'] and chosen['validationLoss'] == selected
    assert chosen['parts'] == selected_parts
    assert {k: float(np.linalg.norm(model.p[k]-parent.p[k])) for k in KEYS} == record['parameterGroupChangesL2']
    assert all(v > 0 for v in record['parameterGroupChangesL2'].values())
    held_out = np.r_[data['uniform_validation_graphs'], data['mixed_validation_graphs']]
    assert not np.isin(data['graph'][data['training']], held_out).any()
    assert not np.intersect1d(data['training'], np.r_[data['captain_validation'],
        data['positive_validation'], data['negative_validation'], data['mixed_validation']]).size
    positives = {kind: int(((data['kind'][data['training']] == kind) &
        (data['actual_gain'][data['training']] > 0)).sum()) for kind in record['rowsByKind']}
    assert positives == record['improvingTrainingExamplesByKind']
    assert record['featureQuantizationMaximumAbsoluteError'] == data['feature_quantization_error'][0]
    result = {'status': 'pass', 'balancedDatasetReconstructed': True,
        'failedFloat64DatasetComparedInChunks': True, 'onlyFeatureInputPrecisionChanged': True,
        'wholeGraphAndCaptainFoldExcluded': True, 'normalizationAndInitialParametersUnchanged': True,
        'initialAndSelectedValidationLossRecomputed': True, 'allParameterChangesVerified': True,
        'networkParameters': sum(v.size for v in model.p.values()), 'optimizerHistoryIndependentlyReplayed': False,
        'trainingPositiveExamplesByKind': positives,
        'mixedValidationPositiveExamples': int((data['actual_gain'][data['mixed_validation']] > 0).sum()),
        'featureQuantizationMaximumAbsoluteError': record['featureQuantizationMaximumAbsoluteError']}
    assert result['networkParameters'] == 17474 and result['mixedValidationPositiveExamples'] == 152
    destination.write_text(json.dumps(result, indent=2)+'\n'); print(json.dumps(result), flush=True)


def actions():
    destination = ROOT/'actions-verification.json'; assert not destination.exists()
    checks = ROOT/'verification1'; checks.mkdir(exist_ok=False)
    fixture(checks/'fixture-64', 89003+64); flatten_fixture(checks/'fixture-64', checks/'fixture-64-individual')
    for name in INPUT_FILES:
        assert digest(checks/'fixture-64'/name) == digest(ROOT/'mixed-curriculum1/graph-64/input'/name)
        assert digest(checks/'fixture-64-individual'/name) == digest(ROOT/'mixed-curriculum1/graph-64/input-individual'/name)
    full_actions = positives = accepted_total = 0; checked_stages = []
    for index, (graph, view) in enumerate((g, v) for g in range(64, 96) for v in ['overview', 'individual']):
        stage = ROOT/'mixed-curriculum1'/f'graph-{graph:02}'/view
        report = json.loads((stage/'report.json').read_text()); directory = Path(report['sourceDirectory'])
        assert report['codeSha256'] == code_hashes()
        assert {n: digest(directory/n) for n in INPUT_FILES} == report['sourceInputs']
        for file, key in [('observations.npz', 'observationsSha256'), ('actions.jsonl', 'actionsSha256'), ('labels.npz', 'labelsSha256')]:
            assert digest(stage/file) == report[key]
        assert digest(report['checkpoint']) == report['checkpointSha256'] and digest(report['environment']) == report['environmentSha256']
        decoder = WalkDecoder(directory); model, _ = load(Path(report['checkpoint']))
        with np.load(stage/'observations.npz', allow_pickle=False) as saved:
            nodes = saved['node_features'].copy()
            cycles, vocabulary = support(decoder, nodes, 'small-global', report['vocabularySeed'], report['triples'])
            assert vocabulary == report['support'] and np.array_equal(cycles, saved['cycles'])
            assert np.array_equal(AMPLITUDES, saved['amplitudes'])
            scores, feature_hashes, error = rank(model, decoder, nodes, cycles, view == 'overview')
            assert np.array_equal(scores, saved['scores']) and feature_hashes == report['featureChunkHashes']
            assert error == report['scaleFeatureMaxError']
            order, noise, policy = sample_order(scores, report['samplingSeed'], 4.)
            assert np.array_equal(noise, saved['gumbel']) and policy == report['policy']
        if index == 0:
            active = np.any(nodes[:, 4:6] > 0, axis=1)
            exhaustive = sum(int(active[list(word)].sum() >= 2 and
                not decoder.irrelevant_isolate[list(word)].all() and mixed(word, decoder.sizes))
                for word in combinations(range(len(nodes)), 3))
            _, description = global_support(decoder, nodes, 'global', 89411, 8)
            assert exhaustive == description['eligibleMixedSizeTriples']
        native = Native(Path(report['environment']), directory, checks/f'synthetic-full-{index:03}.tsv', view == 'overview', False)
        assert native.initial['visual'] == report['initialVisual'] and native.initial['individualVisual'] == report['initialIndividualVisual']
        best = None; best_visual = report['initialVisual']; best_individual = report['initialIndividualVisual']
        checked = improving = accepted = 0; xs = []; ys = []; gains = []; words = []; amplitudes = []
        try:
            for line in (stage/'actions.jsonl').read_text().splitlines():
                row = json.loads(line); ci, ai = map(int, np.unravel_index(order[checked], scores.shape))
                assert row['rank'] == checked and (row['cycleIndex'], row['amplitudeIndex']) == (ci, ai)
                assert row['cycle'] == cycles[ci].tolist() and row['amplitudes'] == AMPLITUDES[ai].tolist()
                assert row['score'] == scores[ci, ai] and row['gumbel'] == noise[ci, ai]
                action = mixed_action(decoder, cycles[ci], AMPLITUDES[ai]); shift, moved = motion_check(decoder, cycles[ci], AMPLITUDES[ai], action)
                assert row['rawCentroidShiftL2'] == shift and row['movedOwners'] == moved
                assert hashlib.sha256(wire(action).encode()).hexdigest() == row['wireSha256']
                x, _ = action_features(nodes, decoder, cycles[ci:ci+1], AMPLITUDES[ai:ai+1], view == 'overview')
                scales = 512*np.expm1(nodes[cycles[ci], 62])
                assert np.array_equal(x[0, :, 137:139], np.clip(action[:len(nodes)][cycles[ci]]/scales[:, None], -8, 8))
                full = native.request(wire(action, 'MEASURE')); original = row['result']
                assert all(full[k] == original[k] for k in FIELDS)
                admitted = full['legal'] and full['visual'] < best_visual and (view == 'overview' or full['individualVisual'] <= best_individual)
                assert admitted == original['accepted']
                if admitted: best = action; best_visual = full['visual']; best_individual = full['individualVisual']; accepted += 1
                gain = float(report['initialVisual']-full['visual']) if full['legal'] else np.nan
                xs.append(x[0]); ys.append(outcome_target(full, report['initialVisual'])); gains.append(gain)
                words.append(cycles[ci]); amplitudes.append(AMPLITUDES[ai]); improving += int(gain > 0); checked += 1
            zero = native.request(wire(decoder.decode(np.arange(len(nodes), dtype=np.int32)), 'MEASURE'))
            assert zero['visual'] == report['initialVisual'] and zero['individualVisual'] == report['initialIndividualVisual']
        finally: native.close()
        with np.load(stage/'labels.npz', allow_pickle=False) as saved:
            for name, value in [('x', xs), ('y', ys), ('cycles', words), ('amplitudes', amplitudes)]:
                assert np.array_equal(saved[name], np.array(value))
            assert np.array_equal(saved['actual_gain'], np.array(gains), equal_nan=True)
        assert (checked, improving, accepted) == (report['attempts'], report['improvingLegalActions'], report['accepted'])
        assert best_visual == report['final']['visual'] and best_individual == report['final']['individualVisual']
        verify_saved(directory, stage, decoder, best)
        full_actions += checked; positives += improving; accepted_total += accepted
        checked_stages.append({'stage': str(stage), 'actions': checked, 'positives': improving, 'fullSparseParity': True})
        if index % 16 == 0: print(json.dumps({'syntheticStagesVerified': index+1, 'fullScoringActions': full_actions}), flush=True)
        del decoder, model, nodes, cycles, scores, noise, xs; gc.collect()
    actual = []; precision = {}; repeated = {}; captain_full = 0
    for view in ['individual', 'overview']:
        matched = None; sets = []
        for suffix, replay in [('transfer1', replay_equal), ('mixed-transfer2', replay_mixed),
                               ('mixed-trained1', replay_trained), ('mixed-global1', replay_global)]:
            stage = ROOT/(view+'-'+suffix); output = StringIO()
            with redirect_stdout(output): replay(SimpleNamespace(out=stage))
            reconstructed = json.loads(output.getvalue()); report = json.loads((stage/'report.json').read_text())
            if suffix in ['mixed-transfer2', 'mixed-trained1']:
                with np.load(stage/'observations.npz', allow_pickle=False) as saved:
                    arrays = [saved[k].copy() for k in ['node_features', 'cycles', 'gumbel']]
                    if matched is None: matched = arrays
                    else: assert all(np.array_equal(a, b) for a, b in zip(matched, arrays))
                sets.append({json.loads(line)['wireSha256'] for line in (stage/'actions.jsonl').read_text().splitlines()})
            directory = Path(report['sourceDirectory']); decoder = WalkDecoder(directory)
            if suffix == 'mixed-transfer2':
                parent, _ = load(Path(report['checkpoint'])); parent = with_float32_inputs(parent)
                changed_scores, _, _ = rank(parent, decoder, matched[0], matched[1], view == 'overview')
                with np.load(stage/'observations.npz', allow_pickle=False) as saved: old_scores = saved['scores']
                old_order, _, _ = sample_order(old_scores, report['seed']+1000, 1.)
                new_order, _, _ = sample_order(changed_scores, report['seed']+1000, 1.)
                precision[view] = {'maximumScoreChangeWithSameWeights': float(np.max(abs(changed_scores-old_scores))),
                    'changedRankPositionsAmongFirst1024': int((old_order[:1024] != new_order[:1024]).sum()),
                    'changedSelectedIndicesAmongFirst1024': len(set(old_order[:1024]) ^ set(new_order[:1024]))}
                del parent, changed_scores, old_scores, old_order, new_order
            native = Native(Path(report['environment']), directory, checks/(view+'-'+suffix+'-full.tsv'), view == 'overview', False)
            rows = [json.loads(line) for line in (stage/'actions.jsonl').read_text().splitlines()]
            try:
                for row in rows[:16]:
                    action = mixed_action(decoder, np.array(row['cycle']), np.array(row['amplitudes']))
                    full = native.request(wire(action, 'MEASURE'))
                    assert all(full[k] == row['result'][k] for k in FIELDS)
                    captain_full += 1
                zero = native.request(wire(decoder.decode(np.arange(len(decoder.positions), dtype=np.int32)), 'MEASURE'))
                assert zero['visual'] == report['initialVisual'] and zero['individualVisual'] == report['initialIndividualVisual']
            finally: native.close()
            actual.append({'stage': str(stage), 'view': view, 'replay': reconstructed,
                'minimumLegalVisual': min(row['result']['visual'] for row in rows if row['result']['legal']),
                'fullScoringSampleActions': 16, 'allNativeScoresRecomputed': False})
            del decoder, rows; gc.collect()
        repeated[view] = len(sets[0] & sets[1])
    result = {'status': 'pass', 'seededMixedFixtureAndFlatteningReconstructed': True,
        'globalEligibleTripleCountMatchesSmallExhaustiveControl': True,
        'syntheticStagesVerified': len(checked_stages), 'syntheticActionsReplayed': full_actions,
        'allNewSyntheticSparseLabelsEqualFullScoring': True, 'syntheticImprovingActions': positives,
        'syntheticAcceptedActions': accepted_total, 'nativeMeasureLeavesSourcesUnchanged': True,
        'CaptainStages': actual, 'CaptainActionsReplayed': sum(r['replay']['actionsReplayed'] for r in actual),
        'CaptainStrictImprovements': sum(r['replay']['accepted'] for r in actual),
        'CaptainFullScoringSampleActions': captain_full, 'readOnlyFullScoringActions': full_actions+captain_full,
        'allCaptainNativeScoresRecomputed': False, 'frozenTrainedLocalVocabularyAndNoiseMatched': True,
        'frozenTrainedLocalRepeatedWireCounts': repeated, 'inputPrecisionOnlyControls': precision,
        'optimizerHistoryReplayed': False, 'targetMet': False, 'browserVerified': False}
    assert full_actions == 4096 and positives == 612 and captain_full == 128
    assert result['CaptainActionsReplayed'] == 8192 and result['CaptainStrictImprovements'] == 0
    destination.write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps({k: result[k] for k in ['status', 'syntheticActionsReplayed', 'syntheticImprovingActions',
        'CaptainActionsReplayed', 'CaptainStrictImprovements', 'readOnlyFullScoringActions', 'inputPrecisionOnlyControls']}), flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(); parser.add_argument('mode', choices=['training', 'actions'])
    (training if parser.parse_args().mode == 'training' else actions)()
