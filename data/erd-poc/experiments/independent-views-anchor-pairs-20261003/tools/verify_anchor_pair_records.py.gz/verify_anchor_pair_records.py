import sys
from pathlib import Path
sys.path.insert(0,str(Path('scripts/erd-poc').resolve()))
import json,subprocess
import numpy as np
from learn_pair_policy import load,KEYS
from train_anchor_pair_outcomes import outcome_target,regression
from run_anchor_pair_policy import digest

root=Path('.tmp/visualcross-ml-150-750-20261003/pair-anchor-sparse1')
stages=[root/(view+'-'+kind+'1') for kind in ['transfer','adapted'] for view in ['individual','overview']]
reports=[]
for stage in stages:
    r=json.loads((stage/'report.json').read_text())
    p=subprocess.run([sys.executable,'scripts/erd-poc/run_anchor_pair_policy.py','replay','--out',str(stage)],check=True,capture_output=True,text=True)
    replay=json.loads(p.stdout);assert r['accepted']==0
    reference=root/'actual-validation'/(r['view']+'-sparse.tsv')
    for suffix in ['', '.routes.tsv','.individual','.individual.routes.tsv']:
        assert digest(stage/('learned.tsv'+suffix))==digest(Path(str(reference)+suffix))
    actions=[json.loads(line) for line in (stage/'actions.jsonl').read_text().splitlines()]
    legal=[row['result']['visual'] for row in actions if row['result']['legal']]
    reports.append({'stage':str(stage),'view':r['view'],'replay':replay,'sourceGeometryUnchanged':True,
        'bestLegalMeasuredVisual':min(legal),'equalVisualActions':sum(v==r['initialVisual'] for v in legal),
        'reasons':r['reasons'],'wallSeconds':r['wallSeconds']})

training=json.loads((root/'anchor-outcomes-v1.training.json').read_text())
assert digest('scripts/erd-poc/train_anchor_pair_outcomes.py')==training['scriptSha256']
model,_=load(Path(training['pretrainedCheckpoint']));features=[];targets=[]
for entry in training['sourceStages']:
    stage=Path(entry['stage']);assert digest(stage/'report.json')==entry['reportSha256']
    report=json.loads((stage/'report.json').read_text())
    with np.load(stage/'observations.npz',allow_pickle=False) as saved:
        f=saved['pair_features'].copy();order=np.argsort(-saved['scores'],kind='stable')
    for line in (stage/'actions.jsonl').read_text().splitlines():
        row=json.loads(line);features.append(f[order[row['rank']]])
        targets.append(outcome_target(row['result'],report['initialVisual']))
x=np.array(features);y=np.array(targets);train_ids=np.array(training['trainingRowIndices']);val=np.array(training['validationRowIndices'])
assert set(train_ids).isdisjoint(val) and len(set(train_ids)|set(val))==len(y)
rng=np.random.default_rng(training['seed'])
for entry in training['sourceStages']:
    report=json.loads((Path(entry['stage'])/'report.json').read_text());rng.permutation(report['attempts'])
first={k:np.zeros_like(v) for k,v in model.p.items()};second={k:v.copy() for k,v in first.items()};updates=0;best=None
for expected in training['history']:
    ids=rng.permutation(train_ids)
    for offset in range(0,len(ids),128):
        batch=ids[offset:offset+128];_,grads=regression(model,x[batch],y[batch],True)
        norm=np.sqrt(sum(np.sum(g*g) for g in grads.values()));updates+=1
        for k in KEYS:
            g=grads[k]*min(1,5/max(norm,1e-12));first[k]=.9*first[k]+.1*g;second[k]=.999*second[k]+.001*g*g
            model.p[k]-=.001*(first[k]/(1-.9**updates))/(np.sqrt(second[k]/(1-.999**updates))+1e-8)
    actual=regression(model,x[val],y[val]);assert actual==expected['validationHuber'] and updates==expected['updates']
    if expected['epoch']==training['bestEpoch']:best={k:v.copy() for k,v in model.p.items()};selected_updates=updates
saved,_=load(root/'anchor-outcomes-v1.npz')
assert all(np.array_equal(best[k],saved.p[k]) for k in KEYS)
original,_=load(Path(training['pretrainedCheckpoint']))
changes={k:float(np.linalg.norm(saved.p[k]-original.p[k])) for k in KEYS};assert all(value>0 for value in changes.values())
report={'status':'pass','stages':reports,'trainingUpdatesReplayed':updates,'selectedCheckpointUpdates':selected_updates,
    'selectedWeightsBitwiseReproduced':True,'parameterGroupChangesL2':changes,
    'actualImprovementExamples':training['actualImprovementExamples'],'nativeScoresRecomputed':False,
    'totalActionsReplayed':sum(r['replay']['actions'] for r in reports)}
(root/'records-verification.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report))
