"""Exclusive archive writer; copies and verifies bytes, never reruns experiments."""
from pathlib import Path
import ast,gzip,hashlib,json,shutil

root=Path('.tmp/visualcross-ml-150-750-20261003/pair-anchor-sparse1')
archive=Path('data/erd-poc/experiments/independent-views-anchor-pairs-20261003')
assert not archive.exists();archive.mkdir(parents=True)
digest=lambda data:hashlib.sha256(data).hexdigest()
resources={'policy':'serialized; one math thread; nice +10; 256 MiB process-group RSS guard; no hard CPU-percent quota',
    'compilePeakMiB':203.9,'nativeSelfTest':{'fullGeometryComparisons':576,'sparseComparisons':1764,'legalBatches':335,'peakMiB':3.4},
    'actualValidationPeakMiB':80.2,'regressionGradientTest':{'comparisons':31,'maxError':2.795026016189084e-11,'peakMiB':34.1},
    'trainingPeakMiB':48.6,'recordsVerificationPeakMiB':88.8,
    'inferencePeaksMiB':{'individual-transfer1':69.1,'overview-transfer1':67.1,'individual-adapted1':66.7,'overview-adapted1':66.2},
    'recordedFromSuccessfulToolOutputs':True}
(root/'resources.json').write_text(json.dumps(resources,indent=2)+'\n')
entries={str(p):Path('run')/p.relative_to(root) for p in sorted(root.rglob('*')) if p.is_file()}
scripts=Path('scripts/erd-poc');pending=['run_anchor_pair_policy.py','train_anchor_pair_outcomes.py'];seen=set()
while pending:
    name=pending.pop()
    if name in seen:continue
    seen.add(name);p=scripts/name;entries[str(p)]=Path('code')/name
    for node in ast.walk(ast.parse(p.read_text())):
        modules=[node.module] if isinstance(node,ast.ImportFrom) else [n.name for n in node.names] if isinstance(node,ast.Import) else []
        for module in modules:
            if module and (scripts/(module+'.py')).is_file():pending.append(module+'.py')
for name in ['validate_anchor_pair_sparse.py','verify_anchor_pair_records.py','seal_anchor_pair_research.py']:
    entries[str(Path('.tmp')/name)]=Path('tools')/name
entries[str(scripts/'run_memory_bounded.py')]=Path('code/run_memory_bounded.py')
checkpoint=Path('.tmp/visualcross-ml-targets-20261003/pair-policy-v1.npz')
entries[str(checkpoint)]=Path('pretrained')/checkpoint.name
source_base=Path('.tmp/visualcross-ml-150-750-20261003')
for view in ['individual','overview']:
    directory=source_base/(view+'-slot-cached1')
    for name in [prefix+name for prefix in ['', 'individual.'] for name in ['nodes.tsv','edges.tsv','positions.tsv','routes.tsv']]+['components.tsv','groups.tsv','joint-observations.json','experiment.json']:
        entries[str(directory/name)]=Path('fixtures')/view/name
files=[]
for source,relative in sorted(entries.items()):
    data=Path(source).read_bytes();destination=archive/(str(relative)+'.gz');destination.parent.mkdir(parents=True,exist_ok=True)
    packed=gzip.compress(data,compresslevel=1,mtime=0);destination.write_bytes(packed)
    assert gzip.decompress(destination.read_bytes())==data
    files.append({'source':source,'archive':str(destination.relative_to(archive)),'sha256':digest(data),
        'bytes':len(data),'compressedBytes':len(packed)})
stable=Path('data/erd-poc/candidates/captain-ml-independent-views.layout.json')
stable_sha=digest(stable.read_bytes());assert stable_sha=='da2317d3d9fe72181587f543843bfdde3cc7030ca328e93c4f627ae21ec356e7'
verification=json.loads((root/'records-verification.json').read_text())
training=json.loads((root/'anchor-outcomes-v1.training.json').read_text())
validation=json.loads((root/'actual-validation/report.json').read_text())
manifest={'scope':'exact sparse joint scoring and learned equal-size anchor pair proposals',
    'retainedCandidate':str(stable),'retainedCandidateSha256':stable_sha,'promotedCandidateChanged':False,
    'overviewVisual':289,'individualVisual':1964,'targetOverview':150,'targetIndividual':750,'targetMet':False,
    'browserVerified':False,'newProductCandidateCreated':False,
    'sourceGeometryUnchangedForAllFourStages':True,'allCompressedFilesRoundTripHashVerified':True,
    'policyActions':2048,'identityActions':0,'acceptedActions':0,'trainingUpdatesExecuted':280,
    'selectedCheckpointUpdates':217,'adaptedCheckpointSha256':training['checkpointSha256'],
    'actualImprovementTrainingExamples':0,'initialValidationHuber':training['initialValidationHuber'],
    'bestValidationHuber':training['bestValidationHuber'],'validationScope':training['validationScope'],
    'causalAblationVerified':False,'globalTargetImpossibleProved':False,
    'nativeScoringValidation':validation,'recordsVerification':verification,'resources':resources,
    'logicalFiles':len(files),'logicalBytes':sum(f['bytes'] for f in files),'files':files}
path=archive/'manifest.json';path.write_text(json.dumps(manifest,indent=2)+'\n');manifest_sha=digest(path.read_bytes())
provenance=Path('data/erd-poc/candidates/captain-ml-independent-views.provenance.json');before=provenance.read_text();report=json.loads(before)
entry={'archiveManifest':str(path),'archiveManifestSha256':manifest_sha,'promotedCandidateChanged':False,
    'retainedCandidateSha256':stable_sha,'overviewVisual':289,'individualVisual':1964,'newNetworkTrainingUpdates':280,
    'frozenModelPairProposals':2048,'identityOutputBatches':0,'acceptedActions':0,'exactSparseComparisons':1764,
    'actualSceneComparisonActions':48,'targetMet':False,'browserVerified':False}
assert all(row['archiveManifest']!=str(path) for row in report['subsequentResearchArchives'])
report['subsequentResearchArchives'].append(entry)
assert provenance.read_text()==before;provenance.write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'manifest':str(path),'manifestSha256':manifest_sha,'files':len(files),'logicalBytes':manifest['logicalBytes'],
    'restoredHashesVerified':True,'promotedCandidateUnchanged':True}))
