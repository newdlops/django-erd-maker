import sys
from pathlib import Path
sys.path.insert(0,str(Path('scripts/erd-poc').resolve()))
import json,time,hashlib
import numpy as np
from run_anchor_pair_policy import PairDecoder,Native,pair_features,wire,digest
from learn_pair_policy import load

root=Path('.tmp/visualcross-ml-150-750-20261003')
out=root/'pair-anchor-sparse1'/'actual-validation';out.mkdir(exist_ok=False)
checkpoint=Path('.tmp/visualcross-ml-targets-20261003/pair-policy-v1.npz')
model,_=load(checkpoint);report={'views':[],'sourceCodeSha256':digest('scripts/erd-poc/run_anchor_pair_policy.py')}
for view in ['individual','overview']:
    directory=root/(view+'-slot-cached1');decoder=PairDecoder(directory)
    old=json.loads((directory/'joint-observations.json').read_text())
    features=np.array([row['features'][:64] for row in old['nodes']])
    vocabulary=decoder.vocabulary(98337,4096)
    f,error=pair_features(features,decoder,vocabulary,view=='overview')
    scores=model.forward(f)[0];order=np.argsort(-scores,kind='stable')
    actions=[np.zeros((len(decoder.positions)+len(decoder.owner_edges),2))]
    actions += [decoder.action(*vocabulary[i]) for i in order[:16]]
    actions += [decoder.action(*vocabulary[i]) for i in order[-4:]]
    frame=actions[0].copy();frame[0]=[1e6,0];actions.append(frame)
    collide=actions[0].copy();collide[0]=decoder.positions[1]-decoder.positions[0];actions.append(collide)
    port=actions[0].copy();port[len(decoder.positions)]=[.1,-.1];actions.append(port)
    assert len(actions)==24
    wires=[wire(action,'MEASURE') for action in actions]
    rows=[];outputs=[];times=[];initials=[]
    for label,environment,sparse in [
        ('reference',root/'joint-batch-environment-v7',False),
        ('full',root/'pair-anchor-sparse1'/'environment',False),
        ('sparse',root/'pair-anchor-sparse1'/'environment',True)]:
        start=time.monotonic();dest=out/(view+'-'+label+'.tsv')
        native=Native(environment,directory,dest,view=='overview',sparse)
        initial=native.initial;initials.append(initial)
        init_time=time.monotonic()-start;start=time.monotonic()
        try:
            response=[native.request(command) for command in wires]
            assert native.request('SAVE')['saved']
        finally:native.close()
        elapsed=time.monotonic()-start
        stats=json.loads(Path(str(dest)+'.stats.json').read_text())
        assert stats['policyActionsEvaluated']==stats['acceptedActions']==0
        rows.append(response)
        outputs.append([digest(Path(str(dest)+suffix)) for suffix in ['', '.routes.tsv','.individual','.individual.routes.tsv']])
        times.append({'mode':label,'initializationSeconds':init_time,'measurementAndSaveSeconds':elapsed})
        print(json.dumps({'view':view,**times[-1]}),flush=True)
    assert rows[0]==rows[1]==rows[2]
    assert outputs[0]==outputs[1]==outputs[2]
    assert initials[0]==initials[1]==initials[2]
    assert np.array_equal(np.array([row['features'] for row in initials[0]['nodes']]),features)
    item={'view':view,'comparisonsPerBackend':len(wires),'exactResponses':True,'exactInitialObservations':True,
          'nonCommittingSavesIdentical':True,'scaleFeatureMaxError':error,'timing':times,
          'reasons':{reason:sum(row['reason']==reason for row in rows[0]) for reason in sorted({row['reason'] for row in rows[0]})}}
    report['views'].append(item)
    (out/(view+'-measurements.json')).write_text(json.dumps(rows[0],indent=2)+'\n')
report['status']='pass'
(out/'report.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report),flush=True)
