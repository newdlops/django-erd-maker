import sys,json
from pathlib import Path
sys.path.insert(0,str(Path('scripts/erd-poc').resolve()))
import numpy as np
from full_context_pair_model import EXTRA,expand,pressure,warm
from learn_pair_policy import load
from train_anchor_pair_outcomes import regression

root=Path('.tmp/visualcross-ml-150-750-20261003');out=root/'full-pair-model1';out.mkdir(exist_ok=False)
parent,_=load(root/'pair-anchor-sparse1/anchor-outcomes-v1.npz')
with np.load(root/'pair-anchor-sparse1/individual-adapted1/observations.npz') as saved:
    nodes=saved['node_features'].copy();vocabulary=saved['pairs'][:32].copy();base=saved['pair_features'][:32].copy()
x=expand(base,nodes,vocabulary);a,b=vocabulary.T
for endpoint,ids,first,frame,extra in [(0,a,0,52,64),(1,b,24,56,100)]:
    recovered=np.empty((len(x),64));recovered[:,:24]=x[:,first:first+24]
    recovered[:,56:60]=x[:,frame:frame+4];recovered[:,EXTRA]=x[:,extra:extra+36]
    assert np.array_equal(recovered,nodes[ids])
assert np.array_equal(x[:,:64],base)
model,error=warm(parent,x,np.arange(len(x)))
targets=np.linspace(-9,1,len(x));_,grad=regression(model,x,targets,True)
indices=[('w1',(row,col)) for row in [64,72,90,99,100,108,125,135] for col in [0,31,63]]
indices += [('wo',(i,)) for i in [0,31,63]]+[('b1',(i,)) for i in [0,31,63]]+[('bo',(0,))]
largest=0
for key,index in indices:
    value=model.p[key][index];model.p[key][index]=value+1e-5;hi=regression(model,x,targets)
    model.p[key][index]=value-1e-5;lo=regression(model,x,targets);model.p[key][index]=value
    difference=abs((hi-lo)/2e-5-grad[key][index]);assert difference<2e-6,(key,index,difference);largest=max(largest,difference)
test=np.zeros((4,64));pairs=np.array([[0,1],[1,2],[2,3]])
assert not pressure(test,pairs).any();test[0,4]=1;assert np.array_equal(pressure(test,pairs),[True,False,False])
test[3,6]=1;assert np.array_equal(pressure(test,pairs),[True,False,False]);test[3,5]=1
assert np.array_equal(pressure(test,pairs),[True,False,True])
report={'status':'pass','allNativeNodeFeaturesRecovered':True,'legacy64InputsUnchanged':True,
    'warmPredictionMaxDifference':error,'finiteDifferences':len(indices),'extraRowsChecked':8,
    'maxGradientError':largest,'objectivePressureMaskChecks':'pass'}
(out/'feature-validation.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
