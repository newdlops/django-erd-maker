"""Seal this completed experiment, referencing verified prior archive bytes."""
from pathlib import Path
import ast
import gzip
import hashlib
import json

root = Path('.tmp/visualcross-ml-150-750-20261003/full-pair-model1')
archive = Path('data/erd-poc/experiments/independent-views-full-context-pairs-20261003')
assert not archive.exists()
sha = lambda data: hashlib.sha256(data).hexdigest()
digest = lambda path: sha(Path(path).read_bytes())
training = json.loads((root/'training1/training.json').read_text())
verification = json.loads((root/'records-verification.json').read_text())
assert verification['status'] == 'pass'
reports = [json.loads((root/(view+'-full1')/'report.json').read_text()) for view in ['individual', 'overview']]
assert all(report['accepted'] == 0 for report in reports)
resources = {'policy': 'serialized numerical jobs; one math thread; nice +10; 256 MiB process-group RSS guard; no hard CPU-percent quota',
    'featureValidationPeakMiB': 32.6, 'trainingPeakMiB': 80.2,
    'inferencePeakMiB': {'individual': 116.0, 'overview': 78.3},
    'recordsVerificationPeakMiB': 167.1, 'recordedFromSuccessfulToolOutputs': True}
(root/'resources.json').write_text(json.dumps(resources, indent=2)+'\n')

entries = {str(path): Path('run')/path.relative_to(root) for path in sorted(root.rglob('*')) if path.is_file()}
scripts = Path('scripts/erd-poc'); seen = set()
pending = ['full_context_pair_model.py', 'run_full_context_pairs.py', 'run_memory_bounded.py']
while pending:
    name = pending.pop()
    if name in seen:
        continue
    seen.add(name); path = scripts/name; entries[str(path)] = Path('code')/name
    for node in ast.walk(ast.parse(path.read_text())):
        modules = [node.module] if isinstance(node, ast.ImportFrom) else [n.name for n in node.names] if isinstance(node, ast.Import) else []
        for module in modules:
            if module and (scripts/(module+'.py')).is_file():
                pending.append(module+'.py')
for name in ['validate_full_context_pair_model.py', 'verify_full_context_pair_records.py', 'seal_full_context_pair_research.py']:
    entries[str(Path('.tmp')/name)] = Path('tools')/name

prior_index = {}; prerequisite_manifests = []
for name in ['independent-views-anchor-pairs-20261003', 'independent-views-pair-walk-20261003']:
    path = archive.parent/name/'manifest.json'; old = json.loads(path.read_text())
    prerequisite_manifests.append({'path': str(path), 'sha256': digest(path)})
    for entry in old['files']:
        prior_index[entry['source']] = (path.parent, entry)
dependencies = {training['parent']}
for source in training['sourceStages']:
    stage = Path(source['stage']); report = json.loads((stage/'report.json').read_text())
    dependencies.update(str(stage/name) for name in ['report.json', 'observations.npz', 'actions.jsonl'])
    dependencies.add(report['checkpoint'])
for report in reports:
    dependencies.add(report['environment'])
    dependencies.update(str(Path(report['sourceDirectory'])/name) for name in report['sourceInputs'])
    dependencies.update(str(path) for path in (Path(report['environment']).parent/'build-inputs').glob('*') if path.is_file())
    reference = root.parent/'pair-anchor-sparse1/actual-validation'/(report['view']+'-sparse.tsv')
    dependencies.update(str(reference)+suffix for suffix in ['', '.routes.tsv', '.individual', '.individual.routes.tsv'])
referenced = []
for source in sorted(dependencies):
    assert source in prior_index, source
    prior_directory, entry = prior_index[source]
    restored = gzip.decompress((prior_directory/entry['archive']).read_bytes())
    assert sha(restored) == entry['sha256'] == digest(source)
    referenced.append({'source': source, 'archive': str(prior_directory/entry['archive']),
        'sha256': entry['sha256'], 'bytes': entry['bytes'], 'restoreHashVerified': True})

stable = Path('data/erd-poc/candidates/captain-ml-independent-views.layout.json')
stable_sha = digest(stable)
assert stable_sha == 'da2317d3d9fe72181587f543843bfdde3cc7030ca328e93c4f627ae21ec356e7'
archive.mkdir(parents=True); files = []
for source, relative in sorted(entries.items()):
    data = Path(source).read_bytes(); dest = archive/(str(relative)+'.gz')
    dest.parent.mkdir(parents=True, exist_ok=True)
    packed = gzip.compress(data, compresslevel=1, mtime=0); dest.write_bytes(packed)
    assert gzip.decompress(dest.read_bytes()) == data
    files.append({'source': source, 'archive': str(dest.relative_to(archive)), 'sha256': sha(data),
        'bytes': len(data), 'compressedBytes': len(packed)})
manifest = {'scope': 'full native context pair critic and batched ranking of every conflict-touching equal-size pair',
    'retainedCandidate': str(stable), 'retainedCandidateSha256': stable_sha, 'promotedCandidateChanged': False,
    'overviewVisual': 289, 'individualVisual': 1964, 'targetOverview': 150, 'targetIndividual': 750, 'targetMet': False,
    'browserVerified': False, 'newExperimentalCandidates': 0,
    'newTrainingUpdates': training['newTrainingUpdatesExecuted'], 'selectedCheckpointUpdates': training['selectedCheckpointUpdates'],
    'modelParameterCount': training['parameterCount'], 'modelInputFeatures': 136,
    'trainingUniqueActions': training['rows'], 'trainingActiveActions': training['activeRows'],
    'actualImprovementTrainingExamples': 0,
    'neuralScoresComputed': verification['allEligibleNeuralScoresReplayed'],
    'nativeModelProposals': verification['totalModelActionsReplayed'], 'strictImprovements': 0,
    'allSubmittedPairsTouchDirectConflicts': True, 'savedSourceGeometryByteIdentical': True,
    'nativeScoresRecomputedByReplay': False, 'causalAblationVerified': False, 'globalTargetImpossibleProved': False,
    'featureValidation': json.loads((root/'feature-validation.json').read_text()),
    'recordsVerification': verification, 'resources': resources,
    'prerequisiteManifests': prerequisite_manifests, 'referencedFiles': referenced,
    'referencedLogicalBytes': sum(entry['bytes'] for entry in referenced),
    'allReferencedFilesRestoreHashVerified': True,
    'logicalFiles': len(files), 'logicalBytes': sum(entry['bytes'] for entry in files),
    'allCompressedFilesRoundTripHashVerified': True, 'files': files}
path = archive/'manifest.json'; path.write_text(json.dumps(manifest, indent=2)+'\n'); manifest_sha = digest(path)
provenance = Path('data/erd-poc/candidates/captain-ml-independent-views.provenance.json')
before = provenance.read_text(); doc = json.loads(before)
assert doc['candidateSha256'] == stable_sha
assert all(entry['archiveManifest'] != str(path) for entry in doc['subsequentResearchArchives'])
doc['subsequentResearchArchives'].append({'archiveManifest': str(path), 'archiveManifestSha256': manifest_sha,
    'promotedCandidateChanged': False, 'retainedCandidateSha256': stable_sha, 'overviewVisual': 289, 'individualVisual': 1964,
    'newNetworkTrainingUpdates': training['newTrainingUpdatesExecuted'], 'selectedCheckpointUpdates': training['selectedCheckpointUpdates'],
    'modelInputFeatures': 136, 'neuralRankedPairs': manifest['neuralScoresComputed'],
    'frozenModelPairProposals': manifest['nativeModelProposals'], 'acceptedActions': 0,
    'targetMet': False, 'browserVerified': False})
assert provenance.read_text() == before
provenance.write_text(json.dumps(doc, indent=2)+'\n')
print(json.dumps({'manifest': str(path), 'manifestSha256': manifest_sha, 'files': len(files),
    'logicalBytes': manifest['logicalBytes'], 'referencedFiles': len(referenced),
    'reusedPriorLogicalBytes': manifest['referencedLogicalBytes'],
    'allStoredAndReferencedBytesVerified': True, 'promotedCandidateUnchanged': True}))
