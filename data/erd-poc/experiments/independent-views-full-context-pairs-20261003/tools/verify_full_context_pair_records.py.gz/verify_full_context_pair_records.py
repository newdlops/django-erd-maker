"""Replay training and frozen model outputs without another native search."""
import sys
from pathlib import Path
sys.path.insert(0, str(Path('scripts/erd-poc').resolve()))
import hashlib
import json
import subprocess
import numpy as np
from full_context_pair_model import collect, warm, load, pressure
from learn_pair_policy import load as load_parent, KEYS
from run_anchor_pair_policy import digest
from train_anchor_pair_outcomes import regression

root = Path('.tmp/visualcross-ml-150-750-20261003/full-pair-model1')
training = json.loads((root/'training1/training.json').read_text())
assert digest('scripts/erd-poc/full_context_pair_model.py') == training['scriptSha256']
assert digest(training['parent']) == training['parentSha256']
assert digest(root/'training1/dataset.npz') == training['datasetSha256']
assert digest(root/'training1/model.npz') == training['checkpointSha256']
stages = []
for entry in training['sourceStages']:
    stage = Path(entry['stage'])
    assert digest(stage/'report.json') == entry['reportSha256']
    stages.append(stage)
rebuilt, rows, sources = collect(stages)
assert sources == training['sourceStages']
with np.load(root/'training1/dataset.npz', allow_pickle=False) as saved:
    data = {name: saved[name].copy() for name in saved.files}
for name, expected in rebuilt.items():
    if expected.dtype.kind == 'f':
        assert np.array_equal(expected, data[name], equal_nan=True), name
    else:
        assert np.array_equal(expected, data[name]), name
x = data['x']; y = data['y']; active = data['active']; views = data['view']
parent, parent_metadata = load_parent(Path(training['parent']))
prior_stages = {entry['stage'] for entry in parent_metadata['sourceStages']}
prior_ids = {i for i, entry in enumerate(sources) if entry['stage'] in prior_stages}
novel = np.array([not any(i in prior_ids for i in row['sources']) for row in rows])
assert np.array_equal(novel, data['novel_to_parent'])
rng = np.random.default_rng(training['seed']); validation = []
for view in sorted(set(views)):
    for value in [False, True]:
        available = np.flatnonzero((views == view) & (active == value) & novel)
        validation.extend(rng.permutation(available)[:max(1, int(.25*len(available)))])
validation = np.array(sorted(validation))
train_ids = np.setdiff1d(np.arange(len(x)), validation)
sampling = np.r_[train_ids, np.tile(train_ids[active[train_ids]], 3)]
assert np.array_equal(validation, data['validation'])
assert np.array_equal(train_ids, data['training'])
assert np.array_equal(sampling, data['sampling'])
active_validation = validation[active[validation]]
model, warm_error = warm(parent, x, train_ids)
with np.load(root/'training1/model.npz', allow_pickle=False) as saved:
    for key in KEYS:
        assert np.array_equal(model.p[key], saved['initial__'+key])
    assert np.array_equal(model.mean, saved['mean']) and np.array_equal(model.scale, saved['scale'])
initial = {key: value.copy() for key, value in model.p.items()}
first = {key: np.zeros_like(value) for key, value in model.p.items()}
second = {key: value.copy() for key, value in first.items()}
updates = 0; best = None; selected_updates = selected_epoch = 0
best_loss = regression(model, x[active_validation], y[active_validation])
assert best_loss == training['initialActiveValidationHuber']
for expected in training['history']:
    order = rng.permutation(sampling)
    for offset in range(0, len(order), 128):
        batch = order[offset:offset+128]
        _, gradients = regression(model, x[batch], y[batch], True)
        norm = np.sqrt(sum(np.sum(g*g) for g in gradients.values())); updates += 1
        for key in KEYS:
            gradient = gradients[key]*min(1, 5/max(norm, 1e-12))
            first[key] = .9*first[key]+.1*gradient
            second[key] = .999*second[key]+.001*gradient*gradient
            model.p[key] -= .001*(first[key]/(1-.9**updates))/(np.sqrt(second[key]/(1-.999**updates))+1e-8)
        if updates == expected['updates']:
            break
    loss = regression(model, x[active_validation], y[active_validation])
    assert updates == expected['updates'] and loss == expected['activeValidationHuber']
    assert regression(model, x[validation], y[validation]) == expected['allValidationHuber']
    if loss < best_loss:
        best_loss = loss; best = {key: value.copy() for key, value in model.p.items()}
        selected_updates = updates; selected_epoch = expected['epoch']
assert updates == training['newTrainingUpdatesExecuted']
assert (selected_updates, selected_epoch) == (training['selectedCheckpointUpdates'], training['selectedEpoch'])
restored, _ = load(root/'training1/model.npz')
assert all(np.array_equal(best[key], restored.p[key]) for key in KEYS)
changes = {key: float(np.linalg.norm(best[key]-initial[key])) for key in KEYS}
assert all(value > 0 for value in changes.values())

reports = []
for view in ['individual', 'overview']:
    stage = root/(view+'-full1'); report = json.loads((stage/'report.json').read_text())
    result = subprocess.run([sys.executable, 'scripts/erd-poc/run_full_context_pairs.py', 'replay',
                             '--out', str(stage)], check=True, capture_output=True, text=True)
    replay = json.loads(result.stdout); assert report['accepted'] == 0
    reference = root.parent/'pair-anchor-sparse1/actual-validation'/(view+'-sparse.tsv')
    for suffix in ['', '.routes.tsv', '.individual', '.individual.routes.tsv']:
        assert digest(stage/('learned.tsv'+suffix)) == digest(Path(str(reference)+suffix))
    actions = [json.loads(line) for line in (stage/'actions.jsonl').read_text().splitlines()]
    with np.load(stage/'observations.npz', allow_pickle=False) as observations:
        action_pairs = np.array([(row['source'], row['target']) for row in actions])
        assert pressure(observations['node_features'], action_pairs).all()
    legal = [row['result']['visual'] for row in actions if row['result']['legal']]
    reports.append({'view': view, 'replay': replay, 'reasons': report['reasons'],
        'savedGeometryByteIdenticalToReference': True, 'bestLegalMeasuredVisual': min(legal),
        'equalVisualActions': legal.count(report['initialVisual']),
        'allSubmittedPairsTouchDirectConflicts': True,
        'positiveModelPredictions': sum(row['score'] > 0 for row in actions),
        'modelImprovementPredictionsConfirmed': 0})

stable = Path('data/erd-poc/candidates/captain-ml-independent-views.layout.json')
assert digest(stable) == 'da2317d3d9fe72181587f543843bfdde3cc7030ca328e93c4f627ae21ec356e7'
result = {'status': 'pass', 'datasetReconstructedFromMeasuredSources': True,
    'uniqueRows': len(x), 'activeRows': int(active.sum()),
    'validationPairsAbsentFromParentTraining': True, 'unseenGraphValidation': False,
    'trainingUpdatesReplayed': updates, 'selectedCheckpointUpdates': selected_updates,
    'selectedWeightsBitwiseReproduced': True, 'parameterGroupChangesL2': changes,
    'warmPredictionMaxDifference': warm_error, 'actualImprovementExamples': int(np.sum(data['actual_gain'] > 0)),
    'stages': reports, 'nativeScoresRecomputed': False, 'promotedCandidateUnchanged': True,
    'allEligibleNeuralScoresReplayed': sum(row['replay']['allEligibleNeuralScoresReplayed'] for row in reports),
    'totalModelActionsReplayed': sum(row['replay']['modelRankedActionsReplayed'] for row in reports)}
(root/'records-verification.json').write_text(json.dumps(result, indent=2)+'\n')
print(json.dumps(result))
