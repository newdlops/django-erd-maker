"""Rebuild adaptation data and replay updates, scores and decoded proposals."""
import sys
from pathlib import Path
sys.path.insert(0, str(Path('scripts/erd-poc').resolve()))
import json
from contextlib import redirect_stdout
from io import StringIO
from types import SimpleNamespace
import numpy as np
from full_context_pair_model import load
from learn_pair_policy import KEYS
from train_active_pair_outcomes import collect, split
from train_anchor_pair_outcomes import regression
from run_anchor_pair_policy import digest
from run_anchor_pair_walk import WalkDecoder
from run_active_pair_policy import replay as replay_active
from run_neural_cycle_policy import replay as replay_cycles

root = Path('.tmp/visualcross-ml-150-750-20261003/active-pair-model1')
training = json.loads((root/'training1/training.json').read_text())
for name, expected in training['codeSha256'].items():
    assert digest(Path('scripts/erd-poc')/name) == expected
assert digest(root/'training1/model.npz') == training['checkpointSha256']
assert digest(root/'training1/dataset.npz') == training['datasetSha256']
assert digest(training['parent']) == training['parentSha256']
parent = Path(training['parentDirectory'])
assert digest(parent/'training.json') == training['parentTrainingReportSha256']
assert digest(parent/'dataset.npz') == training['parentDatasetSha256']
stages = [Path(source['stage']) for source in training['sourceStages']]
rebuilt, sources, inputs, duplicates = collect(parent, stages)
assert sources == training['sourceStages'] and inputs == training['sourceInputsByView']
assert duplicates == training['duplicatesRemoved']
with np.load(root/'training1/dataset.npz', allow_pickle=False) as saved:
    data = {name: saved[name].copy() for name in saved.files}
for name, expected in rebuilt.items():
    assert np.array_equal(expected, data[name], equal_nan=True) if expected.dtype.kind == 'f' else np.array_equal(expected, data[name])
train_ids, validation, sampling, rng = split(data, training['seed'])
assert np.array_equal(train_ids, data['training'])
assert np.array_equal(validation, data['validation']) and np.array_equal(sampling, data['sampling'])
with np.load(parent/'dataset.npz', allow_pickle=False) as parent_data:
    parent_keys = {(str(view), int(pair[0]), int(pair[1])) for view, pair in zip(parent_data['view'], parent_data['pairs'])}
assert all((str(data['view'][i]), *map(int, data['pairs'][i])) not in parent_keys for i in validation)
model, _ = load(parent/'model.npz'); x = data['x']; y = data['y']
initial = {key: value.copy() for key, value in model.p.items()}
with np.load(root/'training1/model.npz', allow_pickle=False) as saved:
    assert all(np.array_equal(initial[key], saved['initial__'+key]) for key in KEYS)
    assert np.array_equal(model.mean, saved['mean']) and np.array_equal(model.scale, saved['scale'])
first = {key: np.zeros_like(value) for key, value in model.p.items()}
second = {key: value.copy() for key, value in first.items()}; updates = 0
best_loss = regression(model, x[validation], y[validation]); assert best_loss == training['initialValidationHuber']
best = initial; selected_epoch = selected_updates = 0
for expected in training['history']:
    order = rng.permutation(sampling)
    for offset in range(0, len(order), 128):
        batch = order[offset:offset+128]; _, gradients = regression(model, x[batch], y[batch], True)
        norm = np.sqrt(sum(np.sum(g*g) for g in gradients.values())); updates += 1
        for key in KEYS:
            gradient = gradients[key]*min(1, 5/max(norm, 1e-12))
            first[key] = .9*first[key]+.1*gradient
            second[key] = .999*second[key]+.001*gradient*gradient
            model.p[key] -= .001*(first[key]/(1-.9**updates))/(np.sqrt(second[key]/(1-.999**updates))+1e-8)
        if updates == expected['updates']:
            break
    actual = regression(model, x[validation], y[validation])
    assert actual == expected['validationHuber'] and updates == expected['updates']
    if actual < best_loss:
        best_loss = actual; best = {key: value.copy() for key, value in model.p.items()}
        selected_updates = updates; selected_epoch = expected['epoch']
assert updates == training['newTrainingUpdatesExecuted']
assert (selected_updates, selected_epoch) == (training['selectedCheckpointUpdates'], training['selectedEpoch'])
restored, _ = load(root/'training1/model.npz')
assert all(np.array_equal(best[key], restored.p[key]) for key in KEYS)
changes = {key: float(np.linalg.norm(best[key]-initial[key])) for key in KEYS}
assert all(value > 0 for value in changes.values())
reports = []
for kind, replay_stage in [('active', replay_active), ('cycles', replay_cycles)]:
    for view in ['individual', 'overview']:
        stage = root/(view+'-'+kind+'1'); report = json.loads((stage/'report.json').read_text())
        output = StringIO()
        with redirect_stdout(output):
            replay_stage(SimpleNamespace(out=stage))
        replay = json.loads(output.getvalue())
        source_identical = False
        if report['accepted'] == 0:
            reference = root.parent/'pair-anchor-sparse1/actual-validation'/(view+'-sparse.tsv')
            for suffix in ['', '.routes.tsv', '.individual', '.individual.routes.tsv']:
                assert digest(stage/('learned.tsv'+suffix)) == digest(Path(str(reference)+suffix))
            source_identical = True
        rows = [json.loads(line) for line in (stage/'actions.jsonl').read_text().splitlines()]
        legal = [row['result']['visual'] for row in rows if row['result']['legal']]
        decoder = WalkDecoder(Path(report['sourceDirectory']))
        selected = np.array([row['cycle'] if kind == 'cycles' else [row['source'], row['target']] for row in rows])
        relevant_counts = np.sum(~decoder.irrelevant_isolate[selected], axis=1)
        with np.load(stage/'observations.npz', allow_pickle=False) as saved:
            active = np.any(saved['node_features'][:, 4:6] > 0, axis=1)
            active_counts = np.sum(active[selected], axis=1)
        assert (active_counts >= 1).all() and (relevant_counts >= 1).all()
        reports.append({'stage': str(stage), 'view': view, 'family': kind, 'replay': replay,
            'savedGeometryByteIdenticalToReference': source_identical,
            'bestLegalMeasuredVisual': min(legal) if legal else None,
            'equalVisualActions': legal.count(report['initialVisual']), 'reasons': report['reasons'],
            'positiveProxyPredictions': sum(row['score'] > 0 for row in rows),
            'nonIsolatedSingleOwnersPerProposal': {str(n): int(np.sum(relevant_counts == n)) for n in range(1, selected.shape[1]+1)},
            'directlyConflictingOwnersPerProposal': {str(n): int(np.sum(active_counts == n)) for n in range(1, selected.shape[1]+1)}})
result = {'status': 'pass', 'datasetReconstructedFromMeasuredSources': True,
    'rows': len(x), 'newUniqueMeasuredPairs': int(data['novel_to_parent'].sum()), 'duplicatesRemoved': duplicates,
    'validationPairsAbsentFromCompleteParentDataset': True, 'unseenGraphValidation': False,
    'trainingUpdatesReplayed': updates, 'selectedCheckpointUpdates': selected_updates,
    'selectedWeightsBitwiseReproduced': True, 'normalizationUnchanged': True,
    'parameterGroupChangesL2': changes, 'actualImprovementTrainingExamples': int(np.sum(data['actual_gain'] > 0)),
    'stages': reports, 'nativeScoresRecomputed': False,
    'modelActionsReplayed': sum(report['replay'].get('modelActionsReplayed', report['replay'].get('modelRankedActionsReplayed', 0)) for report in reports)}
(root/'records-verification.json').write_text(json.dumps(result, indent=2)+'\n'); print(json.dumps(result))
