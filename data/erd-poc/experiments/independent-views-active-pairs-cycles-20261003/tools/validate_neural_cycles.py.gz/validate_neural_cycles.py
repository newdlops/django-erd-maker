import sys
from pathlib import Path
sys.path.insert(0, str(Path('scripts/erd-poc').resolve()))
import json
import numpy as np
from full_context_pair_model import load, expand
from run_anchor_pair_policy import pair_features
from run_anchor_pair_walk import WalkDecoder
from run_neural_cycle_policy import cycles, cycle_action, rank_cycles

base = Path('.tmp/visualcross-ml-150-750-20261003')
root = base/'active-pair-model1'; model, _ = load(root/'training1/model.npz')
results = []; largest = 0
for view in ['individual', 'overview']:
    decoder = WalkDecoder(base/(view+'-slot-cached1'))
    with np.load(base/'full-pair-model1'/(view+'-full1')/'observations.npz', allow_pickle=False) as saved:
        features = saved['node_features'].copy()
    vocabulary, support = cycles(decoder, features, 84021, 64)
    replay, repeated_support = cycles(decoder, features, 84021, 64)
    assert np.array_equal(vocabulary, replay) and support == repeated_support
    assert np.any(features[vocabulary][:, :, 4:6] > 0, axis=(1, 2)).all()
    assert np.array_equal(decoder.sizes[vocabulary[:, 0]], decoder.sizes[vocabulary[:, 1]])
    assert np.array_equal(decoder.sizes[vocabulary[:, 0]], decoder.sizes[vocabulary[:, 2]])
    for cycle in vocabulary[:32]:
        a, b, c = map(int, cycle)
        action = cycle_action(decoder, cycle); delta = action[:len(decoder.positions)]
        expected = np.zeros_like(delta)
        expected[a] = decoder.positions[b]-decoder.positions[a]
        expected[b] = decoder.positions[c]-decoder.positions[b]
        expected[c] = decoder.positions[a]-decoder.positions[c]
        expected = np.copysign(np.floor(abs(expected)*100+.5), expected)/100
        assert np.array_equal(delta, expected)
        assert set(np.flatnonzero(np.any(delta, axis=1))) == {a, b, c}
        assert np.max(abs(delta.sum(0))) <= .010000001
        assert np.isfinite(action).all() and np.max(abs(action[len(delta):])) <= .5
        inverse = cycle_action(decoder, [a, c, b])
        assert not np.array_equal(action, inverse)
    scores, _, _ = rank_cycles(model, decoder, features, vocabulary, view == 'overview')
    assert np.array_equal(scores[::2], scores[1::2])
    # Independent scalar factor construction verifies the transfer-score meaning.
    for i, (a, b, c) in enumerate(vocabulary[::2][:8]):
        factors = np.array([[a, b], [a, c], [b, c]], dtype=np.int32)
        plain, _ = pair_features(features, decoder, factors, view == 'overview')
        expected = float(model.forward(expand(plain, features, factors))[0].mean())
        error = abs(expected-scores[2*i]); largest = max(largest, error)
        assert error < 1e-12
    results.append({'view': view, 'cycles': len(vocabulary), 'decodedCyclesVerified': 32,
        'uniformVocabularySeedReplay': True, 'sameSizeAndDirectConflictSupport': True,
        'threeCardPermutationDecoded': True, 'directionInverseProducesDistinctOutput': True,
        'factorScoreMeaningVerified': True})
report = {'status': 'pass', 'views': results, 'maximumScalarFactorScoreError': largest,
    'nativeGeometryNotInvoked': True, 'criticTrainedOnCycles': False}
(root/'cycle-validation.json').write_text(json.dumps(report, indent=2)+'\n'); print(json.dumps(report))
