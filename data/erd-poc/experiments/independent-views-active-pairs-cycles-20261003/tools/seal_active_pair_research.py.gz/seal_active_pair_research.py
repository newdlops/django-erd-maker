"""Exclusive archive of adaptation, unmeasured pairs and three-card cycles."""
from pathlib import Path
import ast
import gzip
import hashlib
import json

root = Path('.tmp/visualcross-ml-150-750-20261003/active-pair-model1')
archive = Path('data/erd-poc/experiments/independent-views-active-pairs-cycles-20261003')
assert not archive.exists()
sha = lambda data: hashlib.sha256(data).hexdigest()
digest = lambda path: sha(Path(path).read_bytes())
training = json.loads((root/'training1/training.json').read_text())
verification = json.loads((root/'records-verification.json').read_text())
assert verification['status'] == 'pass' and verification['modelActionsReplayed'] == 4096
assert all(row['replay']['accepted'] == 0 and row['savedGeometryByteIdenticalToReference'] for row in verification['stages'])
reports = [json.loads((root/(view+'-'+kind+'1')/'report.json').read_text())
           for kind in ['active', 'cycles'] for view in ['individual', 'overview']]
resources = {'policy': 'serialized numerical jobs; one math thread; nice +10; 256 MiB process-group RSS guard; no hard CPU-percent quota',
    'trainingPeakMiB': 113.4, 'cycleValidationPeakMiB': 46.5,
    'inferencePeakMiB': {'individual-active1': 112.4, 'overview-active1': 73.6,
                         'individual-cycles1': 71.1, 'overview-cycles1': 61.8},
    'initialSeparateReplayProcessVerificationPeakMiB': 249.3,
    'finalSingleProcessVerificationPeakMiB': 143.2, 'bothVerificationModesPassed': True,
    'recordedFromSuccessfulToolOutputs': True}
(root/'resources.json').write_text(json.dumps(resources, indent=2)+'\n')
entries = {str(path): Path('run')/path.relative_to(root) for path in sorted(root.rglob('*')) if path.is_file()}
scripts = Path('scripts/erd-poc'); pending = ['train_active_pair_outcomes.py', 'run_active_pair_policy.py',
    'run_neural_cycle_policy.py', 'run_memory_bounded.py']; seen = set()
while pending:
    name = pending.pop()
    if name in seen:
        continue
    seen.add(name); path = scripts/name; entries[str(path)] = Path('code')/name
    for node in ast.walk(ast.parse(path.read_text())):
        modules = [node.module] if isinstance(node, ast.ImportFrom) else [item.name for item in node.names] if isinstance(node, ast.Import) else []
        for module in modules:
            if module and (scripts/(module+'.py')).is_file():
                pending.append(module+'.py')
for name in ['validate_neural_cycles.py', 'verify_active_pair_records.py', 'seal_active_pair_research.py']:
    entries[str(Path('.tmp')/name)] = Path('tools')/name
prior_index = {}; prerequisites = []
for name in ['independent-views-anchor-pairs-20261003', 'independent-views-pair-walk-20261003',
             'independent-views-full-context-pairs-20261003']:
    path = archive.parent/name/'manifest.json'; previous = json.loads(path.read_text())
    prerequisites.append({'path': str(path), 'sha256': digest(path)})
    for entry in previous['files']:
        prior_index[entry['source']] = (path.parent, entry)
dependencies = {training['parent'], str(Path(training['parentDirectory'])/'dataset.npz'),
                str(Path(training['parentDirectory'])/'training.json')}
for source in training['sourceStages']:
    stage = Path(source['stage'])
    dependencies.update(str(stage/name) for name in ['report.json', 'observations.npz', 'actions.jsonl'])
parent_report = json.loads((Path(training['parentDirectory'])/'training.json').read_text())
dependencies.update(str(Path(source['stage'])/'report.json') for source in parent_report['sourceStages'])
for report in reports:
    dependencies.add(report['environment'])
    dependencies.update(str(Path(report['sourceDirectory'])/name) for name in report['sourceInputs'])
    dependencies.update(str(path) for path in (Path(report['environment']).parent/'build-inputs').glob('*') if path.is_file())
    reference = root.parent/'pair-anchor-sparse1/actual-validation'/(report['view']+'-sparse.tsv')
    dependencies.update(str(reference)+suffix for suffix in ['', '.routes.tsv', '.individual', '.individual.routes.tsv'])
referenced = []
for source in sorted(dependencies):
    assert source in prior_index, source
    directory, entry = prior_index[source]
    restored = gzip.decompress((directory/entry['archive']).read_bytes())
    assert sha(restored) == entry['sha256'] == digest(source)
    referenced.append({'source': source, 'archive': str(directory/entry['archive']), 'sha256': entry['sha256'],
        'bytes': entry['bytes'], 'restoreHashVerified': True})
stable = Path('data/erd-poc/candidates/captain-ml-independent-views.layout.json'); stable_sha = digest(stable)
assert stable_sha == 'da2317d3d9fe72181587f543843bfdde3cc7030ca328e93c4f627ae21ec356e7'
archive.mkdir(parents=True); files = []
for source, relative in sorted(entries.items()):
    data = Path(source).read_bytes(); dest = archive/(str(relative)+'.gz'); dest.parent.mkdir(parents=True, exist_ok=True)
    packed = gzip.compress(data, compresslevel=1, mtime=0); dest.write_bytes(packed)
    assert gzip.decompress(dest.read_bytes()) == data
    files.append({'source': source, 'archive': str(dest.relative_to(archive)), 'sha256': sha(data),
        'bytes': len(data), 'compressedBytes': len(packed)})
manifest = {'scope': 'full-context critic adaptation, unmeasured active pairs and neural factor-ranked three-card cycles',
    'retainedCandidate': str(stable), 'retainedCandidateSha256': stable_sha, 'promotedCandidateChanged': False,
    'overviewVisual': 289, 'individualVisual': 1964, 'targetOverview': 150, 'targetIndividual': 750, 'targetMet': False,
    'browserVerified': False, 'newExperimentalCandidates': 0, 'newTrainingUpdates': training['newTrainingUpdatesExecuted'],
    'selectedCheckpointUpdates': training['selectedCheckpointUpdates'], 'newUniqueMeasuredPairTrainingRows': 1948,
    'trainingRows': training['rows'], 'validationRows': training['validationRows'], 'actualImprovementTrainingExamples': 0,
    'nativePairProposals': 2048, 'nativeCycleProposals': 2048, 'strictImprovements': 0,
    'cycleCriticTrainedOnCycles': False, 'pairFactorsAreTrainedNeuralPredictions': True,
    'neuralPairScoresReplayed': sum(row['replay'].get('allUnmeasuredNeuralScoresReplayed', 0) for row in verification['stages']),
    'neuralCycleProxyScoresReplayed': sum(row['replay'].get('cycleNeuralScoresReplayed', 0) for row in verification['stages']),
    'repeatedPreviouslyMeasuredPairActions': 0, 'sourceSavedGeometryByteIdentical': True,
    'nativeScoresRecomputedByReplay': False, 'causalAblationVerified': False, 'globalTargetImpossibleProved': False,
    'cycleValidation': json.loads((root/'cycle-validation.json').read_text()), 'recordsVerification': verification,
    'resources': resources, 'prerequisiteManifests': prerequisites, 'referencedFiles': referenced,
    'referencedLogicalBytes': sum(entry['bytes'] for entry in referenced), 'allReferencedFilesRestoreHashVerified': True,
    'logicalFiles': len(files), 'logicalBytes': sum(entry['bytes'] for entry in files),
    'allCompressedFilesRoundTripHashVerified': True, 'files': files}
path = archive/'manifest.json'; path.write_text(json.dumps(manifest, indent=2)+'\n'); manifest_sha = digest(path)
provenance = Path('data/erd-poc/candidates/captain-ml-independent-views.provenance.json')
before = provenance.read_text(); doc = json.loads(before); assert doc['candidateSha256'] == stable_sha
assert all(entry['archiveManifest'] != str(path) for entry in doc['subsequentResearchArchives'])
doc['subsequentResearchArchives'].append({'archiveManifest': str(path), 'archiveManifestSha256': manifest_sha,
    'promotedCandidateChanged': False, 'retainedCandidateSha256': stable_sha, 'overviewVisual': 289, 'individualVisual': 1964,
    'newNetworkTrainingUpdates': training['newTrainingUpdatesExecuted'], 'selectedCheckpointUpdates': training['selectedCheckpointUpdates'],
    'newUniqueMeasuredPairTrainingRows': 1948, 'nativePairProposals': 2048, 'nativeCycleProposals': 2048,
    'acceptedActions': 0, 'targetMet': False, 'browserVerified': False})
assert provenance.read_text() == before; provenance.write_text(json.dumps(doc, indent=2)+'\n')
print(json.dumps({'manifest': str(path), 'manifestSha256': manifest_sha, 'files': len(files),
    'logicalBytes': manifest['logicalBytes'], 'referencedFiles': len(referenced),
    'reusedPriorLogicalBytes': manifest['referencedLogicalBytes'], 'allStoredAndReferencedBytesVerified': True,
    'promotedCandidateUnchanged': True}))
