"""Run the predefined matched fractional transfer stages sequentially."""
import sys
from pathlib import Path
sys.path.insert(0, str(Path('scripts/erd-poc').resolve()))
from types import SimpleNamespace
from run_fractional_cycle_transfer import run

root = Path('.tmp/visualcross-ml-150-750-20261003/directed-cycle-model1')
for view in ['individual', 'overview']:
    for suffix, fraction in [('0001', .001), ('0005', .005), ('0020', .02), ('0100', .1)]:
        run(SimpleNamespace(source=root/(view+'-directed1'), out=root/(view+'-fraction'+suffix),
            fraction=fraction, budget=128, seconds=20))
