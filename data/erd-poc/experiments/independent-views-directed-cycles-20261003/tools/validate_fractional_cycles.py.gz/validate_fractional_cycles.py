"""Verify fractional cycle decoding, source preservation and cent rounding."""
import sys
from pathlib import Path
sys.path.insert(0, str(Path('scripts/erd-poc').resolve()))
import json
import numpy as np
from run_anchor_pair_walk import WalkDecoder
from run_fractional_cycle_transfer import fractional_action
from run_neural_cycle_policy import cycle_action

root = Path('.tmp/visualcross-ml-150-750-20261003/directed-cycle-model1')
path = root/'fractional-validation.json'; assert not path.exists()
checked = 0
for view in ['individual', 'overview']:
    report = json.loads((root/(view+'-directed1')/'report.json').read_text())
    decoder = WalkDecoder(Path(report['sourceDirectory']))
    rows = [json.loads(line) for line in (root/(view+'-directed1')/'actions.jsonl').read_text().splitlines()][:16]
    for row in rows:
        cycle = np.array(row['cycle'], dtype=np.int32)
        assert np.array_equal(fractional_action(decoder, cycle, 1), cycle_action(decoder, cycle))
        assert not fractional_action(decoder, cycle, 0).any()
        for fraction in [.001, .005, .02, .1]:
            action = fractional_action(decoder, cycle, fraction)
            for n, m in zip(cycle, np.roll(cycle, -1)):
                expected = fraction*(decoder.positions[m]-decoder.positions[n])
                expected = np.copysign(np.floor(abs(expected)*100+.5), expected)/100
                assert np.array_equal(action[n], expected)
            moved = decoder.positions+action[:len(decoder.positions)]
            low = (decoder.positions-decoder.sizes/2).min(0)
            high = (decoder.positions+decoder.sizes/2).max(0)
            assert (moved-decoder.sizes/2 >= low-.011).all() and (moved+decoder.sizes/2 <= high+.011).all()
            assert (abs(action[len(decoder.positions):]) <= .5+1e-12).all()
            checked += 1
result = {'status': 'pass', 'fractionalActionsChecked': checked, 'views': 2,
    'unitFractionMatchesOriginalAction': True, 'zeroFractionPreservesSource': True,
    'translationsCheckedIndependentlyAtCents': True, 'nativeActions': 0,
    'scope': 'action decoding only; spacing and hard validity remain native gates'}
path.write_text(json.dumps(result, indent=2)+'\n'); print(json.dumps(result))
