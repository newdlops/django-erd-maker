"""Replay measured-cycle learning and matched controls inside one process."""
import sys
from pathlib import Path
sys.path.insert(0, str(Path('scripts/erd-poc').resolve()))
import gc
import json
from contextlib import redirect_stdout
from io import StringIO
from types import SimpleNamespace
import numpy as np
from directed_cycle_model import CycleCritic, KEYS, load
from full_context_pair_model import load as load_parent
from train_directed_cycle_model import collect, split
from run_anchor_pair_policy import digest
from run_directed_cycle_policy import replay as replay_directed
from run_cycle_endpoint_transfer import replay as replay_endpoint
from run_collinear_cycle_transfer import execute as replay_collinear

root = Path('.tmp/visualcross-ml-150-750-20261003/directed-cycle-model1')
result_path = root/'records-verification.json'
assert not result_path.exists()
training = json.loads((root/'training1/training.json').read_text())
for name, expected in training['codeSha256'].items():
    assert digest(Path('scripts/erd-poc')/name) == expected
assert digest(root/'training1/model.npz') == training['checkpointSha256']
assert digest(root/'training1/dataset.npz') == training['datasetSha256']
assert digest(training['parent']) == training['parentSha256']
rebuilt, sources, inputs = collect(Path(training['parent']), [Path(row['stage']) for row in training['sourceStages']])
assert sources == training['sourceStages'] and inputs == training['sourceInputsByView']
with np.load(root/'training1/dataset.npz', allow_pickle=False) as saved:
    data = {name: saved[name].copy() for name in saved.files}
for name, expected in rebuilt.items():
    assert np.array_equal(expected, data[name], equal_nan=True) if expected.dtype.kind == 'f' else np.array_equal(expected, data[name])
del rebuilt
training_ids, validation, sampling, rng = split(data, training['seed'])
assert np.array_equal(training_ids, data['training'])
assert np.array_equal(validation, data['validation']) and np.array_equal(sampling, data['sampling'])
parent, _ = load_parent(Path(training['parent'])); model = CycleCritic(parent, training['seed'])
x = data['x']; y = data['y']; initial = {key: value.copy() for key, value in model.p.items()}
with np.load(root/'training1/model.npz', allow_pickle=False) as saved:
    assert all(np.array_equal(initial[key], saved['initial__'+key]) for key in KEYS)
    assert np.array_equal(model.mean, saved['mean']) and np.array_equal(model.scale, saved['scale'])
initial_predictions = model.forward(x)[0]
first = {key: np.zeros_like(value) for key, value in model.p.items()}
second = {key: value.copy() for key, value in first.items()}; updates = 0
best_loss = model.loss(x[validation], y[validation]); assert best_loss == training['initialValidationHuber']
best = initial; selected_epoch = selected_updates = 0
for expected in training['history']:
    order = rng.permutation(sampling)
    for offset in range(0, len(order), 64):
        batch = order[offset:offset+64]; _, gradients = model.loss(x[batch], y[batch], True)
        norm = np.sqrt(sum(np.sum(value*value) for value in gradients.values())); updates += 1
        for key in KEYS:
            gradient = gradients[key]*min(1, 5/max(norm, 1e-12))
            first[key] = .9*first[key]+.1*gradient
            second[key] = .999*second[key]+.001*gradient*gradient
            model.p[key] -= .001*(first[key]/(1-.9**updates))/(np.sqrt(second[key]/(1-.999**updates))+1e-8)
        if updates == expected['updates']:
            break
    actual = model.loss(x[validation], y[validation])
    assert actual == expected['validationHuber'] and updates == expected['updates']
    if actual < best_loss:
        best_loss = actual; best = {key: value.copy() for key, value in model.p.items()}
        selected_updates = updates; selected_epoch = expected['epoch']
assert updates == training['newTrainingUpdatesExecuted']
assert (selected_updates, selected_epoch) == (training['selectedCheckpointUpdates'], training['selectedEpoch'])
restored, _ = load(root/'training1/model.npz')
assert all(np.array_equal(best[key], restored.p[key]) for key in KEYS)
changes = {key: float(np.linalg.norm(best[key]-initial[key])) for key in KEYS}
assert all(value > 0 for value in changes.values())
final_predictions = restored.forward(x)[0]
groups = {}
for index in validation:
    groups.setdefault((str(data['view'][index]), *sorted(map(int, data['cycles'][index]))), []).append(int(index))
preferences = {}
for view in ['individual', 'overview']:
    pairs = [ids for key, ids in groups.items() if key[0] == view and y[ids[0]] != y[ids[1]]]
    assert all(len(ids) == 2 for ids in pairs)
    preferences[view] = {'heldOutTriplesWithUnequalTarget': len(pairs),
        'initialDirectedWarmStartPreferenceCorrect': sum((initial_predictions[a]-initial_predictions[b])*(y[a]-y[b]) > 0 for a, b in pairs),
        'selectedCycleModelPreferenceCorrect': sum((final_predictions[a]-final_predictions[b])*(y[a]-y[b]) > 0 for a, b in pairs)}
    preferences[view] = {key: int(value) for key, value in preferences[view].items()}
del x, y, data, model, parent, initial_predictions, final_predictions
gc.collect()
reports = []
for view in ['individual', 'overview']:
    for family in ['directed', 'circular', 'independent', 'collinear']:
        stage = root/(view+'-'+family+'1'); report = json.loads((stage/'report.json').read_text())
        output = StringIO()
        with redirect_stdout(output):
            args = SimpleNamespace(out=stage, command='replay')
            (replay_directed if family == 'directed' else replay_collinear if family == 'collinear' else replay_endpoint)(args)
        replay = json.loads(output.getvalue().splitlines()[-1])
        assert report['accepted'] == 0
        reference = root.parent/'pair-anchor-sparse1/actual-validation'/(view+'-sparse.tsv')
        for suffix in ['', '.routes.tsv', '.individual', '.individual.routes.tsv']:
            assert digest(stage/('learned.tsv'+suffix)) == digest(Path(str(reference)+suffix))
        rows = [json.loads(line) for line in (stage/'actions.jsonl').read_text().splitlines()]
        legal = [row['result']['visual'] for row in rows if 'result' in row and row['result']['legal']]
        reports.append({'stage': str(stage), 'view': view, 'family': family, 'replay': replay,
            'savedGeometryByteIdenticalToReference': True, 'bestLegalMeasuredVisual': min(legal) if legal else None,
            'equalVisualActions': legal.count(report['initialVisual']), 'reasons': report['reasons'],
            'wrappedProposals': report.get('wrappedProposals'),
            'positiveNeuralPredictions': sum(row.get('score', row.get('neuralScore')) > 0 for row in rows)})
        gc.collect()
result = {'status': 'pass', 'datasetReconstructedFromMeasuredCycleSources': True,
    'rows': training['rows'], 'multiConflictRows': training['multiConflictRows'],
    'wholeUnorderedTriplesHeldOutWithBothDirections': True, 'unseenGraphValidation': False,
    'trainingUpdatesReplayed': updates, 'selectedCheckpointUpdates': selected_updates,
    'selectedWeightsBitwiseReproduced': True, 'normalizationUnchanged': True,
    'parameterGroupChangesL2': changes, 'actualImprovementTrainingExamples': training['actualImprovementExamples'],
    'heldOutDirectionPreferences': preferences, 'stages': reports, 'nativeScoresRecomputed': False,
    'directedModelActionsReplayed': sum(row['replay'].get('modelActionsReplayed', 0) for row in reports),
    'matchedDecoderActionsReplayed': sum(row['replay'].get('nativeActions', 0) for row in reports),
    'allDirectedCycleScoresReplayed': sum(row['replay'].get('allDirectedCycleScoresReplayed', 0) for row in reports)}
result_path.write_text(json.dumps(result, indent=2)+'\n')
print(json.dumps({key: result[key] for key in ['status', 'rows', 'trainingUpdatesReplayed',
    'selectedCheckpointUpdates', 'directedModelActionsReplayed', 'matchedDecoderActionsReplayed', 'heldOutDirectionPreferences']}))
