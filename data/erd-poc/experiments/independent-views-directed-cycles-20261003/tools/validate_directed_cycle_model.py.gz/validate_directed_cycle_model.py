import sys
from pathlib import Path
sys.path.insert(0, str(Path('scripts/erd-poc').resolve()))
import json
import numpy as np
from learn_pair_policy import Ranker
from directed_cycle_model import CycleCritic, cycle_features, KEYS
from run_anchor_pair_walk import WalkDecoder

rng = np.random.default_rng(95131); parent = Ranker(73, 5, 6)
model = CycleCritic(parent, 84023, 4); x = rng.normal(size=(7, 3, 5))
expected = parent.forward(x.reshape(-1, 5))[0].reshape(-1, 3).mean(1)
warm_error = float(np.max(abs(model.forward(x)[0]-expected)))
assert warm_error < 1e-12
# Nonzero interaction output weights exercise all new backpropagation paths.
model.p['oh'] = rng.normal(0, .2, 4); model.p['ob'][:] = .1
targets = np.array([-3., -1., -.2, 0., .4, 2., 4.])
_, gradients = model.loss(x, targets, True); maximum = 0; comparisons = 0
for key in KEYS:
    for flat in rng.choice(model.p[key].size, min(6, model.p[key].size), replace=False):
        index = np.unravel_index(flat, model.p[key].shape); value = model.p[key][index]
        model.p[key][index] = value+1e-5; hi = model.loss(x, targets)
        model.p[key][index] = value-1e-5; lo = model.loss(x, targets); model.p[key][index] = value
        error = abs((hi-lo)/2e-5-gradients[key][index]); maximum = max(maximum, error); comparisons += 1
        assert error < 2e-7, (key, index, error)
scores = model.forward(x)[0]
assert np.allclose(scores, model.forward(np.roll(x, 1, axis=1))[0], rtol=0, atol=1e-12)
_, rotated_gradient = model.loss(np.roll(x, 1, axis=1), targets, True)
assert all(np.allclose(gradients[key], rotated_gradient[key], rtol=0, atol=1e-12) for key in KEYS)
assert all(np.linalg.norm(gradients[key]) > 0 for key in KEYS)
base = Path('.tmp/visualcross-ml-150-750-20261003'); views = []
for view in ['individual', 'overview']:
    decoder = WalkDecoder(base/(view+'-slot-cached1'))
    with np.load(base/'active-pair-model1'/(view+'-cycles1')/'observations.npz', allow_pickle=False) as saved:
        nodes = saved['node_features'].copy(); cycles = saved['cycles'][:32].copy()
    features, _ = cycle_features(nodes, decoder, cycles, view == 'overview')
    rotated, _ = cycle_features(nodes, decoder, np.roll(cycles, 1, axis=1), view == 'overview')
    assert np.array_equal(rotated, np.roll(features, 1, axis=1))
    distinct = np.any(features[::2] != features[1::2], axis=(1, 2))
    assert distinct.all()
    views.append({'view': view, 'testedDirectionPairs': len(distinct),
        'orderedDirectionInputsDistinct': int(distinct.sum()), 'rotatedCycleFeatureCorrespondenceExact': True})
root = base/'directed-cycle-model1'; root.mkdir(parents=True, exist_ok=False)
report = {'status': 'pass', 'finiteGradientComparisons': comparisons, 'maximumGradientError': maximum,
    'allTenParameterGroupsExercised': True, 'warmPredictionMaxDifference': warm_error,
    'cyclicRotationScoreAndGradientInvariant': True, 'views': views, 'nativeGeometryNotInvoked': True}
(root/'model-validation.json').write_text(json.dumps(report, indent=2)+'\n'); print(json.dumps(report))
