"""Check matched endpoint decoding without any native proposal or search."""
import sys
from pathlib import Path
sys.path.insert(0, str(Path('scripts/erd-poc').resolve()))
import json
import numpy as np
from run_anchor_pair_walk import WalkDecoder
from run_cycle_endpoint_transfer import IndependentDecoder, CircularDecoder
from run_collinear_cycle_transfer import CollinearSourceDecoder
from run_anchor_pair_policy import digest

root = Path('.tmp/visualcross-ml-150-750-20261003/directed-cycle-model1')
result_path = root/'endpoint-validation.json'
assert not result_path.exists()

def fake(kind):
    decoder = object.__new__(kind)
    decoder.endpoint_groups = np.array([0, 0], dtype=np.int32)
    decoder.endpoint_counts = np.array([2])
    return decoder

values = np.array([[.49, -.49]])
arithmetic = fake(WalkDecoder).pool(values)
independent = fake(IndependentDecoder).pool(values)
circular = fake(CircularDecoder).pool(values)
assert np.array_equal(arithmetic, np.zeros_like(values))
assert np.array_equal(independent, values)
assert np.max(abs(abs(circular)-.5)) < 1e-12
try:
    fake(CircularDecoder).pool(np.array([[.25, -.25]]))
except ArithmeticError:
    pass
else:
    raise AssertionError('ambiguous circular mean must reject')

fixtures = []
for view in ['individual', 'overview']:
    source = json.loads((root/(view+'-directed1')/'report.json').read_text())
    directory = Path(source['sourceDirectory'])
    assert all(digest(directory/name) == expected for name, expected in source['sourceInputs'].items())
    counts = {}
    for kind in [WalkDecoder, IndependentDecoder, CircularDecoder, CollinearSourceDecoder]:
        decoder = kind(directory)
        action = decoder.decode(np.arange(len(decoder.positions), dtype=np.int32))
        assert np.count_nonzero(action) == 0
        counts[kind.__name__] = {'zeroActionPreservesSource': True}
        if kind is CollinearSourceDecoder:
            provider = decoder.provider
            full = decoder.positions[provider.owner]+provider.offsets
            original_direction = (full[provider.full_edges[:, 1]]+provider.base_boundary[:, 1]
                -full[provider.full_edges[:, 0]]-provider.base_boundary[:, 0])
            shift = decoder.anchor_offsets-provider.base_boundary
            determinant = shift[:, :, 0]*original_direction[:, None, 1]-shift[:, :, 1]*original_direction[:, None, 0]
            normalized = abs(determinant)/np.linalg.norm(original_direction, axis=1)[:, None]
            maximum = float(normalized[decoder.collinear_source_edges].max())
            assert maximum < 1e-8
            assert (abs(decoder.anchor_offsets) < decoder.ray_sizes/2).all()
            counts[kind.__name__] |= {'collinearSourceEdges': int(decoder.collinear_source_edges.sum()),
                'strictInteriorSourceEdgesRetained': int((~decoder.collinear_source_edges).sum()),
                'maximumCollinearityDistance': maximum, 'allAnchorsStrictlyInterior': True}
    fixtures.append({'view': view, 'sourceInputs': source['sourceInputs'], 'decoders': counts})

result = {'status': 'pass', 'nativeActions': 0, 'nativeSearchCalls': 0,
    'wrapBoundaryArithmeticCircularAndIndependentCasesChecked': True,
    'ambiguousCircularMeanRejectedWithoutFallback': True, 'sourceFixtures': fixtures,
    'scope': 'decoder algebra and immutable source anchors; does not establish candidate legality'}
result_path.write_text(json.dumps(result, indent=2)+'\n')
print(json.dumps({key: result[key] for key in ['status', 'nativeActions', 'nativeSearchCalls']}))
