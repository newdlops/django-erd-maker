"""Read-only attribution of previously tested neural actions; no new proposals."""
import sys
from pathlib import Path
sys.path.insert(0, str(Path('scripts/erd-poc').resolve()))
import hashlib
import json
import subprocess
import time
from collections import Counter
import numpy as np
from run_anchor_pair_policy import wire, digest
from run_anchor_pair_walk import WalkDecoder
from run_cycle_endpoint_transfer import IndependentDecoder, CircularDecoder
from run_collinear_cycle_transfer import CollinearSourceDecoder
from run_neural_cycle_policy import cycle_action

root = Path('.tmp/visualcross-ml-150-750-20261003/directed-cycle-model1')
out = root/'hard-diagnostics1'
assert not (out/'report.json').exists()
environment = out/'environment'
build_inputs = json.loads((out/'build-inputs-v2.json').read_text())
assert all(digest(out/'build-inputs-v2'/name) == expected for name, expected in build_inputs.items())
started = time.monotonic()
tests = {}
for argument in ['--self-test', '--batch-self-test']:
    value = subprocess.run([str(environment), argument], capture_output=True, text=True, check=True, timeout=15)
    tests[argument] = json.loads(value.stdout)
families = {'directed': WalkDecoder, 'circular': CircularDecoder,
            'independent': IndependentDecoder, 'collinear': CollinearSourceDecoder}
stages = []
prefix = 32
with (out/'actions.jsonl').open('x') as stream:
    for view in ['individual', 'overview']:
        for family, kind in families.items():
            source = root/(view+'-'+family+'1')
            report = json.loads((source/'report.json').read_text())
            assert digest(source/'actions.jsonl') == report['actionsSha256']
            directory = Path(report['sourceDirectory'])
            assert all(digest(directory/name) == expected for name, expected in report['sourceInputs'].items())
            decoder = kind(directory)
            rows = [json.loads(line) for line in (source/'actions.jsonl').read_text().splitlines()][:prefix]
            process = subprocess.Popen([str(environment), '--directory', str(directory), '--overview-only', str(int(view == 'overview'))],
                stdin=subprocess.PIPE, stdout=subprocess.PIPE, text=True, bufsize=1)
            def receive():
                line = process.stdout.readline()
                if not line:
                    raise RuntimeError(f'diagnostic exit {process.poll()}')
                return json.loads(line)
            def request(command):
                process.stdin.write(command+'\n'); process.stdin.flush(); return receive()
            initial = receive(); assert initial['ready'] and initial['readOnly']
            assert initial['visual'] == report['initialVisual']
            assert initial['physical']['total'] == initial['individual']['total'] == 0
            reasons = Counter(); outcomes = []
            components = {view: {key: {'proposalsWithViolation': 0, 'sum': 0, 'max': 0}
                for key in ['ownInterior', 'adjacentCross', 'endpointContact', 'outward']} for view in ['physical', 'individual']}
            commands = []
            try:
                zero = decoder.decode(np.arange(len(decoder.positions), dtype=np.int32))
                base = request(wire(zero, 'DIAG'))
                assert base['legal'] and base['visual'] == initial['visual']
                for row in rows:
                    assert 'decoderRejected' not in row
                    action = cycle_action(decoder, row['cycle']); command = wire(action)
                    assert hashlib.sha256(command.encode()).hexdigest() == row['wireSha256']
                    result = request(wire(action, 'DIAG')); commands.append(wire(action, 'DIAG'))
                    assert all(result[key] == row['result'][key] for key in
                        ['legal', 'visual', 'individualVisual', 'spacing', 'hard', 'individualHard', 'reason'])
                    assert result['sourceGeometryAndCountersUnchanged']
                    reasons[result['reason']] += 1; outcomes.append(result)
                    if result['componentsAvailable']:
                        for presentation, counts in components.items():
                            for key, summary in counts.items():
                                value = result[presentation][key]
                                summary['proposalsWithViolation'] += int(value > 0)
                                summary['sum'] += value; summary['max'] = max(summary['max'], value)
                    stream.write(json.dumps({'view': view, 'family': family, 'rank': row['rank'],
                        'cycle': row['cycle'], 'sourceWireSha256': row['wireSha256'], 'result': result})+'\n')
                repeated = request(commands[0]); assert repeated == outcomes[0]
                assert request(wire(zero, 'DIAG')) == base
            finally:
                if process.poll() is None:
                    process.stdin.write('QUIT\n'); process.stdin.flush(); process.wait(timeout=5)
                assert process.returncode == 0
            stages.append({'sourceStage': str(source), 'sourceReportSha256': digest(source/'report.json'),
                'sourceActionsSha256': digest(source/'actions.jsonl'), 'view': view, 'family': family,
                'previouslyMeasuredActionsObserved': len(rows), 'reasons': dict(reasons),
                'hardComponents': components, 'allRecordedNativeResultsRecomputedExactly': True,
                'firstActionRepeatedWithoutCommit': True, 'zeroActionSourcePreservedBeforeAndAfter': True,
                'projectionOrFrameFailuresNotAttributed': sum(not result['componentsAvailable'] for result in outcomes)})
result = {'kind': 'read-only-hard-attribution-of-fixed-neural-cycle-prefixes-v1', 'status': 'pass',
    'stages': stages, 'prefixActionsPerStage': prefix,
    'previouslyMeasuredActionsObserved': sum(row['previouslyMeasuredActionsObserved'] for row in stages),
    'newNeuralProposals': 0, 'newTrainingUpdates': 0, 'searchCalls': 0, 'coordinateRepairs': 0,
    'sourceGeometryAndCountersUnchanged': True, 'existingDecoderAndAcceptanceGatesUnchanged': True,
    'nativeScoresRecomputedForObservedPrefixes': True, 'hardComponentsCountSameDirectedPairMultiplicityAsGate': True,
    'causesAreOverlappingConditions': True, 'doesNotExplainEntireVocabularyOrProveUnavoidableFloor': True,
    'selfTests': tests, 'environment': str(environment), 'environmentSha256': digest(environment),
    'buildInputs': build_inputs, 'actionsSha256': digest(out/'actions.jsonl'),
    'observerScriptSha256': digest(__file__), 'wallSeconds': time.monotonic()-started}
(out/'report.json').write_text(json.dumps(result, indent=2)+'\n')
print(json.dumps({key: result[key] for key in ['status', 'previouslyMeasuredActionsObserved', 'newNeuralProposals', 'wallSeconds']}))
for stage in stages:
    print(json.dumps({key: stage[key] for key in ['view', 'family', 'reasons', 'hardComponents']}))
