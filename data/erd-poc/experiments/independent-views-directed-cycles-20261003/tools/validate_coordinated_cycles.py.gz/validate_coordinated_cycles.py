import sys
from pathlib import Path
sys.path.insert(0, str(Path('scripts/erd-poc').resolve()))
from itertools import combinations
from types import SimpleNamespace
import json
import numpy as np
from run_directed_cycle_policy import coordinated_cycles, measured, rank
from directed_cycle_model import load
from run_anchor_pair_walk import WalkDecoder

nodes = np.zeros((10, 64)); nodes[[0, 1, 2, 6, 7], 4] = 1
isolated = np.zeros(10, dtype=bool); isolated[[0, 1, 3, 6, 7, 8]] = True
decoder = SimpleNamespace(groups=[np.arange(6), np.arange(6, 10)], irrelevant_isolate=isolated,
    sizes=np.array([[100, 200]]*6+[[300, 400]]*4))
seen = np.array([[0, 2, 4], [0, 4, 2], [0, 1, 3], [0, 3, 1]])
eligible = {triple for group in decoder.groups for triple in combinations(map(int, group), 3)
    if np.any(nodes[list(triple), 4:6] > 0, axis=1).sum() >= 2 and not isolated[list(triple)].all()}
remaining = eligible-{tuple(sorted(row)) for row in seen.tolist()}
vocabulary, support = coordinated_cycles(decoder, nodes, seen, 84029, 4096)
assert support['eligibleUnorderedTriplesBeforeExclusion'] == len(eligible)
assert support['remainingUnmeasuredEligibleTriples'] == len(remaining)
assert {tuple(row) for row in vocabulary[::2].tolist()} == remaining
assert np.array_equal(vocabulary[1::2], vocabulary[::2][:, [0, 2, 1]])
base = Path('.tmp/visualcross-ml-150-750-20261003'); root = base/'directed-cycle-model1'
model, metadata = load(root/'training1/model.npz'); results = []
for view in ['individual', 'overview']:
    decoder = WalkDecoder(base/(view+'-slot-cached1'))
    with np.load(base/'active-pair-model1'/(view+'-cycles1')/'observations.npz', allow_pickle=False) as saved:
        features = saved['node_features'].copy()
    prior = measured(metadata, view)
    vocabulary, support = coordinated_cycles(decoder, features, prior, 84029, 64)
    replay, repeated_support = coordinated_cycles(decoder, features, prior, 84029, 64)
    assert np.array_equal(vocabulary, replay) and support == repeated_support
    assert (np.any(features[vocabulary][:, :, 4:6] > 0, axis=2).sum(1) >= 2).all()
    prior_keys = {tuple(sorted(map(int, cycle))) for cycle in prior}
    assert all(tuple(sorted(map(int, cycle))) not in prior_keys for cycle in vocabulary)
    scores, _, _ = rank(model, decoder, features, vocabulary, view == 'overview')
    distinct = int(np.sum(abs(scores[::2]-scores[1::2]) > 1e-10)); assert distinct > 0
    results.append({'view': view, 'support': support, 'vocabularySeedReplay': True,
        'allCyclesTouchTwoOrThreeDirectConflicts': True, 'previouslyMeasuredTripleExclusion': True,
        'directionPairsTested': len(vocabulary)//2, 'directionPairsWithDifferentLearnedScores': distinct})
report = {'status': 'pass', 'smallCaseCountsAndCompleteVocabularyMatchExhaustiveEnumeration': True,
    'smallCaseEligibleTriples': len(eligible), 'smallCaseUnmeasuredTriples': len(remaining),
    'views': results, 'nativeGeometryNotInvoked': True}
(root/'candidate-validation.json').write_text(json.dumps(report, indent=2)+'\n'); print(json.dumps(report))
