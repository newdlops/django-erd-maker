"""Seal cycle learning, decoder controls and read-only rejection evidence."""
from pathlib import Path
import ast
import gzip
import hashlib
import json

root = Path('.tmp/visualcross-ml-150-750-20261003/directed-cycle-model1')
archive = Path('data/erd-poc/experiments/independent-views-directed-cycles-20261003')
assert not archive.exists()
sha = lambda data: hashlib.sha256(data).hexdigest()
digest = lambda path: sha(Path(path).read_bytes())
training = json.loads((root/'training1/training.json').read_text())
verification = json.loads((root/'records-verification.json').read_text())
fractional = json.loads((root/'fractional-records-verification.json').read_text())
diagnostic = json.loads((root/'hard-diagnostics1/report.json').read_text())
assert verification['status'] == fractional['status'] == diagnostic['status'] == 'pass'
assert verification['directedModelActionsReplayed'] == 2048
assert verification['matchedDecoderActionsReplayed'] == 768
assert fractional['fractionalActionsReplayed'] == 1024
all_stages = verification['stages']+fractional['stages']
assert all(row['replay']['accepted'] == 0 and row['savedGeometryByteIdenticalToReference'] for row in all_stages)
reports = [json.loads((Path(row['stage'])/'report.json').read_text()) for row in all_stages]
assert sum(report['attempts'] for report in reports) == 3840
resources = {'policy': 'serialized numerical jobs; one math thread; nice +10; 256 MiB process-group RSS guard; no hard CPU-percent quota',
    'trainingPeakMiB': 93.5, 'modelValidationPeakMiB': 33.6, 'candidateValidationPeakMiB': 33.0,
    'endpointValidationPeakMiB': 40.4, 'singleProcessRecordsVerificationPeakMiB': 114.9,
    'inferencePeakMiB': {'overview-directed1': 57.4, 'individual-directed1': 57.5,
        'overview-circular1': 58.2, 'overview-independent1': 57.9, 'overview-collinear1': 61.4,
        'individual-circular1': 58.6, 'individual-independent1': None, 'individual-collinear1': None},
    'missingPeakReason': 'two completion console outputs lost during compaction; final reports and absent process state confirmed; not rerun to recover peaks',
    'failedDiagnosticCompilePeakMiB': 175.8, 'successfulDiagnosticCompilePeakMiB': 204.9,
    'readOnlyHardObservationPeakMiB': 51.1, 'fractionalValidationPeakMiB': 40.3,
    'sequentialFractionalInferencePeakMiB': 64.3, 'fractionalRecordsVerificationPeakMiB': 54.7,
    'availablePeaksRecordedFromToolOutputs': True, 'allCurrentNumericalStagesTerminal': True}
(root/'resources.json').write_text(json.dumps(resources, indent=2)+'\n')
full_rows = [json.loads(line) for view in ['individual', 'overview']
    for line in (root/(view+'-directed1')/'actions.jsonl').read_text().splitlines()]
assert len(full_rows) == 2048
analysis = {'retainedOverview': 289, 'retainedIndividual': 1964, 'targetMet': False,
    'unitCyclePositiveVisualBeforeHardGate': sum(row['result']['reason'] == 'hard' and row['result']['visual'] <
        (1964 if index < 1024 else 289) for index, row in enumerate(full_rows)),
    'unitCycleNoLegalImprovements': True, 'fractionalNoLegalImprovements': True,
    'hardPrefixesViolateOnlyAdjacentCross': all(summary['proposalsWithViolation'] == 0 for stage in diagnostic['stages']
        for view in ['physical', 'individual'] for key, summary in stage['hardComponents'][view].items() if key != 'adjacentCross'),
    'hardAttributionScope': 'first 32 words of each of eight stages; projection failures unclassified; causes can overlap in other candidates',
    'wrappedEndpointGroupsInMatchedEndpointControls': 0,
    'noEvidencePoolingWrapExplainsObservedPlateau': True,
    'smallestFractionsProduceLegalTiesButNoGain': True,
    'endpointAndFractionControlsAreFrozenTransfersNotNewlyTrainedPolicies': True,
    'noUnavoidableDecoderFloorOrTargetImpossibilityProved': True,
    'nextResearch': 'use the measured fractional and coordinated-cycle outcomes as action-conditioned learning data; preserve whole-triple validation and distinguish exploration from greedy ranking; do not repeat these fixed controls unchanged'}
(root/'diagnosis.json').write_text(json.dumps(analysis, indent=2)+'\n')
entries = {str(path): Path('run')/path.relative_to(root) for path in sorted(root.rglob('*')) if path.is_file()}
scripts = Path('scripts/erd-poc'); pending = ['directed_cycle_model.py', 'train_directed_cycle_model.py',
    'run_directed_cycle_policy.py', 'run_cycle_endpoint_transfer.py', 'run_collinear_cycle_transfer.py',
    'run_fractional_cycle_transfer.py', 'run_memory_bounded.py']; seen = set()
while pending:
    name = pending.pop()
    if name in seen:
        continue
    seen.add(name); path = scripts/name; entries[str(path)] = Path('code')/name
    for node in ast.walk(ast.parse(path.read_text())):
        modules = [node.module] if isinstance(node, ast.ImportFrom) else [item.name for item in node.names] if isinstance(node, ast.Import) else []
        for module in modules:
            if module and (scripts/(module+'.py')).is_file():
                pending.append(module+'.py')
entries[str(scripts/'ml_batch_hard_diagnostics.cpp')] = Path('code/ml_batch_hard_diagnostics.cpp')
for name in ['validate_directed_cycle_model.py', 'validate_coordinated_cycles.py',
    'validate_cycle_endpoint_decoders.py', 'verify_directed_cycle_records.py', 'observe_cycle_hard_components.py',
    'validate_fractional_cycles.py', 'run_fractional_cycle_controls.py', 'verify_fractional_cycle_records.py',
    'seal_directed_cycle_research.py']:
    entries[str(Path('.tmp')/name)] = Path('tools')/name
prior_index = {}; prerequisites = []
for name in ['independent-views-anchor-pairs-20261003', 'independent-views-pair-walk-20261003',
    'independent-views-full-context-pairs-20261003', 'independent-views-active-pairs-cycles-20261003']:
    path = archive.parent/name/'manifest.json'; previous = json.loads(path.read_text())
    prerequisites.append({'path': str(path), 'sha256': digest(path)})
    for entry in previous['files']:
        prior_index[entry['source']] = (path.parent, entry)
dependencies = {training['parent'], str(Path(training['parent']).parent/'dataset.npz'),
    str(Path(training['parent']).parent/'training.json')}
for source in training['sourceStages']:
    dependencies.update(str(Path(source['stage'])/name) for name in ['report.json', 'observations.npz', 'actions.jsonl'])
for report in reports:
    dependencies.add(report['environment'])
    dependencies.update(str(Path(report['sourceDirectory'])/name) for name in report['sourceInputs'])
    dependencies.update(str(path) for path in (Path(report['environment']).parent/'build-inputs').glob('*') if path.is_file())
    reference = root.parent/'pair-anchor-sparse1/actual-validation'/(report['view']+'-sparse.tsv')
    dependencies.update(str(reference)+suffix for suffix in ['', '.routes.tsv', '.individual', '.individual.routes.tsv'])
referenced = []
for source in sorted(dependencies):
    assert source in prior_index, source
    directory, entry = prior_index[source]
    restored = gzip.decompress((directory/entry['archive']).read_bytes())
    assert sha(restored) == entry['sha256'] == digest(source)
    referenced.append({'source': source, 'archive': str(directory/entry['archive']), 'sha256': entry['sha256'],
        'bytes': entry['bytes'], 'restoreHashVerified': True})
stable = Path('data/erd-poc/candidates/captain-ml-independent-views.layout.json'); stable_sha = digest(stable)
assert stable_sha == 'da2317d3d9fe72181587f543843bfdde3cc7030ca328e93c4f627ae21ec356e7'
archive.mkdir(parents=True); files = []
for source, relative in sorted(entries.items()):
    data = Path(source).read_bytes(); dest = archive/(str(relative)+'.gz'); dest.parent.mkdir(parents=True, exist_ok=True)
    packed = gzip.compress(data, compresslevel=1, mtime=0); dest.write_bytes(packed)
    assert gzip.decompress(dest.read_bytes()) == data
    files.append({'source': source, 'archive': str(dest.relative_to(archive)), 'sha256': sha(data),
        'bytes': len(data), 'compressedBytes': len(packed)})
unique_wires = {}
for report, row in zip(reports, all_stages):
    stage = Path(row['stage'])
    unique_wires.setdefault(report['view'], set()).update(json.loads(line)['wireSha256']
        for line in (stage/'actions.jsonl').read_text().splitlines() if 'wireSha256' in json.loads(line))
manifest = {'scope': 'direction-sensitive interacting cycle critic; coordinated candidates; matched endpoint and fractional transfers; read-only hard attribution',
    'retainedCandidate': str(stable), 'retainedCandidateSha256': stable_sha, 'promotedCandidateChanged': False,
    'overviewVisual': 289, 'individualVisual': 1964, 'targetOverview': 150, 'targetIndividual': 750, 'targetMet': False,
    'browserVerified': False, 'newProductCandidates': 0, 'newTrainingUpdates': training['newTrainingUpdatesExecuted'],
    'selectedCheckpointUpdates': training['selectedCheckpointUpdates'], 'trainingRows': training['rows'],
    'validationRows': training['validationRows'], 'multiConflictTrainingRows': training['multiConflictRows'],
    'actualImprovementTrainingExamples': 0, 'directedCycleCriticTrainedOnCycles': True,
    'nativeDirectedCycleProposals': 2048, 'matchedEndpointProposals': 768, 'fractionalProposals': 1024,
    'allNativeModelActions': 3840, 'uniqueSubmittedWireHashesByView': {view: len(wires) for view, wires in unique_wires.items()},
    'strictImprovements': 0, 'readOnlyPreviouslyMeasuredActionsObserved': 256,
    'modelCycleScoresReplayed': verification['allDirectedCycleScoresReplayed'],
    'repeatedPreviouslyMeasuredTriplesInPrimaryInference': 0, 'savedGeometryByteIdenticalToSource': True,
    'recordReplayNativeScoresRecomputed': False, 'diagnosticPrefixNativeScoresRecomputed': True,
    'causalSuperiorityVerified': False, 'globalTargetImpossibleProved': False, 'cliConfigurationChanged': False,
    'modelValidation': json.loads((root/'model-validation.json').read_text()),
    'candidateValidation': json.loads((root/'candidate-validation.json').read_text()),
    'endpointValidation': json.loads((root/'endpoint-validation.json').read_text()),
    'fractionalValidation': json.loads((root/'fractional-validation.json').read_text()),
    'recordsVerification': verification, 'fractionalRecordsVerification': fractional,
    'hardAttribution': diagnostic, 'diagnosis': analysis, 'resources': resources,
    'prerequisiteManifests': prerequisites, 'referencedFiles': referenced,
    'referencedLogicalBytes': sum(entry['bytes'] for entry in referenced), 'allReferencedFilesRestoreHashVerified': True,
    'logicalFiles': len(files), 'logicalBytes': sum(entry['bytes'] for entry in files),
    'allCompressedFilesRoundTripHashVerified': True, 'files': files}
path = archive/'manifest.json'; path.write_text(json.dumps(manifest, indent=2)+'\n'); manifest_sha = digest(path)
provenance = Path('data/erd-poc/candidates/captain-ml-independent-views.provenance.json')
before = provenance.read_text(); doc = json.loads(before); assert doc['candidateSha256'] == stable_sha
assert all(entry['archiveManifest'] != str(path) for entry in doc['subsequentResearchArchives'])
doc['subsequentResearchArchives'].append({'archiveManifest': str(path), 'archiveManifestSha256': manifest_sha,
    'promotedCandidateChanged': False, 'retainedCandidateSha256': stable_sha, 'overviewVisual': 289, 'individualVisual': 1964,
    'newNetworkTrainingUpdates': training['newTrainingUpdatesExecuted'], 'selectedCheckpointUpdates': training['selectedCheckpointUpdates'],
    'nativeDirectedCycleProposals': 2048, 'matchedEndpointProposals': 768, 'fractionalProposals': 1024,
    'readOnlyPreviouslyMeasuredActionsObserved': 256, 'acceptedActions': 0, 'targetMet': False, 'browserVerified': False})
assert provenance.read_text() == before; provenance.write_text(json.dumps(doc, indent=2)+'\n')
print(json.dumps({'manifest': str(path), 'manifestSha256': manifest_sha, 'files': len(files),
    'logicalBytes': manifest['logicalBytes'], 'referencedFiles': len(referenced),
    'referencedLogicalBytes': manifest['referencedLogicalBytes'], 'allStoredAndReferencedBytesVerified': True,
    'promotedCandidateUnchanged': True}))
