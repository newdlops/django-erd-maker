"""Replay each new fractional proposal and record its measured action scope."""
import sys
from pathlib import Path
sys.path.insert(0, str(Path('scripts/erd-poc').resolve()))
import gc
import json
from contextlib import redirect_stdout
from io import StringIO
from types import SimpleNamespace
from run_anchor_pair_policy import digest
from run_fractional_cycle_transfer import replay

root = Path('.tmp/visualcross-ml-150-750-20261003/directed-cycle-model1')
path = root/'fractional-records-verification.json'; assert not path.exists()
stages = []
for view in ['individual', 'overview']:
    for suffix in ['0001', '0005', '0020', '0100']:
        stage = root/(view+'-fraction'+suffix)
        output = StringIO()
        with redirect_stdout(output):
            replay(SimpleNamespace(out=stage))
        replay_result = json.loads(output.getvalue().splitlines()[-1])
        report = json.loads((stage/'report.json').read_text())
        assert replay_result['accepted'] == report['accepted'] == 0
        reference = root.parent/'pair-anchor-sparse1/actual-validation'/(view+'-sparse.tsv')
        for suffix in ['', '.routes.tsv', '.individual', '.individual.routes.tsv']:
            assert digest(stage/('learned.tsv'+suffix)) == digest(Path(str(reference)+suffix))
        rows = [json.loads(line) for line in (stage/'actions.jsonl').read_text().splitlines()]
        legal = [row['result']['visual'] for row in rows if row['result']['legal']]
        hard = [row['result']['visual'] for row in rows if row['result']['reason'] == 'hard']
        stages.append({'stage': str(stage), 'view': view, 'fraction': report['fraction'], 'replay': replay_result,
            'savedGeometryByteIdenticalToReference': True, 'reasons': report['reasons'],
            'bestLegalMeasuredVisual': min(legal) if legal else None,
            'equalVisualActions': legal.count(report['initialVisual']),
            'legalVisualWorseThanSource': sum(visual > report['initialVisual'] for visual in legal),
            'hardRejectedVisualBetterThanSource': sum(visual < report['initialVisual'] for visual in hard),
            'criticTrainedOnTheseFractions': False})
        gc.collect()
result = {'status': 'pass', 'stages': stages,
    'fractionalActionsReplayed': sum(row['replay']['fractionalActionsReplayed'] for row in stages),
    'accepted': 0, 'allSavedGeometryByteIdenticalToReference': True,
    'frozenUnitFractionCriticTransferOnly': True, 'newTrainingUpdates': 0, 'nativeScoresRecomputed': False}
path.write_text(json.dumps(result, indent=2)+'\n')
print(json.dumps({key: result[key] for key in ['status', 'fractionalActionsReplayed', 'accepted']}))
print(json.dumps([{key: row[key] for key in ['view', 'fraction', 'bestLegalMeasuredVisual',
    'equalVisualActions', 'legalVisualWorseThanSource', 'hardRejectedVisualBetterThanSource']} for row in stages]))
