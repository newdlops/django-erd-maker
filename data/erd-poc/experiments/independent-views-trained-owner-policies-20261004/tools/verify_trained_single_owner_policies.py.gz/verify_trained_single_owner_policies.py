"""Closed neural replay and read-only Native controls for new walk policies."""
import argparse
from collections import Counter
import hashlib
import json
import sys
from pathlib import Path
from types import SimpleNamespace
import numpy as np
sys.path.insert(0,str(Path('scripts/erd-poc').resolve()))
from run_anchor_pair_policy import Native,digest,wire
from run_anchor_pair_walk import WalkDecoder,array_hash,verify_saved
from run_single_owner_cycle_policy_v2 import prepare as local_prepare
from run_single_owner_neural_walk_v2 import cumulative_action,hashes as ordinary_hashes
from run_single_owner_neural_walk_v3 import prepare as cached_prepare,hashes as cached_hashes
from run_single_owner_cycle_policy_v3 import prepare as global_prepare,hashes as global_hashes
from run_neural_owner_batches import propose,decode,hashes as batch_hashes
from single_owner_cached_observer_v2 import CachedObserver
from single_owner_cycle_model import AMPLITUDES,load,motion_key,action,vocabulary,rank,allowed_indices
from owner_amplitude_cycle_model import action_features
from train_anchor_pair_outcomes import outcome_target

ROOT=Path('.tmp/visualcross-ml-150-750-20261004/single-owner-trained-walk1');OUT=ROOT/'verification'
METRICS=('legal','reason','visual','individualVisual','hard','individualHard','spacing')
def bind(stage,expected_hashes):
    r=json.loads((stage/'report.json').read_text());source=Path(r['sourceDirectory'])
    assert r['codeSha256']==expected_hashes()
    for name,s in r['sourceInputs'].items():assert digest(source/name)==s
    for name in ('checkpoint','environment','sourceBinding'):assert digest(r[name])==r[name+'Sha256']
    binding=json.loads(Path(r['sourceBinding']).read_text())['viewSources'][r['view']]
    assert (str(source),r['sourceInputs'],r['initialVisual'])==(binding['directory'],binding['inputs'],binding['expectedVisual'])
    assert digest(stage/'actions.jsonl')==r['actionsSha256']
    return r,source
def immutable(native,path,source,decoder):
    assert native.request('SAVE')['saved'];s=json.loads(Path(str(path)+'.stats.json').read_text())
    assert s['policyActionsEvaluated']==s['acceptedActions']==0
    assert (s['visual'],s['individualVisual'])==(native.initial['visual'],native.initial['individualVisual'])
    # verify_saved expects a fixed stem under its stage directory.
    return s
def compare(actual,expected):assert all(actual[k]==expected[k] for k in METRICS),(actual,expected)

def walks():
    checks=[];full_measurements=feature_controls=0
    for view in ('individual','overview'):
      for kind in ('walk','cached'):
        stage=ROOT/(view+'-'+kind+'1');cached=kind=='cached';r,source=bind(stage,cached_hashes if cached else ordinary_hashes)
        decoder=WalkDecoder(source);model,_=load(Path(r['checkpoint']));observer=CachedObserver(source,decoder)
        control=OUT/(view+'-'+kind+'-control.tsv');native=Native(Path(r['environment']),source,control,view=='overview',False)
        rows=[json.loads(s) for s in (stage/'actions.jsonl').read_text().splitlines()]
        current=np.zeros_like(decoder.positions);visual=r['initialVisual'];individual=r['initialIndividualVisual'];best=None;best_visual=visual;best_ind=individual
        visited={array_hash(current)};attempts=admitted=strict=skips=0;reasons=Counter();xs=[];ys=[];gains=[];cycles_seen=[];amps_seen=[];native_features=0;samples=0
        try:
          for record in r['rounds']:
            p=stage/record['file'];assert digest(p)==record['sha256']
            with np.load(p,allow_pickle=False) as z:
                nodes=z['node_features'].copy();assert np.array_equal(z['current_delta'],current)
                # Every cache-produced feature array used for model selection
                # is compared with an independent full Native observation.
                if cached or record['round'] in (0,len(r['rounds'])//2,len(r['rounds'])-1):
                    state=native.initial if not current.any() else native.request(wire(cumulative_action(decoder,current),'OBS'))
                    assert np.array_equal(nodes,np.array([n['features'] for n in state['nodes']]))
                    assert (state['visual'],state['individualVisual'])==(visual,individual);native_features+=1
                local=SimpleNamespace(positions=decoder.positions+current,sizes=decoder.sizes,provider=decoder.provider,irrelevant_isolate=decoder.irrelevant_isolate)
                args=(model,local,nodes,view,r['seed']+record['round'],r['triples'],r['perRound'])
                values=cached_prepare(*args,r['samplingTemperature']) if cached else local_prepare(*args)
                cycles,support,scores,fh,error,allowed,noise,policy,chosen,dedup=values
                for name,value in [('cycles',cycles),('scores',scores),('allowed_indices',allowed),('gumbel',noise),('proposal_schedule',chosen)]:assert np.array_equal(z[name],value),name
            assert (support,fh,error,policy,dedup)==tuple(record[k] for k in ('support','featureChunkHashes','scaleFeatureMaxError','policy','deduplication'))
            assert (record['visual'],record['individualVisual'])==(visual,individual)
            lookup={int(v):i for i,v in enumerate(allowed)};moved=False
            for i,row in enumerate(x for x in rows if x['round']==record['round']):
                assert not moved and row['proposalRank']==i;ci,ai=map(int,chosen[i]);key=motion_key(local,cycles[ci],AMPLITUDES[ai])
                assert (ci,ai)==(row['cycleIndex'],row['amplitudeIndex']) and list(key)==row['ownerDeltaCents']
                assert row['cycle']==cycles[ci].tolist() and row['amplitudes']==AMPLITUDES[ai].tolist()
                ni=lookup[int(np.ravel_multi_index((ci,ai),scores.shape))];assert row['score']==float(scores[ci,ai]) and row['gumbel']==float(noise[ni,0])
                cents=np.rint(current*100).astype(np.int64);cents[key[0]]+=np.array(key[1:]);delta=cents.astype(np.float64)/100;geometry=array_hash(delta)
                assert geometry==row['cumulativeDeltaHash']
                if 'skipped' in row:assert geometry in visited;skips+=1;continue
                assert geometry not in visited;proposed=cumulative_action(decoder,delta);assert hashlib.sha256(wire(proposed).encode()).hexdigest()==row['wireSha256']
                result=row['result'];reasons[result['reason']]+=1;attempts+=1
                accepted=result['legal'] and result['visual']<best_visual and (view=='overview' or result['individualVisual']<=best_ind)
                walk=result['legal'] and result['visual']<=visual and (view=='overview' or result['individualVisual']<=individual)
                assert accepted==result['accepted'] and walk==row['walkAdmitted']
                if attempts<=16 or accepted:compare(native.request(wire(proposed,'MEASURE')),result);samples+=1
                x,_=action_features(nodes,local,cycles[ci:ci+1],AMPLITUDES[ai:ai+1],view=='overview')
                xs.append(x[0].astype(np.float32));ys.append(outcome_target(result,visual));gains.append(float(visual-result['visual']) if result['legal'] else np.nan);cycles_seen.append(cycles[ci]);amps_seen.append(AMPLITUDES[ai])
                if accepted:best=proposed.copy();best_visual=result['visual'];best_ind=result['individualVisual'];strict+=1
                if walk:current=delta;visited.add(geometry);admitted+=1;moved=True;visual=result['visual'];individual=result['individualVisual']
            if record['round']%8==0:print(json.dumps({'verifiedStage':stage.name,'round':record['round'],'fullNativeFeatureControls':native_features}),flush=True)
          assert np.array_equal(current,np.load(stage/'walk-delta.npy',allow_pickle=False))
          final=native.request(wire(cumulative_action(decoder,current),'MEASURE'));samples+=1
          assert final['legal'] and (final['visual'],final['individualVisual'])==(visual,individual)
          if cached:
              full=native.request(wire(cumulative_action(decoder,current),'OBS'));actual=observer.observe(cumulative_action(decoder,current),final)
              assert np.array_equal(np.array([n['features'] for n in full['nodes']]),np.array([n['features'] for n in actual['nodes']]));native_features+=1
          immutable(native,control,source,decoder)
        finally:native.close()
        assert (attempts,admitted,strict,skips,admitted)==tuple(r[k] for k in ('newNeuralProposals','admittedWalkStates','newStrictImprovements','visitedStateSkips','observations'))
        assert (visual,individual)==(r['walkVisual'],r['walkIndividualVisual']) and best_visual==r['final']['visual'] and dict(reasons)==r['reasons']
        verify_saved(source,stage,decoder,best)
        np.savez_compressed(OUT/(stage.name+'-labels.npz'),x=np.array(xs),y=np.array(ys),actual_gain=np.array(gains),cycles=np.array(cycles_seen),amplitudes=np.array(amps_seen))
        check={'stage':str(stage),'modelScoresSchedulesAndAllActionsReplayed':attempts,'admittedStates':admitted,'strictImprovements':strict,'fullNativeFeatureControls':native_features,'fullNativeMeasurementSamples':samples,'allModelInputStatesNativeVerified':cached,'finalVisual':best_visual,'labelsBaselineIsCurrentWalkVisual':True}
        checks.append(check);feature_controls+=native_features;full_measurements+=samples;print(json.dumps(check),flush=True)
    result={'status':'pass','checks':checks,'readOnlyFullNativeMeasurements':full_measurements,'fullNativeFeatureControls':feature_controls,'newNeuralProposalsDuringVerification':0,'allCachedModelInputsNativeVerifiedExactly':True,'verifierSha256':digest(__file__)}
    (OUT/'walks.audit.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)

def static():
    checks=[];samples=0
    for view in ('individual','overview'):
      for kind in ('batches','global'):
        stage=ROOT/(view+'-'+kind+'1');batch=kind=='batches';r,source=bind(stage,batch_hashes if batch else global_hashes)
        decoder=WalkDecoder(source);model,_=load(Path(r['checkpoint']));assert digest(stage/'observations.npz')==r['observationsSha256']
        with np.load(stage/'observations.npz',allow_pickle=False) as z:
            nodes=z['node_features'].copy()
            if batch:
                cycles,support=vocabulary(decoder,nodes,r['seed'],r['triples']);scores,fh,error=rank(model,decoder,nodes,cycles,view=='overview');allowed=allowed_indices(nodes,cycles)
                for name,value in [('cycles',cycles),('amplitudes',AMPLITUDES),('scores',scores),('allowed_indices',allowed)]:assert np.array_equal(z[name],value)
                assert (support,fh,error)==(r['sourceSupport'],r['featureChunkHashes'],r['scaleFeatureMaxError'])
                assert digest(stage/'proposal-schedule.json')==r['scheduleSha256'];schedule=json.loads((stage/'proposal-schedule.json').read_text())
                for entry in schedule:
                    components,policy,dedup=propose(decoder,cycles,scores,allowed,entry['seed'],entry['arity'],r['temperature'])
                    assert (components,policy,dedup)==(entry['components'],entry['policy'],entry['deduplication'])
            else:
                cycles,support,scores,fh,error,allowed,noise,policy,chosen,dedup=global_prepare(model,decoder,nodes,view,r['seed'],r['triples'],r['budget'])
                for name,value in [('cycles',cycles),('amplitudes',AMPLITUDES),('scores',scores),('allowed_indices',allowed),('gumbel',noise),('proposal_schedule',chosen)]:assert np.array_equal(z[name],value)
                assert (support,fh,error,policy,dedup)==tuple(r[k] for k in ('support','featureChunkHashes','scaleFeatureMaxError','policy','deduplication'))
        rows=[json.loads(s) for s in (stage/'actions.jsonl').read_text().splitlines()];best=None;best_visual=r['initialVisual'];best_ind=r['initialIndividualVisual'];reasons=Counter();wires=set();measured=0
        control=OUT/(stage.name+'-control.tsv');native=Native(Path(r['environment']),source,control,view=='overview',False)
        try:
          assert np.array_equal(nodes,np.array([n['features'] for n in native.initial['nodes']]))
          if not batch:
              labels=np.load(stage/'labels.npz',allow_pickle=False);lookup={int(v):i for i,v in enumerate(allowed)}
              features,_=action_features(nodes,decoder,cycles[chosen[:,0]],AMPLITUDES[chosen[:,1]],view=='overview')
          for i,row in enumerate(rows):
            assert row['rank']==i
            if batch:entry=schedule[i];assert row['arity']==entry['arity'];proposed=decode(decoder,entry['components'])
            else:
                ci,ai=map(int,chosen[i]);assert (ci,ai)==(row['cycleIndex'],row['amplitudeIndex'])
                assert row['cycle']==cycles[ci].tolist() and row['amplitudes']==AMPLITUDES[ai].tolist()
                ni=lookup[int(np.ravel_multi_index((ci,ai),scores.shape))];assert row['score']==float(scores[ci,ai]) and row['gumbel']==float(noise[ni,0])
                proposed=action(decoder,cycles[ci],AMPLITUDES[ai])
                assert np.array_equal(labels['x'][i],features[i].astype(np.float32)) and labels['y'][i]==outcome_target(row['result'],r['initialVisual'])
            key=hashlib.sha256(wire(proposed).encode()).hexdigest();assert key==row['wireSha256'] and key not in wires;wires.add(key)
            result=row['result'];accepted=result['legal'] and result['visual']<best_visual and (view=='overview' or result['individualVisual']<=best_ind)
            assert accepted==result['accepted'];reasons[result['reason']]+=1
            if i<16 or accepted:compare(native.request(wire(proposed,'MEASURE')),result);measured+=1
            if accepted:best=proposed.copy();best_visual=result['visual'];best_ind=result['individualVisual']
          if not batch:labels.close()
          immutable(native,control,source,decoder)
        finally:native.close()
        assert len(rows)==r['attempts'] and dict(reasons)==r['reasons'] and best_visual==r['final']['visual'];verify_saved(source,stage,decoder,best)
        check={'stage':str(stage),'allModelScoresSchedulesAndActionsReplayed':len(rows),'fullNativeMeasurementSamples':measured,'finalVisual':best_visual,'allNativeScoresIndependentlyRecomputed':False}
        checks.append(check);samples+=measured;print(json.dumps(check),flush=True)
    result={'status':'pass','checks':checks,'readOnlyFullNativeMeasurements':samples,'newNeuralProposalsDuringVerification':0,'verifierSha256':digest(__file__)}
    (OUT/'static.audit.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--part',choices=['walks','static'],required=True);a=p.parse_args();OUT.mkdir(exist_ok=True);(walks if a.part=='walks' else static)()
