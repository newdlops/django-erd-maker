"""Version the walk for proven cached observations and model-temperature sampling."""
from pathlib import Path
import hashlib
import json

root=Path('.tmp/visualcross-ml-150-750-20261004/single-owner-trained-walk1')
proof=root/'observer-probe2/probe.audit.json';audit=json.loads(proof.read_text())
observer=Path('scripts/erd-poc/single_owner_cached_observer_v2.py')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert audit['status']=='pass' and audit['observerSourceSha256']==sha(observer)
source=Path('scripts/erd-poc/run_single_owner_neural_walk_v2.py');out=source.with_name('run_single_owner_neural_walk_v3.py');assert not out.exists()
text=source.read_text()
edits={
 'from run_single_owner_cycle_policy_v2 import hashes as policy_hashes, prepare':'from run_single_owner_cycle_policy_v2 import hashes as policy_hashes\nfrom run_fraction_conditioned_policy import sample_order\nfrom single_owner_cached_observer_v2 import CachedObserver',
 'from single_owner_cycle_model import ACTION_SCHEMA, MODEL_KIND, AMPLITUDES, action, load, motion_key':'from single_owner_cycle_model import ACTION_SCHEMA, MODEL_KIND, AMPLITUDES, action, load, motion_key, vocabulary, rank, allowed_indices, schedule',
 "return policy_hashes() | {n: digest(Path(__file__).parent/n) for n in ['run_single_owner_neural_walk.py','run_single_owner_neural_walk_v2.py']}":"return policy_hashes() | {n: digest(Path(__file__).parent/n) for n in ['run_single_owner_neural_walk.py','run_single_owner_neural_walk_v2.py','run_single_owner_neural_walk_v3.py','single_owner_cached_observer.py','single_owner_cached_observer_v2.py']}",
 'assert 1 <= args.rounds <= 64':'assert 1 <= args.rounds <= 256',
 "assert visual == binding['expectedVisual']":"assert visual == binding['expectedVisual']\n    proof = json.loads(args.cache_parity_proof.read_text())\n    assert proof['status'] == 'pass' and proof['observerSourceSha256'] == digest(Path(__file__).parent/'single_owner_cached_observer_v2.py')\n    observer = CachedObserver(args.directory, base)\n    zero = cumulative_action(base, np.zeros_like(base.positions))\n    baseline = native.request(wire(zero, 'MEASURE'))\n    cached_initial = observer.observe(zero, baseline)\n    assert cached_initial == (state | {'observed': True, 'reason': 'ok'}) if False else np.array_equal(\n        np.array([n['features'] for n in cached_initial['nodes']]), np.array([n['features'] for n in state['nodes']]))",
 "state = native.request(wire(warm, 'OBS'))":"state = observer.observe(warm, replay)",
 "model, decoder, nodes, args.view, args.seed+round_id, args.triples, args.per_round)":"model, decoder, nodes, args.view, args.seed+round_id, args.triples, args.per_round, args.temperature)",
 "state = native.request(wire(proposed, 'OBS'))":"state = observer.observe(proposed, result)",
 "'kind': 'single-owner-neural-neutral-walk-v2'":"'kind': 'single-owner-neural-neutral-walk-v3', 'samplingTemperature': args.temperature,\n        'cacheParityProof': str(args.cache_parity_proof), 'cacheParityProofSha256': digest(args.cache_parity_proof),\n        'initialCachedFeaturesExactlyMatchNative': True, 'baselineNativeFullMeasurement': baseline,\n        'initialCacheObservationCount': 1, 'nativeOBSCommandsIssued': 0, 'cachedAdmittedObservations': observations",
 "p.add_argument('--source-binding', type=Path, required=True);":"p.add_argument('--cache-parity-proof', type=Path, required=True); p.add_argument('--temperature', type=float, default=4.); p.add_argument('--source-binding', type=Path, required=True);",
 "p.add_argument('--seed', type=int, default=90709); p.add_argument('--rounds', type=int, default=64)":"p.add_argument('--seed', type=int, default=98303); p.add_argument('--rounds', type=int, default=256)"
}
for a,b in edits.items():assert text.count(a)==1,a;text=text.replace(a,b)
marker='def cumulative_action(decoder, delta):'
prepare='''def prepare(model, decoder, nodes, view, seed, triples, budget, temperature):
    assert 0 < temperature <= 4
    cycles, support = vocabulary(decoder, nodes, seed, triples)
    scores, feature_hashes, error = rank(model, decoder, nodes, cycles, view == 'overview')
    allowed = allowed_indices(nodes, cycles)
    ordered, noise, policy = sample_order(scores.ravel()[allowed, None], seed+1000, temperature)
    chosen, dedup = schedule(decoder, cycles, allowed[ordered], budget)
    return cycles, support, scores, feature_hashes, error, allowed, noise, policy, chosen, dedup


'''
assert text.count(marker)==1;text=text.replace(marker,prepare+marker)
text=text.replace("    assert cached_initial == (state | {'observed': True, 'reason': 'ok'}) if False else np.array_equal(","    assert np.array_equal(")
out.write_text(text)
(root/'cached-runner-binding.json').write_text(json.dumps({'parentRunnerSha256':sha(source),'newRunnerSha256':sha(out),'observerSourceSha256':sha(observer),
 'cacheParityProofSha256':sha(proof),'changes':['read-only exact cached features after Native-proven legal moves','up to 256 rounds within the same 30-second limit','temperature 4 model-score sampling'],
 'modelProposesEveryGeometry':True,'nativeCoordinateSearchOrRepairAdded':False},indent=2)+'\n')
