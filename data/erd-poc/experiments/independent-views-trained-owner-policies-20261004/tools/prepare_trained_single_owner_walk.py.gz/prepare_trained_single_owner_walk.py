"""Copy the promoted, model-generated geometry into immutable walk inputs."""
from pathlib import Path
import hashlib
import json
import shutil

sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
root=Path('.tmp/visualcross-ml-150-750-20261004/single-owner-trained-walk1');root.mkdir(exist_ok=False)
prior=Path('.tmp/visualcross-ml-150-750-20261004/single-owner-learning1')
candidate=Path('data/erd-poc/candidates/captain-ml-independent-views.layout.json')
assert sha(candidate)=='c394c1b9fc4553f4837e6b617dda6ba750b9e3931007bdc6c89966ee4d6b5de3'
layout=json.loads(candidate.read_text());audit=json.loads(candidate.with_name('captain-ml-independent-views.audit.json').read_text())
assert (audit['overviewVisual'],audit['individualVisual'])==(288,1963)
binding=json.loads((prior/'source-binding.json').read_text());views={}
for view in ('overview','individual'):
    old=Path(binding['viewSources'][view]['directory']);out=root/(view+'-source'+str(audit[view+'Visual']));out.mkdir()
    for name,value in binding['viewSources'][view]['inputs'].items():
        assert sha(old/name)==value;shutil.copyfile(old/name,out/name)
    if view=='overview':
        winner=prior/'overview-trained-current1';r=json.loads((winner/'report.json').read_text())
        assert r['final']['visual']==288 and r['savedGeometryMatchesModelOutput']
        for target,source in [('positions.tsv','learned.tsv'),('routes.tsv','learned.tsv.routes.tsv'),
                              ('individual.positions.tsv','learned.tsv.individual'),('individual.routes.tsv','learned.tsv.individual.routes.tsv')]:
            shutil.copyfile(winner/source,out/target)
        exported=json.loads((old/'export.json').read_text());applied=json.loads((prior/'overview-product1/proposal.audit.json').read_text())
        exported.update(sourceFile=audit['overviewSource'],sourceSha256=audit['overviewSourceSha256'],baseline=applied['metrics'],
                        individualBaseline=applied['candidateIndividual'],bboxB=applied['bboxArea']/1e9)
        (out/'export.json').write_text(json.dumps(exported,indent=2)+'\n')
        geometry_nodes=layout['nodes']
        physical=json.loads((prior/'overview-product1/product.scene.json').read_text())['tables']
        positions={key:(float(x),float(y)) for key,x,y in (line.split('\t') for line in (out/'positions.tsv').read_text().splitlines())}
        assert len(positions)==len(physical)==1035
        for n in physical:
            p=positions[n['modelId']];assert abs(p[0]-n['position']['x']-n['size']['width']/2)<1e-8 and abs(p[1]-n['position']['y']-n['size']['height']/2)<1e-8
    else:geometry_nodes=layout['individualView']['nodes']
    positions={key:(float(x),float(y)) for key,x,y in (line.split('\t') for line in (out/'individual.positions.tsv').read_text().splitlines())}
    assert len(positions)==len(geometry_nodes)==1244
    for n in geometry_nodes:
        p=positions[n['modelId']];assert abs(p[0]-n['position']['x']-n['size']['width']/2)<1e-8 and abs(p[1]-n['position']['y']-n['size']['height']/2)<1e-8
    views[view]={'directory':str(out),'inputs':{n:sha(out/n) for n in binding['viewSources'][view]['inputs']},'expectedVisual':audit[view+'Visual']}
record={'viewSources':views,'promotedCandidateSha256':sha(candidate),'promotedAuditSha256':sha(candidate.with_name('captain-ml-independent-views.audit.json')),
 'geometryChosenByNewCode':False,'modelSavedOverviewReport':str(prior/'overview-trained-current1/report.json'),
 'modelSavedOverviewReportSha256':sha(prior/'overview-trained-current1/report.json'),'individualCopiedFromVerified1963Source':True}
(root/'source-binding.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({'preparedSources':views,'newCoordinateProposals':0}),flush=True)

original=Path('scripts/erd-poc/run_single_owner_neural_walk.py');new=original.with_name('run_single_owner_neural_walk_v2.py')
assert not new.exists();text=original.read_text()
edits={
 'from run_single_owner_cycle_policy import hashes as policy_hashes, prepare':'from run_single_owner_cycle_policy_v2 import hashes as policy_hashes, prepare',
 'from single_owner_cycle_model import ACTION_SCHEMA, AMPLITUDES, action, load, motion_key':'from single_owner_cycle_model import ACTION_SCHEMA, MODEL_KIND, AMPLITUDES, action, load, motion_key',
 "return policy_hashes() | {'run_single_owner_neural_walk.py': digest(Path(__file__))}":"return policy_hashes() | {n: digest(Path(__file__).parent/n) for n in ['run_single_owner_neural_walk.py','run_single_owner_neural_walk_v2.py']}",
 "inputs = {n: digest(args.directory/n) for n in INPUT_FILES}; assert inputs == metadata['sourceInputsByView'][args.view]":"inputs = {n: digest(args.directory/n) for n in INPUT_FILES}\n    binding = json.loads(args.source_binding.read_text())['viewSources'][args.view]\n    assert (str(args.directory), inputs) == (binding['directory'], binding['inputs'])",
 "state = native.initial; visual = state['visual']; individual = state['individualVisual']":"state = native.initial; visual = state['visual']; individual = state['individualVisual']\n    assert visual == binding['expectedVisual']",
 'delta = current.copy(); delta[key[0]] += np.array(key[1:])/100':'cents = np.rint(current*100).astype(np.int64); cents[key[0]] += np.array(key[1:])\n                    delta = cents.astype(np.float64)/100',
 "'kind': 'single-owner-neural-neutral-walk-v1'":"'kind': 'single-owner-neural-neutral-walk-v2', 'sourceBinding': str(args.source_binding),\n        'sourceBindingSha256': digest(args.source_binding), 'cumulativeCentMovesEncodedExactly': True",
 "'newTrainingUpdates': 0, 'trainedOnSingleOwnerMoves': False":"'newTrainingUpdates': 0, 'trainedOnSingleOwnerMoves': metadata['kind'] == MODEL_KIND",
 "p.add_argument('--warm-stage', type=Path);":"p.add_argument('--source-binding', type=Path, required=True); p.add_argument('--warm-stage', type=Path);"
}
for a,b in edits.items():assert text.count(a)==1,a;text=text.replace(a,b)
new.write_text(text)
(root/'runner-binding.json').write_text(json.dumps({'originalRunnerSha256':sha(original),'newRunnerSha256':sha(new),
 'changes':['explicit promoted source binding','accurate trained critic lineage','integer-cent cumulative state encoding'],
 'originalRunnerUnchanged':True,'coordinateSearchOrRepairAdded':False},indent=2)+'\n')
