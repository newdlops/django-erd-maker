"""Stream-seal closed trained walks, exact observer and global neural gain."""
import ast
import gzip
import hashlib
import json
import re
import shutil
from pathlib import Path

ROOT=Path('.tmp/visualcross-ml-150-750-20261004/single-owner-trained-walk1')
ARCHIVE=Path('data/erd-poc/experiments/independent-views-trained-owner-policies-20261004')
OLD='c394c1b9fc4553f4837e6b617dda6ba750b9e3931007bdc6c89966ee4d6b5de3'
STABLE=Path('data/erd-poc/candidates/captain-ml-independent-views.layout.json')
def streamed(s):
    h=hashlib.sha256();n=0
    while b:=s.read(65536):h.update(b);n+=len(b)
    return n,h.hexdigest()
def digest(p):
    with Path(p).open('rb') as s:return streamed(s)[1]
def restore(p):
    with Path(p).open('rb') as s:z=s.read(2)==b'\x1f\x8b'
    with (gzip.open(p,'rb') if z else Path(p).open('rb')) as s:return streamed(s)

assert not ARCHIVE.exists() and digest(STABLE)==OLD
audit=json.loads((ROOT/'combined-best1/audit.json').read_text());assert (audit['overviewVisual'],audit['individualVisual'])==(286,1963)
assert audit['models']==1244 and audit['canonicalRelationships']==1727 and not audit['thresholdsMet']
for k in ('actualProductFileLoadVerified','completeIndividualGeometryPreserved','browserRouteFunctionParity','roundTripViewSwitchVerified'):assert audit[k]
candidate=ROOT/'combined-best1/candidate.layout.json';new=digest(candidate);assert new==audit['candidateSha256']
walks=json.loads((ROOT/'verification/walks.audit.json').read_text());static=json.loads((ROOT/'verification/static.audit.json').read_text())
assert walks['status']==static['status']=='pass' and walks['allCachedModelInputsNativeVerifiedExactly']
assert (walks['readOnlyFullNativeMeasurements'],static['readOnlyFullNativeMeasurements'],walks['fullNativeFeatureControls'])==(68,65,88)
names=[v+'-'+k+'1' for v in ('individual','overview') for k in ('walk','cached','batches','global')]
reports=[json.loads((ROOT/n/'report.json').read_text()) for n in names]
proposals=sum(r.get('newNeuralProposals',r.get('attempts',0)) for r in reports);assert proposals==2771
resources={'guardLimitMiB':128,'limitRaised':False,'mathThreads':1,'niceAdjustment':10,'numericalJobsSerialized':True,'hardCpuPercentageQuota':False,'sampledProcessGroupRss':True,'logs':[]}
for p in sorted(ROOT.glob('*.guard.log')):
    txt=p.read_text();peaks=re.findall(r'memory guard: peak=([0-9.]+) MiB limit=([0-9.]+) MiB',txt)
    assert all(float(limit)==128 for _,limit in peaks)
    resources['logs'].append({'path':str(p),'peakMiB':float(peaks[-1][0]) if peaks else None,'exactObserverProbeFailed':p.name=='observer-probe.guard.log'})
(ROOT/'resources.json').write_text(json.dumps(resources,indent=2)+'\n')
diagnosis={'overviewVisual':286,'individualVisual':1963,'targetOverview':150,'targetIndividual':750,'targetMet':False,
 'newNeuralProposals':2771,'ordinaryWalkProposals':82,'cachedWalkProposals':129,'batchedProposals':512,'globalProposals':2048,
 'ordinaryAdmittedNeutralStates':54,'cachedAdmittedNeutralStates':79,'walkStrictImprovements':0,'batchedStrictImprovements':0,
 'globalStrictImprovements':1,'newTrainingUpdates':0,'frozenTrainedCriticSha256':reports[0]['checkpointSha256'],
 'trainedOnSingleOwnerMoves':True,'winningNeuralScore':-1.5750080336494925,'winningRank':70,
 'winningCycle':[174,537,559],'winningAmplitudes':[0,.1,0],
 'winningWireSha256':'2fa3bd2dc819e5825646885956d9f1f5c07f5e7fcb6c05c11e634065a67e1f22',
 'winnerSampledViaNeuralWeightedExploration':True,'learningCausedThisGainEstablished':False,
 'globalSupportAllowsAllSizesAndConflictingIsolatedCards':True,'batchJointInteractionModelTrained':False,
 'exactCachedObserverImplementedAndExecuted':True,'cachedModelInputStateNativeControls':82,
 'allWalkFeatureControls':88,'readOnlyFullNativeMeasurementsInRecordVerification':133,
 'additionalProbeFullMeasurements':7,'additionalProbeNativeOBSCommands':7,
 'allNewNativeActionScoresIndependentlyRecomputed':False,'observerFirstProbeMismatchValues':2,
 'observerFirstProbeMaxAbsDifference':9.999778782798785e-13,'observerV2UsesDarwinLibSystemHypot':True,
 'nativeBuildsThisContinuation':0,'nativeCoordinateSearchOrRepairAdded':False,'allHistoryWireUniquenessClaimed':False,
 'browserVerified':False,'globalGeometryFloorEstablished':False,
 'nextDirection':'Bind verified 286/1963 and use global single-owner support in fresh model trajectories; train from new global/trajectory outcomes with protected word folds; do not repeat closed schedules'}
(ROOT/'diagnosis.json').write_text(json.dumps(diagnosis,indent=2)+'\n')
snapshot=ROOT/'promotion-before';snapshot.mkdir(exist_ok=False)
for suffix in ('layout.json','audit.json','provenance.json'):
    p=STABLE.with_name('captain-ml-independent-views.'+suffix);shutil.copyfile(p,snapshot/p.name)
entries={str(p):Path('run')/p.relative_to(ROOT) for p in ROOT.rglob('*') if p.is_file()}
scripts=Path('scripts/erd-poc');pending=['run_single_owner_neural_walk_v2.py','run_single_owner_neural_walk_v3.py','single_owner_cached_observer.py','single_owner_cached_observer_v2.py','run_neural_owner_batches.py','global_single_owner_support.py','run_single_owner_cycle_policy_v3.py','run_memory_bounded.py']
for name in ('prepare_trained_single_owner_walk.py','probe_single_owner_cached_observer.py','probe_single_owner_cached_observer_v2.py','build_cached_single_owner_walk.py','build_global_single_owner_policy.py','verify_trained_single_owner_policies.py','prepare_global_single_owner_product.py','seal_trained_owner_policies.py','verify_trained_owner_archive.py','promote_trained_owner_policies.py'):
    p=Path('.tmp')/name;assert p.is_file();entries[str(p)]=Path('tools')/name
    for node in ast.walk(ast.parse(p.read_text())):
        if isinstance(node,ast.ImportFrom) and node.module and (scripts/(node.module+'.py')).is_file():pending.append(node.module+'.py')
seen=set()
while pending:
    name=pending.pop()
    if name in seen:continue
    seen.add(name);p=scripts/name;entries[str(p)]=Path('code')/name
    for node in ast.walk(ast.parse(p.read_text())):
        mods=[node.module] if isinstance(node,ast.ImportFrom) else [i.name for i in node.names] if isinstance(node,ast.Import) else []
        for module in mods:
            if module and (scripts/(module+'.py')).is_file():pending.append(module+'.py')
for name in ('apply_learned_single_owner_components.cjs','audit_leaf_card_connections.cjs','compose_independent_views_memory_bounded.cjs'):
    p=scripts/name;entries[str(p)]=Path('code')/name
deps={'data/erd-poc/recovered/captain-2026-09-15-payload.json',audit['individualSource']}
for r in reports:deps.update((r['checkpoint'],r['environment']));deps.update(str(Path(r['sourceDirectory'])/n) for n in r['sourceInputs'])
deps.update(str(Path(audit['individualSource']).parent/n) for n in ('individual.audit.json','workflow.audit.json'))
original=Path('.tmp/visualcross-ml-150-750-20261004/single-owner-learning1/overview-product1')
deps.update(str(original/n) for n in ('candidate.layout.json','product.audit.json'))
deps.add('.tmp/visualcross-ml-150-750-20261004/single-owner-learning1/training2/training.json')
native=Path('.tmp/visualcross-ml-150-750-20261003/pair-neutral-walk1');deps.add(str(native/'build-inputs.json'));deps.update(str(p) for p in (native/'build-inputs').iterdir() if p.is_file())
for item in json.loads((ROOT/'combined-best1/product-code-bindings.json').read_text())['loadedCommonJsModules']:
    p=Path(item['path']);assert digest(p)==item['sha256'];deps.add(str(p))
    if p.parts[0]=='out':
        ts=Path('src').joinpath(*p.parts[1:]).with_suffix('.ts')
        if ts.is_file():deps.add(str(ts))
for source in deps:
    if source not in entries:entries[source]=Path('dependencies')/digest(source)/Path(source).name
parent=Path('data/erd-poc/experiments/independent-views-single-owner-learning-20261004/manifest.json')
assert digest(parent)=='6b9b97a2aafd690eed135ce561091e0b98b29758ee70ba73fbeb397a1a956298'
old=json.loads(parent.read_text());prior={};expected={str(parent):digest(parent)}
for item in old['prerequisiteManifests']:expected[item['path']]=item['sha256']
for item in old['files']:prior[item['sha256']]=(parent.parent/item['archive'],item['bytes'],str(parent))
for item in old['referencedFiles']:prior.setdefault(item['sha256'],(Path(item['archive']),item['bytes'],item['prerequisiteManifest']))
ARCHIVE.mkdir(parents=True);files=[];references=[];reused={};checked=set();required={str(parent)}
for source,relative in sorted(entries.items()):
    p=Path(source);n=p.stat().st_size;value=digest(p)
    if value in prior:
        stored,size,prerequisite=prior[value];assert n==size
        if value not in checked:assert restore(stored)==(n,value);checked.add(value)
        required.add(prerequisite);references.append({'source':source,'archive':str(stored),'bytes':n,'sha256':value,'prerequisiteManifest':prerequisite,'restoreHashVerified':True});continue
    if value in reused:stored,packed=reused[value]
    else:
        stored=Path(str(relative)+'.gz');dest=ARCHIVE/stored;dest.parent.mkdir(parents=True,exist_ok=True)
        with dest.open('xb') as f,gzip.GzipFile(filename='',mode='wb',compresslevel=1,mtime=0,fileobj=f) as z,p.open('rb') as original:
            while b:=original.read(65536):z.write(b)
        assert restore(dest)==(n,value);packed=dest.stat().st_size;reused[value]=(stored,packed)
    files.append({'source':source,'archive':str(stored),'bytes':n,'sha256':value,'compressedBytes':packed})
assert digest(STABLE)==OLD
prerequisites=[]
for p in sorted(required):assert digest(p)==expected[p];prerequisites.append({'path':p,'sha256':expected[p]})
manifest={'scope':'Trained neural trajectories, exact Python observation cache, neural owner batches, global direction support and verified overview gain',
 'previousCandidateSha256':OLD,'candidateSha256':new,'candidateSource':str(candidate),'previousBestSnapshot':str(snapshot),
 'overviewVisual':286,'individualVisual':1963,'targetOverview':150,'targetIndividual':750,'targetMet':False,
 'fullModelsPerView':1244,'fullRelationshipsPerView':1727,'modelSelectedAllGeometry':True,'nativeSearchOrCoordinateRepairs':0,
 'newNeuralProposals':2771,'newTrainingUpdates':0,'frozenTrainedCriticSha256':diagnosis['frozenTrainedCriticSha256'],
 'productAudit':audit,'walksVerification':walks,'staticVerification':static,'diagnosis':diagnosis,'resources':resources,
 'browserVerified':False,'prerequisiteManifests':prerequisites,'files':files,'referencedFiles':references,
 'newPhysicalCompressedFiles':len(reused),'newPhysicalCompressedBytes':sum(v[1] for v in reused.values()),
 'allCompressedAndReferencedBytesRestoreHashVerified':True,'sourcesUnchangedAtSeal':True}
p=ARCHIVE/'manifest.json';p.write_text(json.dumps(manifest,indent=2)+'\n')
result={'manifest':str(p),'manifestSha256':digest(p),'candidateSha256':new,'newPhysicalCompressedFiles':len(reused),
 'newPhysicalCompressedBytes':manifest['newPhysicalCompressedBytes'],'newMappings':len(files),'referencedMappings':len(references)}
receipt=Path('.tmp/trained-owner-archive-seal-receipt.json');assert not receipt.exists();receipt.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
