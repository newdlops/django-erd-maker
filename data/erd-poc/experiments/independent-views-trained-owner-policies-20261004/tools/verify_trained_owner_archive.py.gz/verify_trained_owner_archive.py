"""Independently restore the closed neural-policy archive and match every source."""
import gzip
import hashlib
import json
from pathlib import Path
def digest(p,restore=False):
    p=Path(p)
    with p.open('rb') as s:z=s.read(2)==b'\x1f\x8b'
    h=hashlib.sha256();n=0
    with (gzip.open(p,'rb') if restore and z else p.open('rb')) as s:
        while b:=s.read(32768):h.update(b);n+=len(b)
    return n,h.hexdigest()
receipt=json.loads(Path('.tmp/trained-owner-archive-seal-receipt.json').read_text());p=Path(receipt['manifest'])
assert digest(p)[1]==receipt['manifestSha256'];m=json.loads(p.read_text());objects=set();mappings=0
for category in ('files','referencedFiles'):
    for item in m[category]:
        stored=p.parent/item['archive'] if category=='files' else Path(item['archive']);expected=(item['bytes'],item['sha256'])
        assert digest(stored,True)==expected and digest(item['source'])==expected;objects.add(str(stored));mappings+=1
for item in m['prerequisiteManifests']:assert digest(item['path'])[1]==item['sha256']
assert digest(m['candidateSource'])[1]==m['candidateSha256']
assert m['walksVerification']['status']==m['staticVerification']['status']=='pass'
assert m['walksVerification']['allCachedModelInputsNativeVerifiedExactly'] and m['productAudit']['roundTripViewSwitchVerified']
assert (m['overviewVisual'],m['individualVisual'])==(286,1963) and not m['targetMet']
result={'status':'pass','manifestSha256':receipt['manifestSha256'],'mappingsRestoredAndLiveSourcesMatched':mappings,
 'distinctStoredObjects':len(objects),'prerequisiteManifestsMatched':len(m['prerequisiteManifests']),
 'candidateSha256':m['candidateSha256'],'overviewVisual':286,'individualVisual':1963,'targetMet':False}
out=Path('.tmp/trained-owner-archive-independent-verification.json');assert not out.exists();out.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
