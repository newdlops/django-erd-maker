"""Version the closed one-owner policy for global directional support."""
from pathlib import Path
import hashlib
import json
source=Path('scripts/erd-poc/run_single_owner_cycle_policy_v2.py');dest=source.with_name('run_single_owner_cycle_policy_v3.py');assert not dest.exists()
text=source.read_text();edits={
 "from single_owner_cycle_model import ACTION_SCHEMA, MODEL_KIND, AMPLITUDES, action, allowed_indices, load, rank, schedule, vocabulary":"from single_owner_cycle_model import ACTION_SCHEMA, MODEL_KIND, AMPLITUDES, action, allowed_indices, load, rank, schedule\nfrom global_single_owner_support import vocabulary",
 "'single_owner_cycle_model.py', 'run_single_owner_cycle_policy.py', 'run_single_owner_cycle_policy_v2.py', 'train_anchor_pair_outcomes.py'":"'single_owner_cycle_model.py', 'run_single_owner_cycle_policy.py', 'run_single_owner_cycle_policy_v2.py', 'run_single_owner_cycle_policy_v3.py', 'global_single_owner_support.py', 'train_anchor_pair_outcomes.py'",
 "def prepare(model, decoder, nodes, view, seed, triples, budget):":"def prepare(model, decoder, nodes, view, seed, triples, budget):",
 "seed+1000, 1.)":"seed+1000, 4.)",
 "'kind': 'single-owner-partial-cycle-Captain-policy-v2'":"'kind': 'single-owner-global-Captain-policy-v3', 'samplingTemperature': 4., 'globalAllSizeDirectionSupport': True",
 "assert str(args.directory) == binding['directory'] and inputs == binding['inputs']":"assert str(args.directory) == binding['directory'] and inputs == binding['inputs']",
 "best_visual = native.initial['visual']; xs":"assert native.initial['visual'] == binding['expectedVisual']\n    best_visual = native.initial['visual']; xs"
}
for a,b in edits.items():assert text.count(a)==1,a;text=text.replace(a,b)
dest.write_text(text)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
root=Path('.tmp/visualcross-ml-150-750-20261004/single-owner-trained-walk1')
(root/'global-runner-binding.json').write_text(json.dumps({'parentRunnerSha256':sha(source),'newRunnerSha256':sha(dest),
 'globalSupportSha256':sha('scripts/erd-poc/global_single_owner_support.py'),
 'changes':['global source-based direction vocabulary','conflicting isolated cards retained','temperature 4'],
 'modelInferenceAndGeometryDecoderUnchanged':True,'nativeCoordinateSearchOrRepairAdded':False},indent=2)+'\n')
