"""Bind the independently verified global neural overview winner to the product."""
from pathlib import Path
import hashlib
import json
import shutil
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
root=Path('.tmp/visualcross-ml-150-750-20261004/single-owner-trained-walk1')
assert json.loads((root/'verification/static.audit.json').read_text())['status']=='pass'
stage=root/'overview-global1';r=json.loads((stage/'report.json').read_text())
assert (r['initialVisual'],r['final']['visual'])==(288,286) and r['trainedOnSingleOwnerMoves']
assert r['nativeSearchCalls']==r['coordinateRepairs']==0 and r['accepted']==1
out=root/'overview-product1';out.mkdir(exist_ok=False);source=Path(r['sourceDirectory'])
for name,value in r['sourceInputs'].items():assert sha(source/name)==value;shutil.copyfile(source/name,out/name)
shutil.copyfile(source/'export.json',out/'export.json')
for name in ('learned.tsv','learned.tsv.individual','learned.tsv.routes.tsv','learned.tsv.individual.routes.tsv','learned.tsv.stats.json'):
    shutil.copyfile(stage/name,out/name)
policy={'modelKind':r['checkpointTraining']['kind'],'featureSchema':r['featureSchema'],'actionSchema':r['actionSchema'],
 'checkpoint':r['checkpoint'],'checkpointSha256':r['checkpointSha256'],'untrainedControl':False,'overviewOnly':True,'final':r['final'],
 'criticTrainingUpdatesExecutedInPriorContinuation':r['checkpointTraining']['newTrainingUpdatesExecuted'],
 'selectedCheckpointUpdatesInPriorContinuation':r['checkpointTraining']['selectedCheckpointUpdates'],
 'newTrainingUpdatesDuringInference':0,'globalAllSizeDirectionSupport':True,'conflictingIsolatedCardsEligible':True,
 'experimentReport':str(stage/'report.json'),'experimentReportSha256':sha(stage/'report.json'),
 'modelSelectedAllGeometry':True,'coordinateRepairs':0,'nativeSearchCalls':0,'browserVerified':False}
(out/'learned.tsv.policy.json').write_text(json.dumps(policy,indent=2)+'\n')
(out/'preparation.json').write_text(json.dumps({'stage':str(stage),'stageReportSha256':sha(stage/'report.json'),
 'sourceLayout':json.loads((out/'export.json').read_text())['sourceFile'],'productApplyHelper':'scripts/erd-poc/apply_learned_single_owner_components.cjs',
 'productApplyHelperSha256':sha('scripts/erd-poc/apply_learned_single_owner_components.cjs'),
 'geometryCopiedExactlyFromVerifiedNeuralWinner':True,'newCoordinateProposals':0},indent=2)+'\n')
print(json.dumps({'preparedProduct':str(out),'overviewVisual':286,'newCoordinateProposals':0}),flush=True)
