"""Verify observer features against already completed neural walk states."""
import hashlib
import json
import sys
import time
from pathlib import Path
import numpy as np
sys.path.insert(0,str(Path('scripts/erd-poc').resolve()))
from run_anchor_pair_policy import Native,wire,digest
from run_anchor_pair_walk import WalkDecoder,array_hash
from run_single_owner_neural_walk_v2 import cumulative_action
from single_owner_cached_observer import CachedObserver

root=Path('.tmp/visualcross-ml-150-750-20261004/single-owner-trained-walk1');out=root/'observer-probe1';out.mkdir(exist_ok=False)
checks=[]
for view in ('individual','overview'):
    stage=root/(view+'-walk1');r=json.loads((stage/'report.json').read_text());source=Path(r['sourceDirectory']);decoder=WalkDecoder(source)
    observer=CachedObserver(source,decoder);native=Native(Path(r['environment']),source,out/(view+'-control.tsv'),view=='overview',False)
    try:
        selected=[r['rounds'][i] for i in sorted({0,len(r['rounds'])//2,len(r['rounds'])-1})]
        for record in selected:
            with np.load(stage/record['file'],allow_pickle=False) as saved:
                delta=saved['current_delta'];expected=saved['node_features']
            proposed=cumulative_action(decoder,delta);native_start=time.monotonic();measured=native.request(wire(proposed,'MEASURE'));full=native.request(wire(proposed,'OBS'));native_s=time.monotonic()-native_start
            assert full['observed'] and np.array_equal(expected,np.array([n['features'] for n in full['nodes']]))
            started=time.monotonic();cached=observer.observe(proposed,measured);seconds=time.monotonic()-started
            actual=np.array([n['features'] for n in cached['nodes']]);diff=np.abs(actual-expected)
            if not np.array_equal(actual,expected):
                where=np.argwhere(actual!=expected);details=[{'node':int(n),'feature':int(k),'native':float(expected[n,k]),'cached':float(actual[n,k])} for n,k in where[:20]]
                print(json.dumps({'view':view,'round':record['round'],'differentValues':len(where),'maximumDifference':float(diff.max()),'details':details}),flush=True)
            assert np.array_equal(actual,expected)
            assert (cached['visual'],cached['individualVisual'])==(record['visual'],record['individualVisual'])
            check={'view':view,'round':record['round'],'rowsExactlyMatched':len(actual),'featureHash':array_hash(actual),'cachedSeconds':seconds,'nativeMeasureAndObserveSeconds':native_s}
            checks.append(check);print(json.dumps(check),flush=True)
        assert native.request('SAVE')['saved'];stats=json.loads((out/(view+'-control.tsv.stats.json')).read_text());assert stats['policyActionsEvaluated']==stats['acceptedActions']==0
    finally:native.close()
result={'status':'pass','checks':checks,'newGeometryProposals':0,'fullNativeControlMeasurements':len(checks),'fullNativeControlObservations':len(checks),'observerSourceSha256':digest(Path('scripts/erd-poc/single_owner_cached_observer.py')),'probeSha256':digest(__file__)}
(out/'probe.audit.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
