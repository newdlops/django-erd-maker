"""Streaming seal of completed single-owner policy and bounded failures."""
from pathlib import Path
import ast
import gzip
import hashlib
import json
import re
import shutil

root=Path('.tmp/visualcross-ml-150-750-20261004/single-owner1')
archive=Path('data/erd-poc/experiments/independent-views-single-owner-20261004')
parent=Path('data/erd-poc/experiments/independent-views-owner-amplitudes-20261004-v2/manifest.json')
old_sha='da2317d3d9fe72181587f543843bfdde3cc7030ca328e93c4f627ae21ec356e7'
new_sha='7aa76f957e12361b8e72add0e12e08d97494d78cc087309d9d15448f237cfcda'
def stream_hash(stream):
    h=hashlib.sha256();size=0
    while block:=stream.read(65536):h.update(block);size+=len(block)
    return size,h.hexdigest()
def digest(path):
    with Path(path).open('rb') as s:return stream_hash(s)[1]
def restored(path):
    with Path(path).open('rb') as s:compressed=s.read(2)==b'\x1f\x8b'
    with (gzip.open(path,'rb') if compressed else Path(path).open('rb')) as s:return stream_hash(s)
assert not archive.exists()
audit=json.loads((root/'combined-best3/audit.json').read_text())
assert audit['candidateSha256']==digest(root/'combined-best3/candidate.layout.json')==new_sha
assert (audit['overviewVisual'],audit['individualVisual'])==(289,1963)
assert (audit['models'],audit['canonicalRelationships'])==(1244,1727)
assert (audit['overviewTarget'],audit['individualTarget'])==(150,750) and not audit['thresholdsMet']
for key in ('actualProductFileLoadVerified','completeIndividualGeometryPreserved','browserRouteFunctionParity','roundTripViewSwitchVerified'):
    assert audit[key]
verification=json.loads((root/'verification/records.audit.json').read_text())
assert verification['status']=='pass' and verification['readOnlyFullNativeMeasurements']==59
stable=Path('data/erd-poc/candidates/captain-ml-independent-views.layout.json')
assert digest(stable)==old_sha
snapshot=root/'promotion-before';snapshot.mkdir(exist_ok=False)
for suffix in ('layout.json','audit.json','provenance.json'):
    p=stable.with_name('captain-ml-independent-views.'+suffix);shutil.copyfile(p,snapshot/p.name)
resources={'guardLimitMiB':128,'limitRaised':False,'numericalJobsSerialized':True,'mathThreads':1,
    'niceAdjustment':10,'sampledProcessGroupRss':True,'hardCpuPercentageQuota':False,'logs':[]}
guards=sorted(root.parent.glob('single-owner*.guard.log'))
for path in guards:
    text=path.read_text();peaks=re.findall(r'memory guard: peak=([0-9.]+) MiB limit=([0-9.]+) MiB',text)
    interrupted=re.findall(r'memory limit exceeded: rss=([0-9.]+) MiB limit=([0-9.]+) MiB',text)
    assert all(float(limit)==128 for _,limit in peaks+interrupted)
    resources['logs'].append({'path':str(path),'peakMiB':float(peaks[-1][0]) if peaks else None,
        'guardStoppedAtMiB':float(interrupted[-1][0]) if interrupted else None})
(root/'resources.json').write_text(json.dumps(resources,indent=2)+'\n')
diagnosis={'overviewVisual':289,'individualVisual':1963,'targetOverview':150,'targetIndividual':750,'targetMet':False,
    'frozenNewProposals':2048,'walkNewProposals':25,'newNeuralNativeProposals':2073,
    'distinctNewImprovingActions':1,'knownWinningActionReplayedToWarmWalk':1,'walkNewStrictImprovements':0,
    'walkAdmittedNeutralStates':22,'walkExactObservationCount':23,
    'newTrainingUpdates':0,'frozenCheckpointSha256':'915a84051eedea56c9695a479737706772eef6213ac8b986118ce952c37a7a10',
    'trainedOnSingleOwnerMoves':False,'candidateAmplitudeVectors':66,'exactlyOnePhysicalOwnerMoves':True,
    'frozenIndividualLegalActions':858,'frozenOverviewLegalActions':878,'independentReadOnlyFullMeasurements':59,
    'separateWarmFullScoringMeasurements':1,'allFrozenNativeScoresIndependentlyRecomputed':False,
    'nativeCoordinateSearchOrRepairAdded':False,'savedGeometryMatchesModelOutput':True,
    'observerCacheRuntimeExecuted':False,'observerCacheParityVerified':False,'observerBuildAttempts':4,
    'observerSourceScaffoldsRetained':True,'productCompositionAttempts':3,'productCompositionCompleted':True,
    'browserVerified':False,'globalGeometryFloorEstablished':False,'allHistoryWireUniquenessClaimed':False,
    'nextDirection':'Train on single-owner outcomes and fresh relevant synthetic positives with preserved holdouts; test fresh model schedules and retain the verified 1963 warm geometry; do not rerun completed unchanged trials'}
(root/'diagnosis.json').write_text(json.dumps(diagnosis,indent=2)+'\n')
entries={str(p):Path('run')/p.relative_to(root) for p in root.rglob('*') if p.is_file()}
for p in guards:entries[str(p)]=Path('guards')/p.name
scripts=Path('scripts/erd-poc')
pending=['single_owner_cycle_model.py','run_single_owner_cycle_policy.py','run_single_owner_neural_walk.py','run_memory_bounded.py']
tools=['verify_single_owner_records.py','build_single_owner_observation_cache.py','build_single_owner_observation_cache_v2.py',
       'build_single_owner_observation_cache_v3.py','build_single_owner_observation_cache_v4.py',
       'seal_single_owner_research.py','verify_single_owner_archive.py','promote_single_owner_verified.py']
for name in tools:
    p=Path('.tmp')/name;assert p.is_file();entries[str(p)]=Path('tools')/name
    for node in ast.walk(ast.parse(p.read_text())):
        if isinstance(node,ast.ImportFrom) and node.module and (scripts/(node.module+'.py')).is_file():pending.append(node.module+'.py')
seen=set()
while pending:
    name=pending.pop()
    if name in seen:continue
    seen.add(name);p=scripts/name;entries[str(p)]=Path('code')/name
    for node in ast.walk(ast.parse(p.read_text())):
        modules=[node.module] if isinstance(node,ast.ImportFrom) else [i.name for i in node.names] if isinstance(node,ast.Import) else []
        for module in modules:
            if module and (scripts/(module+'.py')).is_file():pending.append(module+'.py')
for name in ('exact_component_observation_costs.h','exact_component_observation_costs_v2.h',
             'audit_individual_policy_experiment.cjs','compose_independent_views.cjs','compose_independent_views_memory_bounded.cjs'):
    p=scripts/name;entries[str(p)]=Path('code')/name
deps={'data/erd-poc/recovered/captain-2026-09-15-payload.json',
      '.tmp/visualcross-ml-150-750-20261003/overview-bounded-trained2/candidate.layout.json',
      '.tmp/visualcross-ml-150-750-20261003/overview-bounded-trained2/product.audit.json',
      '.tmp/visualcross-ml-150-750-20261003/individual-bounded-trained2/candidate.individual.layout.json'}
for name in ('individual-frozen1','overview-frozen1','individual-walk1'):
    r=json.loads((root/name/'report.json').read_text());deps.update((r['checkpoint'],r['environment']))
    deps.update(str(Path(r['sourceDirectory'])/n) for n in r['sourceInputs'])
native_parent=Path('.tmp/visualcross-ml-150-750-20261003/pair-neutral-walk1')
deps.add(str(native_parent/'build-inputs.json'));deps.update(str(p) for p in (native_parent/'build-inputs').iterdir() if p.is_file())
bindings=json.loads((root/'combined-best3/product-code-bindings.json').read_text())
for item in bindings['loadedCommonJsModules']:
    p=Path(item['path']);assert digest(p)==item['sha256'];deps.add(str(p))
    if p.parts[0]=='out':
        ts=Path('src').joinpath(*p.parts[1:]).with_suffix('.ts')
        if ts.is_file():deps.add(str(ts))
for value in deps:
    if value not in entries:entries[value]=Path('dependencies')/digest(value)/Path(value).name
assert digest(parent)=='6b31d46cd53ab370048e36ba43ed04bdc423e3507adddd42423dca0426a565a7'
old=json.loads(parent.read_text());prior={};expected_prerequisites={str(parent):digest(parent)}
for item in old.get('prerequisiteManifests',[]):expected_prerequisites[item['path']]=item['sha256']
for item in old['files']:
    prior[item['sha256']]=(parent.parent/item['archive'],item['bytes'],str(parent))
for item in old['referencedFiles']:
    prior.setdefault(item['sha256'],(Path(item['archive']),item['bytes'],item['prerequisiteManifest']))
archive.mkdir(parents=True);files=[];references=[];reused={};checked=set();required={str(parent)}
for source,relative in sorted(entries.items()):
    p=Path(source);size=p.stat().st_size;value=digest(p)
    if value in prior:
        stored,expected,prerequisite=prior[value];assert expected==size
        if value not in checked:assert restored(stored)==(size,value);checked.add(value)
        required.add(prerequisite)
        references.append({'source':source,'archive':str(stored),'bytes':size,'sha256':value,
            'prerequisiteManifest':prerequisite,'restoreHashVerified':True});continue
    if value in reused:stored,packed=reused[value]
    else:
        stored=Path(str(relative)+'.gz');destination=archive/stored;destination.parent.mkdir(parents=True,exist_ok=True)
        with destination.open('xb') as output:
            with gzip.GzipFile(filename='',mode='wb',compresslevel=1,mtime=0,fileobj=output) as compressed:
                with p.open('rb') as original:
                    while block:=original.read(65536):compressed.write(block)
        assert restored(destination)==(size,value);packed=destination.stat().st_size;reused[value]=(stored,packed)
    files.append({'source':source,'archive':str(stored),'bytes':size,'sha256':value,'compressedBytes':packed})
assert digest(stable)==old_sha
prerequisites=[]
for p in sorted(required):
    value=digest(p);assert value==expected_prerequisites[p];prerequisites.append({'path':p,'sha256':value})
manifest={'scope':'Single-owner frozen neural transfer, neutral trajectory, full-score/model replay, product composition and preserved bounded failures',
    'previousCandidateSha256':old_sha,'candidateSha256':new_sha,'candidateSource':str(root/'combined-best3/candidate.layout.json'),
    'previousBestSnapshot':str(snapshot),'overviewVisual':289,'individualVisual':1963,
    'targetOverview':150,'targetIndividual':750,'targetMet':False,'fullModelsPerView':1244,'fullRelationshipsPerView':1727,
    'sourceSizesAndCanonicalRelationshipsUnchanged':True,'modelSelectedAllGeometry':True,'nativeSearchOrCoordinateRepairs':0,
    'newNeuralNativeProposals':2073,'distinctNewImprovingActions':1,'knownWarmNeuralActionReplays':1,
    'newTrainingUpdates':0,'frozenCheckpointSha256':diagnosis['frozenCheckpointSha256'],'trainedOnSingleOwnerMoves':False,
    'readOnlyIndependentFullNativeMeasurements':59,'exactWalkObservationsIndependentlyReplayed':23,
    'allFrozenNativeActionScoresIndependentlyRecomputed':False,'browserVerified':False,
    'productAudit':audit,'recordsVerification':verification,'diagnosis':diagnosis,'resources':resources,
    'observerCacheRuntimeExecuted':False,'prerequisiteManifests':prerequisites,'files':files,'referencedFiles':references,
    'newPhysicalCompressedFiles':len(reused),'newPhysicalCompressedBytes':sum(v[1] for v in reused.values()),
    'logicalFiles':len(files),'referencedLogicalFiles':len(references),
    'allCompressedAndReferencedBytesRestoreHashVerified':True,'sourcesUnchangedAtSeal':True}
path=archive/'manifest.json';path.write_text(json.dumps(manifest,indent=2)+'\n')
result={'manifest':str(path),'manifestSha256':digest(path),'candidateSha256':new_sha,
    'newPhysicalCompressedFiles':len(reused),'newPhysicalCompressedBytes':manifest['newPhysicalCompressedBytes'],
    'newMappings':len(files),'referencedMappings':len(references)}
receipt=Path('.tmp/single-owner-archive-seal-receipt.json');assert not receipt.exists()
receipt.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
