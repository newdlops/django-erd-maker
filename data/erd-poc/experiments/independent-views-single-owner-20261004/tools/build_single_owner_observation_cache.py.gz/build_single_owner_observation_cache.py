"""Versioned observer-only native build from its verified immutable parent sources."""
from pathlib import Path
import hashlib
import json

parent = Path('.tmp/visualcross-ml-150-750-20261003/pair-neutral-walk1')
root = Path('.tmp/visualcross-ml-150-750-20261004/single-owner1/cached-observations1')
root.mkdir(parents=True, exist_ok=False); out = root/'build-inputs'; out.mkdir()
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
expected = json.loads((parent/'build-inputs.json').read_text())
for name, value in expected.items():
    p = parent/'build-inputs'/name; assert sha(p) == value; (out/name).write_bytes(p.read_bytes())
component = out/'ml_component_environment.cpp'; text = component.read_text()
start = text.index('  std::vector<double> features(int n,double& scale)')
end = text.index('  void save(', start); block = text[start:end]
assert block.count('const auto ca=cost(a,an,gs),cb=cost(b,ns,es);') == 1
block = block.replace('features(int n,double& scale)',
    'features(int n,double& scale,const NodeCost* cachedPhysical=nullptr,const NodeCost* cachedIndividual=nullptr)')
block = block.replace('const auto ca=cost(a,an,gs),cb=cost(b,ns,es);',
    'const auto ca=cachedPhysical?*cachedPhysical:cost(a,an,gs);\n    const auto cb=cachedIndividual?*cachedIndividual:cost(b,ns,es);')
component.write_text(text[:start]+block+text[end:])
header = Path('scripts/erd-poc/exact_component_observation_costs.h')
(out/header.name).write_bytes(header.read_bytes())
batch = out/'ml_joint_batch_environment.cpp'; text = batch.read_text()
text = text.replace('#include "ml_component_environment.cpp"',
    '#include "ml_component_environment.cpp"\n#include "exact_component_observation_costs.h"',1)
start = text.index('void writeBatchNodes('); end = text.index('Point perimeterPoint(',start)
text = text[:start]+'''void writeBatchNodes(ComponentEnvironment& state) {
  const ExactComponentObservationCosts cache(state);std::cout<<'[';
  for(int n=0;n<int(state.components.size());n++) {
    double scale;const auto f=state.features(n,scale,&cache.physical[n],&cache.individual[n]);
    if(verifyObservationCache) {
      double legacyScale;const auto legacy=state.features(n,legacyScale);
      if(f!=legacy||scale!=legacyScale)throw std::runtime_error("cached observation differs from legacy features");
      observationCacheParityRows++;
    }
    if(n)std::cout<<',';std::cout<<"{\\\"id\\\":"<<n<<",\\\"features\\\":";array(std::cout,f);std::cout<<'}';
  }
  std::cout<<']';
}
'''+text[end:]
marker='    writeBatchNodes(source);std::cout'
assert marker in text
text=text.replace(marker,'    verifyObservationCache=arg(argc,argv,"--verify-observation-cache","0")=="1";\n'+marker,1)
batch.write_text(text)
record={'parentEnvironmentSha256':sha(parent/'environment'),'parentSourceHashes':expected,
    'modifiedSourceHashes':{p.name:sha(p) for p in out.iterdir()},
    'changeScope':'only ComponentEnvironment feature cost overrides and writeBatchNodes observation cache',
    'evaluationDecodingAcceptanceAndSaveBodiesUnchanged':True,'nativeCoordinateProposalOrRepairAdded':False}
(root/'build-inputs.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'observerBuildInputs':str(out),'parentSourcesVerified':len(expected),'coordinateProposalChanges':0}),flush=True)
