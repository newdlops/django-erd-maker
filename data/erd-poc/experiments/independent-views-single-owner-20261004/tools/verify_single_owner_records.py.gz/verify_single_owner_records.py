"""Replay neural schedules/geometry; independently full-score stated samples."""
import sys
from pathlib import Path
sys.path.insert(0,str(Path('scripts/erd-poc').resolve()))
from collections import Counter
import hashlib
import json
from types import SimpleNamespace
import numpy as np
from run_anchor_pair_policy import Native,digest,wire
from run_anchor_pair_walk import WalkDecoder,array_hash,verify_saved
from run_single_owner_cycle_policy import hashes,prepare
from run_single_owner_neural_walk import hashes as walk_hashes,cumulative_action
from single_owner_cycle_model import AMPLITUDES,action,load,motion_key
from owner_amplitude_cycle_model import action_features
from train_anchor_pair_outcomes import outcome_target

root=Path('.tmp/visualcross-ml-150-750-20261004/single-owner1')
out=root/'verification';out.mkdir(exist_ok=False)
metric_keys=('legal','reason','visual','individualVisual','spacing','hard','individualHard')
def bind(stage,walk=False):
    report=json.loads((stage/'report.json').read_text())
    source=Path(report['sourceDirectory'])
    for name,value in report['sourceInputs'].items():assert digest(source/name)==value
    assert digest(report['checkpoint'])==report['checkpointSha256']
    assert digest(report['environment'])==report['environmentSha256']
    assert report['codeSha256']==(walk_hashes() if walk else hashes())
    assert digest(stage/'actions.jsonl')==report['actionsSha256']
    return report,source
def compare(actual,expected):
    assert all(actual[k]==expected[k] for k in metric_keys),(actual,expected)
def immutable(native,path):
    assert native.request('SAVE')['saved']
    stats=json.loads(Path(str(path)+'.stats.json').read_text())
    assert stats['policyActionsEvaluated']==stats['acceptedActions']==0
    assert stats['visual']==native.initial['visual'] and stats['individualVisual']==native.initial['individualVisual']
    return stats
checks=[];measurements=0
for view in ('individual','overview'):
    stage=root/(view+'-frozen1');r,source=bind(stage)
    assert digest(stage/'observations.npz')==r['observationsSha256'] and digest(stage/'labels.npz')==r['labelsSha256']
    decoder=WalkDecoder(source);model,_=load(Path(r['checkpoint']))
    with np.load(stage/'observations.npz',allow_pickle=False) as saved:
        nodes=saved['node_features'].copy()
        cycles,support,scores,fh,error,allowed,noise,policy,chosen,dedup=prepare(model,decoder,nodes,view,r['seed'],r['triples'],r['budget'])
        for name,value in [('cycles',cycles),('amplitudes',AMPLITUDES),('scores',scores),('allowed_indices',allowed),('gumbel',noise),('proposal_schedule',chosen)]:
            assert np.array_equal(saved[name],value),name
    assert (support,fh,error,policy,dedup)==tuple(r[k] for k in ('support','featureChunkHashes','scaleFeatureMaxError','policy','deduplication'))
    features,_=action_features(nodes,decoder,cycles[chosen[:,0]],AMPLITUDES[chosen[:,1]],view=='overview')
    rows=[json.loads(line) for line in (stage/'actions.jsonl').read_text().splitlines()]
    lookup={int(v):i for i,v in enumerate(allowed)}
    best=None;best_visual=r['initialVisual'];best_individual=r['initialIndividualVisual'];wires=set();reasons=Counter()
    labels=np.load(stage/'labels.npz',allow_pickle=False)
    full_path=out/(view+'-full-control.tsv')
    native=Native(Path(r['environment']),source,full_path,view=='overview',False)
    native_samples=0
    try:
        assert np.array_equal(nodes,np.array([n['features'] for n in native.initial['nodes']]))
        assert (native.initial['visual'],native.initial['individualVisual'])==(r['initialVisual'],r['initialIndividualVisual'])
        for i,row in enumerate(rows):
            ci,ai=map(int,chosen[i]);cycle=cycles[ci];amplitudes=AMPLITUDES[ai]
            assert row['rank']==i and (row['cycleIndex'],row['amplitudeIndex'])==(ci,ai)
            assert row['cycle']==cycle.tolist() and row['amplitudes']==amplitudes.tolist()
            ni=lookup[int(np.ravel_multi_index((ci,ai),scores.shape))]
            assert row['score']==float(scores[ci,ai]) and row['gumbel']==float(noise[ni,0])
            proposed=action(decoder,cycle,amplitudes);key=hashlib.sha256(wire(proposed).encode()).hexdigest()
            assert key==row['wireSha256'] and key not in wires;wires.add(key)
            assert np.count_nonzero(np.any(proposed[:len(decoder.positions)]!=0,axis=1))==1
            result=row['result'];gain=float(r['initialVisual']-result['visual']) if result['legal'] else np.nan
            assert np.array_equal(labels['x'][i],features[i].astype(np.float32))
            assert labels['y'][i]==outcome_target(result,r['initialVisual'])
            assert (np.isnan(gain) and np.isnan(labels['actual_gain'][i])) or gain==labels['actual_gain'][i]
            assert np.array_equal(labels['cycles'][i],cycle) and np.array_equal(labels['amplitudes'][i],amplitudes)
            accepted=result['legal'] and result['visual']<best_visual and (view=='overview' or result['individualVisual']<=best_individual)
            assert accepted==result['accepted'] and not result['measureOnly']
            reasons[result['reason']]+=1
            if i<16 or accepted:
                compare(native.request(wire(proposed,'MEASURE')),result);native_samples+=1;measurements+=1
            if accepted:best=proposed;best_visual=result['visual'];best_individual=result['individualVisual']
        baseline=immutable(native,full_path)
    finally:native.close();labels.close()
    assert len(rows)==r['attempts']==1024 and len(wires)==r['uniqueWireHashesWithinStage']
    assert dict(reasons)==r['reasons'] and best_visual==r['final']['visual']
    assert sum(row['result']['accepted'] for row in rows)==r['accepted']
    assert sum(row['result']['legal'] and row['result']['visual']<r['initialVisual'] for row in rows)==r['improvingLegalActions']
    assert sum(row['result']['legal'] and row['result']['visual']==r['initialVisual'] for row in rows)==r['legalTies']
    if best is not None:assert np.array_equal(best,np.load(stage/'best-action.npy',allow_pickle=False))
    verify_saved(source,stage,decoder,best)
    check={'stage':str(stage),'allNeuralScoresAndSchedulesReplayed':True,'actionsAndLabelsReconstructed':len(rows),
        'independentFullScoreSamples':native_samples,'finalVisual':best_visual,'sourceUnchangedByReadOnlyControl':True,
        'allNativeActionScoresIndependentlyRecomputed':False}
    checks.append(check);print(json.dumps(check),flush=True)

stage=root/'individual-walk1';r,source=bind(stage,True)
decoder=WalkDecoder(source);model,_=load(Path(r['checkpoint']))
warm_stage=Path(r['warmStage']);warm_report=json.loads((warm_stage/'report.json').read_text())
assert digest(warm_stage/'report.json')==r['warmStageReportSha256']
warm_row=[json.loads(line) for line in (warm_stage/'actions.jsonl').read_text().splitlines() if json.loads(line)['result']['accepted']][-1]
warm=action(decoder,np.array(warm_row['cycle']),np.array(warm_row['amplitudes']))
assert np.array_equal(warm,np.load(warm_stage/'best-action.npy',allow_pickle=False))
current=warm[:len(decoder.positions)].copy();best=warm.copy();best_visual=visual=warm_row['result']['visual']
individual=best_individual=warm_row['result']['individualVisual']
visited={array_hash(np.zeros_like(current)),array_hash(current)}
rows=[json.loads(line) for line in (stage/'actions.jsonl').read_text().splitlines()]
native_path=out/'walk-full-control.tsv';native=Native(Path(r['environment']),source,native_path,False,False)
attempts=admitted=strict=skips=0;observations=1;reasons=Counter()
try:
    measured=native.request(wire(warm,'MEASURE'));compare(measured,warm_row['result']);compare(measured,r['warmFullScoring']);measurements+=1
    state=native.request(wire(warm,'OBS'));assert state['observed'] and state['visual']==visual
    for record in r['rounds']:
        observation=stage/record['file'];assert digest(observation)==record['sha256']
        with np.load(observation,allow_pickle=False) as saved:
            nodes=saved['node_features'].copy()
            assert np.array_equal(saved['current_delta'],current)
            assert np.array_equal(nodes,np.array([n['features'] for n in state['nodes']]))
            local=SimpleNamespace(positions=decoder.positions+current,sizes=decoder.sizes,provider=decoder.provider,irrelevant_isolate=decoder.irrelevant_isolate)
            cycles,support,scores,fh,error,allowed,noise,policy,chosen,dedup=prepare(model,local,nodes,'individual',r['seed']+record['round'],r['triples'],r['perRound'])
            for name,value in [('cycles',cycles),('scores',scores),('allowed_indices',allowed),('gumbel',noise),('proposal_schedule',chosen)]:
                assert np.array_equal(saved[name],value),name
        assert (support,fh,error,policy,dedup)==tuple(record[k] for k in ('support','featureChunkHashes','scaleFeatureMaxError','policy','deduplication'))
        assert (record['visual'],record['individualVisual'])==(visual,individual)
        lookup={int(v):i for i,v in enumerate(allowed)};moved=False
        for i,row in enumerate(row for row in rows if row['round']==record['round']):
            assert not moved and row['proposalRank']==i
            ci,ai=map(int,chosen[i]);key=motion_key(local,cycles[ci],AMPLITUDES[ai])
            assert (ci,ai)==(row['cycleIndex'],row['amplitudeIndex']) and list(key)==row['ownerDeltaCents']
            assert row['cycle']==cycles[ci].tolist() and row['amplitudes']==AMPLITUDES[ai].tolist()
            ni=lookup[int(np.ravel_multi_index((ci,ai),scores.shape))]
            assert row['score']==float(scores[ci,ai]) and row['gumbel']==float(noise[ni,0])
            delta=current.copy();delta[key[0]]+=np.array(key[1:])/100
            geometry=array_hash(delta);assert geometry==row['cumulativeDeltaHash']
            if 'skipped' in row:
                assert geometry in visited;skips+=1;continue
            assert geometry not in visited
            proposed=cumulative_action(decoder,delta);assert hashlib.sha256(wire(proposed).encode()).hexdigest()==row['wireSha256']
            result=row['result'];compare(native.request(wire(proposed,'MEASURE')),result);measurements+=1;attempts+=1
            reasons[result['reason']]+=1
            accepted=result['legal'] and result['visual']<best_visual and result['individualVisual']<=best_individual
            assert accepted==result['accepted']
            accept_walk=result['legal'] and result['visual']<=visual and result['individualVisual']<=individual
            assert accept_walk==row['walkAdmitted']
            if accepted:strict+=1;best=proposed.copy();best_visual=result['visual'];best_individual=result['individualVisual']
            if accept_walk:
                current=delta;visited.add(geometry);admitted+=1;moved=True
                visual=result['visual'];individual=result['individualVisual']
                state=native.request(wire(proposed,'OBS'));observations+=1
                assert state['observed'] and (state['visual'],state['individualVisual'])==(visual,individual)
        print(json.dumps({'verifiedWalkRound':record['round'],'fullMeasurements':attempts,'exactObservations':observations}),flush=True)
    immutable(native,native_path)
finally:native.close()
assert (attempts,admitted,strict,skips,observations)==tuple(r[k] for k in ('newNeuralProposals','admittedWalkStates','newStrictImprovements','visitedStateSkips','observations'))
assert dict(reasons)==r['reasons'] and r['knownNeuralActionsReplayed']==r['warmAcceptedActions']==1
assert digest(stage/'walk-delta.npy')==r['walkDeltaSha256'] and np.array_equal(current,np.load(stage/'walk-delta.npy',allow_pickle=False))
assert np.array_equal(best,np.load(stage/'best-action.npy',allow_pickle=False))
assert (visual,individual)==(r['walkVisual'],r['walkIndividualVisual']) and best_visual==r['final']['visual']
verify_saved(source,stage,decoder,best)
checks.append({'stage':str(stage),'newNeuralActionsReconstructedAndFullScored':attempts,
    'knownWarmActionFullMeasuredSeparately':1,'roundsNeuralScoresAndSchedulesReplayed':len(r['rounds']),
    'exactFullNativeObservationsReplayed':observations,'admittedWalkStates':admitted,
    'newStrictImprovements':strict,'finalVisual':best_visual,'sourceUnchangedByReadOnlyControl':True})
report={'status':'pass','checks':checks,'readOnlyFullNativeMeasurements':measurements,
    'newNeuralProposalsDuringVerification':0,'savedGeometryMatchesModelOutput':True,
    'nativeCoordinateSearchOrRepairAdded':False,'currentCandidateNotChangedByVerification':True,
    'verifierSha256':digest(Path(__file__))}
(out/'records.audit.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report),flush=True)
