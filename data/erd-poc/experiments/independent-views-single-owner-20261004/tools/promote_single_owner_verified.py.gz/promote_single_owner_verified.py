"""Promote the independently restored 289/1963 pair; retain its predecessor."""
from pathlib import Path
import hashlib
import json
import os

sha=lambda value:hashlib.sha256(value).hexdigest()
root=Path('.tmp/visualcross-ml-150-750-20261004/single-owner1')
receipt=json.loads(Path('.tmp/single-owner-archive-seal-receipt.json').read_text())
verified=json.loads(Path('.tmp/single-owner-archive-independent-verification.json').read_text())
manifest_path=Path(receipt['manifest']);assert sha(manifest_path.read_bytes())==receipt['manifestSha256']==verified['manifestSha256']
manifest=json.loads(manifest_path.read_text());assert verified['status']=='pass'
base=Path('data/erd-poc/candidates/captain-ml-independent-views')
layout=Path(str(base)+'.layout.json');audit_path=Path(str(base)+'.audit.json');provenance_path=Path(str(base)+'.provenance.json')
before=root/'promotion-before';old=manifest['previousCandidateSha256'];new=manifest['candidateSha256']
for path in (layout,audit_path,provenance_path):assert path.read_bytes()==(before/path.name).read_bytes()
assert sha(layout.read_bytes())==old
candidate=Path(manifest['candidateSource']).read_bytes();assert sha(candidate)==new
audit=json.loads((root/'combined-best3/audit.json').read_text())
assert audit==manifest['productAudit'] and audit['candidateSha256']==new
assert (audit['overviewVisual'],audit['individualVisual'])==(289,1963)
assert (audit['overviewTarget'],audit['individualTarget'])==(150,750) and not audit['thresholdsMet']
assert audit['models']==1244 and audit['canonicalRelationships']==1727 and not audit['individualSpacingViolations']
for key in ('actualProductFileLoadVerified','completeIndividualGeometryPreserved','browserRouteFunctionParity','roundTripViewSwitchVerified'):assert audit[key]
previous=json.loads(provenance_path.read_text());assert previous['candidateSha256']==old
assert json.loads(audit_path.read_text())['candidateSha256']==old
audit.update(candidate=str(layout),promoted=True,viewSpecificGeometry=True,browserVerified=False)
prior=list(dict.fromkeys(previous['priorArchives']+[Path(previous['archiveManifest']).parent.name]))
history=previous.get('subsequentResearchArchives',[])
history.append({'archiveManifest':str(manifest_path),'archiveManifestSha256':receipt['manifestSha256'],
    'promotedCandidateChanged':True,'previousCandidateSha256':old,'candidateSha256':new,
    'overviewVisual':289,'individualVisual':1963,'newNetworkTrainingUpdates':0,'nativeModelActions':2073,
    'distinctNewImprovingActions':1,'knownWarmActionReplays':1,'readOnlyFullScoringComparisons':59,
    'targetMet':False,'browserVerified':False})
provenance={**previous,'candidateSha256':new,'previousCandidateSha256':old,'overviewVisual':289,'individualVisual':1963,
    'archiveManifest':str(manifest_path),'archiveManifestSha256':receipt['manifestSha256'],'priorArchives':prior,
    'subsequentResearchArchives':history,'stagesInLatestArchive':3,'additionalActionsArchived':2073,
    'coordinatedNetworkBatchesArchived':0,'modelsTrainedInLatestArchive':0,
    'latestFrozenCriticCheckpointSha256':manifest['frozenCheckpointSha256'],'latestCriticTrainedOnSingleOwnerMoves':False,
    'overviewSource':manifest['productAudit']['overviewSource'],'individualSource':manifest['productAudit']['individualSource'],
    'neuralTranslationDecoder':'view-specific: preserved overview bounded policy; individual single-owner partial-cycle model selection with deterministic perimeter ports',
    'neuralTranslationSchema':'owner-amplitude-cycle-mean-moment-v1-3x141 (individual frozen critic)',
    'overviewNeuralTranslationSchema':previous.get('overviewNeuralTranslationSchema',previous.get('neuralTranslationSchema')),
    'validationEvidence':str(root/'verification/records.audit.json'),'productAuditPeakMiB':115.2,
    'outwardBoundaryContractVerified':True,'causalAblationVerified':False,
    'overviewTarget':150,'individualTarget':750,'targetMet':False,'browserVerified':False,
    'resourceLimitMiB':128,'resourceLimitRaised':False,'nativeCoordinateSearchOrRepairAdded':False,
    'latestResearchArchiveIndependentVerification':'.tmp/single-owner-archive-independent-verification.json'}
pending=[]
for path,data in ((layout,candidate),(audit_path,(json.dumps(audit,indent=2)+'\n').encode()),
                  (provenance_path,(json.dumps(provenance,indent=2)+'\n').encode())):
    temporary=path.with_name(path.name+'.promoting')
    with temporary.open('xb') as stream:stream.write(data)
    pending.append((temporary,path))
for temporary,path in pending:os.replace(temporary,path)
assert sha(layout.read_bytes())==new
for path in (audit_path,provenance_path):assert json.loads(path.read_text())['candidateSha256']==new
result={'promoted':True,'overviewVisual':289,'individualVisual':1963,'candidateSha256':new,
    'previousCandidatePreserved':True,'archiveManifestSha256':receipt['manifestSha256'],'targetMet':False,'browserVerified':False}
Path('.tmp/single-owner-promotion-receipt.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
