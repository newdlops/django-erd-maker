"""Observer-only build; omit uninvoked legacy fixtures to stay below 128 MiB."""
from pathlib import Path
import hashlib
import json

parent = Path('.tmp/visualcross-ml-150-750-20261003/pair-neutral-walk1')
root = Path('.tmp/visualcross-ml-150-750-20261004/single-owner1/cached-observations3')
root.mkdir(parents=True, exist_ok=False)
out = root/'build-inputs'; out.mkdir()
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
expected = json.loads((parent/'build-inputs.json').read_text())
for name, value in expected.items():
    p = parent/'build-inputs'/name
    assert sha(p) == value
    (out/name).write_bytes(p.read_bytes())
component = out/'ml_component_environment.cpp'
text = component.read_text()
start = text.index('  std::vector<double> features(int n,double& scale)')
end = text.index('  void save(', start)
block = text[start:end]
assert block.count('const auto ca=cost(a,an,gs),cb=cost(b,ns,es);') == 1
block = block.replace('features(int n,double& scale)',
    'features(int n,double& scale,const NodeCost* cachedPhysical=nullptr,const NodeCost* cachedIndividual=nullptr)')
block = block.replace('const auto ca=cost(a,an,gs),cb=cost(b,ns,es);',
    'const auto ca=cachedPhysical?*cachedPhysical:cost(a,an,gs);\n    const auto cb=cachedIndividual?*cachedIndividual:cost(b,ns,es);')
text = text[:start]+block+text[end:]
cut = text.index('#include "learned_pair_contexts.h"')
removed_component = text[cut:]
serializer = next(line for line in removed_component.splitlines() if line.startswith('void array('))
component.write_text(text[:cut]+serializer+'\n}\n')
header = Path('scripts/erd-poc/exact_component_observation_costs_v2.h')
(out/header.name).write_bytes(header.read_bytes())
batch = out/'ml_joint_batch_environment.cpp'
original = batch.read_text()
text = original.replace('#include "ml_component_environment.cpp"',
    '#include "ml_component_environment.cpp"\n#include "exact_component_observation_costs_v2.h"', 1)
start = text.index('void batchSelfTest()')
end = text.index('\n}\nint main(',start)
removed_batch = text[start:end]
text = text[:start]+text[end:]
entry = '    if(argc==2&&std::string(argv[1])=="--self-test"){batchSelfTest();return 0;}\n'
assert entry in text
text = text.replace(entry,'',1)
start = text.index('void writeBatchNodes(')
end = text.index('Point perimeterPoint(',start)
text = text[:start]+'''void writeBatchNodes(ComponentEnvironment& state) {
  const ExactComponentObservationCosts cache(state);std::cout<<'[';
  for(int n=0;n<int(state.components.size());n++) {
    double scale;const auto f=state.features(n,scale,&cache.physical[n],&cache.individual[n]);
    if(verifyObservationCache) {
      double legacyScale;const auto legacy=state.features(n,legacyScale);
      if(f!=legacy||scale!=legacyScale)throw std::runtime_error("cached observation differs from legacy features");
      observationCacheParityRows++;
    }
    if(n)std::cout<<',';std::cout<<"{\\\"id\\\":"<<n<<",\\\"features\\\":";array(std::cout,f);std::cout<<'}';
  }
  std::cout<<']';
}
'''+text[end:]
marker = '    writeBatchNodes(source);std::cout'
assert marker in text
text = text.replace(marker,'    verifyObservationCache=arg(argc,argv,"--verify-observation-cache","0")=="1";\n'+marker,1)
text = text.replace('}else if(op=="QUIT")return 0;',
    '}else if(op=="QUIT"){if(verifyObservationCache)std::cerr<<"observation-cache-parity-rows="<<observationCacheParityRows<<"\\n";return 0;}',1)
# Prove the entire decoder/evaluation body remains the immutable parent's bytes.
def evaluation(t):
    return t[t.index('Point perimeterPoint('):t.index('void batchSelfTest()') if 'void batchSelfTest()' in t else t.index('\n}\nint main(')]
assert evaluation(original).rstrip() == evaluation(text).rstrip()
batch.write_text(text)
record = {'parentEnvironmentSha256':sha(parent/'environment'),'parentSourceHashes':expected,
    'modifiedSourceHashes':{p.name:sha(p) for p in out.iterdir()},
    'changeScope':'feature cost overrides, exact observation cache, omit unreachable legacy fixtures/corpus/self-test',
    'removedLegacyComponentTailSha256':hashlib.sha256(removed_component.encode()).hexdigest(),
    'removedBatchSelfTestSha256':hashlib.sha256(removed_batch.encode()).hexdigest(),
    'evaluationAndDecodingBodyByteIdentical':True,'acceptanceAndSaveBodiesUnchanged':True,
    'nativeCoordinateProposalOrRepairAdded':False,'selfTestModeAvailable':False,'arraySerializerPreservedFromParent':True}
(root/'build-inputs.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'observerBuildInputs':str(out),'parentSourcesVerified':len(expected),'coordinateProposalChanges':0}),flush=True)
