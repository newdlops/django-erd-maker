"""Independently stream-restore every archived mapping and match live sources."""
from pathlib import Path
import gzip
import hashlib
import json

def digest(path,restore=False):
    p=Path(path)
    with p.open('rb') as s:compressed=s.read(2)==b'\x1f\x8b'
    h=hashlib.sha256();size=0
    with (gzip.open(p,'rb') if restore and compressed else p.open('rb')) as s:
        while block:=s.read(32768):h.update(block);size+=len(block)
    return size,h.hexdigest()
receipt=json.loads(Path('.tmp/single-owner-archive-seal-receipt.json').read_text())
p=Path(receipt['manifest']);assert digest(p)[1]==receipt['manifestSha256'];manifest=json.loads(p.read_text())
objects=set();mappings=0
for category in ('files','referencedFiles'):
    for item in manifest[category]:
        stored=p.parent/item['archive'] if category=='files' else Path(item['archive'])
        expected=(item['bytes'],item['sha256'])
        assert digest(stored,restore=True)==expected and digest(item['source'])==expected
        objects.add(str(stored));mappings+=1
for item in manifest['prerequisiteManifests']:assert digest(item['path'])[1]==item['sha256']
assert digest(manifest['candidateSource'])[1]==manifest['candidateSha256']
assert manifest['productAudit']['actualProductFileLoadVerified'] and manifest['productAudit']['roundTripViewSwitchVerified']
assert manifest['recordsVerification']['status']=='pass' and not manifest['targetMet']
result={'status':'pass','manifestSha256':receipt['manifestSha256'],'archiveMappingsRestoredAndLiveSourcesMatched':mappings,
    'distinctStoredObjects':len(objects),'prerequisiteManifestsMatched':len(manifest['prerequisiteManifests']),
    'candidateSha256':manifest['candidateSha256'],'overviewVisual':289,'individualVisual':1963,'targetMet':False}
out=Path('.tmp/single-owner-archive-independent-verification.json');assert not out.exists()
out.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
