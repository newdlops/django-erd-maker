// Learned-policy environment. It never generates or scores alternate proposals.
// TRY deterministically decodes one model action: rigid translation, or nearest
// card-slot quantization followed by an atomic swap. Rejection has no fallback.
#include "constrained_dual_node_geometry.h"
#include <memory>
#include <map>
#include <functional>

namespace {
long policyHardScore(const State& s) {
  long result=hardScore(s);
  for(int e=0;e<int(s.edges.size());e++) {
    const auto edge=s.edges[e];const auto line=s.routes[e];
    result+=!outwardBoundary(s,edge.s,line.a,line.b);
    result+=!outwardBoundary(s,edge.t,line.b,line.a);
  }
  return result;
}
constexpr int FEATURE_COUNT=64;
struct Result {bool legal=false,accepted=false;long gain=0,individualGain=0;const char* reason="frame";int decodedTarget=-1;Point decodedDelta{};std::array<double,4> actionBounds{};};
double length(const Segment& s){return std::hypot(s.b.x-s.a.x,s.b.y-s.a.y);}
double distance(Point a,Point b){return std::hypot(a.x-b.x,a.y-b.y);}
struct ComponentEnvironment {
  State a,b;
  std::vector<std::vector<int>> components,groups,nodeGroups;
  std::vector<int> owner,edgeGroup;
  std::vector<std::pair<int,int>> initialEndpoints;
  long initialVisual=0,initialIndividualVisual=0,visual=0,individualVisual=0,initialHard=0,initialIndividualHard=0;
  long attempts=0,accepted=0;
  long acceptedNeutral=0;
  long explorationLimit=0,admissionAllowance=0,savedActionPrefix=-1,acceptedExploratory=0;
  bool allowNeutral=false;
  bool attachedRepresentatives=false;
  bool attachAllPorts=false;
  bool neuralPerimeterPorts=false;
  bool movingRayPorts=false;
  bool boundedMoves=false;
  bool jointMoves=false;
  bool neighborMoves=false;
  bool branchMoves=false;
  std::string branchMode="core";
  std::vector<std::vector<int>> branchGroups;
  bool overviewOnly=false; // Isolated-view experiment; never a shared-layout result.
  bool swapSlots=false;
  bool pairActions=false;
  bool portActions=false;
  bool residualPorts=false;
  bool globalScale=false;
  bool areaExploration=false;
  long temporaryRegressionBudget=0;
  double bboxLimit=0;
  std::vector<int> leafParent;
  bool canonicalStart=false;
  long sourceVisual=0,sourceIndividualVisual=0,sourceHard=0,sourceIndividualHard=0;
  double left=1e100,right=-1e100,top=1e100,bottom=-1e100;
  ComponentEnvironment(State overview,State full,std::vector<std::vector<int>> ns,std::vector<std::vector<int>> es,bool verifyProjection=true)
    :a(std::move(overview)),b(std::move(full)),components(std::move(ns)),groups(std::move(es)) {
    if(components.size()!=a.nodes.size()||groups.size()!=a.edges.size())throw std::runtime_error("mapping size");
    owner.assign(b.nodes.size(),-1);edgeGroup.assign(b.edges.size(),-1);nodeGroups.resize(a.nodes.size());
    for(int n=0;n<int(components.size());n++) {
      for(int m:components[n]){if(owner[m]>=0)throw std::runtime_error("duplicate owner");owner[m]=n;}
      left=std::min(left,a.pos[n].x-a.nodes[n].w/2);right=std::max(right,a.pos[n].x+a.nodes[n].w/2);
      top=std::min(top,a.pos[n].y-a.nodes[n].h/2);bottom=std::max(bottom,a.pos[n].y+a.nodes[n].h/2);
    }
    for(int e=0;e<int(groups.size());e++)for(int f:groups[e]) {
      if(edgeGroup[f]>=0)throw std::runtime_error("duplicate relationship");edgeGroup[f]=e;
      nodeGroups[owner[b.edges[f].s]].push_back(e);nodeGroups[owner[b.edges[f].t]].push_back(e);
    }
    for(auto& v:nodeGroups){std::sort(v.begin(),v.end());v.erase(std::unique(v.begin(),v.end()),v.end());}
    for(int n:owner)if(n<0)throw std::runtime_error("unowned node");
    for(int e:edgeGroup)if(e<0)throw std::runtime_error("unowned relationship");
    leafParent.assign(components.size(),-1);
    for(int n=0;n<int(components.size());n++)if(components[n].size()>1) {
      std::map<int,int> counts;
      for(int m:components[n])for(int e:b.incident[m]) {
        const int other=owner[b.edges[e].s==m?b.edges[e].t:b.edges[e].s];
        if(other!=n&&components[other].size()==1)counts[other]++;
      }
      int most=0;for(auto [parent,count]:counts)if(count>most){most=count;leafParent[n]=parent;}
    }
    for(const auto e:a.edges)initialEndpoints.push_back({std::min(e.s,e.t),std::max(e.s,e.t)});
    for(int e=0;e<int(groups.size());e++) {
      const auto old=a.routes[e];if(!project(e))throw std::runtime_error("initial projection type mismatch: "+a.edges[e].id);
      if(verifyProjection&&(!boundarySame(old.a,a.routes[e].a)||!boundarySame(old.b,a.routes[e].b)))throw std::runtime_error("initial product projection mismatch: "+a.edges[e].id);
    }
    initialVisual=visual=a.full().visual();initialIndividualVisual=individualVisual=b.full().visual();
    initialHard=policyHardScore(a);initialIndividualHard=policyHardScore(b);
  }
  double parameter(Point start,Point end,int n,bool exiting) const {
    double enter=0,leave=1;
    for(auto axis:std::array<std::array<double,4>,2>{{
      {{start.x,end.x-start.x,a.pos[n].x-a.nodes[n].w/2,a.pos[n].x+a.nodes[n].w/2}},
      {{start.y,end.y-start.y,a.pos[n].y-a.nodes[n].h/2,a.pos[n].y+a.nodes[n].h/2}}}}) {
      if(std::abs(axis[1])<1e-12)continue;
      const double x=(axis[2]-axis[0])/axis[1],y=(axis[3]-axis[0])/axis[1];
      enter=std::max(enter,std::min(x,y));leave=std::min(leave,std::max(x,y));
    }
    return exiting?leave:enter;
  }
  void canonicalize() {
    // A fixed geometry representation, used only by an explicitly requested
    // experimental reset. No coordinate selection, objective search or repair.
    canonicalStart=true;sourceVisual=visual;sourceIndividualVisual=individualVisual;sourceHard=initialHard;sourceIndividualHard=initialIndividualHard;
    b.allRoutes();for(int e=0;e<int(groups.size());e++)if(!project(e))throw std::runtime_error("canonical representation changes a Leaf pair");
    initialVisual=visual=a.full().visual();initialIndividualVisual=individualVisual=b.full().visual();
    initialHard=policyHardScore(a);initialIndividualHard=policyHardScore(b);
  }
  bool project(int e) {
    // Product projection selects the shortest external member when the June
    // representative joins two models inside the same Leaf card.
    int representative=-1;
    for(int f:groups[e])if(owner[b.edges[f].s]!=owner[b.edges[f].t]&&(representative<0
      ||length(b.routes[f])<length(b.routes[representative])
      ||(length(b.routes[f])==length(b.routes[representative])&&b.edges[f].id<b.edges[representative].id)))representative=f;
    if(representative<0)return false;
    const auto v=b.edges[representative];const int s=owner[v.s],t=owner[v.t];
    if(s==t)return false;
    const auto old=initialEndpoints[e];
    const bool wasLeaf=components[old.first].size()>1||components[old.second].size()>1;
    const bool isLeaf=components[s].size()>1||components[t].size()>1;
    if(wasLeaf!=isLeaf||(wasLeaf&&old!=std::make_pair(std::min(s,t),std::max(s,t))))return false;
    a.edges[e].s=s;a.edges[e].t=t;
    const auto r=b.routes[representative];
    const double x=components[s].size()>1?parameter(r.a,r.b,s,true):0;
    const double y=components[t].size()>1?parameter(r.a,r.b,t,false):1;
    a.routes[e]=segment({rounded(r.a.x+(r.b.x-r.a.x)*x),rounded(r.a.y+(r.b.y-r.a.y)*x)},
      {rounded(r.a.x+(r.b.x-r.a.x)*y),rounded(r.a.y+(r.b.y-r.a.y)*y)});
    return true;
  }
  std::vector<int> incident(int n) const {
    std::vector<int> es;for(int m:components[n])for(int e:b.incident[m])es.push_back(e);
    std::sort(es.begin(),es.end());es.erase(std::unique(es.begin(),es.end()),es.end());return es;
  }
  struct Context {
    std::vector<int> physical,nodes,edges,groups;
    double l=1e100,r=-1e100,t=1e100,b=-1e100;
    Point center() const{return {(l+r)/2,(t+b)/2};}
  };
  int nearestNeighbor(int n) const {
    int chosen=-1;double gapBest=1e100,centerBest=1e100;
    for(int m=0;m<int(a.nodes.size());m++)if(m!=n) {
      const double dx=std::max(0.,std::abs(a.pos[n].x-a.pos[m].x)-(a.nodes[n].w+a.nodes[m].w)/2);
      const double dy=std::max(0.,std::abs(a.pos[n].y-a.pos[m].y)-(a.nodes[n].h+a.nodes[m].h)/2);
      const double gap=std::round(std::hypot(dx,dy)*1e6),center=std::round(distance(a.pos[n],a.pos[m])*1e6);
      if(gap<gapBest||(gap==gapBest&&center<centerBest)){gapBest=gap;centerBest=center;chosen=m;}
    }
    if(chosen<0)throw std::runtime_error("neighbor action requires two cards");return chosen;
  }
  void setBranches(std::vector<std::vector<int>> rows,const std::string& mode="core") {
    if(mode!="core"&&mode!="cut"&&mode!="pair-cut")throw std::runtime_error("unknown branch mode");
    if(!movingRayPorts||jointMoves||neighborMoves||swapSlots||attachAllPorts||attachedRepresentatives)
      throw std::runtime_error("branch contexts require the moving-ray decoder without other grouping");
    if(mode!="pair-cut"&&rows.size()!=components.size())throw std::runtime_error("branch map size");
    for(int n=0;n<int(rows.size());n++) {
      auto& row=rows[n];std::sort(row.begin(),row.end());
      if(row.empty()||row.front()<0||row.back()>=int(components.size())
         ||(mode!="pair-cut"&&!std::binary_search(row.begin(),row.end(),n))
         ||(mode=="pair-cut"&&row.size()<2)
         ||std::adjacent_find(row.begin(),row.end())!=row.end())throw std::runtime_error("invalid branch map row");
    }
    branchGroups=std::move(rows);branchMoves=true;branchMode=mode;
  }
  int actionCount() const{return branchMoves&&branchMode=="pair-cut"?branchGroups.size():components.size();}
  Context context(int n,int extra=-1) const {
    Context c;
    if(!branchMoves||branchMode!="pair-cut")c.physical.push_back(n);
    if(branchMoves)c.physical.insert(c.physical.end(),branchGroups.at(n).begin(),branchGroups.at(n).end());
    if(extra>=0)c.physical.push_back(extra);
    if(neighborMoves)c.physical.push_back(nearestNeighbor(n));
    if(jointMoves) {
      if(leafParent[n]>=0)c.physical.push_back(leafParent[n]);
      else for(int m=0;m<int(leafParent.size());m++)if(leafParent[m]==n)c.physical.push_back(m);
    }
    const auto unique=[](std::vector<int>& v){std::sort(v.begin(),v.end());v.erase(std::unique(v.begin(),v.end()),v.end());};
    unique(c.physical);
    for(int m:c.physical) {
      c.nodes.insert(c.nodes.end(),components[m].begin(),components[m].end());
      c.groups.insert(c.groups.end(),nodeGroups[m].begin(),nodeGroups[m].end());
      c.l=std::min(c.l,a.pos[m].x-a.nodes[m].w/2);c.r=std::max(c.r,a.pos[m].x+a.nodes[m].w/2);
      c.t=std::min(c.t,a.pos[m].y-a.nodes[m].h/2);c.b=std::max(c.b,a.pos[m].y+a.nodes[m].h/2);
    }
    unique(c.nodes);unique(c.groups);
    for(int m:c.nodes)c.edges.insert(c.edges.end(),b.incident[m].begin(),b.incident[m].end());unique(c.edges);
    return c;
  }
  std::vector<long> actionPressure() const {
    std::vector<long> physical,individual;a.full(&physical);b.full(&individual);
    if(!overviewOnly)for(int n=0;n<int(components.size());n++)for(int m:components[n])physical[n]+=individual[m];
    if(!branchMoves||branchMode!="pair-cut")return physical;
    std::vector<long> pressure(branchGroups.size());
    for(int n=0;n<int(branchGroups.size());n++)for(int m:branchGroups[n])pressure[n]+=physical[m];
    return pressure;
  }
  static void mark(State& s,const std::vector<int>& ns,const std::vector<int>& es,bool value) {
    for(int n:ns)s.moved[n]=value;for(int e:es)s.changedEdge[e]=value;
  }
  std::array<double,4> translationBounds(int n) const {
    const auto c=context(n);
    std::array<double,4> box{{left-c.l,right-c.r,top-c.t,bottom-c.b}};
    const auto constrain=[&](const State& state,const std::vector<int>& members) {
      std::vector<bool> moved(state.nodes.size());for(int m:members)moved[m]=true;
      for(int m:members)for(int other=0;other<int(state.nodes.size());other++)if(!moved[other]) {
        const double dx=state.pos[other].x-state.pos[m].x,dy=state.pos[other].y-state.pos[m].y;
        const double rx=std::abs(dx)-(state.nodes[m].w+state.nodes[other].w)/2-55.99;
        const double ry=std::abs(dy)-(state.nodes[m].h+state.nodes[other].h)/2-41.99;
        if(rx<0&&ry<0)throw std::runtime_error("bounded action source has a spacing violation");
        // Select one already separating axis, never consult the objective.
        const int axis=rx>=0&&(ry<0||std::floor(rx*1e6+.5)>=std::floor(ry*1e6+.5))?0:2;
        const double offset=axis==0?dx:dy,room=axis==0?rx:ry;
        if(offset>0)box[axis+1]=std::min(box[axis+1],room);
        else box[axis]=std::max(box[axis],-room);
      }
    };
    constrain(a,c.physical);constrain(b,c.nodes);
    for(int k=0;k<4;k+=2) {
      if(box[k]>0||box[k+1]<0)throw std::runtime_error("bounded action must contain zero");
      // Inward cent rounding with a numerical margin keeps boundary sums safe.
      box[k]=std::ceil(std::min(0.,box[k]+1e-7)*100)/100;
      box[k+1]=std::floor(std::max(0.,box[k+1]-1e-7)*100)/100;
    }
    return box;
  }
  static Point decodeBounded(Point latent,const std::array<double,4>& box) {
    const auto decode=[&](double z,int axis) {
      const double fraction=std::tanh(z);
      return rounded(fraction*(fraction>=0?box[axis+1]:-box[axis]));
    };
    return {decode(latent.x,0),decode(latent.y,2)};
  }
  static NodeCost cost(const State& s,const std::vector<int>& ns,const std::vector<int>& es) {
    NodeCost c{s.local(ns,es),0};
    for(int e:es) {
      const auto v=s.edges[e];const auto line=s.routes[e];
      c.hard+=!outwardBoundary(s,v.s,line.a,line.b)+!outwardBoundary(s,v.t,line.b,line.a);
      c.hard+=hits(line,s.pos[v.s],s.nodes[v.s],-.02)+hits(line,s.pos[v.t],s.nodes[v.t],-.02);
      for(int f=0;f<int(s.edges.size());f++)if(f!=e&&(!s.changedEdge[f]||e<f)) {
        const auto w=s.edges[f];const bool adjacent=v.s==w.s||v.s==w.t||v.t==w.s||v.t==w.t;
        c.hard+=2*(long(adjacent&&crosses(line,s.routes[f]))+boundaryContact(s,e,line,f,s.routes[f]));
      }
    }
    return c;
  }
  Result trial(int n,Point delta,bool commit) {
    if(n<0||n>=actionCount()||!std::isfinite(delta.x)||!std::isfinite(delta.y))throw std::runtime_error("invalid policy action");
    attempts++;
    Result r;int target=-1;
    if(boundedMoves) {
      if(!movingRayPorts||swapSlots||jointMoves||neighborMoves)throw std::runtime_error("invalid bounded decoder combination");
      r.actionBounds=translationBounds(n);delta=decodeBounded(delta,r.actionBounds);
    }else delta={rounded(delta.x),rounded(delta.y)};
    r.decodedDelta=delta;
    if(neighborMoves){if(jointMoves||swapSlots||!attachAllPorts)throw std::runtime_error("neighbor decoder requires attached ports and no other grouping");r.decodedTarget=nearestNeighbor(n);}
    if(swapSlots) {
      if(jointMoves||attachedRepresentatives||attachAllPorts)throw std::runtime_error("swap decoder requires single components and ray ports");
      // Vector quantization of the model's desired point into a card slot.
      // No metric is consulted, and rejection never tries a second slot.
      const Point desired{a.pos[n].x+delta.x,a.pos[n].y+delta.y};double nearest=1e100;
      for(int m=0;m<int(components.size());m++) {
        const double d=std::round(distance(desired,a.pos[m])*1e6)/1e6;
        if(d<nearest){nearest=d;target=m;}
      }
      r.decodedTarget=target;
      if(target==n){r.reason="same-slot";return r;}
      delta={a.pos[target].x-a.pos[n].x,a.pos[target].y-a.pos[n].y};
    }
    const auto c=context(n,target);const auto& an=c.physical;const auto& es=c.edges;const auto& gs=c.groups;const auto& ns=c.nodes;
    const auto movement=[&](int m){return m==target?Point{-delta.x,-delta.y}:delta;};
    for(int m:an) {
      const auto d=movement(m);const Point p{a.pos[m].x+d.x,a.pos[m].y+d.y};
      if(p.x-a.nodes[m].w/2<left||p.x+a.nodes[m].w/2>right||p.y-a.nodes[m].h/2<top||p.y+a.nodes[m].h/2>bottom)return r;
    }
    mark(a,an,gs,true);mark(b,ns,es,true);
    const auto ca=cost(a,an,gs),cb=cost(b,ns,es);
    std::vector<Segment> ar,br;std::vector<Edge> ae;std::vector<Point> ap,bp;
    for(int m:an)ap.push_back(a.pos[m]);
    for(int e:gs){ar.push_back(a.routes[e]);ae.push_back(a.edges[e]);}
    for(int e:es)br.push_back(b.routes[e]);for(int m:ns)bp.push_back(b.pos[m]);
    std::set<int> attached;
    if(attachAllPorts)attached.insert(es.begin(),es.end());
    if(attachedRepresentatives)for(int g:gs) {
      int representative=-1;
      for(int e:groups[g])if(owner[b.edges[e].s]!=owner[b.edges[e].t]&&(representative<0||length(b.routes[e])<length(b.routes[representative])
        ||(length(b.routes[e])==length(b.routes[representative])&&b.edges[e].id<b.edges[representative].id)))representative=e;
      if(representative>=0)attached.insert(representative);
    }
    for(int m:an){const auto d=movement(m);a.pos[m].x+=d.x;a.pos[m].y+=d.y;}
    // Quantize the supplied displacement once; preserve the input's original
    // center precision in both physical and individual representations.
    for(int m:ns){const auto d=movement(owner[m]);b.pos[m].x+=d.x;b.pos[m].y+=d.y;}
    for(int e:es){const auto v=b.edges[e];
      if(attached.count(e)) {
        auto r=b.routes[e];
        if(b.moved[v.s]){r.a.x=rounded(r.a.x+delta.x);r.a.y=rounded(r.a.y+delta.y);}
        if(b.moved[v.t]){r.b.x=rounded(r.b.x+delta.x);r.b.y=rounded(r.b.y+delta.y);}
        b.routes[e]=segment(r.a,r.b);
      }else if(movingRayPorts) {
        const auto old=b.routes[e];
        if(b.moved[v.s]&&b.moved[v.t])b.routes[e]=segment({rounded(old.a.x+delta.x),rounded(old.a.y+delta.y)},
          {rounded(old.b.x+delta.x),rounded(old.b.y+delta.y)});
        else if(b.moved[v.s])b.routes[e]=segment(port(b.pos[v.s],b.nodes[v.s],old.b),old.b);
        else if(b.moved[v.t])b.routes[e]=segment(old.a,port(b.pos[v.t],b.nodes[v.t],old.a));
      }else b.routes[e]=segment(port(b.pos[v.s],b.nodes[v.s],b.pos[v.t]),port(b.pos[v.t],b.nodes[v.t],b.pos[v.s]));
    }
    bool projected=true;for(int e:gs)projected=project(e)&&projected;
    r.reason=projected?"spacing":"projection";bool valid=projected;
    for(int m:an)valid=valid&&spaced(a,m);for(int m:ns)valid=valid&&spaced(b,m);
    if(valid) {
      const auto da=cost(a,an,gs),db=cost(b,ns,es);
      r.gain=ca.score.visual()-da.score.visual();r.individualGain=cb.score.visual()-db.score.visual();
      r.legal=da.hard<=ca.hard&&db.hard<=cb.hard;
      const bool neutral=allowNeutral&&(delta.x!=0||delta.y!=0);
      const bool monotone=r.gain>=0&&(overviewOnly?(r.gain>0||neutral):r.individualGain>=0&&(r.gain||r.individualGain||neutral));
      const long allowance=std::clamp(admissionAllowance,0L,explorationLimit);
      const bool exploratory=explorationLimit>0&&r.gain>=-allowance&&visual-r.gain<=initialVisual+explorationLimit
        &&(overviewOnly||(r.individualGain>=-allowance&&individualVisual-r.individualGain<=initialIndividualVisual+explorationLimit))
        &&(r.gain||(!overviewOnly&&r.individualGain)||neutral);
      r.accepted=r.legal&&(monotone||exploratory);
      r.reason=da.hard>ca.hard?"overview-hard":db.hard>cb.hard?"individual-hard":
        r.accepted?(r.gain<0||(!overviewOnly&&r.individualGain<0)?"accepted-exploratory":r.gain==0&&(overviewOnly||r.individualGain==0)?"accepted-neutral":"accepted"):
        r.gain<0?"overview-regression":!overviewOnly&&r.individualGain<0?"individual-regression":"equal";
    }
    if(commit&&r.accepted){visual-=r.gain;individualVisual-=r.individualGain;accepted++;acceptedNeutral+=r.gain==0&&(overviewOnly||r.individualGain==0);acceptedExploratory+=r.gain<0||(!overviewOnly&&r.individualGain<0);}
    else {
      for(size_t i=0;i<an.size();i++)a.pos[an[i]]=ap[i];for(size_t i=0;i<ns.size();i++)b.pos[ns[i]]=bp[i];
      for(size_t i=0;i<gs.size();i++){a.routes[gs[i]]=ar[i];a.edges[gs[i]]=ae[i];}
      for(size_t i=0;i<es.size();i++)b.routes[es[i]]=br[i];
    }
    mark(a,an,gs,false);mark(b,ns,es,false);return r;
  }
  std::vector<double> features(int n,double& scale,const NodeCost* cachedPhysical=nullptr,const NodeCost* cachedIndividual=nullptr) {
    const auto contextValue=context(n);const Point p=contextValue.center();const auto& es=contextValue.edges;const auto& gs=contextValue.groups;
    const auto& an=contextValue.physical;const auto& ns=contextValue.nodes;
    mark(a,an,gs,true);mark(b,ns,es,true);
    const auto ca=cachedPhysical?*cachedPhysical:cost(a,an,gs);
    const auto cb=cachedIndividual?*cachedIndividual:cost(b,ns,es);
    std::vector<Point> neighbors;std::vector<double> lengths;
    for(int e:es){const auto v=b.edges[e];const int m=b.moved[v.s]?v.t:v.s;if(b.moved[m])continue;neighbors.push_back(b.pos[m]);lengths.push_back(distance(p,b.pos[m]));}
    std::sort(lengths.begin(),lengths.end());scale=std::max(512.,lengths.empty()?512.:lengths[lengths.size()/2]);
    std::vector<double> out;const auto add=[&](double x){out.push_back(std::clamp(x,-8.,8.));};
    add((contextValue.r-contextValue.l)/scale);add((contextValue.b-contextValue.t)/scale);add(std::log1p(ns.size()));add(std::log1p(es.size()));
    add(std::log1p(ca.score.cross));add(std::log1p(ca.score.hit));add(std::log1p(cb.score.cross));add(std::log1p(cb.score.hit));
    add(std::log1p(ca.hard));add(std::log1p(cb.hard));
    double x=0,y=0,xx=0,yy=0,ux=0,uy=0;
    for(Point q:neighbors){const double dx=(q.x-p.x)/scale,dy=(q.y-p.y)/scale,len=std::max(.001,std::hypot(dx,dy));x+=dx;y+=dy;xx+=dx*dx;yy+=dy*dy;ux+=dx/len;uy+=dy/len;}
    const double count=std::max(size_t(1),neighbors.size());add(x/count);add(y/count);add(xx/count);add(yy/count);add(ux/count);add(uy/count);
    std::vector<std::pair<double,int>> nearby;
    for(int m=0;m<int(a.nodes.size());m++)if(!a.moved[m])nearby.push_back({std::round(distance(p,a.pos[m])*1e6)/1e6,m});std::sort(nearby.begin(),nearby.end());
    for(int k=0;k<4;k++) {
      if(k>=int(nearby.size())){for(int j=0;j<4;j++)add(0);continue;}
      const int m=nearby[k].second;add((a.pos[m].x-p.x)/scale);add((a.pos[m].y-p.y)/scale);add(a.nodes[m].w/scale);add(a.nodes[m].h/scale);
    }
    struct Conflict {Segment line;double distance;bool hit;long cross;};std::vector<Conflict> conflicts;
    for(int f=0;f<int(b.edges.size());f++)if(!b.moved[b.edges[f].s]&&!b.moved[b.edges[f].t]) {
      const auto line=b.routes[f];bool hit=false;long crossing=0;
      for(int m:ns)hit=hit||hits(line,b.pos[m],b.nodes[m]);for(int e:es)crossing+=crosses(line,b.routes[e]);
      if(!hit&&!crossing)continue;
      const double dx=line.b.x-line.a.x,dy=line.b.y-line.a.y,t=std::clamp(((p.x-line.a.x)*dx+(p.y-line.a.y)*dy)/std::max(.01,dx*dx+dy*dy),0.,1.);
      conflicts.push_back({line,std::hypot(p.x-line.a.x-t*dx,p.y-line.a.y-t*dy),hit,crossing});
    }
    std::stable_sort(conflicts.begin(),conflicts.end(),[](auto x,auto y){return std::round(x.distance*1e6)<std::round(y.distance*1e6);});
    for(int k=0;k<4;k++) {
      if(k>=int(conflicts.size())){for(int j=0;j<6;j++)add(0);continue;}
      auto c=conflicts[k];if(c.line.a.x>c.line.b.x||(c.line.a.x==c.line.b.x&&c.line.a.y>c.line.b.y))std::swap(c.line.a,c.line.b);
      add((c.line.a.x-p.x)/scale);add((c.line.a.y-p.y)/scale);add((c.line.b.x-p.x)/scale);add((c.line.b.y-p.y)/scale);add(c.hit);add(std::log1p(c.cross));
    }
    if(boundedMoves) {
      const auto box=translationBounds(n);
      add(-box[0]/scale);add(box[1]/scale);add(-box[2]/scale);add(box[3]/scale);
    }else {
      add((contextValue.l-left)/scale);add((right-contextValue.r)/scale);
      add((contextValue.t-top)/scale);add((bottom-contextValue.b)/scale);
    }
    add(lengths.empty()?0:lengths.front()/scale);add(lengths.empty()?0:lengths.back()/scale);
    add(std::log1p(scale/512));add(std::log1p(gs.size()));
    mark(a,an,gs,false);mark(b,ns,es,false);
    if(out.size()!=FEATURE_COUNT)throw std::runtime_error("feature schema");
    if(boundedMoves)scale=1; // Model outputs dimensionless tanh latents.
    return out;
  }
  void save(const std::string& path) {
    const auto x=a.full(),y=b.full();const auto h=policyHardScore(a),ih=policyHardScore(b);
    if(x.visual()!=visual||y.visual()!=individualVisual||h>initialHard||ih>initialIndividualHard||x.overlap||x.spacing||y.overlap||y.spacing)
      throw std::runtime_error("global final audit disagrees with rollout");
    a.save(path);b.save(path+".individual");
    std::ofstream f(path+".stats.json");f<<"{\"initialVisual\":"<<(canonicalStart?sourceVisual:initialVisual)<<",\"visual\":"<<visual
      <<",\"initialIndividualVisual\":"<<(canonicalStart?sourceIndividualVisual:initialIndividualVisual)
      <<",\"individualVisual\":"<<individualVisual<<",\"hardConditions\":"<<h<<",\"initialHardConditions\":"<<(canonicalStart?sourceHard:initialHard)
      <<",\"individualHardConditions\":"<<ih<<",\"initialIndividualHardConditions\":"<<(canonicalStart?sourceIndividualHard:initialIndividualHard)
      <<",\"canonicalStart\":"<<(canonicalStart?"true":"false")<<",\"rolloutInitialVisual\":"<<initialVisual<<",\"rolloutInitialIndividualVisual\":"<<initialIndividualVisual
      <<",\"jointMoves\":"<<(jointMoves?"true":"false")
      <<",\"neighborMoves\":"<<(neighborMoves?"true":"false")
      <<",\"branchMoves\":"<<(branchMoves?"true":"false")
      <<",\"branchMode\":\""<<(branchMoves?branchMode:"none")<<'"'
      <<",\"movingRayPorts\":"<<(movingRayPorts?"true":"false")
      <<",\"boundedMoves\":"<<(boundedMoves?"true":"false")
      <<",\"overviewOnly\":"<<(overviewOnly?"true":"false")
      <<",\"allowNeutral\":"<<(allowNeutral?"true":"false")<<",\"acceptedNeutralActions\":"<<acceptedNeutral
      <<",\"explorationLimit\":"<<explorationLimit<<",\"savedActionPrefix\":"<<savedActionPrefix<<",\"acceptedExploratoryActions\":"<<acceptedExploratory
      <<",\"swapSlots\":"<<(swapSlots?"true":"false")
      <<",\"pairActions\":"<<(pairActions?"true":"false")
      <<",\"portActions\":"<<(portActions?"true":"false")
      <<",\"residualPorts\":"<<(residualPorts?"true":"false")
      <<",\"globalScale\":"<<(globalScale?"true":"false")<<",\"bboxLimit\":"<<std::setprecision(15)<<bboxLimit
      <<",\"areaExploration\":"<<(areaExploration?"true":"false")<<",\"temporaryRegressionBudget\":"<<temporaryRegressionBudget
      <<",\"globalAttachedPorts\":"<<(globalScale&&attachAllPorts?"true":"false")
      <<",\"overlap\":0,\"spacing\":0,\"policyActionsEvaluated\":"<<attempts<<",\"acceptedActions\":"<<accepted
      <<",\"heuristicSearchCalls\":0,\"proposalAuthority\":\"external-policy\",\"decoder\":\""
      <<(boundedMoves?"model tanh latent decoded inside current spacing/frame translation bounds with moving-ray ports":neuralPerimeterPorts?"model card translations and boundary-perimeter endpoint offsets":pairActions?"model-selected card pair; exact center swap with ray ports":movingRayPorts?"model component translation; reattach moving endpoints to fixed opposite ports":neighborMoves?"model translation of a card and its nearest rectangle neighbor; all ports attached":globalScale?(attachAllPorts?"model log scales about physical bounds; rigid Leaf translation and attached boundary ports":"model log scales about current physical bounds; rigid Leaf translation and center-ray ports"):portActions?"model boundary parameters on original endpoint sides; straight lines":swapSlots?"model desired point quantized to nearest card slot; atomic center swap with ray ports":attachAllPorts?"rigid component translation with every port attached":attachedRepresentatives?"rigid translation, attached overview ports, center-ray other ports":"rigid component translation plus center-ray incident ports")<<"\"}\n";
  }
};
std::vector<std::vector<int>> mapping(const std::string& file,const std::vector<std::string>& outer,const std::vector<std::string>& inner) {
  std::unordered_map<std::string,int> o,i;for(int n=0;n<int(outer.size());n++)o[outer[n]]=n;for(int n=0;n<int(inner.size());n++)i[inner[n]]=n;
  std::vector<std::vector<int>> rows(outer.size());std::ifstream input(file);std::string line;if(!input)throw std::runtime_error("missing mapping");
  while(std::getline(input,line)){auto fields=split(line);auto& row=rows.at(o.at(fields[0]));if(!row.empty())throw std::runtime_error("duplicate mapping");for(size_t k=1;k<fields.size();k++)row.push_back(i.at(fields[k]));}
  for(const auto& row:rows)if(row.empty())throw std::runtime_error("empty mapping");return rows;
}
ComponentEnvironment load(const std::string& dir) {
  State a=loadView(dir,""),b=loadView(dir,"individual.");std::vector<std::string> an,bn,ae,be;
  for(auto n:a.nodes)an.push_back(n.id);for(auto n:b.nodes)bn.push_back(n.id);for(auto e:a.edges)ae.push_back(e.id);for(auto e:b.edges)be.push_back(e.id);
  auto ns=mapping(dir+"/components.tsv",an,bn),es=mapping(dir+"/groups.tsv",ae,be);return ComponentEnvironment(a,b,ns,es);
}
}
