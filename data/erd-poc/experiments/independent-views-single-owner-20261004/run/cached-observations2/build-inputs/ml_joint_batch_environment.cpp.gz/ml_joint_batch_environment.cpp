// Exact, non-searching validator for a complete batch of neural translations.
// Every batch is decoded from the same source; only model outputs move cards.
#define ERD_COMPONENT_HELPERS_ONLY
#include "ml_component_environment.cpp"
#include "exact_component_observation_costs_v2.h"

namespace {
struct BatchResult {bool legal=false;const char* reason="frame";long visual=0,individual=0,hard=0,individualHard=0,spacing=0;};
// Exact delta scoring against an immutable source. This only measures the
// already decoded model output; it cannot propose or change any coordinates.
struct ExactSparseScore {
  State source;
  Score baseline;
  long baselineHard;
  explicit ExactSparseScore(const State& state)
    :source(state),baseline(state.full()),baselineHard(policyHardScore(state)) {}
  NodeCost measure(State& candidate) {
    if(candidate.nodes.size()!=source.nodes.size()||candidate.edges.size()!=source.edges.size())
      throw std::runtime_error("sparse score topology size mismatch");
    std::vector<int> nodes,edges;
    for(int n=0;n<int(source.nodes.size());n++)
      if(source.pos[n].x!=candidate.pos[n].x||source.pos[n].y!=candidate.pos[n].y)nodes.push_back(n);
    ComponentEnvironment::mark(source,nodes,{},true);
    ComponentEnvironment::mark(candidate,nodes,{},true);
    for(int e=0;e<int(source.edges.size());e++) {
      const auto old=source.edges[e],now=candidate.edges[e];
      const auto before=source.routes[e],after=candidate.routes[e];
      // Include endpoint-identity changes, indirectly pooled ports and moved
      // incident cards even when the line itself happens to stay unchanged.
      if(old.s!=now.s||old.t!=now.t||source.moved[old.s]||source.moved[old.t]
         ||source.moved[now.s]||source.moved[now.t]
         ||before.a.x!=after.a.x||before.a.y!=after.a.y
         ||before.b.x!=after.b.x||before.b.y!=after.b.y)edges.push_back(e);
    }
    ComponentEnvironment::mark(source,{},edges,true);
    ComponentEnvironment::mark(candidate,{},edges,true);
    const auto before=ComponentEnvironment::cost(source,nodes,edges);
    const auto after=ComponentEnvironment::cost(candidate,nodes,edges);
    ComponentEnvironment::mark(source,nodes,edges,false);
    ComponentEnvironment::mark(candidate,nodes,edges,false);
    return {baseline+after.score-before.score,baselineHard+after.hard-before.hard};
  }
};
struct ExactSparseBatchScore {
  ExactSparseScore a,b;
  explicit ExactSparseBatchScore(const ComponentEnvironment& source):a(source.a),b(source.b) {}
};
void writeBatchNodes(ComponentEnvironment& state) {
  const ExactComponentObservationCosts cache(state);std::cout<<'[';
  for(int n=0;n<int(state.components.size());n++) {
    double scale;const auto f=state.features(n,scale,&cache.physical[n],&cache.individual[n]);
    if(verifyObservationCache) {
      double legacyScale;const auto legacy=state.features(n,legacyScale);
      if(f!=legacy||scale!=legacyScale)throw std::runtime_error("cached observation differs from legacy features");
      observationCacheParityRows++;
    }
    if(n)std::cout<<',';std::cout<<"{\"id\":"<<n<<",\"features\":";array(std::cout,f);std::cout<<'}';
  }
  std::cout<<']';
}
Point perimeterPoint(double phase,double w,double h) {
  double t=phase-std::floor(phase);t*=2*(w+h);
  if(t<w)return {t-w/2,-h/2};
  if(t<w+h)return {w/2,t-w-h/2};
  if(t<2*w+h)return {w/2-(t-w-h),h/2};
  return {-w/2,h/2-(t-2*w-h)};
}
Point perimeterShift(Point original,Point center,double w,double h,double action) {
  if(!std::isfinite(action)||std::abs(action)>.500000001)throw std::runtime_error("invalid neural perimeter offset");
  const double x=original.x-center.x,y=original.y-center.y;
  const double distances[]={std::abs(y+h/2),std::abs(x-w/2),std::abs(y-h/2),std::abs(x+w/2)};
  const double phases[]={x+w/2,w+y+h/2,w+h+w/2-x,2*w+h+h/2-y};
  int side=0;for(int k=1;k<4;k++)if(distances[k]<distances[side])side=k;
  const double phase=phases[side]/(2*(w+h));
  const auto before=perimeterPoint(phase,w,h),after=perimeterPoint(phase+action,w,h);
  return {original.x+(after.x-before.x),original.y+(after.y-before.y)};
}
BatchResult evaluateBatch(const ComponentEnvironment& source,const std::vector<Point>& delta,ComponentEnvironment& candidate,
                          const std::vector<Point>& perimeter={},ExactSparseBatchScore* sparse=nullptr) {
  if(delta.size()!=source.components.size())throw std::runtime_error("batch size mismatch");
  if(source.neuralPerimeterPorts&&perimeter.size()!=source.b.edges.size())throw std::runtime_error("perimeter batch size mismatch");
  candidate=source;BatchResult result;
  for(int n=0;n<int(delta.size());n++) {
    if(!std::isfinite(delta[n].x)||!std::isfinite(delta[n].y))throw std::runtime_error("nonfinite neural translation");
    const Point d{rounded(delta[n].x),rounded(delta[n].y)};
    auto& p=candidate.a.pos[n];p.x+=d.x;p.y+=d.y;
    const auto size=candidate.a.nodes[n];
    if(p.x-size.w/2<source.left-1e-7||p.x+size.w/2>source.right+1e-7
       ||p.y-size.h/2<source.top-1e-7||p.y+size.h/2>source.bottom+1e-7)return result;
    for(int member:candidate.components[n]){candidate.b.pos[member].x+=d.x;candidate.b.pos[member].y+=d.y;}
  }
  // Fixed decoder, with no repair or alternative endpoint search.
  if(source.attachAllPorts||source.neuralPerimeterPorts) {
    for(int e=0;e<int(source.b.edges.size());e++) {
      const auto endpoints=source.b.edges[e];auto original=source.b.routes[e];
      if(source.neuralPerimeterPorts) {
        const auto s=source.b.nodes[endpoints.s],t=source.b.nodes[endpoints.t];
        original.a=perimeterShift(original.a,source.b.pos[endpoints.s],s.w,s.h,perimeter[e].x);
        original.b=perimeterShift(original.b,source.b.pos[endpoints.t],t.w,t.h,perimeter[e].y);
      }
      const auto ds=delta[source.owner[endpoints.s]],dt=delta[source.owner[endpoints.t]];
      candidate.b.routes[e]=segment({rounded(original.a.x+rounded(ds.x)),rounded(original.a.y+rounded(ds.y))},
                                    {rounded(original.b.x+rounded(dt.x)),rounded(original.b.y+rounded(dt.y))});
    }
  }else candidate.b.allRoutes();
  for(int g=0;g<int(candidate.groups.size());g++)if(!candidate.project(g)){result.reason="projection";return result;}
  const auto ca=sparse?sparse->a.measure(candidate.a):NodeCost{candidate.a.full(),0};
  const auto cb=sparse?sparse->b.measure(candidate.b):NodeCost{candidate.b.full(),0};
  const auto a=ca.score,b=cb.score;
  result.visual=candidate.visual=a.visual();result.individual=candidate.individualVisual=b.visual();
  result.spacing=a.spacing+b.spacing;
  if(a.spacing||b.spacing||a.overlap||b.overlap){result.reason="spacing";return result;}
  result.hard=sparse?ca.hard:policyHardScore(candidate.a);
  result.individualHard=sparse?cb.hard:policyHardScore(candidate.b);
  if(result.hard>source.initialHard||result.individualHard>source.initialIndividualHard){result.reason="hard";return result;}
  result.legal=true;result.reason="legal";return result;
}

}
int main(int argc,char** argv) {
  try {
    auto source=load(arg(argc,argv,"--directory"));source.overviewOnly=arg(argc,argv,"--overview-only","0")=="1";
    source.attachAllPorts=arg(argc,argv,"--attached-ports","0")=="1";
    source.neuralPerimeterPorts=arg(argc,argv,"--neural-perimeter-ports","0")=="1";
    source.temporaryRegressionBudget=std::stol(arg(argc,argv,"--regression-limit","0"));
    if(source.temporaryRegressionBudget<0||source.temporaryRegressionBudget>200)throw std::runtime_error("invalid temporary batch regression limit");
    const bool sparseEnabled=arg(argc,argv,"--sparse-scoring","0")=="1";
    std::unique_ptr<ExactSparseBatchScore> sparse;
    if(sparseEnabled)sparse=std::make_unique<ExactSparseBatchScore>(source);
    auto best=source;long attempts=0,accepted=0;
    std::cout<<std::setprecision(12)<<"{\"ready\":true,\"visual\":"<<source.visual<<",\"individualVisual\":"<<source.individualVisual<<",\"nodes\":";
    verifyObservationCache=arg(argc,argv,"--verify-observation-cache","0")=="1";
    writeBatchNodes(source);std::cout<<'}'<<std::endl;
    std::string line;
    while(std::getline(std::cin,line)) {
      std::istringstream command(line);std::string op;command>>op;
      if(op=="TRY"||op=="MEASURE"||op=="OBS") {
        const bool measureOnly=op=="MEASURE";
        std::vector<Point> delta(source.components.size());
        for(auto& d:delta)if(!(command>>d.x>>d.y))throw std::runtime_error("incomplete neural batch");
        std::vector<Point> perimeter;
        if(source.neuralPerimeterPorts) {
          perimeter.resize(source.b.edges.size());
          for(auto& p:perimeter)if(!(command>>p.x>>p.y))throw std::runtime_error("incomplete neural perimeter batch");
        }
        std::string extra;if(command>>extra)throw std::runtime_error("extra neural batch coordinates");
        auto candidate=source;const auto r=evaluateBatch(source,delta,candidate,perimeter,sparse.get());
        // Observe exactly this supplied geometry without committing it, changing
        // the source, incrementing action counters or selecting alternatives.
        if(op=="OBS") {
          std::cout<<"{\"observed\":"<<(r.legal?"true":"false")<<",\"visual\":"<<r.visual
            <<",\"individualVisual\":"<<r.individual<<",\"reason\":\""<<r.reason<<'"';
          if(r.legal){std::cout<<",\"nodes\":";writeBatchNodes(candidate);}
          std::cout<<'}'<<std::endl;continue;
        }
        if(!measureOnly)attempts++;
        const long ceiling=accepted?best.visual:source.visual+source.temporaryRegressionBudget;
        const long individualCeiling=accepted?best.individualVisual:source.individualVisual+source.temporaryRegressionBudget;
        const bool improve=!measureOnly&&r.legal&&r.visual<ceiling&&(source.overviewOnly||r.individual<=individualCeiling);
        if(improve){best=std::move(candidate);accepted++;}
        std::cout<<"{\"accepted\":"<<(improve?"true":"false")<<",\"legal\":"<<(r.legal?"true":"false")<<",\"visual\":"<<r.visual
          <<",\"measureOnly\":"<<(measureOnly?"true":"false")
          <<",\"individualVisual\":"<<r.individual<<",\"spacing\":"<<r.spacing<<",\"hard\":"<<r.hard<<",\"individualHard\":"<<r.individualHard
          <<",\"reason\":\""<<r.reason<<"\"}"<<std::endl;
      }else if(op=="SAVE") {
        best.attempts=attempts;best.accepted=accepted;best.save(arg(argc,argv,"--out"));std::cout<<"{\"saved\":true}"<<std::endl;
      }else if(op=="QUIT"){if(verifyObservationCache)std::cerr<<"observation-cache-parity-rows="<<observationCacheParityRows<<"\n";return 0;}
      else throw std::runtime_error("unknown neural batch command");
    }
  }catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 2;}
}
