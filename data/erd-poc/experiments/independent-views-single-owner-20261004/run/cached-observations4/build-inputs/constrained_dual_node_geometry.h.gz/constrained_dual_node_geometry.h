#pragma once
// Shared geometry and delta tests only; no proposal/search entrypoint.
// Bounded translation of ordinary cards with attached straight boundary ports.
// Both rendered presentations must improve or remain equal at every step.
#include "constrained_scene.h"
#include "constrained_boundary_sweep.h"
#include <set>
#include <sstream>

namespace {
State loadView(const std::string& directory,const std::string& prefix) {
  State s;std::unordered_map<std::string,int> nodes,edges;std::string line;
  std::ifstream ns(directory+"/"+prefix+"nodes.tsv");if(!ns)throw std::runtime_error("missing nodes");
  while(std::getline(ns,line)) {
    const auto v=split(line);if(v.size()!=3||nodes.count(v[0]))throw std::runtime_error("invalid node");
    nodes[v[0]]=s.nodes.size();s.nodes.push_back({v[0],std::stod(v[1]),std::stod(v[2])});
  }
  s.pos.resize(s.nodes.size());s.incident.resize(s.nodes.size());s.adj.resize(s.nodes.size());s.moved.resize(s.nodes.size());
  std::set<int> present;std::ifstream ps(directory+"/"+prefix+"positions.tsv");
  if(!ps)throw std::runtime_error("missing positions");
  while(std::getline(ps,line)) {
    const auto v=split(line);if(v.size()!=3||!nodes.count(v[0])||!present.insert(nodes.at(v[0])).second)
      throw std::runtime_error("invalid position");
    s.pos[nodes.at(v[0])]={std::stod(v[1]),std::stod(v[2])};
  }
  if(present.size()!=s.nodes.size()||s.nodes.empty())throw std::runtime_error("missing position");
  std::ifstream es(directory+"/"+prefix+"edges.tsv");if(!es)throw std::runtime_error("missing edges");
  while(std::getline(es,line)) {
    const auto v=split(line);if(v.size()!=3||edges.count(v[0])||!nodes.count(v[1])||!nodes.count(v[2]))
      throw std::runtime_error("invalid edge");
    const int a=nodes.at(v[1]),b=nodes.at(v[2]),e=s.edges.size();if(a==b)throw std::runtime_error("self edge");
    edges[v[0]]=e;s.edges.push_back({v[0],a,b});s.incident[a].push_back(e);s.incident[b].push_back(e);
  }
  s.routes.resize(s.edges.size());s.changedEdge.resize(s.edges.size());present.clear();
  std::ifstream rs(directory+"/"+prefix+"routes.tsv");if(!rs)throw std::runtime_error("missing routes");
  while(std::getline(rs,line)) {
    const auto v=split(line);if(v.size()!=2||!edges.count(v[0])||!present.insert(edges.at(v[0])).second)
      throw std::runtime_error("invalid route");
    std::string text=v[1];std::replace(text.begin(),text.end(),',',' ');std::istringstream points(text);Point a,b;std::string extra;
    if(!(points>>a.x>>a.y>>b.x>>b.y)||(points>>extra))throw std::runtime_error("route is not straight");
    s.routes[edges.at(v[0])]=segment(a,b);
  }
  if(present.size()!=s.edges.size())throw std::runtime_error("missing route");
  return s;
}
long hardScore(const State& s) {
  long result=0;for(int e=0;e<int(s.edges.size());e++)result+=boundaryEdgeCost(s,e,s.routes[e]).hard;return result;
}
struct NodeCost {Score score;long hard=0;};
}
