// Search every constant-cost interval of a rectangular boundary on the saved
// 0.01 coordinate grid. The other endpoint and all other routes stay fixed.
// This is a local straight-port proposal, not a global layout optimum.
#pragma once
#include <array>

namespace {
struct BoundaryCost {
  long cross=0,hit=0,hard=0;
  long visual()const{return cross+hit;}
};
BoundaryCost operator+(BoundaryCost a,BoundaryCost b){return {a.cross+b.cross,a.hit+b.hit,a.hard+b.hard};}
BoundaryCost operator-(BoundaryCost a,BoundaryCost b){return {a.cross-b.cross,a.hit-b.hit,a.hard-b.hard};}
bool boundaryBetter(BoundaryCost a,BoundaryCost b){
  if(a.hard!=b.hard)return a.hard<b.hard;
  if(a.visual()!=b.visual())return a.visual()<b.visual();
  return a.hit<b.hit;
}
bool boundaryEqual(BoundaryCost a,BoundaryCost b){return a.cross==b.cross&&a.hit==b.hit&&a.hard==b.hard;}
bool boundarySame(Point a,Point b){return std::abs(a.x-b.x)<.001&&std::abs(a.y-b.y)<.001;}
// Match the product's independent-view endpoint contract exactly. Merely
// missing the rectangle shrunk by .02 can still cut inward near a corner.
bool outwardBoundary(const State& s,int node,Point p,Point peer){
  const auto center=s.pos[node];const auto size=s.nodes[node];constexpr double eps=.011;
  const double l=center.x-size.w/2,r=center.x+size.w/2,t=center.y-size.h/2,b=center.y+size.h/2;
  return std::isfinite(p.x)&&std::isfinite(p.y)&&p.x>=l-eps&&p.x<=r+eps&&p.y>=t-eps&&p.y<=b+eps
    &&std::hypot(p.x-peer.x,p.y-peer.y)>eps
    &&((std::abs(p.x-l)<=eps&&peer.x<=p.x+eps)||(std::abs(p.x-r)<=eps&&peer.x>=p.x-eps)
      ||(std::abs(p.y-t)<=eps&&peer.y<=p.y+eps)||(std::abs(p.y-b)<=eps&&peer.y>=p.y-eps));
}
bool boundaryOn(Point p,const Segment& l){return std::abs(orient(l.a,l.b,p))<1e-5
  &&p.x>=l.l-1e-6&&p.x<=l.r+1e-6&&p.y>=l.t-1e-6&&p.y<=l.bottom+1e-6;}
bool boundaryContact(const State& s,int e,const Segment& a,int f,const Segment& b){
  if(a.l>b.r+1e-6||b.l>a.r+1e-6||a.t>b.bottom+1e-6||b.t>a.bottom+1e-6)return false;
  const auto u=s.edges[e],v=s.edges[f];
  const auto allowed=[&](Point p){return
    (u.s==v.s&&boundarySame(a.a,b.a)&&boundarySame(p,a.a))||
    (u.s==v.t&&boundarySame(a.a,b.b)&&boundarySame(p,a.a))||
    (u.t==v.s&&boundarySame(a.b,b.a)&&boundarySame(p,a.b))||
    (u.t==v.t&&boundarySame(a.b,b.b)&&boundarySame(p,a.b));};
  return (!allowed(a.a)&&boundaryOn(a.a,b))||(!allowed(a.b)&&boundaryOn(a.b,b))||
    (!allowed(b.a)&&boundaryOn(b.a,a))||(!allowed(b.b)&&boundaryOn(b.b,a));
}
BoundaryCost boundaryEdgeCost(const State& s,int e,const Segment& line){
  BoundaryCost c;const auto edge=s.edges[e];
  for(int f=0;f<int(s.edges.size());f++)if(e!=f){
    const auto other=s.edges[f];const bool adjacent=edge.s==other.s||edge.s==other.t||edge.t==other.s||edge.t==other.t;
    const bool crossing=crosses(line,s.routes[f]);c.cross+=crossing;
    c.hard+=crossing&&adjacent;c.hard+=boundaryContact(s,e,line,f,s.routes[f]);
  }
  for(int n=0;n<int(s.nodes.size());n++){
    const bool own=n==edge.s||n==edge.t;
    const bool hit=hits(line,s.pos[n],s.nodes[n],own?-.02:10);
    if(own)c.hard+=hit;else c.hit+=hit;
  }return c;
}
}
