"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.resolveOgdfLayoutBinaryPath = resolveOgdfLayoutBinaryPath;
const promises_1 = require("node:fs/promises");
const node_path_1 = __importDefault(require("node:path"));
async function resolveOgdfLayoutBinaryPath(extensionRootPath) {
    const envOverride = process.env.DJANGO_ERD_OGDF_LAYOUT_BIN;
    const platformKey = `${process.platform}-${process.arch}`;
    const candidatePaths = [
        envOverride,
        node_path_1.default.join(extensionRootPath, "bin", "ogdf", platformKey, ogdfLayoutBinaryName()),
        node_path_1.default.join(extensionRootPath, "native", "ogdf", platformKey, ogdfLayoutBinaryName()),
    ].filter((value) => Boolean(value));
    for (const candidatePath of candidatePaths) {
        if (await pathExists(candidatePath)) {
            return candidatePath;
        }
    }
    return undefined;
}
function ogdfLayoutBinaryName() {
    return process.platform === "win32"
        ? "django-erd-ogdf-layout.exe"
        : "django-erd-ogdf-layout";
}
async function pathExists(filePath) {
    try {
        await (0, promises_1.access)(filePath);
        return true;
    }
    catch {
        return false;
    }
}
