"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.readArray = readArray;
exports.readBoolean = readBoolean;
exports.readLiteral = readLiteral;
exports.readModelId = readModelId;
exports.readNumber = readNumber;
exports.readOptionalBoolean = readOptionalBoolean;
exports.readOptionalModelId = readOptionalModelId;
exports.readOptionalNumber = readOptionalNumber;
exports.readOptionalObject = readOptionalObject;
exports.readOptionalString = readOptionalString;
exports.readRecord = readRecord;
exports.readString = readString;
exports.readStringArray = readStringArray;
const modelIdentity_1 = require("../domain/modelIdentity");
function readArray(record, key, context) {
    const value = record[key];
    if (!Array.isArray(value)) {
        throw new Error(`${context}.${key} must be an array.`);
    }
    return value;
}
function readBoolean(record, key, context) {
    const value = record[key];
    if (typeof value !== "boolean") {
        throw new Error(`${context}.${key} must be a boolean.`);
    }
    return value;
}
function readLiteral(record, key, allowed, context) {
    const value = readString(record, key, context);
    if (!allowed.includes(value)) {
        throw new Error(`${context}.${key} must be one of: ${allowed.join(", ")}.`);
    }
    return value;
}
function readModelId(record, key, context) {
    const value = readString(record, key, context);
    if (!(0, modelIdentity_1.isModelId)(value)) {
        throw new Error(`${context}.${key} must be a canonical model ID.`);
    }
    return value;
}
function readNumber(record, key, context) {
    const value = record[key];
    if (typeof value !== "number" || Number.isNaN(value)) {
        throw new Error(`${context}.${key} must be a number.`);
    }
    return value;
}
function readOptionalBoolean(record, key, context) {
    const value = record[key];
    if (value === undefined || value === null) {
        return undefined;
    }
    if (typeof value !== "boolean") {
        throw new Error(`${context}.${key} must be a boolean when present.`);
    }
    return value;
}
function readOptionalModelId(record, key, context) {
    const value = record[key];
    if (value === undefined || value === null) {
        return undefined;
    }
    if (typeof value !== "string" || !(0, modelIdentity_1.isModelId)(value)) {
        throw new Error(`${context}.${key} must be a canonical model ID when present.`);
    }
    return value;
}
function readOptionalNumber(record, key, context) {
    const value = record[key];
    if (value === undefined || value === null) {
        return undefined;
    }
    if (typeof value !== "number" || Number.isNaN(value)) {
        throw new Error(`${context}.${key} must be a number when present.`);
    }
    return value;
}
function readOptionalObject(record, key, context) {
    const value = record[key];
    if (value === undefined || value === null) {
        return undefined;
    }
    return readRecord(value, `${context}.${key}`);
}
function readOptionalString(record, key, context) {
    const value = record[key];
    if (value === undefined || value === null) {
        return undefined;
    }
    if (typeof value !== "string") {
        throw new Error(`${context}.${key} must be a string when present.`);
    }
    return value;
}
function readRecord(value, context) {
    if (!isRecord(value)) {
        throw new Error(`${context} must be an object.`);
    }
    return value;
}
function readString(record, key, context) {
    const value = record[key];
    if (typeof value !== "string") {
        throw new Error(`${context}.${key} must be a string.`);
    }
    return value;
}
function readStringArray(record, key, context) {
    return readArray(record, key, context).map((item, index) => {
        if (typeof item !== "string") {
            throw new Error(`${context}.${key}[${index}] must be a string.`);
        }
        return item;
    });
}
function isRecord(value) {
    return typeof value === "object" && value !== null && !Array.isArray(value);
}
