import { isModelId, makeModelId, type ModelId, type ModelIdentity } from "../domain/modelIdentity";
import type { AnalyzerDiagnostic, SourceLocation, SourceRange } from "../diagnostics/analyzerDiagnostic";
import type { DiagramGraph, GraphNode, MethodAssociation, StructuralGraphEdge } from "../graph/diagramGraph";
import {
  OGDF_LAYOUT_MODES,
  type CanonicalCrossingMetadata,
  type EdgeCrossing,
  type LayoutEngineMetadata,
  type LayoutMode,
  type LayoutSnapshot,
  type LeafBundle,
  type NodeLayout,
  type Point,
  type RenderedCarrierRoute,
  type RoutedEdgePath,
  type Size,
  type TopCrossEdge,
} from "../graph/layoutContract";
import type {
  AnalysisSummary,
  AnalyzerOutput,
  ChoiceFieldMetadata,
  ChoiceOption,
  ExtractedModel,
  FieldRelation,
  MethodRelatedModelReference,
  ModelField,
  PropertyAttribute,
  RelationTargetReference,
  UserMethod,
} from "./analyzerContract";
import { CONTRACT_VERSION, type ContractVersion } from "./contractVersion";
import {
  readArray,
  readBoolean,
  readLiteral,
  readModelId,
  readNumber,
  readOptionalBoolean,
  readOptionalNumber,
  readOptionalObject,
  readOptionalModelId,
  readOptionalString,
  readRecord,
  readString,
  readStringArray,
  type JsonRecord,
} from "./runtimeGuards";
import type { PipelineTimings } from "./pipelineTimingContract";
import type {
  DiagramViewportSnapshot,
  DiagramBootstrapPayload,
  InitialViewState,
  LayoutExecutionSnapshot,
  SelectedMethodContext,
  TableViewOptions,
} from "./webviewContract";

export function decodeDiagramBootstrapPayload(
  value: unknown,
): DiagramBootstrapPayload {
  const root = readRecord(value, "diagramBootstrapPayload");

  return {
    analyzer: decodeAnalyzerOutput(readRecord(root.analyzer, "diagramBootstrapPayload.analyzer")),
    contractVersion: decodeContractVersion(root, "contractVersion", "diagramBootstrapPayload"),
    graph: decodeGraph(readRecord(root.graph, "diagramBootstrapPayload.graph")),
    layout: decodeLayout(readRecord(root.layout, "diagramBootstrapPayload.layout"), "diagramBootstrapPayload.layout"),
    layoutExecution: decodeLayoutExecution(root),
    layoutFailures: decodeLayoutFailures(root),
    timings: decodePipelineTimings(root),
    view: decodeViewState(readRecord(root.view, "diagramBootstrapPayload.view")),
  };
}

export function decodeLayoutSnapshot(
  value: unknown,
  context = "layoutSnapshot",
): LayoutSnapshot {
  return decodeLayout(readRecord(value, context), context);
}

function decodeAnalyzerOutput(record: JsonRecord): AnalyzerOutput {
  return {
    contractVersion: decodeContractVersion(record, "contractVersion", "diagramBootstrapPayload.analyzer"),
    diagnostics: readArray(record, "diagnostics", "diagramBootstrapPayload.analyzer").map((item, index) =>
      decodeDiagnostic(item, `diagramBootstrapPayload.analyzer.diagnostics[${index}]`),
    ),
    models: readArray(record, "models", "diagramBootstrapPayload.analyzer").map((item, index) =>
      decodeExtractedModel(item, `diagramBootstrapPayload.analyzer.models[${index}]`),
    ),
    summary: decodeAnalysisSummary(
      readRecord(record.summary, "diagramBootstrapPayload.analyzer.summary"),
    ),
  };
}

function decodeAnalysisSummary(record: JsonRecord): AnalysisSummary {
  return {
    canonicalModelIdCollisionCount: readOptionalNumber(
      record,
      "canonicalModelIdCollisionCount",
      "diagramBootstrapPayload.analyzer.summary",
    ),
    diagnosticCount: readNumber(record, "diagnosticCount", "diagramBootstrapPayload.analyzer.summary"),
    discoveredAppCount: readNumber(record, "discoveredAppCount", "diagramBootstrapPayload.analyzer.summary"),
    discoveredModelCount: readNumber(record, "discoveredModelCount", "diagramBootstrapPayload.analyzer.summary"),
    workspaceRoot: readString(record, "workspaceRoot", "diagramBootstrapPayload.analyzer.summary"),
  };
}

function decodeChoiceFieldMetadata(record: JsonRecord, context: string): ChoiceFieldMetadata {
  return {
    isChoiceField: readBoolean(record, "isChoiceField", context) as true,
    isFullyResolved: readBoolean(record, "isFullyResolved", context),
    options: readArray(record, "options", context).map((item, index) =>
      decodeChoiceOption(item, `${context}.options[${index}]`),
    ),
  };
}

function decodeChoiceOption(value: unknown, context: string): ChoiceOption {
  const record = readRecord(value, context);

  return {
    label: readString(record, "label", context),
    value: readString(record, "value", context),
    valueKind: readLiteral(record, "valueKind", ["boolean", "null", "number", "string"], context),
  };
}

function decodeContractVersion(
  record: JsonRecord,
  key: string,
  context: string,
): ContractVersion {
  const value = readString(record, key, context);

  if (value !== CONTRACT_VERSION) {
    throw new Error(`${context}.${key} must equal contract version ${CONTRACT_VERSION}.`);
  }

  return value;
}

function decodeDiagnostic(value: unknown, context: string): AnalyzerDiagnostic {
  const record = readRecord(value, context);
  const locationRecord = readOptionalObject(record, "location", context);

  return {
    code: readLiteral(
      record,
      "code",
      ["partial_inference", "syntax_error", "unresolved_reference", "unsupported_construct"],
      context,
    ),
    location: locationRecord ? decodeSourceLocation(locationRecord, `${context}.location`) : undefined,
    message: readString(record, "message", context),
    relatedModelId: readOptionalModelId(record, "relatedModelId", context),
    severity: readLiteral(record, "severity", ["error", "info", "warning"], context),
  };
}

function decodeExtractedModel(value: unknown, context: string): ExtractedModel {
  const record = readRecord(value, context);

  return {
    databaseTableName: readOptionalString(record, "databaseTableName", context),
    declaredBaseClasses: readStringArray(record, "declaredBaseClasses", context),
    fields: readArray(record, "fields", context).map((item, index) =>
      decodeModelField(item, `${context}.fields[${index}]`),
    ),
    hasExplicitDatabaseTableName: readOptionalBoolean(
      record,
      "hasExplicitDatabaseTableName",
      context,
    ),
    identity: decodeModelIdentity(readRecord(record.identity, `${context}.identity`), `${context}.identity`),
    methods: readArray(record, "methods", context).map((item, index) =>
      decodeUserMethod(item, `${context}.methods[${index}]`),
    ),
    properties: readArray(record, "properties", context).map((item, index) =>
      decodePropertyAttribute(item, `${context}.properties[${index}]`),
    ),
  };
}

function decodeGraph(record: JsonRecord): DiagramGraph {
  return {
    diagnostics: readArray(record, "diagnostics", "diagramBootstrapPayload.graph").map((item, index) =>
      decodeDiagnostic(item, `diagramBootstrapPayload.graph.diagnostics[${index}]`),
    ),
    methodAssociations: readArray(record, "methodAssociations", "diagramBootstrapPayload.graph").map((item, index) =>
      decodeMethodAssociation(item, `diagramBootstrapPayload.graph.methodAssociations[${index}]`),
    ),
    nodes: readArray(record, "nodes", "diagramBootstrapPayload.graph").map((item, index) =>
      decodeGraphNode(item, `diagramBootstrapPayload.graph.nodes[${index}]`),
    ),
    structuralEdges: readArray(record, "structuralEdges", "diagramBootstrapPayload.graph").map((item, index) =>
      decodeStructuralGraphEdge(item, `diagramBootstrapPayload.graph.structuralEdges[${index}]`),
    ),
  };
}

function decodeGraphNode(value: unknown, context: string): GraphNode {
  const record = readRecord(value, context);

  return {
    appLabel: readString(record, "appLabel", context),
    modelId: readModelId(record, "modelId", context),
    modelName: readString(record, "modelName", context),
  };
}

function decodeFieldRelation(record: JsonRecord, context: string): FieldRelation {
  return {
    kind: readLiteral(
      record,
      "kind",
      [
        "foreign_key",
        "many_to_many",
        "one_to_one",
        "reverse_foreign_key",
        "reverse_many_to_many",
        "reverse_one_to_one",
      ],
      context,
    ),
    reverseAccessorName: readOptionalString(record, "reverseAccessorName", context),
    target: decodeRelationTargetReference(
      readRecord(record.target, `${context}.target`),
      `${context}.target`,
    ),
    throughModelId: readOptionalModelId(record, "throughModelId", context),
  };
}

function decodeLayout(record: JsonRecord, context: string): LayoutSnapshot {
  const layout: LayoutSnapshot = {
    crossings: readArray(record, "crossings", context).map((item, index) =>
      decodeEdgeCrossing(item, `${context}.crossings[${index}]`),
    ),
    engineMetadata: decodeLayoutEngineMetadata(record, context),
    mode: readLiteral(record, "mode", OGDF_LAYOUT_MODES, context),
    nodes: readArray(record, "nodes", context).map((item, index) =>
      decodeNodeLayout(item, `${context}.nodes[${index}]`),
    ),
    routedEdges: readArray(record, "routedEdges", context).map((item, index) =>
      decodeRoutedEdgePath(item, `${context}.routedEdges[${index}]`),
    ),
  };
  const individual = readOptionalObject(record, "individualView", context);
  if (individual) {
    const viewContext = `${context}.individualView`;
    const nodes = readArray(individual, "nodes", viewContext).map((item, index) =>
      decodeNodeLayout(item, `${viewContext}.nodes[${index}]`));
    const routedEdges = readArray(individual, "routedEdges", viewContext).map((item, index) =>
      decodeRoutedEdgePath(item, `${viewContext}.routedEdges[${index}]`));
    const originalNodes = new Map(layout.nodes.map(node => [node.modelId, node]));
    const originalEdges = new Map(layout.routedEdges.map(edge => [edge.edgeId, edge]));
    if (nodes.length !== originalNodes.size || new Set(nodes.map(node => node.modelId)).size !== nodes.length
      || routedEdges.length !== originalEdges.size || new Set(routedEdges.map(edge => edge.edgeId)).size !== routedEdges.length) {
      throw new Error(`${viewContext} must preserve every node and route exactly once.`);
    }
    for (const node of nodes) {
      const original = originalNodes.get(node.modelId);
      if (!original || node.size.width !== original.size.width || node.size.height !== original.size.height
        || node.clusterId !== original.clusterId) {
        throw new Error(`${viewContext} must preserve node identity, dimensions and membership.`);
      }
    }
    for (const edge of routedEdges) {
      const original = originalEdges.get(edge.edgeId);
      if (!original || edge.sourceModelId !== original.sourceModelId || edge.targetModelId !== original.targetModelId
        || edge.points.length !== 2) {
        throw new Error(`${viewContext} must preserve straight relationship routes.`);
      }
    }
    layout.individualView = { nodes, routedEdges };
  }
  return layout;
}

function decodeLayoutEngineMetadata(
  record: JsonRecord,
  context: string,
): LayoutEngineMetadata | undefined {
  const metadata = readOptionalObject(record, "engineMetadata", context);
  if (!metadata) {
    return undefined;
  }

  return {
    relationshipPresentation: metadata.relationshipPresentation === "june-bundled"
      ? "june-bundled"
      : undefined,
    actualAlgorithm: readOptionalString(metadata, "actualAlgorithm", `${context}.engineMetadata`),
    actualMode: readOptionalLayoutMode(metadata, "actualMode", `${context}.engineMetadata`),
    aspectRatio: readOptionalNumber(metadata, "aspectRatio", `${context}.engineMetadata`),
    boundingBoxArea: readOptionalNumber(metadata, "boundingBoxArea", `${context}.engineMetadata`),
    bundleBundleOverlaps: readOptionalNumber(metadata, "bundleBundleOverlaps", `${context}.engineMetadata`),
    bundleEdgeIntersections: readOptionalNumber(metadata, "bundleEdgeIntersections", `${context}.engineMetadata`),
    bundleNodeOverlaps: readOptionalNumber(metadata, "bundleNodeOverlaps", `${context}.engineMetadata`),
    canonicalCrossing: decodeCanonicalCrossing(metadata, `${context}.engineMetadata`),
    carrierBundleEdgeIntersections: readOptionalNumber(metadata, "carrierBundleEdgeIntersections", `${context}.engineMetadata`),
    carrierBundleNodeOverlaps: readOptionalNumber(metadata, "carrierBundleNodeOverlaps", `${context}.engineMetadata`),
    carrierEdgeCrossings: readOptionalNumber(metadata, "carrierEdgeCrossings", `${context}.engineMetadata`),
    carrierEdgeNodeIntersections: readOptionalNumber(metadata, "carrierEdgeNodeIntersections", `${context}.engineMetadata`),
    carrierNodeOverlaps: readOptionalNumber(metadata, "carrierNodeOverlaps", `${context}.engineMetadata`),
    carrierRouteSegments: readOptionalNumber(metadata, "carrierRouteSegments", `${context}.engineMetadata`),
    carrierVisualCrossings: readOptionalNumber(metadata, "carrierVisualCrossings", `${context}.engineMetadata`),
    edgeCrossings: readOptionalNumber(metadata, "edgeCrossings", `${context}.engineMetadata`),
    edgeLengthStddev: readOptionalNumber(metadata, "edgeLengthStddev", `${context}.engineMetadata`),
    edgeNodeIntersections: readOptionalNumber(metadata, "edgeNodeIntersections", `${context}.engineMetadata`),
    edgeSegmentOverlaps: readOptionalNumber(metadata, "edgeSegmentOverlaps", `${context}.engineMetadata`),
    hubCarrierClusters: readOptionalNumber(metadata, "hubCarrierClusters", `${context}.engineMetadata`),
    hubCarrierEdgesGrouped: readOptionalNumber(metadata, "hubCarrierEdgesGrouped", `${context}.engineMetadata`),
    hubCarrierThreshold: readOptionalNumber(metadata, "hubCarrierThreshold", `${context}.engineMetadata`),
    inheritanceCarrierGrouping: readOptionalBoolean(
      metadata,
      "inheritanceCarrierGrouping",
      `${context}.engineMetadata`,
    ),
    intraClusterCarrierGrouping: readOptionalBoolean(
      metadata,
      "intraClusterCarrierGrouping",
      `${context}.engineMetadata`,
    ),
    leafBundles: decodeLeafBundles(metadata, `${context}.engineMetadata`),
    meanEdgeLength: readOptionalNumber(metadata, "meanEdgeLength", `${context}.engineMetadata`),
    nodeClearanceMin: readOptionalNumber(metadata, "nodeClearanceMin", `${context}.engineMetadata`),
    nodeClearanceTarget: readOptionalNumber(metadata, "nodeClearanceTarget", `${context}.engineMetadata`),
    nodeOverlaps: readOptionalNumber(metadata, "nodeOverlaps", `${context}.engineMetadata`),
    nodeSpacingOverlaps: readOptionalNumber(metadata, "nodeSpacingOverlaps", `${context}.engineMetadata`),
    overlappingEdges: readOptionalNumber(metadata, "overlappingEdges", `${context}.engineMetadata`),
    rawRouteCrossings: readOptionalNumber(metadata, "rawRouteCrossings", `${context}.engineMetadata`),
    renderedCarrierRoutes: decodeRenderedCarrierRoutes(
      metadata,
      `${context}.engineMetadata`,
    ),
    renderedEdgeCount: readOptionalNumber(metadata, "renderedEdgeCount", `${context}.engineMetadata`),
    requestedAlgorithm: readOptionalString(metadata, "requestedAlgorithm", `${context}.engineMetadata`),
    requestedMode: readOptionalLayoutMode(metadata, "requestedMode", `${context}.engineMetadata`),
    routeSegments: readOptionalNumber(metadata, "routeSegments", `${context}.engineMetadata`),
    semanticCarrierBundledRelationships: readOptionalNumber(metadata, "semanticCarrierBundledRelationships", `${context}.engineMetadata`),
    semanticCarrierBundleGroups: readOptionalNumber(metadata, "semanticCarrierBundleGroups", `${context}.engineMetadata`),
    semanticCarrierCoincidentRelationships: readOptionalNumber(metadata, "semanticCarrierCoincidentRelationships", `${context}.engineMetadata`),
    semanticCarrierCrossingsAvoided: readOptionalNumber(metadata, "semanticCarrierCrossingsAvoided", `${context}.engineMetadata`),
    semanticCarrierDisconnectedRelationships: readOptionalNumber(metadata, "semanticCarrierDisconnectedRelationships", `${context}.engineMetadata`),
    semanticCarrierEligibleRelationships: readOptionalNumber(metadata, "semanticCarrierEligibleRelationships", `${context}.engineMetadata`),
    semanticCarrierFallbackRelationships: readOptionalNumber(metadata, "semanticCarrierFallbackRelationships", `${context}.engineMetadata`),
    semanticCarrierMissingRelationships: readOptionalNumber(metadata, "semanticCarrierMissingRelationships", `${context}.engineMetadata`),
    semanticCarrierObstacleIntersections: readOptionalNumber(metadata, "semanticCarrierObstacleIntersections", `${context}.engineMetadata`),
    semanticCarrierObstacleIntersectionsAvoided: readOptionalNumber(metadata, "semanticCarrierObstacleIntersectionsAvoided", `${context}.engineMetadata`),
    semanticCarrierRelationships: readOptionalNumber(metadata, "semanticCarrierRelationships", `${context}.engineMetadata`),
    semanticCarrierSegments: readOptionalNumber(metadata, "semanticCarrierSegments", `${context}.engineMetadata`),
    semanticCarrierSelfRelationships: readOptionalNumber(metadata, "semanticCarrierSelfRelationships", `${context}.engineMetadata`),
    strategy: readOptionalString(metadata, "strategy", `${context}.engineMetadata`),
    strategyReason: readOptionalString(metadata, "strategyReason", `${context}.engineMetadata`),
    visualCrossings: readOptionalNumber(metadata, "visualCrossings", `${context}.engineMetadata`),
    visualCrossingsScope: readOptionalString(metadata, "visualCrossingsScope", `${context}.engineMetadata`),
    stressScore: readOptionalNumber(metadata, "stressScore", `${context}.engineMetadata`),
    edgeLengthCv: readOptionalNumber(metadata, "edgeLengthCv", `${context}.engineMetadata`),
    crossingAngleMean: readOptionalNumber(metadata, "crossingAngleMean", `${context}.engineMetadata`),
    crossingAngleCv: readOptionalNumber(metadata, "crossingAngleCv", `${context}.engineMetadata`),
    edgeBendTotal: readOptionalNumber(metadata, "edgeBendTotal", `${context}.engineMetadata`),
    hubClearanceP10: readOptionalNumber(metadata, "hubClearanceP10", `${context}.engineMetadata`),
    clusterCompactnessMean: readOptionalNumber(metadata, "clusterCompactnessMean", `${context}.engineMetadata`),
    crossingsPerEdgeP50: readOptionalNumber(metadata, "crossingsPerEdgeP50", `${context}.engineMetadata`),
    crossingsPerEdgeP90: readOptionalNumber(metadata, "crossingsPerEdgeP90", `${context}.engineMetadata`),
    cleanEdgeRatio: readOptionalNumber(metadata, "cleanEdgeRatio", `${context}.engineMetadata`),
    edgeCrossingsBetweenClusters: readOptionalNumber(metadata, "edgeCrossingsBetweenClusters", `${context}.engineMetadata`),
    nodeAreaCoverage: readOptionalNumber(metadata, "nodeAreaCoverage", `${context}.engineMetadata`),
    emptySpaceCv: readOptionalNumber(metadata, "emptySpaceCv", `${context}.engineMetadata`),
    compositeQuality: readOptionalNumber(metadata, "compositeQuality", `${context}.engineMetadata`),
    subCleanQuality: readOptionalNumber(metadata, "subCleanQuality", `${context}.engineMetadata`),
    subSeverityQuality: readOptionalNumber(metadata, "subSeverityQuality", `${context}.engineMetadata`),
    subAngleQuality: readOptionalNumber(metadata, "subAngleQuality", `${context}.engineMetadata`),
    subStressQuality: readOptionalNumber(metadata, "subStressQuality", `${context}.engineMetadata`),
    subCompactQuality: readOptionalNumber(metadata, "subCompactQuality", `${context}.engineMetadata`),
    subUniformQuality: readOptionalNumber(metadata, "subUniformQuality", `${context}.engineMetadata`),
    subSpreadQuality: readOptionalNumber(metadata, "subSpreadQuality", `${context}.engineMetadata`),
    topCrossEdges: decodeTopCrossEdges(metadata, `${context}.engineMetadata`),
    clusterByModelId: decodeClusterByModelId(metadata, `${context}.engineMetadata`),
  };
}

function decodeRenderedCarrierRoutes(
  record: JsonRecord,
  context: string,
): RenderedCarrierRoute[] | undefined {
  if (record.renderedCarrierRoutes === undefined) {
    return undefined;
  }
  return readArray(record, "renderedCarrierRoutes", context).map((item, index) => {
    const routeContext = `${context}.renderedCarrierRoutes[${index}]`;
    const route = readRecord(item, routeContext);
    const carrierId = readString(route, "carrierId", routeContext);
    const memberEdgeIds = readStringArray(route, "memberEdgeIds", routeContext);
    const points = readArray(route, "points", routeContext).map((point, pointIndex) =>
      decodePoint(
        readRecord(point, `${routeContext}.points[${pointIndex}]`),
        `${routeContext}.points[${pointIndex}]`,
      ),
    );
    if (carrierId.length === 0 || memberEdgeIds.length < 1 || points.length < 2) {
      throw new Error(
        `${routeContext} must contain a carrierId, at least one member, and at least two points.`,
      );
    }
    return { carrierId, memberEdgeIds, points };
  });
}

function decodeCanonicalCrossing(
  record: JsonRecord,
  context: string,
): CanonicalCrossingMetadata | undefined {
  const canonicalCrossing = readOptionalObject(
    record,
    "canonicalCrossing",
    context,
  );
  if (!canonicalCrossing) {
    return undefined;
  }

  const canonicalContext = `${context}.canonicalCrossing`;
  return {
    adjacentEdgeIntersections: readOptionalNumber(
      canonicalCrossing,
      "adjacentEdgeIntersections",
      canonicalContext,
    ),
    boundViolation: readBoolean(
      canonicalCrossing,
      "boundViolation",
      canonicalContext,
    ),
    certifierVersion: readString(
      canonicalCrossing,
      "certifierVersion",
      canonicalContext,
    ),
    collinearOverlaps: readOptionalNumber(
      canonicalCrossing,
      "collinearOverlaps",
      canonicalContext,
    ),
    completeRoutes: readBoolean(
      canonicalCrossing,
      "completeRoutes",
      canonicalContext,
    ),
    degenerateSegments: readOptionalNumber(
      canonicalCrossing,
      "degenerateSegments",
      canonicalContext,
    ),
    domain: readLiteral(
      canonicalCrossing,
      "domain",
      ["canonical-simple-v1"],
      canonicalContext,
    ),
    edgeCount: readNumber(canonicalCrossing, "edgeCount", canonicalContext),
    gap: readOptionalNumber(canonicalCrossing, "gap", canonicalContext),
    invariantViolations: readOptionalNumber(
      canonicalCrossing,
      "invariantViolations",
      canonicalContext,
    ),
    k3nCertificates: readNumber(
      canonicalCrossing,
      "k3nCertificates",
      canonicalContext,
    ),
    k3nContribution: readNumber(
      canonicalCrossing,
      "k3nContribution",
      canonicalContext,
    ),
    kuratowskiCertificates: readNumber(
      canonicalCrossing,
      "kuratowskiCertificates",
      canonicalContext,
    ),
    kuratowskiContribution: readNumber(
      canonicalCrossing,
      "kuratowskiContribution",
      canonicalContext,
    ),
    lowerBound: readNumber(
      canonicalCrossing,
      "lowerBound",
      canonicalContext,
    ),
    method: readString(canonicalCrossing, "method", canonicalContext),
    nodeCount: readNumber(canonicalCrossing, "nodeCount", canonicalContext),
    nonIncidentNodeHits: readOptionalNumber(
      canonicalCrossing,
      "nonIncidentNodeHits",
      canonicalContext,
    ),
    nonProperContacts: readNumber(
      canonicalCrossing,
      "nonProperContacts",
      canonicalContext,
    ),
    pointContacts: readOptionalNumber(
      canonicalCrossing,
      "pointContacts",
      canonicalContext,
    ),
    optimality: readOptionalNumber(
      canonicalCrossing,
      "optimality",
      canonicalContext,
    ),
    properDrawing: readBoolean(
      canonicalCrossing,
      "properDrawing",
      canonicalContext,
    ),
    routeCrossingPairs: readNumber(
      canonicalCrossing,
      "routeCrossingPairs",
      canonicalContext,
    ),
    routeCrossingPoints: readNumber(
      canonicalCrossing,
      "routeCrossingPoints",
      canonicalContext,
    ),
    selfIntersections: readOptionalNumber(
      canonicalCrossing,
      "selfIntersections",
      canonicalContext,
    ),
  };
}


function decodeTopCrossEdges(
  record: JsonRecord,
  context: string,
): TopCrossEdge[] | undefined {
  if (record.topCrossEdges === undefined) return undefined;
  const items = readArray(record, "topCrossEdges", context);
  return items.map((item, index) => {
    const rec = readRecord(item, `${context}.topCrossEdges[${index}]`);
    const source = rec.sourceModelId;
    const target = rec.targetModelId;
    const crossings = rec.crossings;
    if (typeof source !== "string" || !isModelId(source)
        || typeof target !== "string" || !isModelId(target)
        || typeof crossings !== "number") {
      throw new Error(`${context}.topCrossEdges[${index}] malformed`);
    }
    return { sourceModelId: source, targetModelId: target, crossings };
  });
}


function decodeClusterByModelId(
  record: JsonRecord,
  context: string,
): Record<string, string> | undefined {
  const raw = record.clusterByModelId;
  if (raw === undefined || raw === null) return undefined;
  if (typeof raw !== "object" || Array.isArray(raw)) {
    throw new Error(`${context}.clusterByModelId must be an object`);
  }
  const out: Record<string, string> = {};
  for (const [k, v] of Object.entries(raw as Record<string, unknown>)) {
    if (typeof v !== "string") {
      throw new Error(`${context}.clusterByModelId[${k}] must be a string`);
    }
    out[k] = v;
  }
  return out;
}

function decodeLeafBundles(
  record: JsonRecord,
  context: string,
): LeafBundle[] | undefined {
  if (record.leafBundles === undefined) {
    return undefined;
  }
  return readArray(record, "leafBundles", context).map((item, index) =>
    decodeLeafBundle(readRecord(item, `${context}.leafBundles[${index}]`), `${context}.leafBundles[${index}]`),
  );
}

function decodeLeafBundle(record: JsonRecord, context: string): LeafBundle {
  const bbox = readRecord(record.bbox, `${context}.bbox`);
  const sharedRootRaw = record.sharedRootModelIds;
  let sharedRootModelIds: ModelId[] | undefined;
  if (Array.isArray(sharedRootRaw)) {
    sharedRootModelIds = sharedRootRaw.map((item, index) => {
      if (typeof item !== "string" || !isModelId(item)) {
        throw new Error(
          `${context}.sharedRootModelIds[${index}] must be a canonical model ID.`,
        );
      }
      return item;
    });
  }
  return {
    anchor: decodePoint(readRecord(record.anchor, `${context}.anchor`), `${context}.anchor`),
    bbox: {
      height: readNumber(bbox, "height", `${context}.bbox`),
      width: readNumber(bbox, "width", `${context}.bbox`),
      x: readNumber(bbox, "x", `${context}.bbox`),
      y: readNumber(bbox, "y", `${context}.bbox`),
    },
    leafModelIds: readArray(record, "leafModelIds", context).map((item, index) => {
      if (typeof item !== "string" || !isModelId(item)) {
        throw new Error(`${context}.leafModelIds[${index}] must be a canonical model ID.`);
      }
      return item;
    }),
    parentModelId: readModelId(record, "parentModelId", context),
    sharedRootModelIds,
  };
}

function readOptionalLayoutMode(
  record: JsonRecord,
  key: string,
  context: string,
): LayoutMode | undefined {
  const value = readOptionalString(record, key, context);
  if (value === undefined) {
    return undefined;
  }

  if (!OGDF_LAYOUT_MODES.includes(value as LayoutMode)) {
    throw new Error(`${context}.${key} must be one of: ${OGDF_LAYOUT_MODES.join(", ")}.`);
  }

  return value as LayoutMode;
}

function decodeLayoutExecution(record: JsonRecord): LayoutExecutionSnapshot | undefined {
  const layoutExecution = readOptionalObject(record, "layoutExecution", "diagramBootstrapPayload");

  if (!layoutExecution) {
    return undefined;
  }

  return {
    appliedMode: readLiteral(layoutExecution, "appliedMode", OGDF_LAYOUT_MODES, "diagramBootstrapPayload.layoutExecution"),
    durationMs: readOptionalNumber(layoutExecution, "durationMs", "diagramBootstrapPayload.layoutExecution"),
    engine: readLiteral(layoutExecution, "engine", ["analyzer", "empty", "ogdf"], "diagramBootstrapPayload.layoutExecution"),
    engineMetadata: decodeLayoutEngineMetadata(layoutExecution, "diagramBootstrapPayload.layoutExecution"),
    reason: readOptionalString(layoutExecution, "reason", "diagramBootstrapPayload.layoutExecution"),
    requestedMode: readLiteral(layoutExecution, "requestedMode", OGDF_LAYOUT_MODES, "diagramBootstrapPayload.layoutExecution"),
    status: readLiteral(
      layoutExecution,
      "status",
      ["applied", "empty", "fallback", "quality-degraded"],
      "diagramBootstrapPayload.layoutExecution",
    ),
  };
}

function decodeLayoutFailures(
  record: JsonRecord,
): Partial<Record<LayoutMode, string>> | undefined {
  const layoutFailures = readOptionalObject(record, "layoutFailures", "diagramBootstrapPayload");

  if (!layoutFailures) {
    return undefined;
  }

  const decoded: Partial<Record<LayoutMode, string>> = {};
  for (const [layoutMode, reason] of Object.entries(layoutFailures)) {
    if (!OGDF_LAYOUT_MODES.includes(layoutMode as LayoutMode)) {
      throw new Error(`diagramBootstrapPayload.layoutFailures.${layoutMode} must be a known layout mode.`);
    }
    if (typeof reason !== "string") {
      throw new Error(`diagramBootstrapPayload.layoutFailures.${layoutMode} must be a string.`);
    }

    decoded[layoutMode as LayoutMode] = reason;
  }

  return decoded;
}

function decodeMethodAssociation(value: unknown, context: string): MethodAssociation {
  const record = readRecord(value, context);

  return {
    confidence: readLiteral(record, "confidence", ["high", "low", "medium"], context),
    id: readString(record, "id", context),
    methodName: readString(record, "methodName", context),
    provenance: readLiteral(record, "provenance", ["method_inference"], context),
    sourceModelId: readModelId(record, "sourceModelId", context),
    targetModelId: readModelId(record, "targetModelId", context),
  };
}

function decodeMethodRelatedModelReference(
  value: unknown,
  context: string,
): MethodRelatedModelReference {
  const record = readRecord(value, context);

  return {
    confidence: readLiteral(record, "confidence", ["high", "low", "medium"], context),
    evidence: readOptionalString(record, "evidence", context),
    rawReference: readOptionalString(record, "rawReference", context),
    targetModelId: readOptionalModelId(record, "targetModelId", context),
  };
}

function decodePipelineTimings(record: JsonRecord): PipelineTimings | undefined {
  const timings = readOptionalObject(record, "timings", "diagramBootstrapPayload");

  if (!timings) {
    return undefined;
  }

  return {
    analyzerBootstrapMs: readOptionalNumber(timings, "analyzerBootstrapMs", "diagramBootstrapPayload.timings"),
    discoveryMs: readOptionalNumber(timings, "discoveryMs", "diagramBootstrapPayload.timings"),
    extractMs: readOptionalNumber(timings, "extractMs", "diagramBootstrapPayload.timings"),
    graphMs: readOptionalNumber(timings, "graphMs", "diagramBootstrapPayload.timings"),
    layoutMs: readOptionalNumber(timings, "layoutMs", "diagramBootstrapPayload.timings"),
    ogdfLayoutMs: readOptionalNumber(timings, "ogdfLayoutMs", "diagramBootstrapPayload.timings"),
    parseMs: readOptionalNumber(timings, "parseMs", "diagramBootstrapPayload.timings"),
    renderDocumentMs: readOptionalNumber(timings, "renderDocumentMs", "diagramBootstrapPayload.timings"),
  };
}

function decodeModelField(value: unknown, context: string): ModelField {
  const record = readRecord(value, context);
  const choiceMetadata = readOptionalObject(record, "choiceMetadata", context);
  const relation = readOptionalObject(record, "relation", context);

  return {
    choiceMetadata: choiceMetadata
      ? decodeChoiceFieldMetadata(choiceMetadata, `${context}.choiceMetadata`)
      : undefined,
    fieldType: readString(record, "fieldType", context),
    name: readString(record, "name", context),
    nullable: readBoolean(record, "nullable", context),
    persistence: readLiteral(record, "persistence", ["computed", "stored"], context),
    primaryKey: readBoolean(record, "primaryKey", context),
    relation: relation ? decodeFieldRelation(relation, `${context}.relation`) : undefined,
  };
}

function decodeModelIdentity(record: JsonRecord, context: string): ModelIdentity {
  const appLabel = readString(record, "appLabel", context);
  const modelName = readString(record, "modelName", context);
  const id = readModelId(record, "id", context);
  const canonicalId = makeModelId(appLabel, modelName);

  if (id !== canonicalId) {
    throw new Error(`${context}.id must match ${canonicalId}.`);
  }

  return {
    appLabel,
    id,
    modelName,
    modulePath: readOptionalString(record, "modulePath", context),
  };
}

function decodeNodeLayout(value: unknown, context: string): NodeLayout {
  const record = readRecord(value, context);

  const clusterId = typeof record.clusterId === "string" && record.clusterId.length > 0
    ? record.clusterId
    : undefined;
  return {
    clusterId,
    modelId: readModelId(record, "modelId", context),
    position: decodePoint(readRecord(record.position, `${context}.position`), `${context}.position`),
    size: decodeSize(readRecord(record.size, `${context}.size`), `${context}.size`),
  };
}

function decodePoint(record: JsonRecord, context: string): Point {
  return {
    x: readNumber(record, "x", context),
    y: readNumber(record, "y", context),
  };
}

function decodePropertyAttribute(value: unknown, context: string): PropertyAttribute {
  const record = readRecord(value, context);

  return {
    name: readString(record, "name", context),
    returnType: readOptionalString(record, "returnType", context),
  };
}

function decodeRelationTargetReference(
  record: JsonRecord,
  context: string,
): RelationTargetReference {
  return {
    appLabelHint: readOptionalString(record, "appLabelHint", context),
    rawReference: readString(record, "rawReference", context),
    resolutionState: readLiteral(record, "resolutionState", ["deferred", "resolved", "unresolved"], context),
    resolvedModelId: readOptionalModelId(record, "resolvedModelId", context),
  };
}

function decodeRoutedEdgePath(value: unknown, context: string): RoutedEdgePath {
  const record = readRecord(value, context);

  return {
    crossingIds: readStringArray(record, "crossingIds", context),
    edgeId: readString(record, "edgeId", context),
    points: readArray(record, "points", context).map((item, index) =>
      decodePoint(readRecord(item, `${context}.points[${index}]`), `${context}.points[${index}]`),
    ),
    sourceModelId: readOptionalModelId(record, "sourceModelId", context),
    targetModelId: readOptionalModelId(record, "targetModelId", context),
  };
}

function decodeSelectedMethodContext(
  record: JsonRecord,
  context: string,
): SelectedMethodContext {
  return {
    methodName: readString(record, "methodName", context),
    modelId: readModelId(record, "modelId", context),
  };
}

function decodeSize(record: JsonRecord, context: string): Size {
  return {
    height: readNumber(record, "height", context),
    width: readNumber(record, "width", context),
  };
}

function decodeSourceLocation(record: JsonRecord, context: string): SourceLocation {
  const range = readOptionalObject(record, "range", context);

  return {
    filePath: readString(record, "filePath", context),
    range: range ? decodeSourceRange(range, `${context}.range`) : undefined,
    symbolName: readOptionalString(record, "symbolName", context),
  };
}

function decodeSourceRange(record: JsonRecord, context: string): SourceRange {
  return {
    endColumn: readNumber(record, "endColumn", context),
    endLine: readNumber(record, "endLine", context),
    startColumn: readNumber(record, "startColumn", context),
    startLine: readNumber(record, "startLine", context),
  };
}

function decodeStructuralGraphEdge(value: unknown, context: string): StructuralGraphEdge {
  const record = readRecord(value, context);

  return {
    id: readString(record, "id", context),
    kind: readLiteral(
      record,
      "kind",
      [
        "foreign_key",
        "many_to_many",
        "one_to_one",
        "reverse_foreign_key",
        "reverse_many_to_many",
        "reverse_one_to_one",
        "inheritance",
      ],
      context,
    ),
    provenance: readLiteral(record, "provenance", ["declared", "derived_reverse"], context),
    sourceModelId: readModelId(record, "sourceModelId", context),
    targetModelId: readModelId(record, "targetModelId", context),
  };
}

function decodeTableViewOptions(value: unknown, context: string): TableViewOptions {
  const record = readRecord(value, context);
  const manualPosition = readOptionalObject(record, "manualPosition", context);

  return {
    hidden: readBoolean(record, "hidden", context),
    manualPosition: manualPosition
      ? decodePoint(manualPosition, `${context}.manualPosition`)
      : undefined,
    modelId: readModelId(record, "modelId", context),
    showMethodHighlights: readBoolean(record, "showMethodHighlights", context),
    showMethods: readBoolean(record, "showMethods", context),
    showProperties: readBoolean(record, "showProperties", context),
  };
}

function decodeUserMethod(value: unknown, context: string): UserMethod {
  const record = readRecord(value, context);

  return {
    name: readString(record, "name", context),
    relatedModels: readArray(record, "relatedModels", context).map((item, index) =>
      decodeMethodRelatedModelReference(item, `${context}.relatedModels[${index}]`),
    ),
    visibility: readLiteral(record, "visibility", ["private", "protected", "public"], context),
  };
}

function decodeViewState(record: JsonRecord): InitialViewState {
  const selectedMethodContext = readOptionalObject(
    record,
    "selectedMethodContext",
    "diagramBootstrapPayload.view",
  );
  const viewportRecord = readOptionalObject(
    record,
    "viewport",
    "diagramBootstrapPayload.view",
  );

  return {
    collapseClusters: record.collapseClusters === true,
    edgeBundling: record.edgeBundling === true,
    useEdgeBends: record.useEdgeBends === true,
    clusterGraphLayout: record.clusterGraphLayout === true,
    bubbleLayout: record.bubbleLayout === true,
    optimizedLayout: record.optimizedLayout === true,
    layoutMode: readLiteral(record, "layoutMode", OGDF_LAYOUT_MODES, "diagramBootstrapPayload.view"),
    selectedMethodContext: selectedMethodContext
      ? decodeSelectedMethodContext(
          selectedMethodContext,
          "diagramBootstrapPayload.view.selectedMethodContext",
        )
      : undefined,
    selectedModelId: readOptionalModelId(record, "selectedModelId", "diagramBootstrapPayload.view"),
    tableOptions: readArray(record, "tableOptions", "diagramBootstrapPayload.view").map((item, index) =>
      decodeTableViewOptions(item, `diagramBootstrapPayload.view.tableOptions[${index}]`),
    ),
    viewport: viewportRecord
      ? decodeViewportSnapshot(
          viewportRecord,
          "diagramBootstrapPayload.view.viewport",
        )
      : undefined,
  };
}

function decodeViewportSnapshot(
  record: JsonRecord,
  context: string,
): DiagramViewportSnapshot {
  return {
    panX: readNumber(record, "panX", context),
    panY: readNumber(record, "panY", context),
    zoom: readNumber(record, "zoom", context),
  };
}

function decodeEdgeCrossing(value: unknown, context: string): EdgeCrossing {
  const record = readRecord(value, context);
  const edgeIds = readStringArray(record, "edgeIds", context);

  if (edgeIds.length !== 2) {
    throw new Error(`${context}.edgeIds must contain exactly two edge IDs.`);
  }

  return {
    edgeIds: [edgeIds[0], edgeIds[1]],
    id: readString(record, "id", context),
    markerStyle: readLiteral(record, "markerStyle", ["bridge", "marker"], context),
    position: decodePoint(readRecord(record.position, `${context}.position`), `${context}.position`),
  };
}
