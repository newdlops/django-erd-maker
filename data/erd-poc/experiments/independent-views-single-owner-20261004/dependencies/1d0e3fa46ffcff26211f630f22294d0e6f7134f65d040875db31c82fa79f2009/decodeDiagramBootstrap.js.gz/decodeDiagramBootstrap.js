"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.decodeDiagramBootstrapPayload = decodeDiagramBootstrapPayload;
exports.decodeLayoutSnapshot = decodeLayoutSnapshot;
const modelIdentity_1 = require("../domain/modelIdentity");
const layoutContract_1 = require("../graph/layoutContract");
const contractVersion_1 = require("./contractVersion");
const runtimeGuards_1 = require("./runtimeGuards");
function decodeDiagramBootstrapPayload(value) {
    const root = (0, runtimeGuards_1.readRecord)(value, "diagramBootstrapPayload");
    return {
        analyzer: decodeAnalyzerOutput((0, runtimeGuards_1.readRecord)(root.analyzer, "diagramBootstrapPayload.analyzer")),
        contractVersion: decodeContractVersion(root, "contractVersion", "diagramBootstrapPayload"),
        graph: decodeGraph((0, runtimeGuards_1.readRecord)(root.graph, "diagramBootstrapPayload.graph")),
        layout: decodeLayout((0, runtimeGuards_1.readRecord)(root.layout, "diagramBootstrapPayload.layout"), "diagramBootstrapPayload.layout"),
        layoutExecution: decodeLayoutExecution(root),
        layoutFailures: decodeLayoutFailures(root),
        timings: decodePipelineTimings(root),
        view: decodeViewState((0, runtimeGuards_1.readRecord)(root.view, "diagramBootstrapPayload.view")),
    };
}
function decodeLayoutSnapshot(value, context = "layoutSnapshot") {
    return decodeLayout((0, runtimeGuards_1.readRecord)(value, context), context);
}
function decodeAnalyzerOutput(record) {
    return {
        contractVersion: decodeContractVersion(record, "contractVersion", "diagramBootstrapPayload.analyzer"),
        diagnostics: (0, runtimeGuards_1.readArray)(record, "diagnostics", "diagramBootstrapPayload.analyzer").map((item, index) => decodeDiagnostic(item, `diagramBootstrapPayload.analyzer.diagnostics[${index}]`)),
        models: (0, runtimeGuards_1.readArray)(record, "models", "diagramBootstrapPayload.analyzer").map((item, index) => decodeExtractedModel(item, `diagramBootstrapPayload.analyzer.models[${index}]`)),
        summary: decodeAnalysisSummary((0, runtimeGuards_1.readRecord)(record.summary, "diagramBootstrapPayload.analyzer.summary")),
    };
}
function decodeAnalysisSummary(record) {
    return {
        canonicalModelIdCollisionCount: (0, runtimeGuards_1.readOptionalNumber)(record, "canonicalModelIdCollisionCount", "diagramBootstrapPayload.analyzer.summary"),
        diagnosticCount: (0, runtimeGuards_1.readNumber)(record, "diagnosticCount", "diagramBootstrapPayload.analyzer.summary"),
        discoveredAppCount: (0, runtimeGuards_1.readNumber)(record, "discoveredAppCount", "diagramBootstrapPayload.analyzer.summary"),
        discoveredModelCount: (0, runtimeGuards_1.readNumber)(record, "discoveredModelCount", "diagramBootstrapPayload.analyzer.summary"),
        workspaceRoot: (0, runtimeGuards_1.readString)(record, "workspaceRoot", "diagramBootstrapPayload.analyzer.summary"),
    };
}
function decodeChoiceFieldMetadata(record, context) {
    return {
        isChoiceField: (0, runtimeGuards_1.readBoolean)(record, "isChoiceField", context),
        isFullyResolved: (0, runtimeGuards_1.readBoolean)(record, "isFullyResolved", context),
        options: (0, runtimeGuards_1.readArray)(record, "options", context).map((item, index) => decodeChoiceOption(item, `${context}.options[${index}]`)),
    };
}
function decodeChoiceOption(value, context) {
    const record = (0, runtimeGuards_1.readRecord)(value, context);
    return {
        label: (0, runtimeGuards_1.readString)(record, "label", context),
        value: (0, runtimeGuards_1.readString)(record, "value", context),
        valueKind: (0, runtimeGuards_1.readLiteral)(record, "valueKind", ["boolean", "null", "number", "string"], context),
    };
}
function decodeContractVersion(record, key, context) {
    const value = (0, runtimeGuards_1.readString)(record, key, context);
    if (value !== contractVersion_1.CONTRACT_VERSION) {
        throw new Error(`${context}.${key} must equal contract version ${contractVersion_1.CONTRACT_VERSION}.`);
    }
    return value;
}
function decodeDiagnostic(value, context) {
    const record = (0, runtimeGuards_1.readRecord)(value, context);
    const locationRecord = (0, runtimeGuards_1.readOptionalObject)(record, "location", context);
    return {
        code: (0, runtimeGuards_1.readLiteral)(record, "code", ["partial_inference", "syntax_error", "unresolved_reference", "unsupported_construct"], context),
        location: locationRecord ? decodeSourceLocation(locationRecord, `${context}.location`) : undefined,
        message: (0, runtimeGuards_1.readString)(record, "message", context),
        relatedModelId: (0, runtimeGuards_1.readOptionalModelId)(record, "relatedModelId", context),
        severity: (0, runtimeGuards_1.readLiteral)(record, "severity", ["error", "info", "warning"], context),
    };
}
function decodeExtractedModel(value, context) {
    const record = (0, runtimeGuards_1.readRecord)(value, context);
    return {
        databaseTableName: (0, runtimeGuards_1.readOptionalString)(record, "databaseTableName", context),
        declaredBaseClasses: (0, runtimeGuards_1.readStringArray)(record, "declaredBaseClasses", context),
        fields: (0, runtimeGuards_1.readArray)(record, "fields", context).map((item, index) => decodeModelField(item, `${context}.fields[${index}]`)),
        hasExplicitDatabaseTableName: (0, runtimeGuards_1.readOptionalBoolean)(record, "hasExplicitDatabaseTableName", context),
        identity: decodeModelIdentity((0, runtimeGuards_1.readRecord)(record.identity, `${context}.identity`), `${context}.identity`),
        methods: (0, runtimeGuards_1.readArray)(record, "methods", context).map((item, index) => decodeUserMethod(item, `${context}.methods[${index}]`)),
        properties: (0, runtimeGuards_1.readArray)(record, "properties", context).map((item, index) => decodePropertyAttribute(item, `${context}.properties[${index}]`)),
    };
}
function decodeGraph(record) {
    return {
        diagnostics: (0, runtimeGuards_1.readArray)(record, "diagnostics", "diagramBootstrapPayload.graph").map((item, index) => decodeDiagnostic(item, `diagramBootstrapPayload.graph.diagnostics[${index}]`)),
        methodAssociations: (0, runtimeGuards_1.readArray)(record, "methodAssociations", "diagramBootstrapPayload.graph").map((item, index) => decodeMethodAssociation(item, `diagramBootstrapPayload.graph.methodAssociations[${index}]`)),
        nodes: (0, runtimeGuards_1.readArray)(record, "nodes", "diagramBootstrapPayload.graph").map((item, index) => decodeGraphNode(item, `diagramBootstrapPayload.graph.nodes[${index}]`)),
        structuralEdges: (0, runtimeGuards_1.readArray)(record, "structuralEdges", "diagramBootstrapPayload.graph").map((item, index) => decodeStructuralGraphEdge(item, `diagramBootstrapPayload.graph.structuralEdges[${index}]`)),
    };
}
function decodeGraphNode(value, context) {
    const record = (0, runtimeGuards_1.readRecord)(value, context);
    return {
        appLabel: (0, runtimeGuards_1.readString)(record, "appLabel", context),
        modelId: (0, runtimeGuards_1.readModelId)(record, "modelId", context),
        modelName: (0, runtimeGuards_1.readString)(record, "modelName", context),
    };
}
function decodeFieldRelation(record, context) {
    return {
        kind: (0, runtimeGuards_1.readLiteral)(record, "kind", [
            "foreign_key",
            "many_to_many",
            "one_to_one",
            "reverse_foreign_key",
            "reverse_many_to_many",
            "reverse_one_to_one",
        ], context),
        reverseAccessorName: (0, runtimeGuards_1.readOptionalString)(record, "reverseAccessorName", context),
        target: decodeRelationTargetReference((0, runtimeGuards_1.readRecord)(record.target, `${context}.target`), `${context}.target`),
        throughModelId: (0, runtimeGuards_1.readOptionalModelId)(record, "throughModelId", context),
    };
}
function decodeLayout(record, context) {
    const layout = {
        crossings: (0, runtimeGuards_1.readArray)(record, "crossings", context).map((item, index) => decodeEdgeCrossing(item, `${context}.crossings[${index}]`)),
        engineMetadata: decodeLayoutEngineMetadata(record, context),
        mode: (0, runtimeGuards_1.readLiteral)(record, "mode", layoutContract_1.OGDF_LAYOUT_MODES, context),
        nodes: (0, runtimeGuards_1.readArray)(record, "nodes", context).map((item, index) => decodeNodeLayout(item, `${context}.nodes[${index}]`)),
        routedEdges: (0, runtimeGuards_1.readArray)(record, "routedEdges", context).map((item, index) => decodeRoutedEdgePath(item, `${context}.routedEdges[${index}]`)),
    };
    const individual = (0, runtimeGuards_1.readOptionalObject)(record, "individualView", context);
    if (individual) {
        const viewContext = `${context}.individualView`;
        const nodes = (0, runtimeGuards_1.readArray)(individual, "nodes", viewContext).map((item, index) => decodeNodeLayout(item, `${viewContext}.nodes[${index}]`));
        const routedEdges = (0, runtimeGuards_1.readArray)(individual, "routedEdges", viewContext).map((item, index) => decodeRoutedEdgePath(item, `${viewContext}.routedEdges[${index}]`));
        const originalNodes = new Map(layout.nodes.map(node => [node.modelId, node]));
        const originalEdges = new Map(layout.routedEdges.map(edge => [edge.edgeId, edge]));
        if (nodes.length !== originalNodes.size || new Set(nodes.map(node => node.modelId)).size !== nodes.length
            || routedEdges.length !== originalEdges.size || new Set(routedEdges.map(edge => edge.edgeId)).size !== routedEdges.length) {
            throw new Error(`${viewContext} must preserve every node and route exactly once.`);
        }
        for (const node of nodes) {
            const original = originalNodes.get(node.modelId);
            if (!original || node.size.width !== original.size.width || node.size.height !== original.size.height
                || node.clusterId !== original.clusterId) {
                throw new Error(`${viewContext} must preserve node identity, dimensions and membership.`);
            }
        }
        for (const edge of routedEdges) {
            const original = originalEdges.get(edge.edgeId);
            if (!original || edge.sourceModelId !== original.sourceModelId || edge.targetModelId !== original.targetModelId
                || edge.points.length !== 2) {
                throw new Error(`${viewContext} must preserve straight relationship routes.`);
            }
        }
        layout.individualView = { nodes, routedEdges };
    }
    return layout;
}
function decodeLayoutEngineMetadata(record, context) {
    const metadata = (0, runtimeGuards_1.readOptionalObject)(record, "engineMetadata", context);
    if (!metadata) {
        return undefined;
    }
    return {
        relationshipPresentation: metadata.relationshipPresentation === "june-bundled"
            ? "june-bundled"
            : undefined,
        actualAlgorithm: (0, runtimeGuards_1.readOptionalString)(metadata, "actualAlgorithm", `${context}.engineMetadata`),
        actualMode: readOptionalLayoutMode(metadata, "actualMode", `${context}.engineMetadata`),
        aspectRatio: (0, runtimeGuards_1.readOptionalNumber)(metadata, "aspectRatio", `${context}.engineMetadata`),
        boundingBoxArea: (0, runtimeGuards_1.readOptionalNumber)(metadata, "boundingBoxArea", `${context}.engineMetadata`),
        bundleBundleOverlaps: (0, runtimeGuards_1.readOptionalNumber)(metadata, "bundleBundleOverlaps", `${context}.engineMetadata`),
        bundleEdgeIntersections: (0, runtimeGuards_1.readOptionalNumber)(metadata, "bundleEdgeIntersections", `${context}.engineMetadata`),
        bundleNodeOverlaps: (0, runtimeGuards_1.readOptionalNumber)(metadata, "bundleNodeOverlaps", `${context}.engineMetadata`),
        canonicalCrossing: decodeCanonicalCrossing(metadata, `${context}.engineMetadata`),
        carrierBundleEdgeIntersections: (0, runtimeGuards_1.readOptionalNumber)(metadata, "carrierBundleEdgeIntersections", `${context}.engineMetadata`),
        carrierBundleNodeOverlaps: (0, runtimeGuards_1.readOptionalNumber)(metadata, "carrierBundleNodeOverlaps", `${context}.engineMetadata`),
        carrierEdgeCrossings: (0, runtimeGuards_1.readOptionalNumber)(metadata, "carrierEdgeCrossings", `${context}.engineMetadata`),
        carrierEdgeNodeIntersections: (0, runtimeGuards_1.readOptionalNumber)(metadata, "carrierEdgeNodeIntersections", `${context}.engineMetadata`),
        carrierNodeOverlaps: (0, runtimeGuards_1.readOptionalNumber)(metadata, "carrierNodeOverlaps", `${context}.engineMetadata`),
        carrierRouteSegments: (0, runtimeGuards_1.readOptionalNumber)(metadata, "carrierRouteSegments", `${context}.engineMetadata`),
        carrierVisualCrossings: (0, runtimeGuards_1.readOptionalNumber)(metadata, "carrierVisualCrossings", `${context}.engineMetadata`),
        edgeCrossings: (0, runtimeGuards_1.readOptionalNumber)(metadata, "edgeCrossings", `${context}.engineMetadata`),
        edgeLengthStddev: (0, runtimeGuards_1.readOptionalNumber)(metadata, "edgeLengthStddev", `${context}.engineMetadata`),
        edgeNodeIntersections: (0, runtimeGuards_1.readOptionalNumber)(metadata, "edgeNodeIntersections", `${context}.engineMetadata`),
        edgeSegmentOverlaps: (0, runtimeGuards_1.readOptionalNumber)(metadata, "edgeSegmentOverlaps", `${context}.engineMetadata`),
        hubCarrierClusters: (0, runtimeGuards_1.readOptionalNumber)(metadata, "hubCarrierClusters", `${context}.engineMetadata`),
        hubCarrierEdgesGrouped: (0, runtimeGuards_1.readOptionalNumber)(metadata, "hubCarrierEdgesGrouped", `${context}.engineMetadata`),
        hubCarrierThreshold: (0, runtimeGuards_1.readOptionalNumber)(metadata, "hubCarrierThreshold", `${context}.engineMetadata`),
        inheritanceCarrierGrouping: (0, runtimeGuards_1.readOptionalBoolean)(metadata, "inheritanceCarrierGrouping", `${context}.engineMetadata`),
        intraClusterCarrierGrouping: (0, runtimeGuards_1.readOptionalBoolean)(metadata, "intraClusterCarrierGrouping", `${context}.engineMetadata`),
        leafBundles: decodeLeafBundles(metadata, `${context}.engineMetadata`),
        meanEdgeLength: (0, runtimeGuards_1.readOptionalNumber)(metadata, "meanEdgeLength", `${context}.engineMetadata`),
        nodeClearanceMin: (0, runtimeGuards_1.readOptionalNumber)(metadata, "nodeClearanceMin", `${context}.engineMetadata`),
        nodeClearanceTarget: (0, runtimeGuards_1.readOptionalNumber)(metadata, "nodeClearanceTarget", `${context}.engineMetadata`),
        nodeOverlaps: (0, runtimeGuards_1.readOptionalNumber)(metadata, "nodeOverlaps", `${context}.engineMetadata`),
        nodeSpacingOverlaps: (0, runtimeGuards_1.readOptionalNumber)(metadata, "nodeSpacingOverlaps", `${context}.engineMetadata`),
        overlappingEdges: (0, runtimeGuards_1.readOptionalNumber)(metadata, "overlappingEdges", `${context}.engineMetadata`),
        rawRouteCrossings: (0, runtimeGuards_1.readOptionalNumber)(metadata, "rawRouteCrossings", `${context}.engineMetadata`),
        renderedCarrierRoutes: decodeRenderedCarrierRoutes(metadata, `${context}.engineMetadata`),
        renderedEdgeCount: (0, runtimeGuards_1.readOptionalNumber)(metadata, "renderedEdgeCount", `${context}.engineMetadata`),
        requestedAlgorithm: (0, runtimeGuards_1.readOptionalString)(metadata, "requestedAlgorithm", `${context}.engineMetadata`),
        requestedMode: readOptionalLayoutMode(metadata, "requestedMode", `${context}.engineMetadata`),
        routeSegments: (0, runtimeGuards_1.readOptionalNumber)(metadata, "routeSegments", `${context}.engineMetadata`),
        semanticCarrierBundledRelationships: (0, runtimeGuards_1.readOptionalNumber)(metadata, "semanticCarrierBundledRelationships", `${context}.engineMetadata`),
        semanticCarrierBundleGroups: (0, runtimeGuards_1.readOptionalNumber)(metadata, "semanticCarrierBundleGroups", `${context}.engineMetadata`),
        semanticCarrierCoincidentRelationships: (0, runtimeGuards_1.readOptionalNumber)(metadata, "semanticCarrierCoincidentRelationships", `${context}.engineMetadata`),
        semanticCarrierCrossingsAvoided: (0, runtimeGuards_1.readOptionalNumber)(metadata, "semanticCarrierCrossingsAvoided", `${context}.engineMetadata`),
        semanticCarrierDisconnectedRelationships: (0, runtimeGuards_1.readOptionalNumber)(metadata, "semanticCarrierDisconnectedRelationships", `${context}.engineMetadata`),
        semanticCarrierEligibleRelationships: (0, runtimeGuards_1.readOptionalNumber)(metadata, "semanticCarrierEligibleRelationships", `${context}.engineMetadata`),
        semanticCarrierFallbackRelationships: (0, runtimeGuards_1.readOptionalNumber)(metadata, "semanticCarrierFallbackRelationships", `${context}.engineMetadata`),
        semanticCarrierMissingRelationships: (0, runtimeGuards_1.readOptionalNumber)(metadata, "semanticCarrierMissingRelationships", `${context}.engineMetadata`),
        semanticCarrierObstacleIntersections: (0, runtimeGuards_1.readOptionalNumber)(metadata, "semanticCarrierObstacleIntersections", `${context}.engineMetadata`),
        semanticCarrierObstacleIntersectionsAvoided: (0, runtimeGuards_1.readOptionalNumber)(metadata, "semanticCarrierObstacleIntersectionsAvoided", `${context}.engineMetadata`),
        semanticCarrierRelationships: (0, runtimeGuards_1.readOptionalNumber)(metadata, "semanticCarrierRelationships", `${context}.engineMetadata`),
        semanticCarrierSegments: (0, runtimeGuards_1.readOptionalNumber)(metadata, "semanticCarrierSegments", `${context}.engineMetadata`),
        semanticCarrierSelfRelationships: (0, runtimeGuards_1.readOptionalNumber)(metadata, "semanticCarrierSelfRelationships", `${context}.engineMetadata`),
        strategy: (0, runtimeGuards_1.readOptionalString)(metadata, "strategy", `${context}.engineMetadata`),
        strategyReason: (0, runtimeGuards_1.readOptionalString)(metadata, "strategyReason", `${context}.engineMetadata`),
        visualCrossings: (0, runtimeGuards_1.readOptionalNumber)(metadata, "visualCrossings", `${context}.engineMetadata`),
        visualCrossingsScope: (0, runtimeGuards_1.readOptionalString)(metadata, "visualCrossingsScope", `${context}.engineMetadata`),
        stressScore: (0, runtimeGuards_1.readOptionalNumber)(metadata, "stressScore", `${context}.engineMetadata`),
        edgeLengthCv: (0, runtimeGuards_1.readOptionalNumber)(metadata, "edgeLengthCv", `${context}.engineMetadata`),
        crossingAngleMean: (0, runtimeGuards_1.readOptionalNumber)(metadata, "crossingAngleMean", `${context}.engineMetadata`),
        crossingAngleCv: (0, runtimeGuards_1.readOptionalNumber)(metadata, "crossingAngleCv", `${context}.engineMetadata`),
        edgeBendTotal: (0, runtimeGuards_1.readOptionalNumber)(metadata, "edgeBendTotal", `${context}.engineMetadata`),
        hubClearanceP10: (0, runtimeGuards_1.readOptionalNumber)(metadata, "hubClearanceP10", `${context}.engineMetadata`),
        clusterCompactnessMean: (0, runtimeGuards_1.readOptionalNumber)(metadata, "clusterCompactnessMean", `${context}.engineMetadata`),
        crossingsPerEdgeP50: (0, runtimeGuards_1.readOptionalNumber)(metadata, "crossingsPerEdgeP50", `${context}.engineMetadata`),
        crossingsPerEdgeP90: (0, runtimeGuards_1.readOptionalNumber)(metadata, "crossingsPerEdgeP90", `${context}.engineMetadata`),
        cleanEdgeRatio: (0, runtimeGuards_1.readOptionalNumber)(metadata, "cleanEdgeRatio", `${context}.engineMetadata`),
        edgeCrossingsBetweenClusters: (0, runtimeGuards_1.readOptionalNumber)(metadata, "edgeCrossingsBetweenClusters", `${context}.engineMetadata`),
        nodeAreaCoverage: (0, runtimeGuards_1.readOptionalNumber)(metadata, "nodeAreaCoverage", `${context}.engineMetadata`),
        emptySpaceCv: (0, runtimeGuards_1.readOptionalNumber)(metadata, "emptySpaceCv", `${context}.engineMetadata`),
        compositeQuality: (0, runtimeGuards_1.readOptionalNumber)(metadata, "compositeQuality", `${context}.engineMetadata`),
        subCleanQuality: (0, runtimeGuards_1.readOptionalNumber)(metadata, "subCleanQuality", `${context}.engineMetadata`),
        subSeverityQuality: (0, runtimeGuards_1.readOptionalNumber)(metadata, "subSeverityQuality", `${context}.engineMetadata`),
        subAngleQuality: (0, runtimeGuards_1.readOptionalNumber)(metadata, "subAngleQuality", `${context}.engineMetadata`),
        subStressQuality: (0, runtimeGuards_1.readOptionalNumber)(metadata, "subStressQuality", `${context}.engineMetadata`),
        subCompactQuality: (0, runtimeGuards_1.readOptionalNumber)(metadata, "subCompactQuality", `${context}.engineMetadata`),
        subUniformQuality: (0, runtimeGuards_1.readOptionalNumber)(metadata, "subUniformQuality", `${context}.engineMetadata`),
        subSpreadQuality: (0, runtimeGuards_1.readOptionalNumber)(metadata, "subSpreadQuality", `${context}.engineMetadata`),
        topCrossEdges: decodeTopCrossEdges(metadata, `${context}.engineMetadata`),
        clusterByModelId: decodeClusterByModelId(metadata, `${context}.engineMetadata`),
    };
}
function decodeRenderedCarrierRoutes(record, context) {
    if (record.renderedCarrierRoutes === undefined) {
        return undefined;
    }
    return (0, runtimeGuards_1.readArray)(record, "renderedCarrierRoutes", context).map((item, index) => {
        const routeContext = `${context}.renderedCarrierRoutes[${index}]`;
        const route = (0, runtimeGuards_1.readRecord)(item, routeContext);
        const carrierId = (0, runtimeGuards_1.readString)(route, "carrierId", routeContext);
        const memberEdgeIds = (0, runtimeGuards_1.readStringArray)(route, "memberEdgeIds", routeContext);
        const points = (0, runtimeGuards_1.readArray)(route, "points", routeContext).map((point, pointIndex) => decodePoint((0, runtimeGuards_1.readRecord)(point, `${routeContext}.points[${pointIndex}]`), `${routeContext}.points[${pointIndex}]`));
        if (carrierId.length === 0 || memberEdgeIds.length < 1 || points.length < 2) {
            throw new Error(`${routeContext} must contain a carrierId, at least one member, and at least two points.`);
        }
        return { carrierId, memberEdgeIds, points };
    });
}
function decodeCanonicalCrossing(record, context) {
    const canonicalCrossing = (0, runtimeGuards_1.readOptionalObject)(record, "canonicalCrossing", context);
    if (!canonicalCrossing) {
        return undefined;
    }
    const canonicalContext = `${context}.canonicalCrossing`;
    return {
        adjacentEdgeIntersections: (0, runtimeGuards_1.readOptionalNumber)(canonicalCrossing, "adjacentEdgeIntersections", canonicalContext),
        boundViolation: (0, runtimeGuards_1.readBoolean)(canonicalCrossing, "boundViolation", canonicalContext),
        certifierVersion: (0, runtimeGuards_1.readString)(canonicalCrossing, "certifierVersion", canonicalContext),
        collinearOverlaps: (0, runtimeGuards_1.readOptionalNumber)(canonicalCrossing, "collinearOverlaps", canonicalContext),
        completeRoutes: (0, runtimeGuards_1.readBoolean)(canonicalCrossing, "completeRoutes", canonicalContext),
        degenerateSegments: (0, runtimeGuards_1.readOptionalNumber)(canonicalCrossing, "degenerateSegments", canonicalContext),
        domain: (0, runtimeGuards_1.readLiteral)(canonicalCrossing, "domain", ["canonical-simple-v1"], canonicalContext),
        edgeCount: (0, runtimeGuards_1.readNumber)(canonicalCrossing, "edgeCount", canonicalContext),
        gap: (0, runtimeGuards_1.readOptionalNumber)(canonicalCrossing, "gap", canonicalContext),
        invariantViolations: (0, runtimeGuards_1.readOptionalNumber)(canonicalCrossing, "invariantViolations", canonicalContext),
        k3nCertificates: (0, runtimeGuards_1.readNumber)(canonicalCrossing, "k3nCertificates", canonicalContext),
        k3nContribution: (0, runtimeGuards_1.readNumber)(canonicalCrossing, "k3nContribution", canonicalContext),
        kuratowskiCertificates: (0, runtimeGuards_1.readNumber)(canonicalCrossing, "kuratowskiCertificates", canonicalContext),
        kuratowskiContribution: (0, runtimeGuards_1.readNumber)(canonicalCrossing, "kuratowskiContribution", canonicalContext),
        lowerBound: (0, runtimeGuards_1.readNumber)(canonicalCrossing, "lowerBound", canonicalContext),
        method: (0, runtimeGuards_1.readString)(canonicalCrossing, "method", canonicalContext),
        nodeCount: (0, runtimeGuards_1.readNumber)(canonicalCrossing, "nodeCount", canonicalContext),
        nonIncidentNodeHits: (0, runtimeGuards_1.readOptionalNumber)(canonicalCrossing, "nonIncidentNodeHits", canonicalContext),
        nonProperContacts: (0, runtimeGuards_1.readNumber)(canonicalCrossing, "nonProperContacts", canonicalContext),
        pointContacts: (0, runtimeGuards_1.readOptionalNumber)(canonicalCrossing, "pointContacts", canonicalContext),
        optimality: (0, runtimeGuards_1.readOptionalNumber)(canonicalCrossing, "optimality", canonicalContext),
        properDrawing: (0, runtimeGuards_1.readBoolean)(canonicalCrossing, "properDrawing", canonicalContext),
        routeCrossingPairs: (0, runtimeGuards_1.readNumber)(canonicalCrossing, "routeCrossingPairs", canonicalContext),
        routeCrossingPoints: (0, runtimeGuards_1.readNumber)(canonicalCrossing, "routeCrossingPoints", canonicalContext),
        selfIntersections: (0, runtimeGuards_1.readOptionalNumber)(canonicalCrossing, "selfIntersections", canonicalContext),
    };
}
function decodeTopCrossEdges(record, context) {
    if (record.topCrossEdges === undefined)
        return undefined;
    const items = (0, runtimeGuards_1.readArray)(record, "topCrossEdges", context);
    return items.map((item, index) => {
        const rec = (0, runtimeGuards_1.readRecord)(item, `${context}.topCrossEdges[${index}]`);
        const source = rec.sourceModelId;
        const target = rec.targetModelId;
        const crossings = rec.crossings;
        if (typeof source !== "string" || !(0, modelIdentity_1.isModelId)(source)
            || typeof target !== "string" || !(0, modelIdentity_1.isModelId)(target)
            || typeof crossings !== "number") {
            throw new Error(`${context}.topCrossEdges[${index}] malformed`);
        }
        return { sourceModelId: source, targetModelId: target, crossings };
    });
}
function decodeClusterByModelId(record, context) {
    const raw = record.clusterByModelId;
    if (raw === undefined || raw === null)
        return undefined;
    if (typeof raw !== "object" || Array.isArray(raw)) {
        throw new Error(`${context}.clusterByModelId must be an object`);
    }
    const out = {};
    for (const [k, v] of Object.entries(raw)) {
        if (typeof v !== "string") {
            throw new Error(`${context}.clusterByModelId[${k}] must be a string`);
        }
        out[k] = v;
    }
    return out;
}
function decodeLeafBundles(record, context) {
    if (record.leafBundles === undefined) {
        return undefined;
    }
    return (0, runtimeGuards_1.readArray)(record, "leafBundles", context).map((item, index) => decodeLeafBundle((0, runtimeGuards_1.readRecord)(item, `${context}.leafBundles[${index}]`), `${context}.leafBundles[${index}]`));
}
function decodeLeafBundle(record, context) {
    const bbox = (0, runtimeGuards_1.readRecord)(record.bbox, `${context}.bbox`);
    const sharedRootRaw = record.sharedRootModelIds;
    let sharedRootModelIds;
    if (Array.isArray(sharedRootRaw)) {
        sharedRootModelIds = sharedRootRaw.map((item, index) => {
            if (typeof item !== "string" || !(0, modelIdentity_1.isModelId)(item)) {
                throw new Error(`${context}.sharedRootModelIds[${index}] must be a canonical model ID.`);
            }
            return item;
        });
    }
    return {
        anchor: decodePoint((0, runtimeGuards_1.readRecord)(record.anchor, `${context}.anchor`), `${context}.anchor`),
        bbox: {
            height: (0, runtimeGuards_1.readNumber)(bbox, "height", `${context}.bbox`),
            width: (0, runtimeGuards_1.readNumber)(bbox, "width", `${context}.bbox`),
            x: (0, runtimeGuards_1.readNumber)(bbox, "x", `${context}.bbox`),
            y: (0, runtimeGuards_1.readNumber)(bbox, "y", `${context}.bbox`),
        },
        leafModelIds: (0, runtimeGuards_1.readArray)(record, "leafModelIds", context).map((item, index) => {
            if (typeof item !== "string" || !(0, modelIdentity_1.isModelId)(item)) {
                throw new Error(`${context}.leafModelIds[${index}] must be a canonical model ID.`);
            }
            return item;
        }),
        parentModelId: (0, runtimeGuards_1.readModelId)(record, "parentModelId", context),
        sharedRootModelIds,
    };
}
function readOptionalLayoutMode(record, key, context) {
    const value = (0, runtimeGuards_1.readOptionalString)(record, key, context);
    if (value === undefined) {
        return undefined;
    }
    if (!layoutContract_1.OGDF_LAYOUT_MODES.includes(value)) {
        throw new Error(`${context}.${key} must be one of: ${layoutContract_1.OGDF_LAYOUT_MODES.join(", ")}.`);
    }
    return value;
}
function decodeLayoutExecution(record) {
    const layoutExecution = (0, runtimeGuards_1.readOptionalObject)(record, "layoutExecution", "diagramBootstrapPayload");
    if (!layoutExecution) {
        return undefined;
    }
    return {
        appliedMode: (0, runtimeGuards_1.readLiteral)(layoutExecution, "appliedMode", layoutContract_1.OGDF_LAYOUT_MODES, "diagramBootstrapPayload.layoutExecution"),
        durationMs: (0, runtimeGuards_1.readOptionalNumber)(layoutExecution, "durationMs", "diagramBootstrapPayload.layoutExecution"),
        engine: (0, runtimeGuards_1.readLiteral)(layoutExecution, "engine", ["analyzer", "empty", "ogdf"], "diagramBootstrapPayload.layoutExecution"),
        engineMetadata: decodeLayoutEngineMetadata(layoutExecution, "diagramBootstrapPayload.layoutExecution"),
        reason: (0, runtimeGuards_1.readOptionalString)(layoutExecution, "reason", "diagramBootstrapPayload.layoutExecution"),
        requestedMode: (0, runtimeGuards_1.readLiteral)(layoutExecution, "requestedMode", layoutContract_1.OGDF_LAYOUT_MODES, "diagramBootstrapPayload.layoutExecution"),
        status: (0, runtimeGuards_1.readLiteral)(layoutExecution, "status", ["applied", "empty", "fallback", "quality-degraded"], "diagramBootstrapPayload.layoutExecution"),
    };
}
function decodeLayoutFailures(record) {
    const layoutFailures = (0, runtimeGuards_1.readOptionalObject)(record, "layoutFailures", "diagramBootstrapPayload");
    if (!layoutFailures) {
        return undefined;
    }
    const decoded = {};
    for (const [layoutMode, reason] of Object.entries(layoutFailures)) {
        if (!layoutContract_1.OGDF_LAYOUT_MODES.includes(layoutMode)) {
            throw new Error(`diagramBootstrapPayload.layoutFailures.${layoutMode} must be a known layout mode.`);
        }
        if (typeof reason !== "string") {
            throw new Error(`diagramBootstrapPayload.layoutFailures.${layoutMode} must be a string.`);
        }
        decoded[layoutMode] = reason;
    }
    return decoded;
}
function decodeMethodAssociation(value, context) {
    const record = (0, runtimeGuards_1.readRecord)(value, context);
    return {
        confidence: (0, runtimeGuards_1.readLiteral)(record, "confidence", ["high", "low", "medium"], context),
        id: (0, runtimeGuards_1.readString)(record, "id", context),
        methodName: (0, runtimeGuards_1.readString)(record, "methodName", context),
        provenance: (0, runtimeGuards_1.readLiteral)(record, "provenance", ["method_inference"], context),
        sourceModelId: (0, runtimeGuards_1.readModelId)(record, "sourceModelId", context),
        targetModelId: (0, runtimeGuards_1.readModelId)(record, "targetModelId", context),
    };
}
function decodeMethodRelatedModelReference(value, context) {
    const record = (0, runtimeGuards_1.readRecord)(value, context);
    return {
        confidence: (0, runtimeGuards_1.readLiteral)(record, "confidence", ["high", "low", "medium"], context),
        evidence: (0, runtimeGuards_1.readOptionalString)(record, "evidence", context),
        rawReference: (0, runtimeGuards_1.readOptionalString)(record, "rawReference", context),
        targetModelId: (0, runtimeGuards_1.readOptionalModelId)(record, "targetModelId", context),
    };
}
function decodePipelineTimings(record) {
    const timings = (0, runtimeGuards_1.readOptionalObject)(record, "timings", "diagramBootstrapPayload");
    if (!timings) {
        return undefined;
    }
    return {
        analyzerBootstrapMs: (0, runtimeGuards_1.readOptionalNumber)(timings, "analyzerBootstrapMs", "diagramBootstrapPayload.timings"),
        discoveryMs: (0, runtimeGuards_1.readOptionalNumber)(timings, "discoveryMs", "diagramBootstrapPayload.timings"),
        extractMs: (0, runtimeGuards_1.readOptionalNumber)(timings, "extractMs", "diagramBootstrapPayload.timings"),
        graphMs: (0, runtimeGuards_1.readOptionalNumber)(timings, "graphMs", "diagramBootstrapPayload.timings"),
        layoutMs: (0, runtimeGuards_1.readOptionalNumber)(timings, "layoutMs", "diagramBootstrapPayload.timings"),
        ogdfLayoutMs: (0, runtimeGuards_1.readOptionalNumber)(timings, "ogdfLayoutMs", "diagramBootstrapPayload.timings"),
        parseMs: (0, runtimeGuards_1.readOptionalNumber)(timings, "parseMs", "diagramBootstrapPayload.timings"),
        renderDocumentMs: (0, runtimeGuards_1.readOptionalNumber)(timings, "renderDocumentMs", "diagramBootstrapPayload.timings"),
    };
}
function decodeModelField(value, context) {
    const record = (0, runtimeGuards_1.readRecord)(value, context);
    const choiceMetadata = (0, runtimeGuards_1.readOptionalObject)(record, "choiceMetadata", context);
    const relation = (0, runtimeGuards_1.readOptionalObject)(record, "relation", context);
    return {
        choiceMetadata: choiceMetadata
            ? decodeChoiceFieldMetadata(choiceMetadata, `${context}.choiceMetadata`)
            : undefined,
        fieldType: (0, runtimeGuards_1.readString)(record, "fieldType", context),
        name: (0, runtimeGuards_1.readString)(record, "name", context),
        nullable: (0, runtimeGuards_1.readBoolean)(record, "nullable", context),
        persistence: (0, runtimeGuards_1.readLiteral)(record, "persistence", ["computed", "stored"], context),
        primaryKey: (0, runtimeGuards_1.readBoolean)(record, "primaryKey", context),
        relation: relation ? decodeFieldRelation(relation, `${context}.relation`) : undefined,
    };
}
function decodeModelIdentity(record, context) {
    const appLabel = (0, runtimeGuards_1.readString)(record, "appLabel", context);
    const modelName = (0, runtimeGuards_1.readString)(record, "modelName", context);
    const id = (0, runtimeGuards_1.readModelId)(record, "id", context);
    const canonicalId = (0, modelIdentity_1.makeModelId)(appLabel, modelName);
    if (id !== canonicalId) {
        throw new Error(`${context}.id must match ${canonicalId}.`);
    }
    return {
        appLabel,
        id,
        modelName,
        modulePath: (0, runtimeGuards_1.readOptionalString)(record, "modulePath", context),
    };
}
function decodeNodeLayout(value, context) {
    const record = (0, runtimeGuards_1.readRecord)(value, context);
    const clusterId = typeof record.clusterId === "string" && record.clusterId.length > 0
        ? record.clusterId
        : undefined;
    return {
        clusterId,
        modelId: (0, runtimeGuards_1.readModelId)(record, "modelId", context),
        position: decodePoint((0, runtimeGuards_1.readRecord)(record.position, `${context}.position`), `${context}.position`),
        size: decodeSize((0, runtimeGuards_1.readRecord)(record.size, `${context}.size`), `${context}.size`),
    };
}
function decodePoint(record, context) {
    return {
        x: (0, runtimeGuards_1.readNumber)(record, "x", context),
        y: (0, runtimeGuards_1.readNumber)(record, "y", context),
    };
}
function decodePropertyAttribute(value, context) {
    const record = (0, runtimeGuards_1.readRecord)(value, context);
    return {
        name: (0, runtimeGuards_1.readString)(record, "name", context),
        returnType: (0, runtimeGuards_1.readOptionalString)(record, "returnType", context),
    };
}
function decodeRelationTargetReference(record, context) {
    return {
        appLabelHint: (0, runtimeGuards_1.readOptionalString)(record, "appLabelHint", context),
        rawReference: (0, runtimeGuards_1.readString)(record, "rawReference", context),
        resolutionState: (0, runtimeGuards_1.readLiteral)(record, "resolutionState", ["deferred", "resolved", "unresolved"], context),
        resolvedModelId: (0, runtimeGuards_1.readOptionalModelId)(record, "resolvedModelId", context),
    };
}
function decodeRoutedEdgePath(value, context) {
    const record = (0, runtimeGuards_1.readRecord)(value, context);
    return {
        crossingIds: (0, runtimeGuards_1.readStringArray)(record, "crossingIds", context),
        edgeId: (0, runtimeGuards_1.readString)(record, "edgeId", context),
        points: (0, runtimeGuards_1.readArray)(record, "points", context).map((item, index) => decodePoint((0, runtimeGuards_1.readRecord)(item, `${context}.points[${index}]`), `${context}.points[${index}]`)),
        sourceModelId: (0, runtimeGuards_1.readOptionalModelId)(record, "sourceModelId", context),
        targetModelId: (0, runtimeGuards_1.readOptionalModelId)(record, "targetModelId", context),
    };
}
function decodeSelectedMethodContext(record, context) {
    return {
        methodName: (0, runtimeGuards_1.readString)(record, "methodName", context),
        modelId: (0, runtimeGuards_1.readModelId)(record, "modelId", context),
    };
}
function decodeSize(record, context) {
    return {
        height: (0, runtimeGuards_1.readNumber)(record, "height", context),
        width: (0, runtimeGuards_1.readNumber)(record, "width", context),
    };
}
function decodeSourceLocation(record, context) {
    const range = (0, runtimeGuards_1.readOptionalObject)(record, "range", context);
    return {
        filePath: (0, runtimeGuards_1.readString)(record, "filePath", context),
        range: range ? decodeSourceRange(range, `${context}.range`) : undefined,
        symbolName: (0, runtimeGuards_1.readOptionalString)(record, "symbolName", context),
    };
}
function decodeSourceRange(record, context) {
    return {
        endColumn: (0, runtimeGuards_1.readNumber)(record, "endColumn", context),
        endLine: (0, runtimeGuards_1.readNumber)(record, "endLine", context),
        startColumn: (0, runtimeGuards_1.readNumber)(record, "startColumn", context),
        startLine: (0, runtimeGuards_1.readNumber)(record, "startLine", context),
    };
}
function decodeStructuralGraphEdge(value, context) {
    const record = (0, runtimeGuards_1.readRecord)(value, context);
    return {
        id: (0, runtimeGuards_1.readString)(record, "id", context),
        kind: (0, runtimeGuards_1.readLiteral)(record, "kind", [
            "foreign_key",
            "many_to_many",
            "one_to_one",
            "reverse_foreign_key",
            "reverse_many_to_many",
            "reverse_one_to_one",
            "inheritance",
        ], context),
        provenance: (0, runtimeGuards_1.readLiteral)(record, "provenance", ["declared", "derived_reverse"], context),
        sourceModelId: (0, runtimeGuards_1.readModelId)(record, "sourceModelId", context),
        targetModelId: (0, runtimeGuards_1.readModelId)(record, "targetModelId", context),
    };
}
function decodeTableViewOptions(value, context) {
    const record = (0, runtimeGuards_1.readRecord)(value, context);
    const manualPosition = (0, runtimeGuards_1.readOptionalObject)(record, "manualPosition", context);
    return {
        hidden: (0, runtimeGuards_1.readBoolean)(record, "hidden", context),
        manualPosition: manualPosition
            ? decodePoint(manualPosition, `${context}.manualPosition`)
            : undefined,
        modelId: (0, runtimeGuards_1.readModelId)(record, "modelId", context),
        showMethodHighlights: (0, runtimeGuards_1.readBoolean)(record, "showMethodHighlights", context),
        showMethods: (0, runtimeGuards_1.readBoolean)(record, "showMethods", context),
        showProperties: (0, runtimeGuards_1.readBoolean)(record, "showProperties", context),
    };
}
function decodeUserMethod(value, context) {
    const record = (0, runtimeGuards_1.readRecord)(value, context);
    return {
        name: (0, runtimeGuards_1.readString)(record, "name", context),
        relatedModels: (0, runtimeGuards_1.readArray)(record, "relatedModels", context).map((item, index) => decodeMethodRelatedModelReference(item, `${context}.relatedModels[${index}]`)),
        visibility: (0, runtimeGuards_1.readLiteral)(record, "visibility", ["private", "protected", "public"], context),
    };
}
function decodeViewState(record) {
    const selectedMethodContext = (0, runtimeGuards_1.readOptionalObject)(record, "selectedMethodContext", "diagramBootstrapPayload.view");
    const viewportRecord = (0, runtimeGuards_1.readOptionalObject)(record, "viewport", "diagramBootstrapPayload.view");
    return {
        collapseClusters: record.collapseClusters === true,
        edgeBundling: record.edgeBundling === true,
        useEdgeBends: record.useEdgeBends === true,
        clusterGraphLayout: record.clusterGraphLayout === true,
        bubbleLayout: record.bubbleLayout === true,
        optimizedLayout: record.optimizedLayout === true,
        layoutMode: (0, runtimeGuards_1.readLiteral)(record, "layoutMode", layoutContract_1.OGDF_LAYOUT_MODES, "diagramBootstrapPayload.view"),
        selectedMethodContext: selectedMethodContext
            ? decodeSelectedMethodContext(selectedMethodContext, "diagramBootstrapPayload.view.selectedMethodContext")
            : undefined,
        selectedModelId: (0, runtimeGuards_1.readOptionalModelId)(record, "selectedModelId", "diagramBootstrapPayload.view"),
        tableOptions: (0, runtimeGuards_1.readArray)(record, "tableOptions", "diagramBootstrapPayload.view").map((item, index) => decodeTableViewOptions(item, `diagramBootstrapPayload.view.tableOptions[${index}]`)),
        viewport: viewportRecord
            ? decodeViewportSnapshot(viewportRecord, "diagramBootstrapPayload.view.viewport")
            : undefined,
    };
}
function decodeViewportSnapshot(record, context) {
    return {
        panX: (0, runtimeGuards_1.readNumber)(record, "panX", context),
        panY: (0, runtimeGuards_1.readNumber)(record, "panY", context),
        zoom: (0, runtimeGuards_1.readNumber)(record, "zoom", context),
    };
}
function decodeEdgeCrossing(value, context) {
    const record = (0, runtimeGuards_1.readRecord)(value, context);
    const edgeIds = (0, runtimeGuards_1.readStringArray)(record, "edgeIds", context);
    if (edgeIds.length !== 2) {
        throw new Error(`${context}.edgeIds must contain exactly two edge IDs.`);
    }
    return {
        edgeIds: [edgeIds[0], edgeIds[1]],
        id: (0, runtimeGuards_1.readString)(record, "id", context),
        markerStyle: (0, runtimeGuards_1.readLiteral)(record, "markerStyle", ["bridge", "marker"], context),
        position: decodePoint((0, runtimeGuards_1.readRecord)(record.position, `${context}.position`), `${context}.position`),
    };
}
