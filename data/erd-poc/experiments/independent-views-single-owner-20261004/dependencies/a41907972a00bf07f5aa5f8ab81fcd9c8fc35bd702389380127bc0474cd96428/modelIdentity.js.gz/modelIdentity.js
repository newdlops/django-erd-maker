"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.makeModelId = makeModelId;
exports.isModelId = isModelId;
function makeModelId(appLabel, modelName) {
    return `${appLabel}.${modelName}`;
}
function isModelId(value) {
    const segments = value.split(".");
    return segments.length === 2 && segments.every((segment) => segment.length > 0);
}
