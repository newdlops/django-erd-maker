"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.acquireOptimizedLayoutFlight = acquireOptimizedLayoutFlight;
exports.compareOptimizedLayoutQuality = compareOptimizedLayoutQuality;
exports.selectPreferredOptimizedLayoutJson = selectPreferredOptimizedLayoutJson;
exports.preserveBestOptimizedLayoutCache = preserveBestOptimizedLayoutCache;
const promises_1 = require("node:fs/promises");
const decodeDiagramBootstrap_1 = require("../../../shared/protocol/decodeDiagramBootstrap");
const canonicalCrossingNonRegression_1 = require("./canonicalCrossingNonRegression");
const optimizedLayoutFlights = new Map();
// A keyed FIFO lease keeps identical optimized runs from racing on the same
// cache file. Followers wait for the producer, then re-check the cache and
// reuse its result. Different topology/options keys remain fully concurrent.
async function acquireOptimizedLayoutFlight(key, onWait, maxWaitMs) {
    const previous = optimizedLayoutFlights.get(key);
    let resolveCurrent;
    const current = new Promise((resolve) => {
        resolveCurrent = resolve;
    });
    optimizedLayoutFlights.set(key, current);
    if (previous) {
        onWait?.();
        try {
            await waitForPreviousFlight(previous, key, maxWaitMs);
        }
        catch (error) {
            // Do not leave this follower as another permanently-pending queue head.
            // A timed-out producer may never release, so remove the follower and let
            // a later request make progress after the native process is reaped.
            resolveCurrent?.();
            if (optimizedLayoutFlights.get(key) === current) {
                optimizedLayoutFlights.delete(key);
            }
            throw error;
        }
    }
    let released = false;
    return {
        waited: previous !== undefined,
        release() {
            if (released) {
                return;
            }
            released = true;
            resolveCurrent?.();
            if (optimizedLayoutFlights.get(key) === current) {
                optimizedLayoutFlights.delete(key);
            }
        },
    };
}
async function waitForPreviousFlight(previous, key, maxWaitMs) {
    if (maxWaitMs === undefined
        || !Number.isFinite(maxWaitMs)
        || maxWaitMs <= 0) {
        await previous;
        return;
    }
    let timeout;
    try {
        await Promise.race([
            previous,
            new Promise((_resolve, reject) => {
                timeout = setTimeout(() => {
                    reject(new Error(`optimized layout in-flight wait timed out after ${Math.round(maxWaitMs)}ms`
                        + ` · key=${key}`));
                }, maxWaitMs);
            }),
        ]);
    }
    finally {
        if (timeout !== undefined) {
            clearTimeout(timeout);
        }
    }
}
const AUTHORITATIVE_VISIBLE_VISUAL_SCOPE = "rendered-canonical-direct-node-bundles-v3";
function hasAuthoritativeVisibleVisualScope(metadata) {
    return metadata?.visualCrossingsScope === AUTHORITATIVE_VISIBLE_VISUAL_SCOPE;
}
// Negative means left is preferable, positive means right is preferable. New
// snapshots measure visualCrossings from every visible semantic carrier
// segment, including branches, trunks, and table penetrations, so that the
// exact scene is primary.
// Legacy carrier-scoped snapshots retain the older raw-route-first ordering.
function compareOptimizedLayoutQuality(left, right, targets = {}) {
    const exactVisibleScene = hasAuthoritativeVisibleVisualScope(left)
        && hasAuthoritativeVisibleVisualScope(right);
    if (exactVisibleScene) {
        // Once both requested limits are met, an area-invalid result cannot win
        // merely by having one fewer crossing. Route/canonical safety gates are
        // still applied by selection before this quality comparison.
        const leftMeetsTargets = meetsVisualAndAreaTargets(left, targets);
        const rightMeetsTargets = meetsVisualAndAreaTargets(right, targets);
        if (leftMeetsTargets !== rightMeetsTargets) {
            return leftMeetsTargets ? -1 : 1;
        }
    }
    const lowerIsBetter = exactVisibleScene
        ? [
            "visualCrossings",
            "nodeOverlaps",
            "edgeNodeIntersections",
            "edgeCrossings",
            "rawRouteCrossings",
            "bundleNodeOverlaps",
            "bundleEdgeIntersections",
            "overlappingEdges",
            "edgeSegmentOverlaps",
            "nodeSpacingOverlaps",
            "boundingBoxArea",
        ]
        : [
            "rawRouteCrossings",
            "visualCrossings",
            "nodeOverlaps",
            "bundleNodeOverlaps",
            "edgeNodeIntersections",
            "edgeCrossings",
            "bundleEdgeIntersections",
            "overlappingEdges",
            "edgeSegmentOverlaps",
            "nodeSpacingOverlaps",
            "boundingBoxArea",
        ];
    for (const key of lowerIsBetter) {
        const comparison = compareFiniteMetric(left?.[key], right?.[key]);
        if (comparison !== 0) {
            return comparison;
        }
    }
    const leftQuality = finiteNumber(left?.compositeQuality);
    const rightQuality = finiteNumber(right?.compositeQuality);
    if (leftQuality === undefined && rightQuality === undefined) {
        return 0;
    }
    if (leftQuality === undefined) {
        return 1;
    }
    if (rightQuality === undefined) {
        return -1;
    }
    return rightQuality - leftQuality;
}
function meetsVisualAndAreaTargets(metadata, targets) {
    const visual = finiteNumber(metadata?.visualCrossings);
    const area = finiteNumber(metadata?.boundingBoxArea);
    const areaTarget = targets.boundingBoxArea ?? 1e9;
    return visual !== undefined
        && visual >= 0
        && visual <= (targets.visualCrossings ?? 500)
        && area !== undefined
        && area > 0
        && (areaTarget <= 0 || area <= areaTarget);
}
function selectPreferredOptimizedLayoutJson(existingJson, candidateJson, options = {}) {
    const candidate = (0, decodeDiagramBootstrap_1.decodeLayoutSnapshot)(JSON.parse(candidateJson), "ogdfOptimizedLayoutCacheCandidate");
    let existing;
    try {
        existing = (0, decodeDiagramBootstrap_1.decodeLayoutSnapshot)(JSON.parse(existingJson), "ogdfOptimizedLayoutCacheExisting");
    }
    catch {
        return selection("candidate", candidateJson, undefined, candidate);
    }
    const exactVisibleScene = hasAuthoritativeVisibleVisualScope(existing.engineMetadata)
        && hasAuthoritativeVisibleVisualScope(candidate.engineMetadata);
    if (!exactVisibleScene
        && !(0, canonicalCrossingNonRegression_1.evaluateAllEdgeCrossingNonRegression)(existing.engineMetadata, candidate.engineMetadata).ok) {
        return selection("existing", existingJson, existing, candidate, "all-edge-non-regression");
    }
    if (!(0, canonicalCrossingNonRegression_1.evaluateCanonicalCrossingNonRegression)(existing.engineMetadata, candidate.engineMetadata).ok) {
        return selection("existing", existingJson, existing, candidate, "canonical-non-regression");
    }
    const canonicalObstacleRelief = (0, canonicalCrossingNonRegression_1.evaluateCanonicalObstacleRelief)(existing.engineMetadata, candidate.engineMetadata, finiteNumber(existing.engineMetadata?.visualCrossings) ?? Number.NaN, finiteNumber(candidate.engineMetadata?.visualCrossings) ?? Number.NaN, options.maxCanonicalVisualDebtPerGain
        ?? canonicalCrossingNonRegression_1.DEFAULT_CANONICAL_OBSTACLE_RELIEF_MAX_VISUAL_DEBT_PER_GAIN);
    if (canonicalObstacleRelief.ok) {
        return selection("candidate", candidateJson, existing, candidate, undefined, "canonical-obstacle-relief");
    }
    if (compareOptimizedLayoutQuality(existing.engineMetadata, candidate.engineMetadata, options.qualityTargets) <= 0) {
        return selection("existing", existingJson, existing, candidate, "quality");
    }
    return selection("candidate", candidateJson, existing, candidate, undefined, "quality");
}
// The caller holds the in-process flight lease. Re-reading immediately before
// write also protects against a result produced by another extension host or
// an execution that began before the current host acquired its lease.
async function preserveBestOptimizedLayoutCache(cachePath, candidateJson, options = {}) {
    let result;
    try {
        const existingJson = await (0, promises_1.readFile)(cachePath, "utf8");
        result = selectPreferredOptimizedLayoutJson(existingJson, candidateJson, options);
    }
    catch {
        const candidate = (0, decodeDiagramBootstrap_1.decodeLayoutSnapshot)(JSON.parse(candidateJson), "ogdfOptimizedLayoutCacheCandidate");
        result = selection("candidate", candidateJson, undefined, candidate);
    }
    if (result.source === "candidate") {
        await (0, promises_1.writeFile)(cachePath, result.json, "utf8");
    }
    return result;
}
function compareFiniteMetric(left, right) {
    const leftNumber = finiteNumber(left);
    const rightNumber = finiteNumber(right);
    if (leftNumber === undefined && rightNumber === undefined) {
        return 0;
    }
    if (leftNumber === undefined) {
        return 1;
    }
    if (rightNumber === undefined) {
        return -1;
    }
    return leftNumber - rightNumber;
}
function finiteNumber(value) {
    return typeof value === "number" && Number.isFinite(value)
        ? value
        : undefined;
}
function selection(source, json, existing, candidate, preservationReason, candidateReason) {
    return {
        candidateReason,
        candidateVisualCrossings: finiteNumber(candidate.engineMetadata?.visualCrossings),
        existingVisualCrossings: finiteNumber(existing?.engineMetadata?.visualCrossings),
        json,
        preservationReason,
        source,
    };
}
