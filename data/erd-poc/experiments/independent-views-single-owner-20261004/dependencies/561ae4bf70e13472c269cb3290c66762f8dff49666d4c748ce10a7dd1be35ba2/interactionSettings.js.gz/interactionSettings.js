"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DEFAULT_INTERACTION_SETTINGS = exports.INTERACTION_SETTING_DESCRIPTORS = void 0;
exports.clampInteractionSetting = clampInteractionSetting;
exports.formatInteractionSettingValue = formatInteractionSettingValue;
exports.normalizeInteractionSettings = normalizeInteractionSettings;
exports.INTERACTION_SETTING_DESCRIPTORS = [
    {
        hint: "Canvas drag sensitivity.",
        key: "panSpeed",
        label: "Pan Speed",
        max: 1.5,
        min: 0.25,
        step: 0.05,
    },
    {
        hint: "Wheel and toolbar zoom sensitivity.",
        key: "zoomSpeed",
        label: "Zoom Speed",
        max: 1.5,
        min: 0.1,
        step: 0.05,
    },
];
exports.DEFAULT_INTERACTION_SETTINGS = {
    panSpeed: 0.7,
    zoomSpeed: 0.6,
};
const INTERACTION_SETTING_LIMITS = new Map(exports.INTERACTION_SETTING_DESCRIPTORS.map((descriptor) => [descriptor.key, descriptor]));
function clampInteractionSetting(key, value) {
    const descriptor = INTERACTION_SETTING_LIMITS.get(key);
    const fallback = exports.DEFAULT_INTERACTION_SETTINGS[key];
    if (!descriptor || !Number.isFinite(value)) {
        return fallback;
    }
    return roundToStep(Math.max(descriptor.min, Math.min(descriptor.max, value)), descriptor.step);
}
function formatInteractionSettingValue(value) {
    return `${Math.round(value * 100)}%`;
}
function normalizeInteractionSettings(value) {
    return {
        panSpeed: clampInteractionSetting("panSpeed", value?.panSpeed ?? exports.DEFAULT_INTERACTION_SETTINGS.panSpeed),
        zoomSpeed: clampInteractionSetting("zoomSpeed", value?.zoomSpeed ?? exports.DEFAULT_INTERACTION_SETTINGS.zoomSpeed),
    };
}
function roundToStep(value, step) {
    return Math.round(Math.round(value / step) * step * 100) / 100;
}
