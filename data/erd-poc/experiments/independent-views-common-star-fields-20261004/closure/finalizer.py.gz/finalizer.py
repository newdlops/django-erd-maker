"""Bind final closure and retain a precise post-seal documentation correction."""
import gzip
import hashlib
import json
from pathlib import Path


def digest(path, packed=False):
    h = hashlib.sha256()
    with (gzip.open(path, 'rb') if packed else Path(path).open('rb')) as stream:
        while block := stream.read(65536):
            h.update(block)
    return h.hexdigest()


receipt = json.loads(Path('.tmp/common-star-fields-archive-seal-receipt.json').read_text())
proof_path = Path('.tmp/common-star-fields-archive-independent-verification.json')
proof = json.loads(proof_path.read_text())
manifest_path = Path(receipt['manifest'])
assert proof['status'] == 'pass' and digest(manifest_path) == receipt['manifestSha256'] == proof['manifestSha256']
manifest = json.loads(manifest_path.read_text())
changed = [item['source'] for category in ('files', 'referencedFiles') for item in manifest[category]
    if digest(item['source']) != item['sha256']]
assert changed == ['context.md'], changed
assert manifest['rollup']['stages']['individual-component1']['actualTrainedVisuals'] == [2243, 2227, 2220, 2217]
archive = manifest_path.parent
extras = (('context.md', Path('context.md')), ('finalizer.py', Path(__file__)),
    ('independent-restore.json', proof_path),
    ('archive-seal2.guard.log', Path('.tmp/common-star-fields-archive-seal2.guard.log')),
    ('archive-restore.guard.log', Path('.tmp/common-star-fields-archive-restore.guard.log')))
retained = []
for name, source in extras:
    target = archive / 'closure' / (name + '.gz')
    target.parent.mkdir(exist_ok=True)
    with target.open('xb') as destination, gzip.GzipFile(filename='', mode='wb', compresslevel=1,
        mtime=0, fileobj=destination) as packed, source.open('rb') as original:
        while block := original.read(65536):
            packed.write(block)
    assert digest(target, True) == digest(source)
    retained.append(dict(source=str(source), archive=str(target.relative_to(archive)), sha256=digest(source)))
record = dict(status='pass', verifiedManifestSha256=receipt['manifestSha256'],
    restoredMappingsAtSeal=proof['allMappingsRestoredAndLiveMatched'], distinctStoredObjects=proof['distinctStoredObjects'],
    currentBindingsMatched=proof['allMappingsRestoredAndLiveMatched'] - 1,
    currentNumericCodeCheckpointAndSourceBindingsUnchanged=True,
    postSealDocumentationCorrection=dict(source='context.md', correctedTrainedOutputVisuals=[2243, 2227, 2220, 2217],
        priorApproximateRange=[2217, 2227], archivedNumericalRollupAlreadyCorrect=True),
    extraFiles=retained, reviewCandidateSha256=manifest['reviewSha256'],
    bestCandidateSha256=manifest['candidateSha256'], strictImprovements=0,
    overviewVisual=285, individualVisual=1963, reviewOverviewVisual=287, reviewIndividualVisual=1963,
    targetMet=False, goalContinues=True, allRequiredVerificationJobsTerminal=True,
    browserVerified=False, fullTypecheckPassed=False, memoryLimitMiB=128,
    nextStep='Prove a nontrivial legal response of a source-preserving, tied original-card phase field before longer reward learning')
path = archive / 'final-artifact-record.json'
with path.open('x') as stream:
    stream.write(json.dumps(record, indent=2) + '\n')
print(json.dumps(dict(status='pass', finalRecord=str(path), sha256=digest(path),
    manifestSha256=receipt['manifestSha256'], goalComplete=False)), flush=True)
