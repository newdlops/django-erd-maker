"""Bind the verified 285/1963 NN geometry without proposing coordinates."""
from pathlib import Path
import hashlib
import json

source = Path('.tmp/prepare_global_owner_walk.py')
out = Path('.tmp/prepare_geometry_world_sources.py')
assert not out.exists()
text = source.read_text().split("\noriginal = Path('scripts/erd-poc/run_single_owner_neural_walk_v3.py')")[0]
changes = {
    "single-owner-global-walk1')\nprior = Path('.tmp/visualcross-ml-150-750-20261004/single-owner-trained-walk1')":
    "geometry-world1')\nprior = Path('.tmp/visualcross-ml-150-750-20261004/single-owner-global-walk1')",
    '4c88250bd2dce3ffb85d640c35d11d952664b0358658a0f0b35b94cbccd28688':
    '4e741de39ca655c7ff042422b9407206427f89e02ecd56b7f4a9f36f6a5cd02e',
    "(audit['overviewVisual'], audit['individualVisual']) == (286, 1963)":
    "(audit['overviewVisual'], audit['individualVisual']) == (285, 1963)",
    "winner = prior / 'overview-global1'": "winner = prior / 'overview-trained1'",
    "report['final']['visual'] == 286": "report['final']['visual'] == 285"
}
for old, new in changes.items():
    assert text.count(old) == 1, old
    text = text.replace(old, new)
text += "\nprint(json.dumps({'preparedViews': list(views), 'expectedVisual': {'overview': 285, 'individual': 1963}, 'newCoordinateProposals': 0}), flush=True)\n"
out.write_text(text)
print(json.dumps({'sourcePreparer': str(out), 'sha256': hashlib.sha256(out.read_bytes()).hexdigest()}), flush=True)
