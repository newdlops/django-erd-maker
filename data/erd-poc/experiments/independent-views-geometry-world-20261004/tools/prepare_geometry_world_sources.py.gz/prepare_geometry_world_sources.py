"""Bind the current NN-generated 286/1963 geometry for fresh global trajectories."""
from pathlib import Path
import hashlib
import json
import shutil


def digest(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


root = Path('.tmp/visualcross-ml-150-750-20261004/geometry-world1')
prior = Path('.tmp/visualcross-ml-150-750-20261004/single-owner-global-walk1')
candidate = Path('data/erd-poc/candidates/captain-ml-independent-views.layout.json')
assert digest(candidate) == '4e741de39ca655c7ff042422b9407206427f89e02ecd56b7f4a9f36f6a5cd02e'
layout = json.loads(candidate.read_text())
audit_path = candidate.with_name('captain-ml-independent-views.audit.json')
audit = json.loads(audit_path.read_text())
assert (audit['overviewVisual'], audit['individualVisual']) == (285, 1963)
binding = json.loads((prior / 'source-binding.json').read_text())
winner = prior / 'overview-trained1'
report = json.loads((winner / 'report.json').read_text())
assert report['final']['visual'] == 285 and report['savedGeometryMatchesModelOutput']
root.mkdir(exist_ok=False)
views = {}
for view in ('overview', 'individual'):
    source = Path(binding['viewSources'][view]['directory'])
    out = root / (view + '-source' + str(audit[view + 'Visual']))
    out.mkdir()
    for name, value in binding['viewSources'][view]['inputs'].items():
        assert digest(source / name) == value
        shutil.copyfile(source / name, out / name)
    if view == 'overview':
        for target, saved in [('positions.tsv', 'learned.tsv'), ('routes.tsv', 'learned.tsv.routes.tsv'),
                              ('individual.positions.tsv', 'learned.tsv.individual'),
                              ('individual.routes.tsv', 'learned.tsv.individual.routes.tsv')]:
            shutil.copyfile(winner / saved, out / target)
        exported = json.loads((source / 'export.json').read_text())
        applied = json.loads((prior / 'overview-product1/proposal.audit.json').read_text())
        exported.update(sourceFile=audit['overviewSource'], sourceSha256=audit['overviewSourceSha256'],
                        baseline=applied['metrics'], individualBaseline=applied['candidateIndividual'],
                        bboxB=applied['bboxArea'] / 1e9)
        (out / 'export.json').write_text(json.dumps(exported, indent=2) + '\n')
        geometry_nodes = layout['nodes']
        physical = json.loads((prior / 'overview-product1/product.scene.json').read_text())['tables']
        positions = {key: (float(x), float(y)) for key, x, y in
                     (line.split('\t') for line in (out / 'positions.tsv').read_text().splitlines())}
        assert len(positions) == len(physical) == 1035
        for node in physical:
            p = positions[node['modelId']]
            assert abs(p[0] - node['position']['x'] - node['size']['width'] / 2) < 1e-8
            assert abs(p[1] - node['position']['y'] - node['size']['height'] / 2) < 1e-8
    else:
        geometry_nodes = layout['individualView']['nodes']
    positions = {key: (float(x), float(y)) for key, x, y in
                 (line.split('\t') for line in (out / 'individual.positions.tsv').read_text().splitlines())}
    assert len(positions) == len(geometry_nodes) == 1244
    for node in geometry_nodes:
        p = positions[node['modelId']]
        assert abs(p[0] - node['position']['x'] - node['size']['width'] / 2) < 1e-8
        assert abs(p[1] - node['position']['y'] - node['size']['height'] / 2) < 1e-8
    views[view] = {'directory': str(out),
                   'inputs': {name: digest(out / name) for name in binding['viewSources'][view]['inputs']},
                   'expectedVisual': audit[view + 'Visual']}
record = {'viewSources': views, 'promotedCandidateSha256': digest(candidate),
          'promotedAuditSha256': digest(audit_path), 'geometryChosenByNewCode': False,
          'modelSavedOverviewReport': str(winner / 'report.json'),
          'modelSavedOverviewReportSha256': digest(winner / 'report.json'),
          'individualCopiedFromVerified1963Source': True}
(root / 'source-binding.json').write_text(json.dumps(record, indent=2) + '\n')

print(json.dumps({'preparedViews': list(views), 'expectedVisual': {'overview': 285, 'individual': 1963}, 'newCoordinateProposals': 0}), flush=True)
