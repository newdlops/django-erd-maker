"""Replay all NN rankings and independently full-measure every attempted move."""
import hashlib
import json
from pathlib import Path
import sys
import numpy as np
sys.path.insert(0,str(Path('scripts/erd-poc').resolve()))
from geometry_world_model import load, digest, WorldProxy as SingleProxy
from geometry_world_multi_owner import WorldProxy as PairProxy
from geometry_world_port_model import PortDecoder, WorldProxy as PortProxy, PATTERNS, same_face_patterns
from run_geometry_world_port_policy import decode_row, PREFIXES
from run_geometry_world_policy import source_geometry, PRIOR_WEIGHT
from run_geometry_world_local_swap_policy import LocalSwapDecoder
from run_single_owner_cycle_policy_v4 import prepare
from single_owner_cycle_model import load as load_actor, AMPLITUDES, action
from run_anchor_pair_walk import WalkDecoder, verify_saved
from run_anchor_pair_policy import Native, wire
from single_owner_cached_observer_v2 import CachedObserver

ROOT=Path('.tmp/visualcross-ml-150-750-20261004/geometry-world1'); OUT=ROOT/'verification'
FIELDS=('legal','reason','visual','individualVisual','hard','individualHard','spacing')
CASES=['individual-trained1','overview-trained1','individual-swap-trained1','overview-swap-trained1',
       'individual-local-trained1','individual-ports-trained1','overview-ports-trained1']
models,_=load(ROOT/'training2/model.npz'); reports=[]; totals={'rankings':0,'actions':0,'fullMeasurements':0,'slowDecoderControls':0}
for name in CASES:
    stage=ROOT/name; report=json.loads((stage/'report.json').read_text()); directory=Path(report['sourceDirectory'])
    for file,sha in report['codeSha256'].items(): assert digest(Path('scripts/erd-poc')/file)==sha
    for file,sha in report['sourceInputs'].items(): assert digest(directory/file)==sha
    for file,key in [('actions.jsonl','actionsSha256'),('ranking.jsonl','rankingSha256'),('observations.npz','observationsSha256')]:
        assert digest(stage/file)==report[key]
    assert digest(report['worldCheckpoint'])==report['worldSha256'] and digest(report['environment'])==report['environmentSha256']
    assert digest(report['sourceBinding'])==report['sourceBindingSha256']
    assert report['nativeSearchCalls']==report['coordinateRepairs']==report['newTrainingUpdatesDuringInference']==0
    rows=[json.loads(line) for line in (stage/'ranking.jsonl').read_text().splitlines()]
    actions=[json.loads(line) for line in (stage/'actions.jsonl').read_text().splitlines()]
    decoder=WalkDecoder(directory); observer=CachedObserver(directory,decoder)
    zero=decoder.decode(np.arange(len(decoder.positions),dtype=np.int32))
    before,sizes,edges=source_geometry(observer,zero,report['view'])
    full_out=OUT/name; full_out.mkdir(exist_ok=False)
    native=Native(Path(report['environment']),directory,full_out/'learned.tsv',report['view']=='overview',False)
    errors=[]; legal=0; slow=0
    try:
        baseline=native.request(wire(zero,'MEASURE')); totals['fullMeasurements']+=1
        assert baseline['legal'] and baseline['visual']==report['initialVisual']
        nodes=np.array([n['features'] for n in native.initial['nodes']])
        with np.load(stage/'observations.npz',allow_pickle=False) as obs:
            assert np.array_equal(nodes,obs['nodes'])
            if '-ports-' in name:
                ports=PortDecoder(observer,zero,report['view']); before=ports.geometry(zero); proxy=PortProxy(models)
                active=np.any(nodes[:,4:6]>0,axis=1); eligible=np.flatnonzero(active[decoder.provider.owner_edges].any(1))
                if report['view']=='overview': eligible=eligible[ports.group_index[eligible]>=0]
                selected=np.random.default_rng(report['seed']).choice(eligible,min(report['edgesRequested'],len(eligible)),replace=False)
                assert np.array_equal(eligible,obs['eligible_edges']) and np.array_equal(selected,obs['chosen_edges'])
                words=np.array([(int(e),p) for e in selected for p in same_face_patterns(ports,int(e))],dtype=np.int32)
                assert np.array_equal(words[:len(obs['words'])],obs['words'])
                singles=rows[:report['singleCandidatesScored']]
                single_order=np.argsort(-np.array([r['score'] for r in singles]),kind='stable'); unique=[]; seen=set()
                for index in single_order:
                    row=singles[int(index)]
                    if row['score']<=.5 or row['edge'] in seen: continue
                    unique.append(int(index)); seen.add(row['edge'])
                    if len(unique)==max(PREFIXES): break
                assert np.array_equal(np.array(unique,dtype=np.int32),obs['positive_unique_indices'])
                joint_parts=[unique[:count] for count in PREFIXES if count<=len(unique)]
                assert [row['parts'] for row in rows[len(singles):]]==joint_parts
                for i,row in enumerate(singles): assert [row['edge'],row['pattern']]==obs['words'][i].tolist()
                make=lambda row:decode_row(zero,ports.n,row,singles)
                geometry=lambda proposed:ports.geometry(proposed)
                predicted_key='prediction'; score_weight=0.
            elif '-swap-' in name or '-local-' in name:
                support_decoder=LocalSwapDecoder(directory) if '-local-' in name else decoder
                vocabulary=support_decoder.eligible_pairs(report['seed'],report['vocabularyRequested'])
                active=np.any(nodes[:,4:6]>0,axis=1); vocabulary=vocabulary[active[vocabulary].any(1)]
                assert np.array_equal(vocabulary,obs['vocabulary'])
                assert all(row['owners']==vocabulary[i].tolist() for i,row in enumerate(rows))
                proxy=PairProxy(models); make=lambda row:decoder.action(*row['owners'])
                geometry=lambda proposed:source_geometry(observer,proposed,report['view'])[0]
                predicted_key='prediction'; score_weight=0.
            else:
                assert digest(report['actorCheckpoint'])==report['actorSha256']
                actor,_=load_actor(Path(report['actorCheckpoint']))
                cycles,support,prior,hashes,error,allowed,noise,prior_policy,chosen,dedup=prepare(
                    actor,decoder,nodes,report['view'],report['seed'],1024,report['shortlistRequested'])
                for a,b in [(cycles,obs['cycles']),(prior,obs['prior_scores']),(allowed,obs['allowed_indices']),
                    (noise,obs['gumbel']),(chosen,obs['shortlist'])]: assert np.array_equal(a,b)
                assert hashes==report['priorFeatureChunkHashes'] and dedup==report['deduplication']
                assert all([row['cycleIndex'],row['amplitudeIndex']]==chosen[i].tolist() for i,row in enumerate(rows))
                proxy=SingleProxy(models); make=lambda row:action(decoder,cycles[row['cycleIndex']],AMPLITUDES[row['amplitudeIndex']])
                geometry=lambda proposed:source_geometry(observer,proposed,report['view'])[0]
                predicted_key='worldPrediction'; score_weight=PRIOR_WEIGHT
            scores=[]
            for row in rows:
                proposed=make(row); after=geometry(proposed)
                assert hashlib.sha256(wire(proposed).encode()).hexdigest()==row['wireSha256']
                prediction=proxy.delta(before,after,sizes,edges); assert prediction==row[predicted_key],(name,row['candidateIndex'] if 'candidateIndex' in row else row['shortlistIndex'])
                score=-prediction['predictedDelta']+score_weight*row.get('priorScore',0.)
                assert score==row['score']; scores.append(score)
            order=np.argsort(-np.array(scores),kind='stable')
            assert np.array_equal(order,obs['order'])
            assert np.array_equal(scores,obs['world_scores'] if 'world_scores' in obs else obs['scores'])
            for rank,row in enumerate(actions):
                expected=rows[int(order[rank])]; assert row['rank']==rank
                assert all(row[k]==value for k,value in expected.items())
                proposed=make(row); after=geometry(proposed)
                pos,full_pos,physical,full,_=observer.decode(proposed)
                exact=(pos,physical) if report['view']=='overview' else (full_pos,full)
                assert all(np.array_equal(a,b) for a,b in zip(after,exact)); slow+=1
                measured=native.request(wire(proposed,'MEASURE')); totals['fullMeasurements']+=1
                assert all(measured[k]==row['result'][k] for k in FIELDS),(name,row,measured)
                assert row['result']['accepted'] is False
                if measured['legal']:
                    legal+=1; errors.append(abs(row[predicted_key]['predictedDelta']-(measured['visual']-baseline['visual'])))
            assert native.request('SAVE')['saved']
        stats=json.loads((full_out/'learned.tsv.stats.json').read_text())
        assert stats['policyActionsEvaluated']==stats['acceptedActions']==0
        assert stats['visual']==baseline['visual'] and stats['individualVisual']==baseline['individualVisual']
        verify_saved(directory,full_out,decoder,None); verify_saved(directory,stage,decoder,None)
    finally:
        native.close()
    assert len(actions)==report['attempts'] and report['accepted']==0
    totals['rankings']+=len(rows); totals['actions']+=len(actions); totals['slowDecoderControls']+=slow
    summary={'stage':name,'modelRankingsReplayed':len(rows),'attemptedActionsFullMeasured':len(actions),
        'legalActions':legal,'maxAbsolutePredictedDeltaErrorOnLegalActions':max(errors) if errors else None,
        'slowDecoderEqualityControls':slow,'savedCandidateMatchesModelChosenBest':True,
        'sourceFeatureArrayExactlyMatchesFullNative':True,'strictImprovement':False}
    reports.append(summary); print(json.dumps(summary),flush=True)
assert totals=={'rankings':8040,'actions':736,'fullMeasurements':743,'slowDecoderControls':736},totals
stable=Path('data/erd-poc/candidates/captain-ml-independent-views.layout.json')
assert digest(stable)==json.loads((ROOT/'source-binding.json').read_text())['promotedCandidateSha256']
result={'status':'pass','scope':'Every recorded NN ranking, every attempted action, complete source features, decoded geometry and saved-source outputs',
    'totals':totals,'stages':reports,'newNativeTryCallsDuringVerification':0,
    'globalGeometryMinimumEstablished':False,'worldPredictsFutureMetricsPerfectly':False,
    'canonicalCandidateUnchanged':True,'candidateSha256':digest(stable),'overviewVisual':285,'individualVisual':1963,
    'targetOverview':150,'targetIndividual':750,'targetMet':False,'actualBrowserChecked':False,
    'verificationCodeSha256':digest(__file__)}
(OUT/'policies.audit.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'status':'pass',**totals}),flush=True)
