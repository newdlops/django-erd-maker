"""Stream-seal learned geometry models, fixed ranks and fully verified outcomes."""
import ast
import gzip
import hashlib
import json
from pathlib import Path
import sys

ROOT=Path('.tmp/visualcross-ml-150-750-20261004/geometry-world1')
ARCHIVE=Path('data/erd-poc/experiments/independent-views-geometry-world-20261004')
STABLE=Path('data/erd-poc/candidates/captain-ml-independent-views.layout.json')
CANONICAL='4e741de39ca655c7ff042422b9407206427f89e02ecd56b7f4a9f36f6a5cd02e'
PARENT=Path('data/erd-poc/experiments/independent-views-global-owner-learning-20261004/manifest.json')
PARENT_SHA='b17325cd48e8e977b6e7c58211491b84cd52dc2eedce1345de58c47a92575ffb'


def streamed(stream):
    h=hashlib.sha256(); size=0
    while block:=stream.read(65536): h.update(block); size+=len(block)
    return size,h.hexdigest()


def digest(path):
    with Path(path).open('rb') as stream: return streamed(stream)[1]


def restored(path):
    with Path(path).open('rb') as stream: packed=stream.read(2)==b'\x1f\x8b'
    with (gzip.open(path,'rb') if packed else Path(path).open('rb')) as stream: return streamed(stream)


assert not ARCHIVE.exists() and digest(STABLE)==CANONICAL and digest(PARENT)==PARENT_SHA
proofs={name:json.loads((ROOT/'verification'/(name+'.audit.json')).read_text()) for name in ('training','policies')}
assert all(p['status']=='pass' for p in proofs.values())
assert proofs['policies']['totals']=={'rankings':8040,'actions':736,'fullMeasurements':743,'slowDecoderControls':736}
training=json.loads((ROOT/'training2/report.json').read_text()); diagnosis=json.loads((ROOT/'diagnosis.json').read_text())
assert training['newTrainingUpdatesExecuted']==29920 and diagnosis['strictImprovements']==0
assert digest(ROOT/'training2/model.npz')==proofs['training']['modelSha256']==diagnosis['trainedWorldSha256']
resources=json.loads((ROOT/'resources.json').read_text())
assert resources['limitMiB']==128 and resources['allListedJobsTerminal'] and not resources['limitRaised']
entries={str(p):Path('run')/p.relative_to(ROOT) for p in ROOT.rglob('*') if p.is_file()}
scripts=Path('scripts/erd-poc'); pending=[p.name for p in scripts.glob('*geometry_world*.py')]+['run_memory_bounded.py']
for name in ('prepare_geometry_world.py','prepare_geometry_world_sources.py','verify_geometry_world_training.py',
             'verify_geometry_world_policies.py','seal_geometry_world.py','verify_geometry_world_archive.py'):
    p=Path('.tmp')/name; assert p.is_file(); entries[str(p)]=Path('tools')/name
    for node in ast.walk(ast.parse(p.read_text())):
        modules=[node.module] if isinstance(node,ast.ImportFrom) else [i.name for i in node.names] if isinstance(node,ast.Import) else []
        for module in modules:
            if module and (scripts/(module+'.py')).is_file(): pending.append(module+'.py')
seen=set()
while pending:
    name=pending.pop()
    if name in seen: continue
    seen.add(name); p=scripts/name; assert p.is_file(); entries[str(p)]=Path('code')/name
    for node in ast.walk(ast.parse(p.read_text())):
        modules=[node.module] if isinstance(node,ast.ImportFrom) else [i.name for i in node.names] if isinstance(node,ast.Import) else []
        for module in modules:
            if module and (scripts/(module+'.py')).is_file(): pending.append(module+'.py')
dependencies={str(STABLE),str(STABLE.with_suffix('.audit.json'))}
# Correct the compound layout suffix explicitly.
dependencies.discard(str(STABLE.with_suffix('.audit.json')))
dependencies.update(str(STABLE.with_name('captain-ml-independent-views.'+suffix)) for suffix in ('layout.json','audit.json','provenance.json'))
dependencies.update(['context.md','data/erd-poc/candidates/README.md',
    'data/erd-poc/recovered/captain-2026-09-15-payload.json',str(PARENT.parent/'promotion/artifact-record.json')])
for path in ROOT.glob('*/report.json'):
    r=json.loads(path.read_text())
    for key in ('actorCheckpoint','environment','worldCheckpoint'):
        if key in r: dependencies.add(r[key])
native=Path('.tmp/visualcross-ml-150-750-20261003/pair-neutral-walk1')
dependencies.add(str(native/'environment')); dependencies.add(str(native/'build-inputs.json'))
dependencies.update(str(p) for p in (native/'build-inputs').iterdir() if p.is_file())
for source in dependencies:
    assert Path(source).is_file(),source
    entries.setdefault(source,Path('dependencies')/digest(source)/Path(source).name)
parent=json.loads(PARENT.read_text()); expected={str(PARENT):PARENT_SHA}; known={}
for item in parent['prerequisiteManifests']: expected[item['path']]=item['sha256']
for item in parent['files']: known.setdefault(item['sha256'],(PARENT.parent/item['archive'],item['bytes'],str(PARENT)))
for item in parent['referencedFiles']: known.setdefault(item['sha256'],(Path(item['archive']),item['bytes'],item['prerequisiteManifest']))
ARCHIVE.mkdir(parents=True); files=[]; references=[]; reused={}; checked=set(); required={str(PARENT)}
for source,relative in sorted(entries.items()):
    p=Path(source); size=p.stat().st_size; sha=digest(p)
    if sha in known:
        stored,original_size,prerequisite=known[sha]; assert size==original_size
        if sha not in checked: assert restored(stored)==(size,sha); checked.add(sha)
        required.add(prerequisite)
        references.append({'source':source,'archive':str(stored),'bytes':size,'sha256':sha,
            'prerequisiteManifest':prerequisite,'restoreHashVerified':True}); continue
    if sha in reused: stored,packed=reused[sha]
    else:
        stored=Path(str(relative)+'.gz'); destination=ARCHIVE/stored; destination.parent.mkdir(parents=True,exist_ok=True)
        with destination.open('xb') as out,gzip.GzipFile(filename='',mode='wb',compresslevel=1,mtime=0,fileobj=out) as packed_stream,p.open('rb') as original:
            while block:=original.read(65536): packed_stream.write(block)
        assert restored(destination)==(size,sha); packed=destination.stat().st_size; reused[sha]=(stored,packed)
    files.append({'source':source,'archive':str(stored),'bytes':size,'sha256':sha,'compressedBytes':packed})
prerequisites=[]
for filename in sorted(required):
    assert digest(filename)==expected[filename]; prerequisites.append({'path':filename,'sha256':expected[filename]})
assert digest(STABLE)==CANONICAL
manifest={'scope':'Learned pair event models, complete optimizer replay, fixed model rankings and all attempted full Native measurements; current product preserved',
    'candidateSource':str(STABLE),'candidateSha256':CANONICAL,'overviewVisual':285,'individualVisual':1963,
    'targetOverview':150,'targetIndividual':750,'targetMet':False,'promotedNewCandidate':False,
    'newTrainingUpdates':29920,'learnedModelParameters':1538,'modelRankings':8040,'actualNeuralMoves':736,
    'strictImprovements':0,'verification':proofs,'training':training,'diagnosis':diagnosis,'resources':resources,
    'nativeCoordinateSearchOrRepairs':0,'browserVerified':False,'prerequisiteManifests':prerequisites,
    'files':files,'referencedFiles':references,'newPhysicalCompressedFiles':len(reused),
    'newPhysicalCompressedBytes':sum(v[1] for v in reused.values()),'allStoredAndReferencedMappingsRestoreHashVerified':True,
    'sourcesUnchangedAtSeal':True}
path=ARCHIVE/'manifest.json'; path.write_text(json.dumps(manifest,indent=2)+'\n')
receipt={'manifest':str(path),'manifestSha256':digest(path),'candidateSha256':CANONICAL,
    'newMappings':len(files),'referencedMappings':len(references),'newPhysicalCompressedFiles':len(reused),
    'newPhysicalCompressedBytes':manifest['newPhysicalCompressedBytes']}
out=Path('.tmp/geometry-world-archive-seal-receipt.json'); assert not out.exists()
out.write_text(json.dumps(receipt,indent=2)+'\n'); print(json.dumps(receipt),flush=True)
