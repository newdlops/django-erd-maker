"""Rebuild fixed teachers/folds and independently replay every Adam update."""
import json
from pathlib import Path
import sys
import numpy as np
sys.path.insert(0,str(Path('scripts/erd-poc').resolve()))
from geometry_world_model import Classifier, FEATURES, digest, load
from learn_pair_policy import KEYS
from train_geometry_world import source_rows, synthetic_rows, metrics

ROOT=Path('.tmp/visualcross-ml-150-750-20261004/geometry-world1')
TRAIN=ROOT/'training2'; OUT=ROOT/'verification'; OUT.mkdir(exist_ok=True)
ENV=Path('.tmp/visualcross-ml-150-750-20261003/pair-neutral-walk1/environment')
report=json.loads((TRAIN/'report.json').read_text())
assert digest(ROOT/'source-binding.json')==report['sourceBindingSha256']
assert digest(ENV)==report['nativeEnvironmentSha256']
assert digest(TRAIN/'dataset.npz')==report['datasetSha256']
for name,sha in report['codeSha256'].items(): assert digest(Path('scripts/erd-poc')/name)==sha
sources,controls=source_rows(ROOT/'source-binding.json',ENV,OUT,report['seed'])
synthetic=synthetic_rows(report['seed']+1)
models,_=load(TRAIN/'model.npz'); initial_models,_=load(TRAIN/'model.npz',True)
proofs={}
with np.load(TRAIN/'dataset.npz',allow_pickle=False) as dataset:
    for task in FEATURES:
        parts=sources[task]+synthetic[task]
        x,y,validation,groups=[np.concatenate([p[i] for p in parts]) for i in range(4)]
        for key,value in [('x',x),('y',y),('validation',validation),('groups',groups)]:
            assert np.array_equal(value,dataset[task+'__'+key])
        assert set(np.unique(groups[validation & (groups>=100)]))=={104,109,114,119}
        train=np.flatnonzero(~validation); val=np.flatnonzero(validation)
        model=Classifier(report['seed']+FEATURES[task],FEATURES[task],24)
        model.mean=x[train].mean(0,dtype=np.float64); model.scale=np.maximum(.1,x[train].std(0,dtype=np.float64))
        assert np.array_equal(model.mean,models[task].mean) and np.array_equal(model.scale,models[task].scale)
        assert all(np.array_equal(model.p[k],initial_models[task].p[k]) for k in KEYS)
        first={k:np.zeros_like(v) for k,v in model.p.items()}; second={k:np.zeros_like(v) for k,v in model.p.items()}
        rng=np.random.default_rng(report['seed']+FEATURES[task]); positive=train[y[train]]; negative=train[~y[train]]
        updates=0; chosen=None; best=None; best_loss=float('inf'); selected=0
        for row in report['tasks'][task]['trace']:
            balanced=np.r_[train,rng.choice(positive,max(0,len(negative)-len(positive)),replace=True)]
            order=rng.permutation(balanced)
            for offset in range(0,len(order),256):
                batch=order[offset:offset+256]; loss,grads=model.loss(x[batch],y[batch],np.ones(len(batch)),True)
                assert np.isfinite(loss); updates+=1
                for k in KEYS:
                    first[k]=.9*first[k]+.1*grads[k]; second[k]=.999*second[k]+.001*grads[k]*grads[k]
                    model.p[k]-=.003*(first[k]/(1-.9**updates))/(np.sqrt(second[k]/(1-.999**updates))+1e-8)
                if updates==row['updates']: break
            assert updates==row['updates']
            value=model.loss(x[val],y[val],np.ones(len(val)))
            assert value==row['validationBce'],(task,row,value)
            if value<best_loss: best_loss=value; best={k:v.copy() for k,v in model.p.items()}; selected=updates
        assert updates==report['tasks'][task]['updatesExecuted'] and selected==report['tasks'][task]['selectedCheckpointUpdates']
        assert all(np.array_equal(best[k],models[task].p[k]) for k in KEYS)
        for stage,m in [('initial',initial_models[task]),('final',models[task])]:
            for name,mask in [('source',validation & (groups<100)),('synthetic',validation & (groups>=100))]:
                assert metrics(m,x[mask],y[mask])==report['tasks'][task][stage][name]
        proofs[task]={'rowsRebuilt':len(y),'updatesReplayed':updates,'selectedUpdates':selected,
            'allSavedParameterArraysExactlyMatched':True,'normalizationRebuiltFromTrainingOnly':True,
            'initialAndSelectedValidationMetricsMatched':True}
        print(json.dumps({'task':task,**proofs[task]}),flush=True)
assert sum(p['updatesReplayed'] for p in proofs.values())==report['newTrainingUpdatesExecuted']==29920
result={'status':'pass','scope':'All teacher rows/folds, normalizers, initialization, 29920 optimizer updates, selected weights and validation metrics',
    'modelSha256':digest(TRAIN/'model.npz'),'datasetSha256':digest(TRAIN/'dataset.npz'),
    'sourceBindingSha256':digest(ROOT/'source-binding.json'),'nativeSourceBaselineControls':controls,
    'nativeReadOnlyFullMeasurements':2,'trainingNativeSearchCalls':0,'tasks':proofs,
    'teacherPairLabelsIndependentlyExportedByNative':False,
    'sourceHoldoutIsUnseenCaptainScene':False,'goalTargetMet':False,
    'verificationCodeSha256':digest(__file__)}
(OUT/'training.audit.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'status':'pass','updatesReplayed':29920}),flush=True)
