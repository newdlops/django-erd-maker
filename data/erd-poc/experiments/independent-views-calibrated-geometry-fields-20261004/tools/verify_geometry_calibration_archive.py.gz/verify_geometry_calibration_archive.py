"""Independently restore calibrated-learning objects and compare live source bytes."""
import gzip
import hashlib
import json
from pathlib import Path


def hash_file(path, restore=False):
    with Path(path).open('rb') as stream:
        packed = stream.read(2) == b'\x1f\x8b'
    h = hashlib.sha256()
    size = 0
    with (gzip.open(path, 'rb') if packed and restore else Path(path).open('rb')) as stream:
        while block := stream.read(32768):
            h.update(block)
            size += len(block)
    return size, h.hexdigest()


receipt = json.loads(Path('.tmp/geometry-calibration-archive-seal-receipt.json').read_text())
path = Path(receipt['manifest'])
assert hash_file(path)[1] == receipt['manifestSha256']
manifest = json.loads(path.read_text())
objects = set()
mappings = 0
for category in ('files', 'referencedFiles'):
    for item in manifest[category]:
        stored = path.parent / item['archive'] if category == 'files' else Path(item['archive'])
        expected = item['bytes'], item['sha256']
        assert hash_file(stored, True) == expected and hash_file(item['source']) == expected
        objects.add(str(stored))
        mappings += 1
for item in manifest['prerequisiteManifests']:
    assert hash_file(item['path'])[1] == item['sha256']
assert hash_file(manifest['candidateSource'])[1] == manifest['candidateSha256']
assert all(p['status'] == 'pass' for p in manifest['verification'].values())
assert (manifest['overviewVisual'], manifest['individualVisual']) == (285, 1963)
assert not manifest['targetMet'] and not manifest['promotedNewCandidate'] and manifest['strictImprovements'] == 0
assert manifest['newTrainingUpdates'] == 2430
assert manifest['diagnosis']['fullNativeVerificationMeasurements'] == 1091
assert manifest['verification']['tied-fields']['totals']['recordedRewardLabelsUsedWithoutFullRemeasurement'] == 364
result = dict(status='pass', manifestSha256=receipt['manifestSha256'],
    mappingsRestoredAndLiveSourcesMatched=mappings, distinctStoredObjects=len(objects),
    prerequisiteManifestsMatched=len(manifest['prerequisiteManifests']),
    candidateSha256=manifest['candidateSha256'], overviewVisual=285, individualVisual=1963, targetMet=False,
    restoreVerifierSha256=hash_file(__file__)[1])
out = Path('.tmp/geometry-calibration-archive-independent-verification.json')
assert not out.exists()
out.write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result), flush=True)
