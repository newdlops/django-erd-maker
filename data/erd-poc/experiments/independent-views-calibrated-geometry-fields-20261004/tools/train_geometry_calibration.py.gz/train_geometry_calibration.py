"""Fit a small neural temperature mixture to previously full-proven outcomes."""
import hashlib
import json
from pathlib import Path
import sys
import numpy as np
sys.path.insert(0,str(Path('scripts/erd-poc').resolve()))
from calibrated_geometry_world import CurveProxy,Mixture,TEMPERATURES,SCHEMA,softmax
from geometry_world_model import load,digest
from run_anchor_pair_walk import WalkDecoder
from single_owner_cached_observer_v2 import CachedObserver
from single_owner_cycle_model import action,AMPLITUDES
from run_geometry_world_policy import source_geometry
from run_geometry_world_port_policy import decode_row

PARENT=Path('.tmp/visualcross-ml-150-750-20261004/geometry-world1')
OUT=Path('.tmp/visualcross-ml-150-750-20261004/geometry-calibration1/training1'); OUT.mkdir(parents=True,exist_ok=False)
proof=json.loads((PARENT/'verification/policies.audit.json').read_text()); assert proof['status']=='pass'
assert proof['totals']['actions']==736 and proof['totals']['fullMeasurements']==743
checkpoint=PARENT/'training2/model.npz'; models,_=load(checkpoint); proxy=CurveProxy(models)
xs=[]; ys=[]; vals=[]; groups=[]; records=[]; skipped=0
for group,summary in enumerate(proof['stages']):
    stage=PARENT/summary['stage']; report=json.loads((stage/'report.json').read_text())
    assert digest(stage/'actions.jsonl')==report['actionsSha256']
    directory=Path(report['sourceDirectory']); decoder=WalkDecoder(directory); observer=CachedObserver(directory,decoder)
    zero=decoder.decode(np.arange(len(decoder.positions),dtype=np.int32)); before,sizes,edges=source_geometry(observer,zero,report['view'])
    singles=[json.loads(line) for line in (stage/'ranking.jsonl').read_text().splitlines() if json.loads(line).get('kind')=='single']
    for line in (stage/'actions.jsonl').read_text().splitlines():
        row=json.loads(line)
        if not row['result']['legal']: skipped+=1; continue
        if '-ports-' in summary['stage']: proposed=decode_row(zero,len(decoder.positions),row,singles)
        elif 'owners' in row: proposed=decoder.action(*row['owners'])
        else: proposed=action(decoder,np.array(row['cycle']),np.array(row['amplitudes']))
        after=source_geometry(observer,proposed,report['view'])[0]
        curve=proxy.spectrum(before,after,sizes,edges)
        key=report['view']+':'+row['wireSha256']; validation=int(hashlib.sha256(key.encode()).hexdigest()[:8],16)%5==0
        xs.append(curve); ys.append(float(row['result']['visual']-report['initialVisual'])); vals.append(validation); groups.append(group)
        records.append({'source':str(stage/'actions.jsonl'),'rank':row['rank'],'view':report['view'],
            'wireSha256':row['wireSha256'],'splitKey':key,'validation':validation})
    print(json.dumps({'sourceStage':summary['stage'],'totalLegalRows':len(xs)}),flush=True)
x=np.array(xs,dtype=np.float32); y=np.array(ys); validation=np.array(vals,dtype=bool); groups=np.array(groups,dtype=np.int16)
assert len(y)==493 and skipped==243 and np.isfinite(x).all()
train=np.flatnonzero(~validation); val=np.flatnonzero(validation)
model=Mixture(); initial=model.theta.copy(); first=np.zeros_like(initial); second=np.zeros_like(initial)
rng=np.random.default_rng(105103); trace=[]; best_loss=float('inf'); best=None; updates=0; selected=0
initial_loss=model.loss(x[val],y[val]); raw_loss=float(np.mean((x[val,4]+x[val,11]-y[val])**2))
for epoch in range(300):
    order=rng.permutation(train)
    for offset in range(0,len(order),64):
        batch=order[offset:offset+64]; loss,gradient=model.loss(x[batch],y[batch],True); assert np.isfinite(loss)
        updates+=1; first=.9*first+.1*gradient; second=.999*second+.001*gradient*gradient
        model.theta-=.03*(first/(1-.9**updates))/(np.sqrt(second/(1-.999**updates))+1e-8)
    loss=model.loss(x[val],y[val]); trace.append({'epoch':epoch+1,'updates':updates,'validationMse':loss})
    if loss<best_loss: best_loss=loss; best=model.theta.copy(); selected=updates
model.theta=best
np.savez_compressed(OUT/'dataset.npz',x=x,y=y,validation=validation,groups=groups)
(OUT/'rows.jsonl').write_text(''.join(json.dumps(r)+'\n' for r in records))
metadata={'schema':SCHEMA,'eventModel':str(checkpoint),'eventModelSha256':digest(checkpoint),
    'parentFullMeasurementProof':str(PARENT/'verification/policies.audit.json'),
    'parentFullMeasurementProofSha256':digest(PARENT/'verification/policies.audit.json'),
    'sourceBinding':str(PARENT/'source-binding.json'),'sourceBindingSha256':digest(PARENT/'source-binding.json'),
    'parameters':14,'featureInputDtype':'float32','innerArithmeticDtype':'float64','seed':105103,
    'temperatures':TEMPERATURES.tolist(),'rows':len(y),'trainingRows':len(train),'validationRows':len(val),
    'illegalRowsExcluded':skipped,'updatesExecuted':updates,'selectedCheckpointUpdates':selected,
    'initialUniformMixtureValidationMse':initial_loss,'rawUncalibratedValidationMse':raw_loss,
    'selectedValidationMse':best_loss,'selectedWeights':softmax(model.theta).tolist(),'trace':trace,
    'trainingNewNativeMeasurements':0,'trainingCoordinateSearchCalls':0,
    'validationScope':'Within-source whole-action hash holdout; not an unseen Captain scene',
    'featureContainsExactFutureMetric':False,'targetUsesPreviouslyFullMeasuredNativeDelta':True,
    'datasetSha256':digest(OUT/'dataset.npz'),'rowsSha256':digest(OUT/'rows.jsonl'),
    'codeSha256':{'calibrated_geometry_world.py':digest('scripts/erd-poc/calibrated_geometry_world.py'),
        'trainer':digest(__file__)}}
np.savez_compressed(OUT/'model.npz',theta=model.theta,initial_theta=initial,metadata=np.array(json.dumps(metadata)))
(OUT/'report.json').write_text(json.dumps(metadata,indent=2)+'\n')
print(json.dumps({k:metadata[k] for k in ['rows','trainingRows','validationRows','updatesExecuted','selectedCheckpointUpdates',
    'rawUncalibratedValidationMse','initialUniformMixtureValidationMse','selectedValidationMse','selectedWeights']}
    |{'checkpointSha256':digest(OUT/'model.npz')}),flush=True)
