"""Rebuild outcome-bound calibration rows and replay all 2,100 updates."""
import hashlib
import json
from pathlib import Path
import sys
import numpy as np
sys.path.insert(0,str(Path('scripts/erd-poc').resolve()))
from calibrated_geometry_world import CurveProxy,Mixture,softmax
from geometry_world_model import load,digest
from run_anchor_pair_walk import WalkDecoder
from single_owner_cached_observer_v2 import CachedObserver
from single_owner_cycle_model import action
from run_geometry_world_policy import source_geometry
from run_geometry_world_port_policy import decode_row

ROOT=Path('.tmp/visualcross-ml-150-750-20261004/geometry-calibration1')
PARENT=Path('.tmp/visualcross-ml-150-750-20261004/geometry-world1')
TRAIN=ROOT/'training1'; OUT=ROOT/'verification'; OUT.mkdir(exist_ok=True)
report=json.loads((TRAIN/'report.json').read_text())
for p,k in [(TRAIN/'dataset.npz','datasetSha256'),(TRAIN/'rows.jsonl','rowsSha256'),
    (Path(report['eventModel']),'eventModelSha256'),(Path(report['parentFullMeasurementProof']),'parentFullMeasurementProofSha256'),
    (Path(report['sourceBinding']),'sourceBindingSha256')]: assert digest(p)==report[k]
assert digest('scripts/erd-poc/calibrated_geometry_world.py')==report['codeSha256']['calibrated_geometry_world.py']
assert digest('.tmp/train_geometry_calibration.py')==report['codeSha256']['trainer']
proof=json.loads(Path(report['parentFullMeasurementProof']).read_text()); assert proof['status']=='pass'
events,_=load(Path(report['eventModel'])); proxy=CurveProxy(events)
rows=[json.loads(line) for line in (TRAIN/'rows.jsonl').read_text().splitlines()]
index=skipped=0; split_keys={}; source_summaries=[]
with np.load(TRAIN/'dataset.npz',allow_pickle=False) as data:
    x,y,validation,groups=[data[k].copy() for k in ('x','y','validation','groups')]
for group,summary in enumerate(proof['stages']):
    stage=PARENT/summary['stage']; source_report=json.loads((stage/'report.json').read_text())
    assert digest(stage/'actions.jsonl')==source_report['actionsSha256']
    source=Path(source_report['sourceDirectory']); decoder=WalkDecoder(source); observer=CachedObserver(source,decoder)
    zero=decoder.decode(np.arange(len(decoder.positions),dtype=np.int32))
    before,sizes,edges=source_geometry(observer,zero,source_report['view'])
    singles=[r for line in (stage/'ranking.jsonl').read_text().splitlines() if (r:=json.loads(line)).get('kind')=='single']
    local=0
    for line in (stage/'actions.jsonl').read_text().splitlines():
        row=json.loads(line)
        if not row['result']['legal']: skipped+=1; continue
        if '-ports-' in summary['stage']: proposed=decode_row(zero,len(decoder.positions),row,singles)
        elif 'owners' in row: proposed=decoder.action(*row['owners'])
        else: proposed=action(decoder,np.array(row['cycle']),np.array(row['amplitudes']))
        after=source_geometry(observer,proposed,source_report['view'])[0]
        assert np.array_equal(x[index],proxy.spectrum(before,after,sizes,edges))
        assert y[index]==row['result']['visual']-source_report['initialVisual'] and groups[index]==group
        key=source_report['view']+':'+row['wireSha256']; val=int(hashlib.sha256(key.encode()).hexdigest()[:8],16)%5==0
        assert bool(validation[index])==val and rows[index]=={'source':str(stage/'actions.jsonl'),'rank':row['rank'],
            'view':source_report['view'],'wireSha256':row['wireSha256'],'splitKey':key,'validation':val}
        if key in split_keys: assert split_keys[key]==val
        split_keys[key]=val; index+=1; local+=1
    source_summaries.append({'stage':summary['stage'],'legalRowsRebuilt':local})
    print(json.dumps(source_summaries[-1]),flush=True)
assert index==len(rows)==len(y)==493 and skipped==243
assert x.dtype==np.float32 and np.isfinite(x).all()
train=np.flatnonzero(~validation); val=np.flatnonzero(validation)
assert (len(train),len(val))==(396,97)
model=Mixture(); first=np.zeros_like(model.theta); second=first.copy(); rng=np.random.default_rng(report['seed'])
assert model.loss(x[val],y[val])==report['initialUniformMixtureValidationMse']
assert float(np.mean((x[val,4]+x[val,11]-y[val])**2))==report['rawUncalibratedValidationMse']
best_loss=float('inf'); selected=updates=0; best=None
for row in report['trace']:
    order=rng.permutation(train)
    for offset in range(0,len(order),64):
        batch=order[offset:offset+64]; loss,gradient=model.loss(x[batch],y[batch],True)
        assert np.isfinite(loss); updates+=1
        first=.9*first+.1*gradient; second=.999*second+.001*gradient*gradient
        model.theta-=.03*(first/(1-.9**updates))/(np.sqrt(second/(1-.999**updates))+1e-8)
    value=model.loss(x[val],y[val]); assert row['updates']==updates and row['validationMse']==value
    if value<best_loss: best_loss=value; best=model.theta.copy(); selected=updates
assert (updates,selected)==(2100,70) and best_loss==report['selectedValidationMse']
with np.load(TRAIN/'model.npz',allow_pickle=False) as saved:
    assert np.array_equal(best,saved['theta']) and np.array_equal(saved['initial_theta'],np.zeros_like(best))
assert softmax(best).tolist()==report['selectedWeights']
result={'status':'pass','checkpointSha256':digest(TRAIN/'model.npz'),'rowsRebuilt':493,'trainingRows':396,
    'validationRows':97,'illegalRowsExcluded':243,'updatesReplayed':2100,'selectedUpdates':70,
    'allSavedWeightsExactlyMatched':True,'wholeActionSplitKeysDisjoint':True,'sourceStages':source_summaries,
    'rawValidationMse':report['rawUncalibratedValidationMse'],'calibratedValidationMse':best_loss,
    'newNativeMeasurements':0,'nativeGroundTruthProof':report['parentFullMeasurementProof'],
    'validationIsUnseenCaptainScene':False,'verificationCodeSha256':digest(__file__)}
(OUT/'calibration.audit.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:result[k] for k in ['status','rowsRebuilt','updatesReplayed','selectedUpdates','rawValidationMse','calibratedValidationMse']}),flush=True)
