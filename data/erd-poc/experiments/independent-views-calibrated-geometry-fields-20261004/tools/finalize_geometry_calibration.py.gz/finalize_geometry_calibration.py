"""Bind sealed learning records to independent restore and terminal RSS receipts."""
import hashlib
import json
from pathlib import Path
import re


def digest(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        while block := stream.read(65536):
            h.update(block)
    return h.hexdigest()


seal = Path('.tmp/geometry-calibration-archive-seal-receipt.json')
restore = Path('.tmp/geometry-calibration-archive-independent-verification.json')
s = json.loads(seal.read_text())
r = json.loads(restore.read_text())
manifest = Path(s['manifest'])
assert digest(manifest) == s['manifestSha256'] == r['manifestSha256'] and r['status'] == 'pass'
root = Path('.tmp/visualcross-ml-150-750-20261004/geometry-calibration1')
paths = dict(manifest=manifest, sealReceipt=seal, restoreReceipt=restore,
    calibrationModel=root/'training1/model.npz', calibrationDataset=root/'training1/dataset.npz',
    resourceLedger=root/'resources.json', diagnosis=root/'diagnosis.json',
    candidate=Path('data/erd-poc/candidates/captain-ml-independent-views.layout.json'),
    sealGuardLog=Path('.tmp/geometry-calibration-archive-seal.guard.log'),
    restoreGuardLog=Path('.tmp/geometry-calibration-archive-restore.guard.log'))
for name in ('calibration', 'walks', 'fields', 'tied-fields', 'field-hard-diagnosis'):
    paths[name + 'Proof'] = root/'verification'/(name + '.audit.json')
bindings = {name: dict(path=str(path), sha256=digest(path)) for name, path in paths.items()}
assert bindings['candidate']['sha256'] == s['candidateSha256'] == '4e741de39ca655c7ff042422b9407206427f89e02ecd56b7f4a9f36f6a5cd02e'
peaks = {}
for name in ('sealGuardLog', 'restoreGuardLog'):
    matches = re.findall(r'memory guard: peak=([0-9.]+) MiB limit=([0-9.]+) MiB', paths[name].read_text())
    assert len(matches) == 1 and float(matches[0][1]) == 128
    peaks[name] = float(matches[0][0])
    assert peaks[name] <= 128
record = dict(status='pass', immutableMainManifestUnchanged=True, bindings=bindings,
    restoreScope={key: r[key] for key in ('mappingsRestoredAndLiveSourcesMatched', 'distinctStoredObjects', 'prerequisiteManifestsMatched')},
    archiveSampledPeakMiB=peaks, sampledPeaksAreNotHardInstantaneousMemoryBounds=True,
    newProductCandidatePromoted=False, overviewVisual=285, individualVisual=1963, targetMet=False)
out = manifest.parent/'final-artifact-record.json'
assert not out.exists()
out.write_text(json.dumps(record, indent=2) + '\n')
result = dict(status='pass', finalRecord=str(out), finalRecordSha256=digest(out), bindingsChecked=len(bindings))
print(json.dumps(result), flush=True)
