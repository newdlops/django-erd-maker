"""Classify existing learned geometry; emit no candidate or changed coordinates."""
import json
from pathlib import Path
import sys
import numpy as np
sys.path.insert(0,str(Path('scripts/erd-poc').resolve()))
from compact_patch_neural_policy import PatchActor
from geometry_world_model import digest
from run_anchor_pair_walk import WalkDecoder
from single_owner_cached_observer_v2 import CachedObserver,crossing_matrix


def own_hits(lines,positions,sizes):
    low,high=positions-sizes/2+.02,positions+sizes/2-.02
    origin,direction=lines[:,0],lines[:,1]-lines[:,0]
    valid=np.all(lines.max(1)>low,axis=1)&np.all(lines.min(1)<high,axis=1)
    lower,upper=np.zeros(len(lines)),np.ones(len(lines))
    for axis in (0,1):
        d=direction[:,axis]; parallel=abs(d)<1e-9; den=np.where(parallel,1.,d)
        a,b=(low[:,axis]-origin[:,axis])/den,(high[:,axis]-origin[:,axis])/den
        lower=np.maximum(lower,np.where(parallel,0.,np.minimum(a,b)))
        upper=np.minimum(upper,np.where(parallel,1.,np.maximum(a,b)))
        valid&=np.where(parallel,(origin[:,axis]>low[:,axis])&(origin[:,axis]<high[:,axis]),upper-lower>1e-9)
    return valid&(upper>1e-9)&(lower<1-1e-9)


def classify(positions,sizes,lines,edges):
    centers=positions[edges]; half=sizes[edges]/2; low,high=centers-half,centers+half
    peer=lines[:,::-1]; eps=.011
    outward=np.isfinite(lines).all(2)&np.all(lines>=low-eps,2)&np.all(lines<=high+eps,2)
    outward&=np.linalg.norm(lines-peer,axis=2)>eps
    outward&=((abs(lines[:,:,0]-low[:,:,0])<=eps)&(peer[:,:,0]<=lines[:,:,0]+eps)
        |(abs(lines[:,:,0]-high[:,:,0])<=eps)&(peer[:,:,0]>=lines[:,:,0]-eps)
        |(abs(lines[:,:,1]-low[:,:,1])<=eps)&(peer[:,:,1]<=lines[:,:,1]+eps)
        |(abs(lines[:,:,1]-high[:,:,1])<=eps)&(peer[:,:,1]>=lines[:,:,1]-eps))
    own=np.stack([own_hits(lines,centers[:,end],sizes[edges[:,end]]) for end in (0,1)],axis=1)
    crosses=crossing_matrix(lines); adjacent=np.any(edges[:,None,:,None]==edges[None,:,None,:],axis=(2,3))
    cross_pairs=np.argwhere(np.triu(crosses&adjacent,1)); contact_pairs=[]
    for first in range(0,len(lines),32):
        a=lines[first:first+32,None]; b=lines[None]; ae=edges[first:first+32,None]; be=edges[None]
        valid=np.all(a.min(2)<=b.max(2)+1e-6,2)&np.all(b.min(2)<=a.max(2)+1e-6,2)
        contact=np.zeros(valid.shape,dtype=bool)
        for from_a in (True,False):
            origin,segment=(a,b) if from_a else (b,a)
            vector=segment[:,:,1]-segment[:,:,0]
            for endpoint in (0,1):
                point=origin[:,:,endpoint]; rel=point-segment[:,:,0]
                on=abs(vector[:,:,0]*rel[:,:,1]-vector[:,:,1]*rel[:,:,0])<1e-5
                on&=np.all(point>=segment.min(2)-1e-6,2)&np.all(point<=segment.max(2)+1e-6,2)
                allowed=np.zeros(valid.shape,dtype=bool)
                for i in (0,1):
                    for j in (0,1):
                        allowed|=(ae[:,:,i]==be[:,:,j])&np.all(abs(a[:,:,i]-b[:,:,j])<.001,2)&np.all(abs(point-a[:,:,i])<.001,2)
                contact|=on&~allowed
        row,col=np.nonzero(valid&contact)
        contact_pairs.extend((first+int(r),int(c)) for r,c in zip(row,col) if first+r<c)
    return {'inwardOrInvalidBoundaryEndpoints':int(np.count_nonzero(~outward)),
        'ownCardReentries':int(own.sum()),'adjacentProperCrossings':len(cross_pairs),
        'disallowedBoundaryContacts':len(contact_pairs),
        'totalHard':int(np.count_nonzero(~outward)+own.sum()+2*len(cross_pairs)+2*len(contact_pairs)),
        'firstAdjacentCrossingPairs':cross_pairs[:8].tolist(),'firstBoundaryContactPairs':contact_pairs[:8]}


ROOT=Path('.tmp/visualcross-ml-150-750-20261004/geometry-calibration1'); stage=ROOT/'individual-field1'
report=json.loads((stage/'report.json').read_text()); decoder=WalkDecoder(Path(report['sourceDirectory']))
observer=CachedObserver(Path(report['sourceDirectory']),decoder)
with np.load(stage/'observations.npz',allow_pickle=False) as data: nodes,active=data['nodes'].copy(),data['active'].copy()
model=PatchActor(nodes,decoder,active,report['maxStep'],report['seed'])
records=[json.loads(line) for line in (stage/'actions.jsonl').read_text().splitlines()]
diagnoses=[]
for row in [records[0],records[-1]]:
    assert digest(row['checkpoint'])==row['checkpointSha256']
    with np.load(row['checkpoint'],allow_pickle=False) as saved: model.p={k:saved[k].copy() for k in model.p}
    proposed=model.forward(nodes)[0]; _,positions,_,lines,_=observer.decode(proposed)
    found=classify(positions,observer.full_sizes,lines,observer.edges)
    assert found['totalHard']==row['result']['individualHard']==row['result']['hard'],(found,row['result'])
    diagnoses.append({'step':row['step'],'checkpointSha256':row['checkpointSha256'],**found})
    print(json.dumps(diagnoses[-1]),flush=True)
result={'status':'pass','scope':'First and last trained field outputs; Python hard-kind totals matched recorded Native metrics',
    'inspectedOutputs':diagnoses,'proposesNewCoordinates':False,'coordinateRepairs':0,
    'allFieldOutputsHardKindsClassified':False,'diagnosticCodeSha256':digest(__file__)}
(ROOT/'verification/field-hard-diagnosis.audit.json').write_text(json.dumps(result,indent=2)+'\n')
