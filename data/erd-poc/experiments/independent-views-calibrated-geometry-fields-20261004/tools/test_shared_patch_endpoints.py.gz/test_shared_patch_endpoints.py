"""Catch splitting of originally coincident endpoints on one original card."""
import json
from pathlib import Path
import sys
import numpy as np
sys.path.insert(0,str(Path('scripts/erd-poc').resolve()))
if '--tied' in sys.argv:
    from compact_patch_tied_policy import TiedPatchActor as Actor
else:
    from compact_patch_neural_policy import PatchActor as Actor
from run_anchor_pair_walk import WalkDecoder
from single_owner_cached_observer_v2 import CachedObserver

stage=Path('.tmp/visualcross-ml-150-750-20261004/geometry-calibration1/individual-field1')
report=json.loads((stage/'report.json').read_text()); decoder=WalkDecoder(Path(report['sourceDirectory']))
with np.load(stage/'observations.npz',allow_pickle=False) as saved: nodes,active=saved['nodes'].copy(),saved['active'].copy()
model=Actor(nodes,decoder,active,report['maxStep'],report['seed'])
with np.load(stage/'model-step-004.npz',allow_pickle=False) as saved: model.p={k:saved[k].copy() for k in model.p}
observer=CachedObserver(Path(report['sourceDirectory']),decoder)
_,_,_,lines,_=observer.decode(model.forward(nodes)[0]); points=lines.reshape(-1,2)
original=decoder.provider.original_ports.reshape(-1,2); owners=decoder.provider.full_edges.ravel()
groups={}
for i,(owner,point) in enumerate(zip(owners,original)): groups.setdefault((int(owner),float(point[0]),float(point[1])),[]).append(i)
split=[]
for key,indices in groups.items():
    if len(indices)>1 and not np.all(points[indices]==points[indices[0]]): split.append({'owner':key[0],'indices':indices[:4]})
assert not split, f'{len(split)} originally coincident endpoint groups split: {split[:2]}'
print('PASS: original-card shared endpoints remain exactly coincident after NN inference and cent decoding')
