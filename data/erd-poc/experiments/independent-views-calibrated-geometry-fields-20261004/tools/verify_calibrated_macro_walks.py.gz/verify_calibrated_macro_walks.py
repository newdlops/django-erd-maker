"""Replay all interrupted-turn macro ranks, observations and Native outcomes."""
import hashlib
import json
from pathlib import Path
import sys
import numpy as np
sys.path.insert(0,str(Path('scripts/erd-poc').resolve()))
from calibrated_geometry_world import load,digest
from run_calibrated_macro_walk import decode,permutation_hash,proposal_permutation,vocabulary,transforms
from run_calibrated_macro_policy import UnpooledDecoder
from run_geometry_world_policy import source_geometry
from run_fraction_conditioned_policy import sample_order
from run_anchor_pair_policy import Native,wire
from run_anchor_pair_walk import verify_saved
from single_owner_cached_observer_v2 import CachedObserver
from types import SimpleNamespace

ROOT=Path('.tmp/visualcross-ml-150-750-20261004/geometry-calibration1'); OUT=ROOT/'verification'
FIELDS=('legal','reason','visual','individualVisual','hard','individualHard','spacing')
results=[]; counts={'rankings':0,'attemptedActionsFullMeasured':0,'fullFeatureControls':0,'fullMeasures':0}
for view in ('individual','overview'):
    stage=ROOT/(view+'-walk1'); report=json.loads((stage/'report.json').read_text()); source=Path(report['sourceDirectory'])
    for name,sha in report['codeSha256'].items(): assert digest(Path('scripts/erd-poc')/name)==sha
    for name,sha in report['sourceInputs'].items(): assert digest(source/name)==sha
    for name in ('checkpoint','sourceBinding','environment'): assert digest(report[name])==report[name+'Sha256']
    assert digest(stage/'actions.jsonl')==report['actionsSha256']
    decoder=UnpooledDecoder(source); observer=CachedObserver(source,decoder); proxy,model,_=load(Path(report['checkpoint']))
    current=np.arange(len(decoder.positions),dtype=np.int32); zero=decode(decoder,current)
    before,sizes,edges=source_geometry(observer,zero,view); seen={permutation_hash(current)}
    native_out=OUT/(view+'-walk-native'); native_out.mkdir(exist_ok=True)
    native=Native(Path(report['environment']),source,native_out/'learned.tsv',view=='overview',False)
    actions=[json.loads(line) for line in (stage/'actions.jsonl').read_text().splitlines()]
    action_index=0; admitted=0; best_visual=report['initialVisual']; exact_state=native.initial
    try:
        baseline=native.request(wire(zero,'MEASURE')); counts['fullMeasures']+=1
        assert baseline['legal'] and baseline['visual']==best_visual
        for round_row in report['rounds']:
            assert round_row['sourcePermutationSha256']==permutation_hash(current)
            obs_path=Path(round_row['observation']); rank_path=Path(round_row['ranking'])
            assert digest(obs_path)==round_row['observationSha256'] and digest(rank_path)==round_row['rankingSha256']
            rows=[json.loads(line) for line in rank_path.read_text().splitlines()]
            with np.load(obs_path,allow_pickle=False) as obs:
                nodes=obs['nodes'].copy(); assert np.array_equal(obs['permutation'],current)
                assert np.array_equal(nodes,np.array([n['features'] for n in exact_state['nodes']]))
                counts['fullFeatureControls']+=1
                words,support=vocabulary(SimpleNamespace(groups=decoder.groups,positions=decoder.positions[current]),
                    nodes,report['seed']+round_row['round'],report['wordsPerRound'])
                assert support==round_row['support']; generated=[]; spectra=[]; local_seen=set()
                for wi,word in enumerate(words):
                    for shift,reverse in transforms(len(word)):
                        p=proposal_permutation(current,word,shift,reverse); key=permutation_hash(p)
                        if key in seen or key in local_seen: continue
                        local_seen.add(key); proposed=decode(decoder,p)
                        after=source_geometry(observer,proposed,view)[0]; spectrum=proxy.spectrum(before,after,sizes,edges)
                        score=-float(model.forward(spectrum[None])[0]); spectra.append(spectrum)
                        generated.append({'candidateIndex':len(generated),'wordIndex':wi,'word':word,'shift':shift,
                            'reverse':reverse,'permutationSha256':key,'score':score,
                            'wireSha256':hashlib.sha256(wire(proposed).encode()).hexdigest()})
                assert generated==rows and len(rows)==round_row['candidatesScored']
                scores=np.array([r['score'] for r in rows]); order,noise,policy=sample_order(scores[:,None],
                    report['seed']+1000+round_row['round'],report['temperature'])
                assert np.array_equal(obs['spectra'],spectra) and np.array_equal(obs['scores'],scores)
                assert np.array_equal(obs['order'],order) and np.array_equal(obs['gumbel'],noise) and policy==round_row['policy']
            counts['rankings']+=len(rows)
            for rank,index in enumerate(order[:report['perRound']]):
                if action_index==len(actions) or actions[action_index]['round']!=round_row['round']: break
                row=actions[action_index]; assert row['rank']==rank
                expected=rows[int(index)]; assert all(row[k]==v for k,v in expected.items())
                p=proposal_permutation(current,row['word'],row['shift'],row['reverse']); proposed=decode(decoder,p)
                measured=native.request(wire(proposed,'MEASURE')); counts['fullMeasures']+=1
                assert all(measured[k]==row['result'][k] for k in FIELDS),(row,measured)
                assert not row['result']['accepted'] and row['walkAdmitted']==measured['legal']
                counts['attemptedActionsFullMeasured']+=1; action_index+=1
                if row['walkAdmitted']:
                    current=p; seen.add(permutation_hash(p)); admitted+=1
                    before,sizes,edges=source_geometry(observer,proposed,view)
                    exact_state=native.request(wire(proposed,'OBS'))
                    assert exact_state['visual']==measured['visual'] and exact_state['individualVisual']==measured['individualVisual']
                    break
        assert action_index==len(actions)==report['attempts'] and admitted==report['admittedStates']
        assert native.request('SAVE')['saved']
        stats=json.loads((native_out/'learned.tsv.stats.json').read_text())
        assert stats['policyActionsEvaluated']==stats['acceptedActions']==0
        verify_saved(source,stage,decoder,None); verify_saved(source,native_out,decoder,None)
    finally: native.close()
    summary={'view':view,'rankingsReplayed':sum(r['candidatesScored'] for r in report['rounds']),
        'attemptedActionsFullMeasured':len(actions),'admittedStates':admitted,'savedVisual':report['final']['visual'],
        'lastExploratoryVisual':report['lastExploratoryVisual'],'allSavedCoordinatesPreserveSource':True}
    results.append(summary); print(json.dumps(summary),flush=True)
assert counts=={'rankings':1952,'attemptedActionsFullMeasured':48,'fullFeatureControls':11,'fullMeasures':50},counts
# The interrupted static run failed on a duplicate wire, with eight prior TRYs.
failed=ROOT/'individual-macro1'; rankings=[json.loads(line) for line in (failed/'ranking.jsonl').read_text().splitlines()]
attempts=[json.loads(line) for line in (failed/'actions.jsonl').read_text().splitlines()]
assert len(rankings)==1441 and len(attempts)==8 and all(not r['result']['accepted'] for r in attempts)
order=np.argsort(-np.array([r['score'] for r in rankings]),kind='stable')
assert len({rankings[int(i)]['wireSha256'] for i in order[:9]})==8
result={'status':'pass','scope':'Every recorded trajectory spectrum/rank, each full Native input observation, every attempted action, saved source geometry; static duplicate cause identified',
    'counts':counts,'stages':results,'failedStaticCompletedActions':8,'failedStaticCandidates':1441,
    'failedStaticNinthCandidateDuplicatesEarlierWire':True,'failedStaticRankingsOrMetricsFullyReplayed':False,
    'newNativeTryCalls':0,'candidatePromoted':False,'overviewVisual':285,'individualVisual':1963,'targetMet':False,
    'verificationCodeSha256':digest(__file__)}
(OUT/'walks.audit.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'status':'pass','counts':counts}),flush=True)
