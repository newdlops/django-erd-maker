"""Replay compact actor learning and independently full-measure all rewards."""
import hashlib
import json
from pathlib import Path
import sys
import numpy as np
sys.path.insert(0,str(Path('scripts/erd-poc').resolve()))
from compact_patch_neural_policy import PatchActor
from run_compact_patch_reward import patch_support,KEYS,SCALES
from joint_reward_training import head_vector,set_head_vector,head_hash
from geometry_world_model import digest
from run_anchor_pair_walk import WalkDecoder,verify_saved
from run_anchor_pair_policy import Native,wire

ROOT=Path('.tmp/visualcross-ml-150-750-20261004/geometry-calibration1'); OUT=ROOT/'verification'
FIELDS=('legal','reason','visual','individualVisual','hard','individualHard','spacing')
totals={'updatesReplayed':0,'fullRewardProbeMeasurements':0,'fullTrainedOutputMeasurements':0,'sourceControls':0}
proofs=[]
for view in ('individual','overview'):
    stage=ROOT/(view+'-field1'); report=json.loads((stage/'report.json').read_text()); directory=Path(report['sourceDirectory'])
    for name,sha in report['codeSha256'].items(): assert digest(Path('scripts/erd-poc')/name)==sha
    for name,sha in report['sourceInputs'].items(): assert digest(directory/name)==sha
    for name in ('environment','sourceBinding'): assert digest(report[name])==report[name+'Sha256']
    for filename,key in [('training.jsonl','trainingSha256'),('actions.jsonl','actionsSha256'),
        ('observations.npz','observationsSha256'),('initial-model.npz','initialModelSha256')]: assert digest(stage/filename)==report[key]
    decoder=WalkDecoder(directory)
    with np.load(stage/'observations.npz',allow_pickle=False) as saved: nodes=saved['nodes'].copy(); active=saved['active'].copy()
    expected,support=patch_support(decoder,nodes,report['patchSize'],report['rootRank'])
    assert np.array_equal(active,expected) and support==report['support']
    model=PatchActor(nodes,decoder,active,report['maxStep'],report['seed'])
    with np.load(stage/'initial-model.npz',allow_pickle=False) as saved:
        for key,value in {**model.p,'active':active,'embedding':model.embedding,'w1':model.w1,'w2':model.w2,
            'mean':model.mean,'scale':model.scale,**model.buffers}.items(): assert np.array_equal(value,saved[key])
    native_out=OUT/(view+'-field-native'); native_out.mkdir(exist_ok=False)
    native=Native(Path(report['environment']),directory,native_out/'learned.tsv',view=='overview',False)
    actions=[json.loads(line) for line in (stage/'actions.jsonl').read_text().splitlines()]
    records=[json.loads(line) for line in (stage/'training.jsonl').read_text().splitlines()]
    first=np.zeros(18); second=first.copy(); best=None; best_visual=report['initialVisual']; best_ind=report['initialIndividualVisual']
    action_index=accepted=probes=0; sigma=report['initialSigma']; ever_changed=False
    try:
        assert np.array_equal(nodes,np.array([n['features'] for n in native.initial['nodes']]))
        zero=model.forward(nodes)[0]; baseline=native.request(wire(zero,'MEASURE')); totals['sourceControls']+=1
        assert baseline['legal'] and baseline['visual']==best_visual and baseline['hard']==baseline['individualHard']==baseline['spacing']==0
        for step,row in enumerate(records,1):
            assert row['step']==step and row['sigma']==sigma and row['rate']==report['rate']
            base=head_vector(model,KEYS,SCALES); assert head_hash(base)==row['baseHeadSha256']; gradient=np.zeros_like(base)
            for direction,probe in enumerate(row['samples']):
                assert probe['seed']==report['seed']+step*100+direction
                noise=np.random.default_rng(probe['seed']).normal(size=base.shape); scores=[]
                for sign,sample in zip((1.,-1.),probe['samples']):
                    assert sample['sign']==sign
                    set_head_vector(model,base+sign*sigma*noise,KEYS,SCALES)
                    command=wire(model.forward(nodes)[0],'MEASURE'); assert hashlib.sha256(command.encode()).hexdigest()==sample['wireSha256']
                    measured=native.request(command); assert all(measured[k]==sample['result'][k] for k in FIELDS),(view,step,measured,sample)
                    assert measured['spacing']==0 and measured['measureOnly'] and not measured['accepted']
                    scores.append(float(measured['visual']+100*measured['spacing']+50*(measured['hard']+measured['individualHard'])))
                    probes+=1; totals['fullRewardProbeMeasurements']+=1
                gradient+=(scores[0]-scores[1])/(4*sigma)*noise
            assert float(np.linalg.norm(gradient))==row['gradientNorm']
            gradient=gradient*min(1.,10/max(float(np.linalg.norm(gradient)),1e-12))
            first=.9*first+.1*gradient; second=.999*second+.001*gradient**2
            head=base-report['rate']*(first/(1-.9**step))/(np.sqrt(second/(1-.999**step))+1e-8)
            assert head_hash(head)==row['trainedHeadSha256']
            set_head_vector(model,head,KEYS,SCALES); changed=not np.array_equal(base,head)
            assert changed==row['headChanged']; ever_changed|=changed
            if step%4==0:
                a=actions[action_index]; assert a['step']==step and digest(a['checkpoint'])==a['checkpointSha256']
                proposed=model.forward(nodes)[0]; assert hashlib.sha256(wire(proposed).encode()).hexdigest()==a['wireSha256']
                measured=native.request(wire(proposed,'MEASURE')); assert all(measured[k]==a['result'][k] for k in FIELDS)
                assert measured['spacing']==0; totals['fullTrainedOutputMeasurements']+=1
                qualifies=bool(measured['legal'] and measured['visual']<best_visual and (view=='overview' or measured['individualVisual']<=best_ind))
                assert qualifies==a['result']['accepted']
                if qualifies: best=proposed.copy(); best_visual=measured['visual']; best_ind=measured['individualVisual']; accepted+=1
                with np.load(a['checkpoint'],allow_pickle=False) as saved:
                    for key,value in {**model.p,'active':active,'embedding':model.embedding,'w1':model.w1,'w2':model.w2,
                        'mean':model.mean,'scale':model.scale,**model.buffers}.items(): assert np.array_equal(value,saved[key])
                action_index+=1
            if not ever_changed: sigma=min(.05,sigma*2)
        assert (len(records),probes,len(actions),accepted)==(report['updatesExecuted'],report['rewardProbes'],report['attempts'],report['accepted'])
        assert best_visual==report['final']['visual']
        verify_saved(directory,stage,decoder,best)
        assert native.request('SAVE')['saved']; stats=json.loads((native_out/'learned.tsv.stats.json').read_text())
        assert stats['policyActionsEvaluated']==stats['acceptedActions']==0
        verify_saved(directory,native_out,decoder,None)
    finally: native.close()
    totals['updatesReplayed']+=len(records)
    summary={'view':view,'updatesReplayed':len(records),'fullRewardProbesMeasured':probes,
        'fullTrainedOutputsMeasured':len(actions),'allFixedEncoderAndDecoderBuffersUnchanged':True,
        'allProposedPhysicalCardSpacingVerifiedZeroByFullNative':True,'acceptedOutputs':accepted,
        'initialVisual':report['initialVisual'],'savedVisual':best_visual}
    proofs.append(summary); print(json.dumps(summary),flush=True)
result={'status':'pass','scope':'Every recorded model update, every reward probe and trained output, complete source features, checkpoint arrays and saved geometry',
    'totals':totals,'stages':proofs,'nativeTryCallsDuringVerification':0,
    'productLoadOrBrowserVerifiedByThisScript':False,'targetProvenByThisScript':False,'verificationCodeSha256':digest(__file__)}
(OUT/'fields.audit.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'status':'pass',**totals}),flush=True)
