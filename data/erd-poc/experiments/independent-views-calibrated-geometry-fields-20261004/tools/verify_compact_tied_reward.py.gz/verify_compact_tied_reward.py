"""Replay tied learning; full-check all outputs and first/last reward controls."""
import hashlib
import json
from pathlib import Path
import sys
import numpy as np

sys.path.insert(0, str(Path('scripts/erd-poc').resolve()))
from compact_patch_tied_policy import TiedPatchActor
from run_compact_patch_reward import patch_support, KEYS, SCALES, objective
from joint_reward_training import head_vector, set_head_vector, head_hash, adam_head
from geometry_world_model import digest
from run_anchor_pair_walk import WalkDecoder, verify_saved
from run_anchor_pair_policy import Native, wire

ROOT = Path('.tmp/visualcross-ml-150-750-20261004/geometry-calibration1')
OUT = ROOT / 'verification'
FIELDS = ('legal', 'reason', 'visual', 'individualVisual', 'hard', 'individualHard', 'spacing')
totals = dict(updatesReplayed=0, allRewardProbeWiresReplayed=0,
              recordedRewardLabelsUsedWithoutFullRemeasurement=0,
              fullRewardProbeMeasurements=0, fullTrainedOutputMeasurements=0, sourceControls=0)
proofs = []
for view in ('individual', 'overview'):
    stage = ROOT / (view + '-tied1')
    report = json.loads((stage / 'report.json').read_text())
    directory = Path(report['sourceDirectory'])
    for name, sha in report['codeSha256'].items():
        assert digest(Path('scripts/erd-poc') / name) == sha
    for name, sha in report['sourceInputs'].items():
        assert digest(directory / name) == sha
    for name in ('environment', 'sourceBinding'):
        assert digest(report[name]) == report[name + 'Sha256']
    for filename, key in [('training.jsonl', 'trainingSha256'), ('actions.jsonl', 'actionsSha256'),
                          ('observations.npz', 'observationsSha256'), ('initial-model.npz', 'initialModelSha256')]:
        assert digest(stage / filename) == report[key]
    decoder = WalkDecoder(directory)
    with np.load(stage / 'observations.npz', allow_pickle=False) as saved:
        nodes = saved['nodes'].copy()
        active = saved['active'].copy()
    expected, support = patch_support(decoder, nodes, report['patchSize'], report['rootRank'])
    assert np.array_equal(active, expected) and support == report['support']
    model = TiedPatchActor(nodes, decoder, active, report['maxStep'], report['seed'])

    def check_arrays(path):
        with np.load(path, allow_pickle=False) as saved:
            for key, value in {**model.p, 'active': active, 'embedding': model.embedding,
                               'w1': model.w1, 'w2': model.w2, 'mean': model.mean,
                               'scale': model.scale, **model.buffers}.items():
                assert np.array_equal(value, saved[key]), key

    check_arrays(stage / 'initial-model.npz')
    actions = [json.loads(line) for line in (stage / 'actions.jsonl').read_text().splitlines()]
    records = [json.loads(line) for line in (stage / 'training.jsonl').read_text().splitlines()]
    native_out = OUT / (view + '-tied-native')
    native_out.mkdir(exist_ok=False)
    native = Native(Path(report['environment']), directory, native_out / 'learned.tsv', view == 'overview', False)
    first = np.zeros(18)
    second = first.copy()
    best = None
    best_visual = report['initialVisual']
    best_ind = report['initialIndividualVisual']
    action_index = accepted = probes = full_probes = 0
    sigma = report['initialSigma']
    ever_changed = False
    try:
        assert np.array_equal(nodes, np.array([n['features'] for n in native.initial['nodes']]))
        baseline = native.request(wire(model.forward(nodes)[0], 'MEASURE'))
        totals['sourceControls'] += 1
        assert baseline['legal'] and baseline['visual'] == best_visual
        assert baseline['hard'] == baseline['individualHard'] == baseline['spacing'] == 0
        for step, row in enumerate(records, 1):
            assert row['step'] == step and row['sigma'] == sigma and row['rate'] == report['rate']
            base = head_vector(model, KEYS, SCALES)
            assert head_hash(base) == row['baseHeadSha256']
            gradient = np.zeros_like(base)
            for direction, probe in enumerate(row['samples']):
                assert probe['seed'] == report['seed'] + step * 100 + direction
                noise = np.random.default_rng(probe['seed']).normal(size=base.shape)
                scores = []
                for sign, sample in zip((1., -1.), probe['samples']):
                    assert sample['sign'] == sign
                    set_head_vector(model, base + sign * sigma * noise, KEYS, SCALES)
                    command = wire(model.forward(nodes)[0], 'MEASURE')
                    assert hashlib.sha256(command.encode()).hexdigest() == sample['wireSha256']
                    if step in (1, len(records)):
                        measured = native.request(command)
                        assert all(measured[k] == sample['result'][k] for k in FIELDS), (view, step)
                        totals['fullRewardProbeMeasurements'] += 1
                        full_probes += 1
                    else:
                        measured = sample['result']
                        totals['recordedRewardLabelsUsedWithoutFullRemeasurement'] += 1
                    assert measured['spacing'] == 0
                    scores.append(objective(measured))
                    probes += 1
                    totals['allRewardProbeWiresReplayed'] += 1
                gradient += (scores[0] - scores[1]) / (4 * sigma) * noise
            assert float(np.linalg.norm(gradient)) == row['gradientNorm']
            head, first, second = adam_head(base, gradient, first, second, step, report['rate'])
            assert head_hash(head) == row['trainedHeadSha256']
            set_head_vector(model, head, KEYS, SCALES)
            changed = not np.array_equal(base, head)
            assert changed == row['headChanged']
            ever_changed |= changed
            if step % 4 == 0:
                action = actions[action_index]
                assert action['step'] == step and digest(action['checkpoint']) == action['checkpointSha256']
                proposed = model.forward(nodes)[0]
                assert hashlib.sha256(wire(proposed).encode()).hexdigest() == action['wireSha256']
                measured = native.request(wire(proposed, 'MEASURE'))
                assert all(measured[k] == action['result'][k] for k in FIELDS), (view, step)
                assert measured['spacing'] == 0
                totals['fullTrainedOutputMeasurements'] += 1
                qualifies = bool(measured['legal'] and measured['visual'] < best_visual
                                 and (view == 'overview' or measured['individualVisual'] <= best_ind))
                assert qualifies == action['result']['accepted']
                if qualifies:
                    best = proposed.copy()
                    best_visual = measured['visual']
                    best_ind = measured['individualVisual']
                    accepted += 1
                check_arrays(action['checkpoint'])
                action_index += 1
            if not ever_changed:
                sigma = min(.05, sigma * 2)
        assert (len(records), probes, len(actions), accepted) == (
            report['updatesExecuted'], report['rewardProbes'], report['attempts'], report['accepted'])
        assert full_probes == 8 and best_visual == report['final']['visual']
        verify_saved(directory, stage, decoder, best)
        assert native.request('SAVE')['saved']
        stats = json.loads((native_out / 'learned.tsv.stats.json').read_text())
        assert stats['policyActionsEvaluated'] == stats['acceptedActions'] == 0
        verify_saved(directory, native_out, decoder, None)
    finally:
        native.close()
    totals['updatesReplayed'] += len(records)
    summary = dict(view=view, updatesReplayed=len(records), allRewardProbeWiresReplayed=probes,
                   fullRewardProbeControlsMeasured=full_probes, fullTrainedOutputsMeasured=len(actions),
                   allFixedEncoderAndDecoderBuffersUnchanged=True, allRecordedProbeSpacingLabelsZero=True,
                   allTrainedOutputSpacingVerifiedZeroByFullNative=True, acceptedOutputs=accepted,
                   initialVisual=report['initialVisual'], savedVisual=best_visual)
    proofs.append(summary)
    print(json.dumps(summary), flush=True)
result = dict(status='pass',
              scope='All updates, reward probe wires, source features, checkpoint arrays, trained outputs and saved geometry; full reward controls only for the first and last update of each view',
              totals=totals, stages=proofs, nativeTryCallsDuringVerification=0,
              productLoadOrBrowserVerifiedByThisScript=False, targetProvenByThisScript=False,
              verificationCodeSha256=digest(__file__))
(OUT / 'tied-fields.audit.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(dict(status='pass', **totals)), flush=True)
