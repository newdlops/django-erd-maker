"""Seal calibrated event ranking and compact NN reward learning with precise scopes."""
import ast
import gzip
import hashlib
import json
from pathlib import Path
import re

ROOT = Path('.tmp/visualcross-ml-150-750-20261004/geometry-calibration1')
WORLD = ROOT.parent / 'geometry-world1'
ARCHIVE = Path('data/erd-poc/experiments/independent-views-calibrated-geometry-fields-20261004')
PARENT = Path('data/erd-poc/experiments/independent-views-geometry-world-20261004/manifest.json')
PARENT_SHA = 'bbb05d5525532628c58084a27999c7c69bf0d46477291732165efa35b3a48831'
STABLE = Path('data/erd-poc/candidates/captain-ml-independent-views.layout.json')
CANONICAL = '4e741de39ca655c7ff042422b9407206427f89e02ecd56b7f4a9f36f6a5cd02e'


def streamed(stream):
    h = hashlib.sha256()
    size = 0
    while block := stream.read(65536):
        h.update(block)
        size += len(block)
    return size, h.hexdigest()


def digest(path):
    with Path(path).open('rb') as stream:
        return streamed(stream)[1]


def restored(path):
    with Path(path).open('rb') as stream:
        packed = stream.read(2) == b'\x1f\x8b'
    with (gzip.open(path, 'rb') if packed else Path(path).open('rb')) as stream:
        return streamed(stream)


assert not ARCHIVE.exists() and digest(STABLE) == CANONICAL and digest(PARENT) == PARENT_SHA
proofs = {name: json.loads((ROOT / 'verification' / (name + '.audit.json')).read_text())
          for name in ('calibration', 'walks', 'fields', 'tied-fields', 'field-hard-diagnosis')}
assert all(p['status'] == 'pass' for p in proofs.values())
assert proofs['calibration']['updatesReplayed'] == 2100
assert proofs['walks']['counts']['fullMeasures'] == 50
assert proofs['fields']['totals']['fullRewardProbeMeasurements'] == 940
assert proofs['tied-fields']['totals'] == dict(updatesReplayed=95, allRewardProbeWiresReplayed=380,
    recordedRewardLabelsUsedWithoutFullRemeasurement=364, fullRewardProbeMeasurements=16,
    fullTrainedOutputMeasurements=23, sourceControls=2)
stages = {}
for name in ('individual-walk1', 'overview-walk1', 'individual-field1', 'overview-field1',
             'individual-tied1', 'overview-tied1'):
    stage = ROOT / name
    report = json.loads((stage / 'report.json').read_text())
    assert report['accepted'] == 0 and report['final']['hardConditions'] == 0
    actions = [json.loads(line) for line in (stage / 'actions.jsonl').read_text().splitlines()]
    summary = {key: report[key] for key in ('view', 'attempts', 'accepted', 'initialVisual')}
    summary['reasons'] = report.get('reasons')
    if 'updatesExecuted' in report:
        rows = [json.loads(line) for line in (stage / 'training.jsonl').read_text().splitlines()]
        samples = [s['result'] for row in rows for pair in row['samples'] for s in pair['samples']]
        summary.update(updatesExecuted=report['updatesExecuted'], rewardProbes=len(samples),
                       legalRewardProbes=sum(s['legal'] for s in samples),
                       minimumProbeHard=min(s['hard'] for s in samples),
                       legalTrainedOutputs=sum(a['result']['legal'] for a in actions),
                       trainableParameters=report['trainableParameters'])
    stages[name] = summary
diagnosis = dict(status='pass', strictImprovements=0, candidatePromoted=False,
    overviewVisual=285, individualVisual=1963, targetOverview=150, targetIndividual=750, targetMet=False,
    newTrainingUpdates=2430, fullyReplayedTrajectoryRankings=1952, completedTryCalls=137,
    completedTryCallsFullyRemeasured=129, failedStaticTryCallsNotFullyRemeasured=8,
    fullNativeVerificationMeasurements=1091, newCompactRewardProbes=1320,
    newCompactRewardProbesFullyRemeasured=956, tiedRewardProbesReplayedFromRecordedLabelsOnly=364,
    calibrationValidationIsUnseenCaptainScene=False,
    calibrationRawValidationMse=proofs['calibration']['rawValidationMse'],
    calibrationSelectedValidationMse=proofs['calibration']['calibratedValidationMse'],
    sourceCoincidentEndpointFixturePassed=True, tiedDecoderDoesNotProveAllAdjacentEdgeLegality=True,
    failedStaticDuplicateCauseVerified=True, failedStaticAllRanksOrMetricsReplayed=False,
    nativeCoordinateSearchOrRepairs=0, browserVerified=False, stages=stages)
assert sum(s.get('updatesExecuted', 0) for s in stages.values()) + 2100 == diagnosis['newTrainingUpdates']
(ROOT / 'diagnosis.json').write_text(json.dumps(diagnosis, indent=2) + '\n')
logs = sorted({p for pattern in ('geometry-calibration-*.guard.log', 'compact-patch-*.guard.log',
                               'shared-patch-*.guard.log') for p in Path('.tmp').glob(pattern)
               if not p.name.startswith('geometry-calibration-archive-')})
jobs = []
for path in logs:
    content = path.read_text()
    peaks = re.findall(r'memory guard: peak=([0-9.]+) MiB limit=([0-9.]+) MiB', content)
    refused = 'refusing to start: another ERD research optimizer is running' in content
    assert len(peaks) == 1 or refused, path
    if peaks:
        peak, limit = map(float, peaks[0])
        assert limit == 128 and peak <= limit
    jobs.append(dict(log=str(path), logSha256=digest(path), sampledPeakMiB=peak if peaks else None,
                     terminalGuardReceiptPresent=bool(peaks), refusedBeforeChildLaunch=refused,
                     tracebackObserved='Traceback (most recent call last)' in content))
resources = dict(limitMiB=128, mathThreads=1, niceAdjustment=10, numericalJobsSerialized=True,
    sampledProcessGroupRssGuard=True, hardCpuPercentageQuota=False, limitRaised=False,
    allListedJobsTerminal=True, observedMaximumSampledPeakMiB=max(j['sampledPeakMiB'] or 0 for j in jobs),
    jobs=jobs, unguardedTextGenerationAttempt=dict(exitCode=137, outputFileCreated=False,
      replacedByWorkspaceApplyPatch=True, mathematicalJob=False, causeEstablished=False))
(ROOT / 'resources.json').write_text(json.dumps(resources, indent=2) + '\n')
entries = {str(p): Path('run') / p.relative_to(ROOT) for p in ROOT.rglob('*') if p.is_file()}
for p in logs:
    entries[str(p)] = Path('logs') / p.name
scripts = Path('scripts/erd-poc')
pending = ['calibrated_geometry_world.py', 'run_calibrated_macro_policy.py', 'run_calibrated_macro_walk.py',
           'compact_patch_neural_policy.py', 'run_compact_patch_reward.py', 'compact_patch_tied_policy.py',
           'run_compact_tied_reward.py', 'run_memory_bounded.py']
helpers = ['train_geometry_calibration.py', 'verify_geometry_calibration.py', 'verify_calibrated_macro_walks.py',
           'verify_compact_patch_reward.py', 'verify_compact_tied_reward.py', 'diagnose_compact_patch_hard.py',
           'test_compact_patch_decoder.py', 'test_shared_patch_endpoints.py',
           'seal_geometry_calibration.py', 'verify_geometry_calibration_archive.py', 'finalize_geometry_calibration.py']


def imports(path):
    for node in ast.walk(ast.parse(path.read_text())):
        modules = [node.module] if isinstance(node, ast.ImportFrom) else (
            [item.name for item in node.names] if isinstance(node, ast.Import) else [])
        for module in modules:
            if module and (scripts / (module + '.py')).is_file():
                pending.append(module + '.py')


for name in helpers:
    p = Path('.tmp') / name
    assert p.is_file(), p
    entries[str(p)] = Path('tools') / name
    imports(p)
seen = set()
while pending:
    name = pending.pop()
    if name in seen:
        continue
    seen.add(name)
    p = scripts / name
    entries[str(p)] = Path('code') / name
    imports(p)
dependencies = {'context.md', 'data/erd-poc/candidates/README.md',
    'data/erd-poc/recovered/captain-2026-09-15-payload.json', str(WORLD / 'source-binding.json'),
    str(WORLD / 'training2/model.npz'), str(WORLD / 'verification/policies.audit.json'),
    str(PARENT.parent / 'final-artifact-record.json'), '.tmp/cli-transport-20261004-followup.json'}
dependencies.update(str(STABLE.with_name('captain-ml-independent-views.' + suffix))
                    for suffix in ('layout.json', 'audit.json', 'provenance.json'))
for view in ('overview-source285', 'individual-source1963'):
    dependencies.update(str(p) for p in (WORLD / view).iterdir() if p.is_file())
parent_proof = json.loads((WORLD / 'verification/policies.audit.json').read_text())
for summary in parent_proof['stages']:
    dependencies.update(str(WORLD / summary['stage'] / name)
                        for name in ('report.json', 'actions.jsonl', 'ranking.jsonl'))
native = Path('.tmp/visualcross-ml-150-750-20261003/pair-neutral-walk1')
dependencies.update((str(native / 'environment'), str(native / 'build-inputs.json')))
dependencies.update(str(p) for p in (native / 'build-inputs').iterdir() if p.is_file())
for source in dependencies:
    assert Path(source).is_file(), source
    entries.setdefault(source, Path('dependencies') / digest(source) / Path(source).name)
parent = json.loads(PARENT.read_text())
expected = {str(PARENT): PARENT_SHA, **{p['path']: p['sha256'] for p in parent['prerequisiteManifests']}}
known = {}
for item in parent['files']:
    known.setdefault(item['sha256'], (PARENT.parent / item['archive'], item['bytes'], str(PARENT)))
for item in parent['referencedFiles']:
    known.setdefault(item['sha256'], (Path(item['archive']), item['bytes'], item['prerequisiteManifest']))
ARCHIVE.mkdir(parents=True)
files = []
references = []
reused = {}
checked = set()
required = {str(PARENT)}
for source, relative in sorted(entries.items()):
    p = Path(source)
    size = p.stat().st_size
    sha = digest(p)
    if sha in known:
        stored, original_size, prerequisite = known[sha]
        assert size == original_size
        if sha not in checked:
            assert restored(stored) == (size, sha)
            checked.add(sha)
        required.add(prerequisite)
        references.append(dict(source=source, archive=str(stored), bytes=size, sha256=sha,
                               prerequisiteManifest=prerequisite, restoreHashVerified=True))
        continue
    if sha in reused:
        stored, packed = reused[sha]
    else:
        stored = Path(str(relative) + '.gz')
        destination = ARCHIVE / stored
        destination.parent.mkdir(parents=True, exist_ok=True)
        with destination.open('xb') as out, gzip.GzipFile(filename='', mode='wb', compresslevel=1,
                mtime=0, fileobj=out) as compressed, p.open('rb') as original:
            while block := original.read(65536):
                compressed.write(block)
        assert restored(destination) == (size, sha)
        packed = destination.stat().st_size
        reused[sha] = stored, packed
    files.append(dict(source=source, archive=str(stored), bytes=size, sha256=sha, compressedBytes=packed))
prerequisites = []
for filename in sorted(required):
    assert digest(filename) == expected[filename]
    prerequisites.append(dict(path=filename, sha256=expected[filename]))
assert digest(STABLE) == CANONICAL
manifest = dict(scope='Calibrated NN ranking and compact learned fields; complete optimizer replay, all actual trajectory/field outputs, precise sampled tied reward scope; failed static run retained',
    candidateSource=str(STABLE), candidateSha256=CANONICAL, overviewVisual=285, individualVisual=1963,
    targetOverview=150, targetIndividual=750, targetMet=False, promotedNewCandidate=False,
    newTrainingUpdates=2430, modelRankingsFullyReplayed=1952, actualNeuralMoves=137,
    actualNeuralMovesFullyRemeasured=129, strictImprovements=0, verification=proofs,
    diagnosis=diagnosis, resources=resources, nativeCoordinateSearchOrRepairs=0, browserVerified=False,
    prerequisiteManifests=prerequisites, files=files, referencedFiles=references,
    newPhysicalCompressedFiles=len(reused), newPhysicalCompressedBytes=sum(v[1] for v in reused.values()),
    allStoredAndReferencedMappingsRestoreHashVerified=True, sourcesUnchangedAtSeal=True)
path = ARCHIVE / 'manifest.json'
path.write_text(json.dumps(manifest, indent=2) + '\n')
receipt = dict(manifest=str(path), manifestSha256=digest(path), candidateSha256=CANONICAL,
    newMappings=len(files), referencedMappings=len(references), newPhysicalCompressedFiles=len(reused),
    newPhysicalCompressedBytes=manifest['newPhysicalCompressedBytes'])
out = Path('.tmp/geometry-calibration-archive-seal-receipt.json')
assert not out.exists()
out.write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt), flush=True)
