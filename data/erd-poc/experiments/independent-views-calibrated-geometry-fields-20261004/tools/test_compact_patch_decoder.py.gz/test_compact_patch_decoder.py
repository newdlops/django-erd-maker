"""Catch spacing loss at active/inactive borders and within a moving patch."""
from pathlib import Path
import sys
import numpy as np
sys.path.insert(0,str(Path('scripts/erd-poc').resolve()))
from compact_patch_neural_policy import patch_buffers,decode_patch

positions=np.array([[0.,0.],[180.,0.],[360.,0.]])
sizes=np.full((3,2),100.); active=np.array([0,1],dtype=np.int32)
buffers=patch_buffers(positions,sizes,active,100.)
assert np.array_equal(decode_patch(np.ones((2,2)),buffers),[[48.,0.],[24.,0.]])
assert np.array_equal(decode_patch(-np.ones((2,2)),buffers),[[0.,0.],[-24.,0.]])
assert np.array_equal(decode_patch(np.zeros((2,2)),buffers),np.zeros((2,2)))
rng=np.random.default_rng(106709)
for _ in range(100):
    delta=np.zeros_like(positions); delta[active]=decode_patch(rng.uniform(-1,1,(2,2)),buffers)
    placed=positions+delta
    assert np.array_equal(placed[2],positions[2])
    assert placed[:,0].min()>=0 and placed[:,0].max()<=360
    for n,m in [(0,1),(0,2),(1,2)]:
        clearance=abs(placed[n]-placed[m])-(sizes[n]+sizes[m])/2-[55.99,41.99]
        assert (clearance>=-1e-8).any(),(placed,n,m)
print('PASS: literal patch limits and 100 independent geometry invariants')
