"""Rebuild amplitude learning and replay stochastic policies and trajectories."""
import sys
from pathlib import Path
sys.path.insert(0, str(Path('scripts/erd-poc').resolve()))
import gc
import hashlib
import json
import zipfile
from contextlib import redirect_stdout
from io import StringIO
from types import SimpleNamespace
import numpy as np
from directed_cycle_model import KEYS, load as load_parent
from fractional_cycle_model import FractionCritic, load
from train_fractional_cycle_model import collect, split, chunk_predictions, code_hashes
from run_fraction_conditioned_policy import replay as replay_independent, FRACTIONS
from run_fraction_cycle_walk import replay as replay_walk
from run_anchor_pair_policy import digest
from run_anchor_pair_walk import WalkDecoder
from learned_global_replay import pairs

root = Path('.tmp/visualcross-ml-150-750-20261003/fraction-conditioned-model1')
path = root/'records-verification.json'; assert not path.exists()
training = json.loads((root/'training1/training.json').read_text())
assert code_hashes() == training['codeSha256']
assert digest(root/'training1/model.npz') == training['checkpointSha256']
assert digest(root/'training1/dataset.npz') == training['datasetSha256']
assert digest(training['parent']) == training['parentSha256']
assert digest(training['parentDataset']) == training['parentDatasetSha256']
assert digest(training['parentTrainingReport']) == training['parentTrainingReportSha256']
parent_directory = Path(training['parent']).parent
rebuilt, sources, inputs = collect(parent_directory, parent_directory.parent)
assert sources == training['sourceStages'] and inputs == training['sourceInputsByView']
with zipfile.ZipFile(root/'training1/dataset.npz') as archive:
    for name, expected in rebuilt.items():
        assert expected.flags.c_contiguous and not expected.dtype.hasobject
        with archive.open(name+'.npy') as stream:
            version = np.lib.format.read_magic(stream)
            assert version in [(1, 0), (2, 0)]
            shape, fortran, dtype = (np.lib.format.read_array_header_1_0 if version == (1, 0)
                else np.lib.format.read_array_header_2_0)(stream)
            assert shape == expected.shape and dtype == expected.dtype and not fortran
            actual_hash = hashlib.sha256(); total = 0
            while block := stream.read(65536):
                actual_hash.update(block); total += len(block)
            assert total == expected.nbytes
            assert actual_hash.hexdigest() == hashlib.sha256(memoryview(expected).cast('B')).hexdigest()
data = rebuilt
with np.load(root/'training1/dataset.npz', allow_pickle=False) as saved:
    data |= {name: saved[name].copy() for name in ['training', 'validation', 'sampling']}
del rebuilt; gc.collect()
training_ids, validation, sampling, rng = split(data, training['seed'])
assert np.array_equal(training_ids, data['training'])
assert np.array_equal(validation, data['validation']) and np.array_equal(sampling, data['sampling'])
with np.load(training['parentDataset'], allow_pickle=False) as saved:
    parent_keys = {(str(view), *sorted(map(int, word))) for view, word in zip(saved['view'], saved['cycles'])}
assert all((str(data['view'][i]), *sorted(map(int, data['cycles'][i]))) not in parent_keys for i in validation)
parent, _ = load_parent(training['parent']); model = FractionCritic(parent)
x = data['x']; y = data['y']; initial = {key: value.copy() for key, value in model.p.items()}
with np.load(root/'training1/model.npz', allow_pickle=False) as saved:
    assert all(np.array_equal(initial[key], saved['initial__'+key]) for key in KEYS)
    assert np.array_equal(model.mean, saved['mean']) and np.array_equal(model.scale, saved['scale'])
assert np.array_equal(model.mean[:136], parent.mean) and np.array_equal(model.scale[:136], parent.scale)
warm = float(np.max(abs(chunk_predictions(model, x)-chunk_predictions(parent, x[:, :, :136]))))
assert warm == training['warmPredictionMaxDifference']
first = {key: np.zeros_like(value) for key, value in model.p.items()}
second = {key: value.copy() for key, value in first.items()}; updates = 0
best_loss = model.loss(x[validation], y[validation]); assert best_loss == training['initialValidationHuber']
best = initial; selected_updates = selected_epoch = 0
for expected in training['history']:
    order = rng.permutation(sampling)
    for offset in range(0, len(order), 64):
        batch = order[offset:offset+64]; _, gradients = model.loss(x[batch], y[batch], True)
        norm = np.sqrt(sum(np.sum(value*value) for value in gradients.values())); updates += 1
        for key in KEYS:
            gradient = gradients[key]*min(1, 5/max(norm, 1e-12))
            first[key] = .9*first[key]+.1*gradient; second[key] = .999*second[key]+.001*gradient*gradient
            model.p[key] -= .001*(first[key]/(1-.9**updates))/(np.sqrt(second[key]/(1-.999**updates))+1e-8)
        if updates == expected['updates']:
            break
    actual = model.loss(x[validation], y[validation]); assert actual == expected['validationHuber'] and updates == expected['updates']
    if actual < best_loss:
        best_loss = actual; best = {key: value.copy() for key, value in model.p.items()}
        selected_updates = updates; selected_epoch = expected['epoch']
assert updates == training['newTrainingUpdatesExecuted']
assert (selected_updates, selected_epoch) == (training['selectedCheckpointUpdates'], training['selectedEpoch'])
restored, _ = load(root/'training1/model.npz'); assert all(np.array_equal(best[key], restored.p[key]) for key in KEYS)
changes = {key: float(np.linalg.norm(best[key]-initial[key])) for key in KEYS}
assert all(value > 0 for value in changes.values())
extra_norm = float(np.linalg.norm(best['w1'][-5:])); assert extra_norm > 0
del x, y, data, model, parent, restored; gc.collect()

independent = []; walks = []; matched = {}
for view in ['individual', 'overview']:
    for name in ['sample1', 'sample4']:
        stage = root/(view+'-'+name); report = json.loads((stage/'report.json').read_text())
        output = StringIO()
        with redirect_stdout(output):
            replay_independent(SimpleNamespace(out=stage))
        replay = json.loads(output.getvalue())
        assert report['accepted'] == 0
        reference = root.parent/'pair-anchor-sparse1/actual-validation'/(view+'-sparse.tsv')
        for suffix in ['', '.routes.tsv', '.individual', '.individual.routes.tsv']:
            assert digest(stage/('learned.tsv'+suffix)) == digest(Path(str(reference)+suffix))
        rows = [json.loads(line) for line in (stage/'actions.jsonl').read_text().splitlines()]
        with np.load(stage/'observations.npz', allow_pickle=False) as saved:
            nodes = saved['node_features'].copy(); vocabulary = saved['cycles'].copy()
            if view not in matched:
                matched[view] = {key: saved[key].copy() for key in ['node_features', 'cycles', 'fractions', 'scores', 'gumbel']}
            else:
                assert all(np.array_equal(saved[key], value) for key, value in matched[view].items())
        active = np.any(nodes[:, 4:6] > 0, axis=1)
        assert all(active[row['cycle']].sum() >= 2 for row in rows)
        legal = [row['result']['visual'] for row in rows if row['result']['legal']]
        hard = [row['result']['visual'] for row in rows if row['result']['reason'] == 'hard']
        independent.append({'stage': str(stage), 'view': view, 'temperature': report['policy']['temperature'],
            'replay': replay, 'reasons': report['reasons'], 'savedGeometryByteIdenticalToReference': True,
            'bestLegalMeasuredVisual': min(legal), 'equalVisualActions': legal.count(report['initialVisual']),
            'hardRejectedVisualBetterThanSource': sum(visual < report['initialVisual'] for visual in hard),
            'fractionActionCounts': {str(fraction): sum(row['fraction'] == fraction for row in rows) for fraction in FRACTIONS},
            'submittedWireHashes': sorted({row['wireSha256'] for row in rows})})
        gc.collect()
    stage = root/(view+'-walk1'); report = json.loads((stage/'report.json').read_text()); output = StringIO()
    with redirect_stdout(output):
        replay_walk(SimpleNamespace(out=stage))
    replay = json.loads(output.getvalue()); assert report['strictImprovements'] == 0
    moved = set(); directly_conflicting = set(); cumulative = None; accepted_fractions = []; per_step = []
    original = Path(report['sourceDirectory']); original_decoder = WalkDecoder(original)
    cumulative = np.zeros_like(original_decoder.positions)
    for step in report['steps']:
        if not step['admitted']:
            continue
        current = stage/f"round-{step['round']:02}"
        row = step['acceptedRow']; word = np.array(row['cycle'], dtype=np.int32)
        with np.load(current/'observations.npz', allow_pickle=False) as saved:
            active = np.any(saved['node_features'][:, 4:6] > 0, axis=1)
        assert active[word].sum() >= 2
        moved.update(map(int, word)); directly_conflicting.update(map(int, word[active[word]]))
        action = np.load(current/'accepted-action.npy'); delta = action[:len(original_decoder.positions)]
        assert np.sum(np.any(delta != 0, axis=1)) == 3
        cumulative += delta; accepted_fractions.append(row['fraction'])
        per_step.append({'round': step['round'], 'directlyConflictingOwnersMoved': int(active[word].sum()),
            'exactlyThreeOwnersMove': True, 'visual': step['visual']})
    assert len(moved) == report['distinctMovedDirectConflictOwners']
    final_directory = Path(report['finalSourceDirectory'])
    final_positions = np.array(list(pairs(final_directory/'positions.tsv').values()))
    assert np.max(abs(final_positions-original_decoder.positions-cumulative)) < 1e-6
    original_full = np.array(list(pairs(original/'individual.positions.tsv').values()))
    final_full = np.array(list(pairs(final_directory/'individual.positions.tsv').values()))
    assert np.max(abs(final_full-original_full-cumulative[original_decoder.provider.owner])) < 1e-6
    low = (final_positions-original_decoder.sizes/2).min(0); high = (final_positions+original_decoder.sizes/2).max(0)
    frame_area = float(np.prod(high-low)); assert frame_area <= 1.5e9
    stop = report['stopReason']
    if report['steps'][-1]['attempts'] == 0 and report['wallSeconds'] >= report['secondsLimit']:
        stop = 'time limit before final-round action; raw stopReason overwritten by no-action branch'
    walks.append({'stage': str(stage), 'view': view, 'replay': replay, 'frameArea': frame_area,
        'distinctMovedOwners': len(moved), 'distinctOwnersDirectlyConflictingWhenMoved': len(directly_conflicting),
        'netMovedOwners': int(np.any(abs(cumulative) > 1e-8, axis=1).sum()),
        'maximumNetDisplacement': float(np.linalg.norm(cumulative, axis=1).max()),
        'acceptedFractionCounts': {str(fraction): accepted_fractions.count(fraction) for fraction in FRACTIONS},
        'rawMovedDirectConflictFieldCountsAllCycleOwners': True, 'derivedStopReason': stop,
        'cumulativePhysicalAndFullTranslationsIndependentlyReconstructed': True, 'admittedSteps': per_step})
    gc.collect()
overlap = {view: len(set(independent[2*i]['submittedWireHashes']) & set(independent[2*i+1]['submittedWireHashes']))
    for i, view in enumerate(['individual', 'overview'])}
for row in independent:
    del row['submittedWireHashes']
result = {'status': 'pass', 'rows': training['rows'], 'novelMeasuredRows': training['novelMeasuredRows'],
    'completeDatasetReconstructed': True, 'validationTriplesAbsentFromCompleteParentDataset': True,
    'validationGroupsIncludeAllFractionsAndDirections': True, 'unseenGraphValidation': False,
    'trainingUpdatesReplayed': updates, 'selectedCheckpointUpdates': selected_updates,
    'selectedWeightsBitwiseReproduced': True, 'originalNormalizationUnchanged': True,
    'additionalInputWeightRowsL2': extra_norm, 'parameterGroupChangesL2': changes,
    'matchedTemperaturesHaveIdenticalCandidateScoresAndGumbelNoise': True,
    'exclusionScope': 'complete checkpoint measured dataset; matched temperatures intentionally repeat some supplied wires',
    'matchedTemperatureRepeatedWireCountsByView': overlap,
    'independentStages': independent, 'walkStages': walks,
    'independentModelActionsReplayed': sum(row['replay']['modelActionsReplayed'] for row in independent),
    'walkModelActionsReplayed': sum(row['replay']['modelActionsReplayed'] for row in walks),
    'walkAdmittedStates': sum(row['replay']['admittedStates'] for row in walks), 'strictImprovements': 0,
    'nativeScoresRecomputed': False}
path.write_text(json.dumps(result, indent=2)+'\n')
print(json.dumps({key: result[key] for key in ['status', 'rows', 'trainingUpdatesReplayed',
    'selectedCheckpointUpdates', 'independentModelActionsReplayed', 'walkModelActionsReplayed', 'walkAdmittedStates']}))
print(json.dumps([{key: row[key] for key in ['view', 'distinctMovedOwners',
    'distinctOwnersDirectlyConflictingWhenMoved', 'maximumNetDisplacement', 'derivedStopReason']} for row in walks]))
