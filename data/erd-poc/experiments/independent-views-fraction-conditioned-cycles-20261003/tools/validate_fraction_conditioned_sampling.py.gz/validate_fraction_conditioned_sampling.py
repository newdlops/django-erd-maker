"""Validate the sampler formula, learned logits and complete-parent exclusion."""
import sys
from pathlib import Path
sys.path.insert(0, str(Path('scripts/erd-poc').resolve()))
import json
import numpy as np
from fractional_cycle_model import load
from run_anchor_pair_walk import WalkDecoder
from run_directed_cycle_policy import coordinated_cycles, measured
from run_fraction_conditioned_policy import sample_order, rank, FRACTIONS

root = Path('.tmp/visualcross-ml-150-750-20261003/fraction-conditioned-model1')
path = root/'sampling-validation.json'; assert not path.exists()
scores = np.array([[3., -1., 0.], [-4., 2., .5]])
order, noise, policy = sample_order(scores, 59, 2.)
expected_noise = np.random.default_rng(59).gumbel(size=scores.shape)
expected_order = sorted(range(scores.size), key=lambda i: (-float(scores.ravel()[i]/2+expected_noise.ravel()[i]), i))
assert np.array_equal(noise, expected_noise) and order.tolist() == expected_order
assert len(set(order.tolist())) == scores.size
assert np.array_equal(sample_order(scores, 59, 2.)[0], order)
probabilities = np.exp(scores/2); probabilities /= probabilities.sum()
assert np.max(abs(probabilities.sum(0)-policy['fractionProbabilityMass'])) < 1e-12
count = np.zeros(scores.size, dtype=int)
for seed in range(4000):
    sampled, _, _ = sample_order(scores, seed, 2.)
    count[sampled[0]] += 1
assert np.max(abs(count/count.sum()-probabilities.ravel())) < .03

model, metadata = load(root/'training1/model.npz'); views = []
for view in ['individual', 'overview']:
    previous = root.parent/'directed-cycle-model1'/(view+'-directed1')
    report = json.loads((previous/'report.json').read_text())
    decoder = WalkDecoder(Path(report['sourceDirectory']))
    with np.load(previous/'observations.npz', allow_pickle=False) as saved:
        nodes = saved['node_features'].copy()
    seen = measured(metadata, view)
    vocabulary, support = coordinated_cycles(decoder, nodes, seen, 84053, 64)
    measured_keys = {tuple(sorted(map(int, word))) for word in seen}
    assert all(tuple(sorted(map(int, word))) not in measured_keys for word in vocabulary)
    predictions, _, _ = rank(model, decoder, nodes, vocabulary, view == 'overview')
    assert predictions.shape == (128, len(FRACTIONS))
    # The added input is now learned, not just a fixed motion decoder transfer.
    different = np.ptp(predictions, axis=1) > 1e-8
    assert different.all()
    views.append({'view': view, 'support': support, 'testedCycleDirections': len(vocabulary),
        'allScoresDependOnActionFraction': True, 'allParentMeasuredTriplesExcluded': True})
result = {'status': 'pass', 'directScalarGumbelOrderChecked': True, 'sameSeedExactReplay': True,
    'withoutReplacement': True, 'firstChoiceBoltzmannDistributionChecks': 4000,
    'maximumEmpiricalProbabilityError': float(np.max(abs(count/count.sum()-probabilities.ravel()))),
    'views': views, 'nativeGeometryNotInvoked': True}
path.write_text(json.dumps(result, indent=2)+'\n')
print(json.dumps({key: result[key] for key in ['status', 'firstChoiceBoltzmannDistributionChecks', 'maximumEmpiricalProbabilityError']}))
