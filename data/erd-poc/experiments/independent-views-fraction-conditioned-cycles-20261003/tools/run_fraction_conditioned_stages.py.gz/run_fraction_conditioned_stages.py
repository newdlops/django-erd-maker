"""Compare two predefined temperatures on identical neural candidate fields."""
import sys
from pathlib import Path
sys.path.insert(0, str(Path('scripts/erd-poc').resolve()))
import gc
import json
from types import SimpleNamespace
from run_fraction_conditioned_policy import run

root = Path('.tmp/visualcross-ml-150-750-20261003/fraction-conditioned-model1')
for view in ['individual', 'overview']:
    source = json.loads((root.parent/'directed-cycle-model1'/(view+'-directed1')/'report.json').read_text())
    for name, temperature in [('sample1', 1.), ('sample4', 4.)]:
        run(SimpleNamespace(out=root/(view+'-'+name), directory=Path(source['sourceDirectory']),
            environment=Path(source['environment']), checkpoint=root/'training1/model.npz', view=view,
            triples=4096, budget=1024, seconds=20, vocabulary_seed=84053, sampling_seed=84059,
            temperature=temperature))
        gc.collect()
