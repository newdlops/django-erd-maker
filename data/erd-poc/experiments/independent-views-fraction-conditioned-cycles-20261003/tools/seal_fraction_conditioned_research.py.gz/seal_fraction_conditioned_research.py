"""Archive amplitude learning, neutral trajectories and frozen-model transfers."""
from pathlib import Path
import ast
import gzip
import hashlib
import json
import re

root = Path('.tmp/visualcross-ml-150-750-20261003/fraction-conditioned-model1')
archive = Path('data/erd-poc/experiments/independent-views-fraction-conditioned-cycles-20261003')
assert not archive.exists()
sha = lambda data: hashlib.sha256(data).hexdigest()
digest = lambda path: sha(Path(path).read_bytes())
training = json.loads((root/'training1/training.json').read_text())
verification = json.loads((root/'records-verification.json').read_text())
followups = json.loads((root/'bounded-followups.json').read_text())
diagnosis = json.loads((root/'diagnosis.json').read_text())
assert verification['status'] == 'pass' and diagnosis['newNativeModelActions'] == 12522
assert diagnosis['strictImprovements'] == followups['strictImprovements'] == 0
assert all(item['replay']['frozenCheckpointActionReplay'] == 'pass' for item in followups['stages'])
assert training['newTrainingUpdatesExecuted'] == 8800 and training['selectedCheckpointUpdates'] == 6820
assert training['checkpointSha256'] == digest(root/'training1/model.npz')
stable = Path('data/erd-poc/candidates/captain-ml-independent-views.layout.json')
stable_sha = digest(stable)
assert stable_sha == 'da2317d3d9fe72181587f543843bfdde3cc7030ca328e93c4f627ae21ec356e7'
provenance = Path('data/erd-poc/candidates/captain-ml-independent-views.provenance.json')
before = provenance.read_text(); doc = json.loads(before)
assert doc['candidateSha256'] == stable_sha
(root/'promotion-provenance-before.json').write_text(before)
resources = {'policy': 'serialized numerical jobs; one math thread; nice +10; 128 MiB process-group sampled RSS guard',
    'hardCpuPercentQuotaEnforced': False, 'memoryLimitMiB': 128,
    'trainingObservedPeakMiB': 116.8, 'modelValidationObservedPeakMiB': 47.3,
    'samplingValidationObservedPeakMiB': 46.4, 'fourSequentialInferenceObservedPeakMiB': 65.3,
    'walkObservedPeakMiB': {'individual': 73.4, 'overview': 74.3},
    'verificationAttempt1ObservedPeakMiB': 153.1, 'verificationAttempt1ExitCode': 137,
    'verificationAttempt1GuardTerminated': True,
    'verificationAttempt2ObservedPeakMiB': 109.9, 'verificationAttempt2ExitCode': 1,
    'verificationAttempt2Failure': 'final JSON serialization of NumPy int64 after numerical assertions passed',
    'passedRecordsVerificationObservedPeakMiB': 117.7,
    'followupDriverAttempt1ObservedPeakMiB': 39.5, 'followupDriverAttempt1ExitCode': 1,
    'followupDriverAttempt1Failure': 'incorrect post-inference statistics key; completed individual inference retained',
    'passedFollowupDriverObservedPeakMiB': 77.8, 'completedIndividualFollowupInferenceRepeated': False,
    'analysisObservedPeakMiB': 0.2, 'analysisShortJobMayBeUndersampled': True,
    'availablePeaksRecordedFromToolOutputs': True, 'allNumericalStagesTerminal': True,
    'limitNotRaisedForVerification': True, 'noFreshDoctorRun': True}
(root/'resources.json').write_text(json.dumps(resources, indent=2)+'\n')
cli = {'cliVersion': '0.160.0', 'proxyVariablesPresent': False, 'baseUrlOverridePresent': False,
    'activeProvider': 'openai', 'standardTuiLogFilePresent': False,
    'retainedDiagnostic': '.tmp/cli-transport-all-threads-diagnostic.json',
    'retainedDiagnosticSha256': digest('.tmp/cli-transport-all-threads-diagnostic.json'),
    'retainedDisconnectEvents': 24, 'retainedDecodeEvents': 21,
    'retainedLatestEvent': '2026-10-03T02:44:59+09:00',
    'retainedLaterIncrementalDiagnostic': '.tmp/cli-transport-incremental-20261003.json',
    'retainedLaterIncrementalDiagnosticSha256': digest('.tmp/cli-transport-incremental-20261003.json'),
    'freshSqliteLogScanPerformed': False, 'actualAffectedTerminalIdentified': False,
    'rootCauseConfirmed': False, 'visualcrossResourceCausalityEstablished': False,
    'configurationOrAuthenticationChanged': False, 'userSessionRestarted': False,
    'officialDocsFetched': ['https://learn.chatgpt.com/docs/app-server#errors',
        'https://developers.openai.com/codex/cli/slash-commands'],
    'slashCommandsUrlReturnedDeveloperCommandsReference': True}
(root/'cli-followup.json').write_text(json.dumps(cli, indent=2)+'\n')

entries = {str(path): Path('run')/path.relative_to(root) for path in sorted(root.rglob('*')) if path.is_file()}
scripts = Path('scripts/erd-poc'); pending = ['fractional_cycle_model.py', 'train_fractional_cycle_model.py',
    'run_fraction_conditioned_policy.py', 'run_fraction_cycle_walk.py', 'learn_card_policy.py',
    'learned_branch_map.py', 'run_memory_bounded.py']; seen = set()
while pending:
    name = pending.pop()
    if name in seen:
        continue
    seen.add(name); path = scripts/name; entries[str(path)] = Path('code')/name
    for node in ast.walk(ast.parse(path.read_text())):
        modules = [node.module] if isinstance(node, ast.ImportFrom) else [item.name for item in node.names] if isinstance(node, ast.Import) else []
        for module in modules:
            if module and (scripts/(module+'.py')).is_file():
                pending.append(module+'.py')
pending = ['ml_joint_batch_environment.cpp', 'ml_component_environment.cpp', 'ml_card_environment.cpp']
seen = set()
while pending:
    name = pending.pop()
    if name in seen:
        continue
    seen.add(name); path = scripts/name; entries[str(path)] = Path('code')/name
    pending.extend(re.findall(r'#include "([^\"]+)"', path.read_text()))
for name in ['validate_fractional_cycle_model.py', 'validate_fraction_conditioned_sampling.py',
    'run_fraction_conditioned_stages.py', 'verify_fraction_conditioned_records.py',
    'run_fraction_walk_bounded_followups.py', 'analyze_fraction_conditioned_outcomes.py',
    'seal_fraction_conditioned_research.py']:
    path = Path('.tmp')/name; ast.parse(path.read_text()); entries[str(path)] = Path('tools')/name

dependencies = {training['parent'], training['parentDataset'], training['parentTrainingReport'],
    str(stable), 'data/erd-poc/candidates/captain-ml-independent-views.audit.json',
    '.tmp/cli-transport-all-threads-diagnostic.json', '.tmp/cli-transport-incremental-20261003.json'}
for source in training['sourceStages']:
    dependencies.update(str(Path(source['stage'])/name) for name in ['report.json', 'actions.jsonl'])
    if source['fraction'] == 1:
        dependencies.add(str(Path(source['stage'])/'observations.npz'))
for view in ['individual', 'overview']:
    report = json.loads((root/(view+'-sample1')/'report.json').read_text())
    dependencies.add(report['environment'])
    dependencies.update(str(Path(report['sourceDirectory'])/name) for name in report['sourceInputs'])
    for name in ['experiment.json', 'export.json']:
        path = Path(report['sourceDirectory'])/name
        if path.is_file():
            dependencies.add(str(path))
    reference = root.parent/'pair-anchor-sparse1/actual-validation'/(view+'-sparse.tsv')
    dependencies.update(str(reference)+suffix for suffix in ['', '.routes.tsv', '.individual', '.individual.routes.tsv'])
    lineage = json.loads((root/(view+'-walk-bounded1')/'lineage.json').read_text())
    dependencies.update([lineage['environment'], lineage['boundedCheckpoint']])
for source in dependencies:
    if source not in entries:
        entries[source] = Path('dependencies')/digest(source)/Path(source).name

# Reuse verified old bytes and identical current bytes instead of storing
# every copied static input and source-layout JSON again.
prior = {}; manifest_hashes = {}
for path in sorted(archive.parent.glob('independent-views-*-20261003/manifest.json')):
    manifest_hashes[str(path)] = digest(path); previous = json.loads(path.read_text())
    for entry in previous.get('files', []):
        stored = entry.get('archive', entry.get('stored'))
        if stored is not None:
            prior[entry['sha256']] = (path.parent/stored, entry['bytes'], str(path))
    for entry in previous.get('referencedFiles', []):
        prior.setdefault(entry['sha256'], (Path(entry['archive']), entry['bytes'], str(path)))
archive.mkdir(parents=True)
files = []; referenced = []; reused = {}; restored_hashes = set(); required_manifests = set()
for source, relative in sorted(entries.items()):
    data = Path(source).read_bytes(); source_sha = sha(data)
    if source_sha in prior:
        stored, size, manifest = prior[source_sha]
        assert size == len(data)
        if source_sha not in restored_hashes:
            packed = stored.read_bytes(); restored = gzip.decompress(packed) if packed[:2] == b'\x1f\x8b' else packed
            assert sha(restored) == source_sha and len(restored) == len(data)
            restored_hashes.add(source_sha)
        required_manifests.add(manifest)
        referenced.append({'source': source, 'archive': str(stored), 'sha256': source_sha,
            'bytes': len(data), 'prerequisiteManifest': manifest, 'restoreHashVerified': True})
        continue
    if source_sha in reused:
        stored, packed_bytes = reused[source_sha]
    else:
        stored = Path(str(relative)+'.gz'); dest = archive/stored; dest.parent.mkdir(parents=True, exist_ok=True)
        packed = gzip.compress(data, compresslevel=1, mtime=0); dest.write_bytes(packed)
        assert gzip.decompress(dest.read_bytes()) == data
        packed_bytes = len(packed); reused[source_sha] = (stored, packed_bytes)
    files.append({'source': source, 'archive': str(stored), 'sha256': source_sha,
        'bytes': len(data), 'compressedBytes': packed_bytes})
assert digest(stable) == stable_sha and provenance.read_text() == before
manifest = {'scope': 'fraction-conditioned learned cycle critic; predefined stochastic temperatures; directly conflicting neutral trajectories; bounded neural transfers on new geometry',
    'retainedCandidate': str(stable), 'retainedCandidateSha256': stable_sha, 'promotedCandidateChanged': False,
    'overviewVisual': 289, 'individualVisual': 1964, 'targetOverview': 150, 'targetIndividual': 750, 'targetMet': False,
    'newTrainingUpdates': 8800, 'selectedCheckpointUpdates': 6820, 'trainingRows': 5120,
    'novelMeasuredTrainingRows': 3072, 'fractionalTrainingRows': 1024, 'validationRows': 607,
    'validationFractionalRows': 200, 'actualImprovementTrainingExamples': 0,
    'newNativeModelActions': 12522, 'independentFractionConditionedActions': 4096,
    'cycleTrajectoryActions': 234, 'cycleTrajectoryAdmittedStates': 37,
    'boundedFollowupActions': 8192, 'boundedNeutralActions': 647, 'strictImprovements': 0,
    'nativeSearchOrCoordinateRepairCalls': 0, 'neutralGeometryPromoted': False,
    'nativeScoresRecomputedDuringRecordReplay': False, 'boundedNativeSaveGlobalAuditPassed': True,
    'browserVerified': False, 'newProductCandidates': 0, 'cliConfigurationChanged': False,
    'modelValidation': json.loads((root/'model-validation.json').read_text()),
    'samplingValidation': json.loads((root/'sampling-validation.json').read_text()),
    'recordsVerification': verification, 'boundedFollowups': followups, 'diagnosis': diagnosis, 'resources': resources,
    'cliFollowup': cli,
    'prerequisiteManifests': [{'path': name, 'sha256': manifest_hashes[name]} for name in sorted(required_manifests)],
    'referencedFiles': referenced, 'referencedLogicalBytes': sum(entry['bytes'] for entry in referenced),
    'allReferencedBytesRestoreHashVerified': True, 'newPhysicalCompressedFiles': len(reused),
    'newPhysicalCompressedBytes': sum(item[1] for item in reused.values()),
    'logicalFiles': len(files), 'logicalBytes': sum(entry['bytes'] for entry in files),
    'identicalCurrentFilesShareStoredBytes': True, 'allCompressedFilesRoundTripHashVerified': True, 'files': files}
path = archive/'manifest.json'; path.write_text(json.dumps(manifest, indent=2)+'\n'); manifest_sha = digest(path)
assert all(entry['archiveManifest'] != str(path) for entry in doc['subsequentResearchArchives'])
doc['subsequentResearchArchives'].append({'archiveManifest': str(path), 'archiveManifestSha256': manifest_sha,
    'promotedCandidateChanged': False, 'retainedCandidateSha256': stable_sha, 'overviewVisual': 289, 'individualVisual': 1964,
    'newNetworkTrainingUpdates': 8800, 'selectedCheckpointUpdates': 6820,
    'nativeModelActions': 12522, 'cycleTrajectoryAdmittedStates': 37, 'boundedNeutralActions': 647,
    'strictImprovements': 0, 'targetMet': False, 'browserVerified': False})
assert provenance.read_text() == before; provenance.write_text(json.dumps(doc, indent=2)+'\n')
print(json.dumps({'manifest': str(path), 'manifestSha256': manifest_sha, 'logicalFiles': len(files),
    'logicalBytes': manifest['logicalBytes'], 'newPhysicalCompressedFiles': len(reused),
    'newPhysicalCompressedBytes': manifest['newPhysicalCompressedBytes'], 'referencedFiles': len(referenced),
    'referencedLogicalBytes': manifest['referencedLogicalBytes'], 'allStoredAndReferencedBytesVerified': True,
    'promotedCandidateUnchanged': True}))
