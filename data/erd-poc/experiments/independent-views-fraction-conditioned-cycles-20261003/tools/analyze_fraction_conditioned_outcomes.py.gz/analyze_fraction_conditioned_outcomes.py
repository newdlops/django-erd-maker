"""Summarize actual model actions without new geometry or native queries."""
from collections import Counter
import hashlib
import json
from pathlib import Path

root = Path('.tmp/visualcross-ml-150-750-20261003/fraction-conditioned-model1')
training = json.loads((root/'training1/training.json').read_text())
verification = json.loads((root/'records-verification.json').read_text())
followups = json.loads((root/'bounded-followups.json').read_text())
assert verification['status'] == 'pass' and training['actualImprovementExamples'] == 0
native_actions = verification['independentModelActionsReplayed']+verification['walkModelActionsReplayed']
bounded = []
for item in followups['stages']:
    stage = Path(item['stage']); policy = json.loads((stage/'learned.tsv.policy.json').read_text())
    lineage = json.loads((stage/'lineage.json').read_text())
    sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
    assert lineage['cycleWalkReportSha256'] == sha(lineage['cycleWalkReport'])
    assert lineage['inferenceCodeSha256'] == sha('scripts/erd-poc/learn_card_policy.py')
    assert all(sha(Path(policy['sourceDirectory'])/name) == expected for name, expected in lineage['sourceInputs'].items())
    observations = {}
    for line in (stage/'learned.tsv.observations.jsonl').read_text().splitlines():
        row = json.loads(line)
        for node in row['nodes']:
            observations[row['round'], node['id']] = node['features']
    reasons = Counter(); accepted = conflicting_contexts = measured = 0
    for line in (stage/'learned.tsv.actions.jsonl').read_text().splitlines():
        row = json.loads(line); result = row['result']; reasons[result['reason']] += 1; measured += 1
        if result['accepted']:
            assert result['reason'] == 'accepted-neutral'
            accepted += 1
            feature = observations[row['round'], row['node']]
            indices = (4, 5) if item['view']=='overview' else (6, 7)
            conflicting_contexts += int(any(feature[i] > 0 for i in indices))
    assert measured == item['attempts'] == item['replay']['actions']
    assert accepted == item['acceptedActions'] == policy['final']['acceptedNeutralActions']
    assert policy['final']['hardConditions'] == policy['final']['individualHardConditions'] == 0
    assert policy['final']['spacing'] == policy['final']['overlap'] == 0
    assert conflicting_contexts == accepted
    bounded.append({'view': item['view'], 'attempts': measured, 'admittedNeutralActions': accepted,
        'acceptedContextsHaveReportedObjectiveConflicts': conflicting_contexts, 'reasons': dict(reasons),
        'nativeSaveGlobalAuditPassed': True, 'initialHardConditions': policy['final']['initialHardConditions'],
        'initialIndividualHardConditions': policy['final']['initialIndividualHardConditions'],
        'checkpointBranchMode': policy['checkpointBranchMode'], 'inferenceBranchMode': policy['branchMode'],
        'newGeometryModelTransfer': True, 'nativeMetricsIndependentlyRecomputedHere': False})
    native_actions += measured
assert native_actions == 12522
result = {'retainedOverview': 289, 'retainedIndividual': 1964, 'targetOverview': 150, 'targetIndividual': 750,
    'targetMet': False, 'newNativeModelActions': native_actions, 'strictImprovements': 0,
    'cycleTrajectoryAdmittedStates': verification['walkAdmittedStates'],
    'boundedAdmittedNeutralActions': sum(item['admittedNeutralActions'] for item in bounded),
    'actualImprovementTrainingExamples': training['actualImprovementExamples'],
    'independentMatchedTemperatureRepeatedWireCounts': verification['matchedTemperatureRepeatedWireCountsByView'],
    'walkDirectConflictOwners': {item['view']: item['distinctOwnersDirectlyConflictingWhenMoved']
        for item in verification['walkStages']},
    'walkRawMovedFieldCountsAllThreeCycleOwners': True,
    'individualWalkLastRoundNoActionsDueToTime': True,
    'cyclePolicyFrozenOnItsOwnNewStates': True, 'newStateOutcomesUsedForAdditionalTraining': False,
    'boundedFollowups': bounded, 'neutralStatesNotPromoted': True,
    'fraction4TenthsWasPreviouslyUnmeasuredTransfer': True,
    'lowerValidationLossEstablishesPredictionLearningNotVisualImprovement': True,
    'globalTargetImpossibleOrDecoderFloorProved': False,
    'nextResearch': 'collect positive model-generated coordinated actions on separate synthetic graphs and hold out complete graphs; current cycle training has no improving action examples; do not repeat these fixed temperatures or followups unchanged',
    'browserVerified': False, 'newProductCandidates': 0}
path = root/'diagnosis.json'; assert not path.exists()
path.write_text(json.dumps(result, indent=2)+'\n')
print(json.dumps({key: result[key] for key in ['newNativeModelActions', 'strictImprovements',
    'cycleTrajectoryAdmittedStates', 'boundedAdmittedNeutralActions', 'walkDirectConflictOwners']}))
