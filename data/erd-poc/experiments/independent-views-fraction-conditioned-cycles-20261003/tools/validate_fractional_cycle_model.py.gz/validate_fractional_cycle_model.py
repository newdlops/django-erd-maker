"""Finite differences and actual decoded-motion features, without native work."""
import sys
from pathlib import Path
sys.path.insert(0, str(Path('scripts/erd-poc').resolve()))
import json
import numpy as np
from learn_pair_policy import Ranker
from directed_cycle_model import CycleCritic, KEYS, load as load_parent, cycle_features
from fractional_cycle_model import FractionCritic, action_features
from run_anchor_pair_walk import WalkDecoder
from run_fractional_cycle_transfer import fractional_action

root = Path('.tmp/visualcross-ml-150-750-20261003/fraction-conditioned-model1')
root.mkdir(exist_ok=False)
rng = np.random.default_rng(84043)
parent = CycleCritic(Ranker(43, 5, 6), head_hidden=4)
parent.p['oh'] = rng.normal(0, .2, 4)
model = FractionCritic(parent)
base = rng.normal(size=(9, 3, 5)); extras = rng.normal(size=(9, 3, 5)); x = np.concatenate([base, extras], axis=2)
assert np.max(abs(model.forward(x)[0]-parent.forward(base)[0])) < 1e-12
model.p['w1'][-5:] = rng.normal(0, .05, model.p['w1'][-5:].shape)
y = model.forward(x)[0]+rng.uniform(-.8, .8, len(x))
_, gradients = model.loss(x, y, True)
checked = 0; maximum = 0
for key in KEYS:
    indices = set(map(int, rng.choice(model.p[key].size, min(6, model.p[key].size), replace=False)))
    if key == 'w1':
        indices |= {int(np.ravel_multi_index((row, 0), model.p[key].shape)) for row in range(5, 10)}
    for flat in sorted(indices):
        index = np.unravel_index(flat, model.p[key].shape); value = model.p[key][index]
        model.p[key][index] = value+1e-5; high = model.loss(x, y)
        model.p[key][index] = value-1e-5; low = model.loss(x, y); model.p[key][index] = value
        error = abs((high-low)/2e-5-gradients[key][index]); assert error < 2e-7, (key, index, error)
        maximum = max(maximum, error); checked += 1
rotated = np.roll(x, 1, axis=1)
assert np.max(abs(model.forward(x)[0]-model.forward(rotated)[0])) < 1e-12
_, other = model.loss(rotated, y, True)
assert all(np.max(abs(gradients[key]-other[key])) < 1e-12 for key in KEYS)

previous = root.parent/'directed-cycle-model1'
parent, _ = load_parent(previous/'training1/model.npz'); model = FractionCritic(parent)
fixtures = []; warm_error = 0; decoded_actions = 0
for view in ['individual', 'overview']:
    stage = previous/(view+'-directed1'); report = json.loads((stage/'report.json').read_text())
    decoder = WalkDecoder(Path(report['sourceDirectory']))
    with np.load(stage/'observations.npz', allow_pickle=False) as saved:
        nodes = saved['node_features'].copy(); cycles = saved['cycles'][:16].copy()
    core, _ = cycle_features(nodes, decoder, cycles, view == 'overview')
    scales = 512*np.expm1(nodes[:, 62])
    for fraction in [.001, .005, .02, .1, 1.]:
        features, _ = action_features(nodes, decoder, cycles, np.full(len(cycles), fraction), view == 'overview')
        assert np.array_equal(features[:, :, :136], core)
        assert (features[:, :, 136] == fraction).all()
        warm_error = max(warm_error, float(np.max(abs(model.forward(features)[0]-parent.forward(core)[0]))))
        for i, cycle in enumerate(cycles):
            actual = fractional_action(decoder, cycle, fraction)[:len(decoder.positions)]
            motion = np.clip(actual[cycle]/scales[cycle, None], -8, 8)
            assert np.array_equal(features[i, :, 137:139], motion)
            assert np.array_equal(features[i, :, 139:141], np.roll(motion, -1, axis=0))
            decoded_actions += 1
        rotated, _ = action_features(nodes, decoder, np.roll(cycles, 1, axis=1),
            np.full(len(cycles), fraction), view == 'overview')
        assert np.array_equal(rotated, np.roll(features, 1, axis=1))
    fixtures.append({'view': view, 'cycleDirections': len(cycles), 'fractions': 5,
        'actionMotionFeaturesMatchDecoder': True, 'rotatedFeaturesMatchExactly': True})
assert warm_error < 1e-10
result = {'status': 'pass', 'finiteGradientComparisons': checked, 'maximumGradientError': maximum,
    'allTenParameterGroupsExercised': True, 'allFiveAdditionalInputRowsExercised': True,
    'cyclicRotationScoreAndGradientInvariant': True, 'warmPredictionMaxDifference': warm_error,
    'decodedFractionalActionsChecked': decoded_actions, 'views': fixtures, 'nativeGeometryNotInvoked': True}
(root/'model-validation.json').write_text(json.dumps(result, indent=2)+'\n')
print(json.dumps({key: result[key] for key in ['status', 'finiteGradientComparisons',
    'maximumGradientError', 'warmPredictionMaxDifference', 'decodedFractionalActionsChecked']}))
