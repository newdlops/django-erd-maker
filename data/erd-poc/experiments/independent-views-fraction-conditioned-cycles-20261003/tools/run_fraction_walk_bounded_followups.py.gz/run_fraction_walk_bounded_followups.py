"""Frozen learned translations on new, model-generated cycle trajectories."""
import sys
from pathlib import Path
sys.path.insert(0, str(Path('scripts/erd-poc').resolve()))
import gc
import json
import shutil
from contextlib import redirect_stdout
from io import StringIO
from types import SimpleNamespace
from learned_global_replay import INPUT_FILES
from learned_branch_map import prepare_branch_map
from learn_card_policy import digest, infer, replay

root = Path('.tmp/visualcross-ml-150-750-20261003/fraction-conditioned-model1')
environment = root.parent/'component-environment-v26'
assert digest(environment) == 'ce208890d9ba6213fe266cbd3cee0b4e7c7277f22e50c9bd01fd6cc225f0a96a'
summary = []
for view, checkpoint_sha, visual in [
    ('individual', '52dfe940a7498f12cbfa016232044ce7df4bd4ade31a57abaef3ede80571aab2', 1964),
    ('overview', '39a135d12be3e7c76d6005b87df65226464307232782920448db1ad68c417992', 289)]:
    walk_path = root/(view+'-walk1')/'report.json'
    walk = json.loads(walk_path.read_text())
    source = Path(walk['finalSourceDirectory'])
    checkpoint = root.parent/'bounded-policy-training1'/(view+'.npz')
    assert digest(checkpoint) == checkpoint_sha
    stage = root/(view+'-walk-bounded1')
    directory = stage/'input'
    completed = (stage/'learned.tsv.policy.json').is_file()
    if not completed:
        stage.mkdir(exist_ok=False); directory.mkdir()
        for name in INPUT_FILES:
            shutil.copyfile(source/name, directory/name)
    assert all(digest(source/name) == digest(directory/name) for name in INPUT_FILES)
    lineage = {'cycleWalkReport': str(walk_path), 'cycleWalkReportSha256': digest(walk_path),
        'cycleWalkCheckpoint': walk['checkpoint'], 'finalCycleSource': str(source),
        'sourceInputs': {name: digest(source/name) for name in INPUT_FILES},
        'branchSourceIdentityType': 'cycle-walk-report-sha256',
        'layoutJsonIdentityClaimed': False, 'positionsCopiedWithoutGeometryChanges': True,
        'environment': str(environment), 'environmentSha256': digest(environment),
        'boundedCheckpoint': str(checkpoint), 'boundedCheckpointSha256': checkpoint_sha,
        'inferenceCodeSha256': digest('scripts/erd-poc/learn_card_policy.py'),
        'branchCodeSha256': digest('scripts/erd-poc/learned_branch_map.py'),
        'trainingExecuted': False, 'neutralStatesAreExperimental': True}
    if completed:
        assert json.loads((stage/'lineage.json').read_text()) == lineage
    else:
        (stage/'lineage.json').write_text(json.dumps(lineage, indent=2)+'\n')
        prepare_branch_map(directory, digest(walk_path), mode='cut')
    output = stage/'learned.tsv'
    args = SimpleNamespace(checkpoint=checkpoint, environment=environment, directory=directory,
        out=output, synthetic_seed=None, untrained=False, branch_moves=True, branch_mode='cut',
        overview_only=view=='overview', allow_neutral=True, area_exploration=False,
        exploration_limit=0, temperature=2., canonical_start=False, seed=85061,
        budget=4096, observations=384, rounds=16, samples=12, seconds=20.)
    if not completed:
        with (stage/'inference.log').open('x') as log, redirect_stdout(log):
            infer(args)
    policy = json.loads(Path(str(output)+'.policy.json').read_text())
    key = 'visual' if view=='overview' else 'individualVisual'
    assert policy['initial'][key] == visual and policy['final'][key] <= visual
    assert policy['checkpointSha256'] == checkpoint_sha and policy['seed'] == args.seed
    assert policy['final']['hardConditions'] == policy['final']['individualHardConditions'] == 0
    assert policy['final']['overlap'] == policy['final']['spacing'] == 0
    captured = StringIO()
    with redirect_stdout(captured):
        replay(SimpleNamespace(checkpoint=checkpoint, out=output))
    verification = json.loads(captured.getvalue())
    (stage/'replay.json').write_text(json.dumps(verification, indent=2)+'\n')
    record = {'view': view, 'stage': str(stage), 'initialVisual': visual,
        'finalVisual': policy['final'][key], 'attempts': policy['final']['policyActionsEvaluated'],
        'acceptedActions': policy['final']['acceptedActions'], 'hard': policy['final']['hardConditions'],
        'strictVisualImprovement': policy['final'][key] < visual, 'replay': verification,
        'cycleSourceInputsByteIdentical': True, 'sourceChangedFromOriginalBoundedInference': True,
        'trainingExecuted': False, 'productAudited': False, 'browserVerified': False}
    (stage/'report.json').write_text(json.dumps(record, indent=2)+'\n')
    summary.append(record)
    print(json.dumps({k: record[k] for k in ['view', 'initialVisual', 'finalVisual', 'attempts', 'acceptedActions']}), flush=True)
    gc.collect()
path = root/'bounded-followups.json'; assert not path.exists()
path.write_text(json.dumps({'stages': summary, 'strictImprovements': sum(r['strictVisualImprovement'] for r in summary),
    'nativeScoresRecomputed': False, 'frozenSyntheticModelTransfer': True}, indent=2)+'\n')
