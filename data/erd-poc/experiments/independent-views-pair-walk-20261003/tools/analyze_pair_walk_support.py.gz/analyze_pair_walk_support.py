from pathlib import Path
import json
import numpy as np
root=Path('.tmp/visualcross-ml-150-750-20261003/pair-neutral-walk1')
views=[]
for view in ['individual','overview']:
    stage=root/(view+'-walk1');report=json.loads((stage/'report.json').read_text())
    actions=[json.loads(line) for line in (stage/'actions.jsonl').read_text().splitlines()]
    pressure_attempts=pressure_admissions=0;admissions=[]
    for observation in report['rounds']:
        with np.load(stage/observation['file']) as data:features=data['node_features'].copy()
        for row in actions:
            if row['round']!=observation['round'] or 'result' not in row:continue
            nodes=[row['source'],row['target']]
            touched=bool(np.any(features[nodes,4:6]>0));pressure_attempts+=touched
            if row['walkAdmitted']:
                pressure_admissions+=touched
                admissions.append({'round':row['round'],'pair':nodes,'touchesDirectObjectiveConflicts':touched,
                    'incidentCounts':np.rint(np.expm1(features[nodes,3])).astype(int).tolist()})
    stats=json.loads((root/(view+'-after-walk-bounded1')/'learned.tsv.stats.json').read_text())
    views.append({'view':view,'walkAttempts':report['attempts'],'walkAdmissions':report['admittedWalkStates'],
        'attemptsTouchingDirectObjectiveConflicts':pressure_attempts,'admissionsTouchingDirectObjectiveConflicts':pressure_admissions,
        'admissions':admissions,'followupPolicyActions':stats['policyActionsEvaluated'],
        'followupAcceptedActions':stats['acceptedActions'],'followupAcceptedNeutralActions':stats['acceptedNeutralActions'],
        'finalVisual':stats['visual'],'finalIndividualVisual':stats['individualVisual']})
report={'views':views,'pairRankerNodeFeatureSlices':[[0,24],[56,60]],
    'excludedExplicitConflictGeometrySlice':[32,56],
    'excludedGeometryDescription':'four native conflict-line observations, each with two endpoint coordinates, hit flag and crossing count',
    'interpretation':'The current pair network cannot directly consume these conflict-segment features. This is a candidate representation limitation, not a proven cause of the plateau.',
    'indirectEndpointPoolingEffectsNotIncludedInPressureFlag':True,'positionsProposed':False}
(root/'support-analysis.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report))
