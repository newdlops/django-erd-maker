import sys,json
from pathlib import Path
sys.path.insert(0,str(Path('scripts/erd-poc').resolve()))
import numpy as np
from run_anchor_pair_walk import WalkDecoder,verify_saved
from run_anchor_pair_policy import Native,wire,pair_features,digest

base=Path('.tmp/visualcross-ml-150-750-20261003');root=base/'pair-neutral-walk1'
out=root/'validation';out.mkdir(exist_ok=False);reports=[]
for view in ['individual','overview']:
    directory=base/(view+'-slot-cached1');decoder=WalkDecoder(directory);n=len(decoder.positions)
    identity=np.arange(n,dtype=np.int32);zero=decoder.decode(identity)
    assert not np.count_nonzero(zero)
    vocab=decoder.eligible_pairs(98339,4096)
    assert np.array_equal(vocab,decoder.eligible_pairs(98339,4096))
    assert not decoder.irrelevant_isolate[vocab].all(1).any()
    old_stage=base/'pair-anchor-sparse1'/(view+'-adapted1');old_report=json.loads((old_stage/'report.json').read_text())
    rows=[json.loads(line) for line in (old_stage/'actions.jsonl').read_text().splitlines()]
    neutral=[row for row in rows if row['result']['legal'] and row['result']['visual']==old_report['initialVisual']]
    row=next(row for row in neutral if not decoder.irrelevant_isolate[[row['source'],row['target']]].all())
    permutation=identity.copy();a,b=row['source'],row['target'];permutation[a],permutation[b]=permutation[b],permutation[a]
    action=decoder.decode(permutation);assert np.array_equal(action,decoder.action(a,b))
    reverse=permutation.copy();reverse[a],reverse[b]=reverse[b],reverse[a];assert np.array_equal(decoder.decode(reverse),zero)
    isolated=next(row for row in neutral if decoder.irrelevant_isolate[[row['source'],row['target']]].all() and not ({row['source'],row['target']}&{a,b}))
    composite=permutation.copy();c,d=isolated['source'],isolated['target'];composite[c],composite[d]=composite[d],composite[c]
    actions=[zero,action,decoder.decode(composite)]
    frame=zero.copy();frame[0]=[1e6,0];actions.append(frame)
    old=Native(base/'pair-anchor-sparse1'/'environment',directory,out/(view+'-reference.tsv'),view=='overview',True)
    try:reference=[old.request(wire(action,'MEASURE')) for action in actions]
    finally:old.close()
    stage=out/view;stage.mkdir()
    native=Native(root/'environment',directory,stage/'learned.tsv',view=='overview',True)
    try:
        assert native.initial==old.initial
        observations=[]
        for index,action in enumerate(actions):
            result=native.request(wire(action,'MEASURE'));assert result==reference[index]
            observed=native.request(wire(action,'OBS'))
            assert observed['observed']==result['legal'] and observed['visual']==result['visual'] and observed['individualVisual']==result['individualVisual']
            if result['legal']:
                assert len(observed['nodes'])==n
                if index==0:assert observed['nodes']==native.initial['nodes']
                perm=[identity,permutation,composite][index]
                features=np.array([row['features'] for row in observed['nodes']])
                _,error=pair_features(features,decoder.feature_view(perm),vocab,view=='overview')
                observations.append({'index':index,'observed':True,'visual':observed['visual'],'scaleFeatureMaxError':error})
            else:assert 'nodes' not in observed
        after=native.request(wire(zero,'OBS'));assert after['nodes']==native.initial['nodes']
        assert native.request('SAVE')['saved']
    finally:native.close()
    stats=json.loads((stage/'learned.tsv.stats.json').read_text());assert stats['policyActionsEvaluated']==stats['acceptedActions']==0
    verify_saved(directory,stage,decoder,None)
    report={'view':view,'exactReferenceMeasurements':len(actions),'observations':observations,'invalidObservationRejected':True,
        'sourceObservationsUnchanged':True,'saveUnchanged':True,'actionCountersUnchanged':True,
        'eligibleVocabulary':len(vocab),'maskedIsolatePairs':4096-len(vocab),'recordedModelFixturePair':[a,b]}
    reports.append(report);print(json.dumps(report),flush=True)
report={'status':'pass','views':reports,'environmentSha256':digest(root/'environment'),
    'walkSourceSha256':digest('scripts/erd-poc/run_anchor_pair_walk.py')}
(out/'report.json').write_text(json.dumps(report,indent=2)+'\n')
