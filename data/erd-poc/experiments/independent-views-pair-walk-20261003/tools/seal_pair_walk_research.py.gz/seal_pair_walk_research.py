"""Exclusive byte-preserving research archive; never rerun after success."""
from pathlib import Path
import ast,gzip,hashlib,json
root=Path('.tmp/visualcross-ml-150-750-20261003/pair-neutral-walk1')
archive=Path('data/erd-poc/experiments/independent-views-pair-walk-20261003')
assert not archive.exists();archive.mkdir(parents=True)
sha=lambda data:hashlib.sha256(data).hexdigest()
resources={'policy':'serialized numerical jobs; one math thread; nice +10; 256 MiB process-group RSS guard; no hard CPU-percent quota',
    'compilePeakMiB':205.9,'nativeSelfTest':{'fullGeometryComparisons':576,'sparseComparisons':1764,'peakMiB':3.4},
    'observationValidationPeakMiB':68.2,'supportAnalysisPeakMiB':32.3,
    'stagesPeakMiB':{'individual-walk1':75.3,'overview-walk1':69.7,'individual-neutral-snapshot1':174.1,
        'overview-neutral-snapshot1':191.9,'individual-after-walk-bounded1':134.4,'overview-after-walk-bounded1':184.3},
    'recordedFromSuccessfulToolOutputs':True}
(root/'resources.json').write_text(json.dumps(resources,indent=2)+'\n')
entries={str(p):Path('run')/p.relative_to(root) for p in sorted(root.rglob('*')) if p.is_file()}
scripts=Path('scripts/erd-poc');pending=['run_anchor_pair_walk.py','export_anchor_pair_walk.py',
    'run_individual_policy_experiment.py','run_learned_leaf_layout.py'];seen=set()
while pending:
    name=pending.pop()
    if name in seen:continue
    seen.add(name);p=scripts/name;entries[str(p)]=Path('code')/name
    for node in ast.walk(ast.parse(p.read_text())):
        modules=[node.module] if isinstance(node,ast.ImportFrom) else [n.name for n in node.names] if isinstance(node,ast.Import) else []
        for module in modules:
            if module and (scripts/(module+'.py')).is_file():pending.append(module+'.py')
for name in ['run_memory_bounded.py','apply_learned_components.cjs','audit_individual_policy_experiment.cjs',
             'audit_leaf_card_connections.cjs','export_learned_components.cjs','probe_overview_boundary.cjs']:
    entries[str(scripts/name)]=Path('code')/name
for name in ['validate_anchor_pair_walk.py','analyze_pair_walk_support.py','seal_pair_walk_research.py']:
    entries[str(Path('.tmp')/name)]=Path('tools')/name
base=root.parent
for path in [base/'pair-anchor-sparse1/anchor-outcomes-v1.npz',base/'bounded-policy-training1/individual.npz',
             base/'bounded-policy-training1/overview.npz',base/'component-environment-v27-o0']:
    entries[str(path)]=Path('pretrained')/path.parent.name/path.name
for view in ['individual','overview']:
    directory=base/(view+'-slot-cached1')
    for name in [prefix+name for prefix in ['', 'individual.'] for name in ['nodes.tsv','edges.tsv','positions.tsv','routes.tsv']]+['components.tsv','groups.tsv','experiment.json']:
        entries[str(directory/name)]=Path('fixtures')/view/name
    candidate=base/(view+'-bounded-trained2')/('candidate.individual.layout.json' if view=='individual' else 'candidate.layout.json')
    entries[str(candidate)]=Path('fixtures')/view/candidate.name
files=[]
for source,relative in sorted(entries.items()):
    data=Path(source).read_bytes();dest=archive/(str(relative)+'.gz');dest.parent.mkdir(parents=True,exist_ok=True)
    packed=gzip.compress(data,compresslevel=1,mtime=0);dest.write_bytes(packed);assert gzip.decompress(dest.read_bytes())==data
    files.append({'source':source,'archive':str(dest.relative_to(archive)),'sha256':sha(data),'bytes':len(data),'compressedBytes':len(packed)})
stable=Path('data/erd-poc/candidates/captain-ml-independent-views.layout.json');stable_sha=sha(stable.read_bytes())
assert stable_sha=='da2317d3d9fe72181587f543843bfdde3cc7030ca328e93c4f627ae21ec356e7'
walks=[json.loads((root/(view+'-walk1')/'report.json').read_text()) for view in ['individual','overview']]
stats=[json.loads((root/(view+'-after-walk-bounded1')/'learned.tsv.stats.json').read_text()) for view in ['individual','overview']]
assert all(s['visual']==value and s['acceptedActions']==s['acceptedNeutralActions'] for s,value in zip(stats,[1964,289]))
manifest={'scope':'learned neutral pair trajectories followed by learned bounded branch translations',
    'retainedCandidate':str(stable),'retainedCandidateSha256':stable_sha,'promotedCandidateChanged':False,
    'overviewVisual':289,'individualVisual':1964,'targetOverview':150,'targetIndividual':750,'targetMet':False,
    'browserVerified':False,'newTrainingUpdates':0,'walkPolicyActions':sum(w['attempts'] for w in walks),
    'admittedWalkStates':sum(w['admittedWalkStates'] for w in walks),'strictWalkImprovements':0,
    'followupPolicyActions':sum(s['policyActionsEvaluated'] for s in stats),
    'acceptedFollowupNeutralActions':sum(s['acceptedNeutralActions'] for s in stats),'strictFollowupImprovements':0,
    'snapshotReDecodes':2,'snapshotAdmissionAllowance':1,'actualSnapshotSourceObjectiveRegression':0,
    'newExperimentalCandidates':4,'completeProductAuditsPassed':4,'causalAblationVerified':False,
    'globalTargetImpossibleProved':False,'resources':resources,
    'observationValidation':json.loads((root/'validation/report.json').read_text()),
    'supportAnalysis':json.loads((root/'support-analysis.json').read_text()),
    'logicalFiles':len(files),'logicalBytes':sum(f['bytes'] for f in files),
    'allCompressedFilesRoundTripHashVerified':True,'files':files}
path=archive/'manifest.json';path.write_text(json.dumps(manifest,indent=2)+'\n');manifest_sha=sha(path.read_bytes())
provenance=Path('data/erd-poc/candidates/captain-ml-independent-views.provenance.json');before=provenance.read_text();p=json.loads(before)
assert all(r['archiveManifest']!=str(path) for r in p['subsequentResearchArchives'])
p['subsequentResearchArchives'].append({'archiveManifest':str(path),'archiveManifestSha256':manifest_sha,
    'promotedCandidateChanged':False,'retainedCandidateSha256':stable_sha,'overviewVisual':289,'individualVisual':1964,
    'newNetworkTrainingUpdates':0,'walkModelProposals':manifest['walkPolicyActions'],'admittedWalkStates':20,
    'followupModelProposals':manifest['followupPolicyActions'],'acceptedFollowupNeutralActions':manifest['acceptedFollowupNeutralActions'],
    'strictImprovements':0,'targetMet':False,'browserVerified':False})
assert provenance.read_text()==before;provenance.write_text(json.dumps(p,indent=2)+'\n')
print(json.dumps({'manifest':str(path),'manifestSha256':manifest_sha,'files':len(files),'logicalBytes':manifest['logicalBytes'],
    'roundTripHashVerified':True,'promotedCandidateUnchanged':True}))
